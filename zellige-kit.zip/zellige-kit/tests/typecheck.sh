#!/usr/bin/env bash
# Type-check the Kotlin payload against a real android.jar + small stubs for the AndroidX/Material classes we use.
#   ANDROID_JAR=/path/android.jar KOTLINC=/path/kotlinc bash tests/typecheck.sh
set -euo pipefail
KIT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
AJ="${ANDROID_JAR:?set ANDROID_JAR to an android-XX/android.jar}"
KC="${KOTLINC:-kotlinc}"
T="$(mktemp -d)"; trap 'rm -rf "$T"' EXIT
mkdir -p "$T/stubs"
find "$KIT/tests/stubs" -name '*.java' > "$T/j.txt"
javac -nowarn -cp "$AJ" -d "$T/stubs" @"$T/j.txt" 2>&1 | grep -v '^Picked up\|^Note:' || true
"$KC" -no-stdlib=false -jvm-target 17 -Xjsr305=ignore -cp "$AJ:$T/stubs" -d "$T/out" "$KIT"/payload/kotlin/*.kt 2>&1 \
  | grep -v '^Picked up' | tee "$T/log.txt" || true
if grep -q 'error:' "$T/log.txt"; then echo "❌ type errors"; exit 1; fi
echo "✔ Kotlin payload type-checks (framework = real android.jar; AndroidX/Material = stubs)"
