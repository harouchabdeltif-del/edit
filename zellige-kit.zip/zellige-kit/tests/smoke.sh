#!/usr/bin/env bash
# Smoke test against a real AndroidIDE checkout (never modifies it: works on copies).
#   bash tests/smoke.sh /path/to/AndroidIDE
set -euo pipefail
SRC="${1:?usage: smoke.sh /path/to/AndroidIDE}"
KIT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
T="$(mktemp -d)"; trap 'rm -rf "$T"' EXIT
fail() { echo "❌ FAIL: $*"; exit 1; }
ok()   { echo "✔ $*"; }

cp -a "$SRC" "$T/pristine"; rm -rf "$T/pristine/.git"
cp -a "$T/pristine" "$T/work"

# 1 ---- inject + rebrand
bash "$KIT/zellige.sh" "$T/work" >"$T/run1.log" 2>&1 || { cat "$T/run1.log"; fail "first run"; }
APP="$T/work/core/app"; [ -d "$APP" ] || APP="$T/work/app"
[ -f "$APP/src/main/java/com/itsaky/androidide/ai/AiPlugin.kt" ] || fail "AiPlugin.kt missing"
grep -q 'AiPlugin.install' "$APP/src/main/java/com/itsaky/androidide/app/IDEApplication.kt" || fail "Application hook"
grep -q 'name="app_name" translatable="false">Zellige<' "$T/work/core/resources/src/main/res/values/strings.xml" || fail "app_name"
ok "inject + rebrand applied"

# 1b ---- new pieces: live-apply engine, home screen, icons, theme
KT="$APP/src/main/java/com/itsaky/androidide/ai"
for f in AiLive.kt AiDiff.kt ZelligeHome.kt Console.kt ConsoleLogic.kt TerminalChrome.kt EditorShell.kt SidebarChrome.kt SettingsChrome.kt NewProjectChrome.kt GitLite.kt DiscoverLogic.kt DiscoverPage.kt GitHubClient.kt; do [ -f "$KT/$f" ] || fail "$f missing"; done
for ic in search menu play stop undo redo more close folder layers check file branch arrow_forward arrow_back explore download star key doc_text; do
  [ -f "$APP/src/main/res/drawable/zl_ic_$ic.xml" ] || fail "zl_ic_$ic.xml missing"
done
grep -q 'name="editor_container_corners">0dp<' "$APP/src/main/res/values/dimens.xml" || fail "editor corners not squared (design C)"
RES="$T/work/core/resources/src/main/res/values"
grep -q '_blue_wave_dark_colorBackground">#ff0a0c10' "$RES/theme_blue_wave.xml" || fail "dark palette not applied"
grep -q 'shapeAppearanceMediumComponent' "$RES/styles.xml" || fail "shape styles missing"
[ -f "$RES/zellige_theme.xml" ] || fail "zellige_theme.xml missing"
if grep -n 'fontFamily' "$RES/styles.xml" | grep -q josefin; then fail "font not switched"; fi
# every XML we touched or created must be well-formed (aapt2 would reject it otherwise)
python3 -I - "$T/work" "$T/pristine" <<'PY' || fail "malformed XML"
import sys, subprocess, xml.dom.minidom as M
from pathlib import Path
work, pris = Path(sys.argv[1]), Path(sys.argv[2])
bad = 0
for f in work.rglob("*.xml"):
    if ".zellige" in f.parts or "build" in f.parts:
        continue
    rel = f.relative_to(work)
    old = pris / rel
    if old.exists() and old.read_bytes() == f.read_bytes():
        continue
    try:
        M.parse(str(f))
    except Exception as e:
        print("  malformed:", rel, e); bad += 1
sys.exit(1 if bad else 0)
PY
ok "live-apply, home screen, icons and theme present; touched XML is well-formed"
# the home screen is an overlay: the original screen sources must stay untouched
for f in core/app/src/main/res/layout/fragment_main.xml core/app/src/main/res/layout-land/fragment_main.xml \
         core/app/src/main/java/com/itsaky/androidide/fragments/MainFragment.kt; do
  cmp -s "$T/pristine/$f" "$T/work/$f" || fail "$f was modified (home must be an overlay)"
done
ok "MainFragment / fragment_main.xml untouched (home is an overlay)"

# 2 ---- line endings: the hook must add exactly 1 line and keep CRLF
A=core/app/src/main/java/com/itsaky/androidide/app/IDEApplication.kt
d=$(diff "$T/pristine/$A" "$T/work/$A" | grep -c '^[<>]' || true)
[ "$d" = "1" ] || fail "IDEApplication diff touches $d lines (expected 1) - newline handling"
ok "Application.kt: only the hook line changed (CRLF preserved)"

# 3 ---- URLs / licence headers / identifiers untouched
if grep -rn --include=*.xml -E 'Zellige(Official|\.git)|/Zellige|github\.com[^ ]*Zellige' "$T/work/core/resources/src/main/res" | grep -q .; then
  fail "a URL or identifier was rewritten"
fi
if grep -rl "applicationId\|com.zellige" "$T/work/core/app/build.gradle.kts" >/dev/null 2>&1 \
   && grep -q 'com\.zellige' "$T/work/core/app/build.gradle.kts"; then fail "package name must not change"; fi
grep -q 'TERMUX_PACKAGE_NAME = "com.itsaky.androidide"' "$T/work/termux/shared/src/main/java/com/termux/shared/termux/TermuxConstants.java" || fail "package constant changed"
ok "URLs, licence comments and package name untouched"

# 4 ---- idempotent: a second run changes nothing, state files included
cp -a "$T/work" "$T/after1"
bash "$KIT/zellige.sh" "$T/work" >"$T/run2.log" 2>&1 || { cat "$T/run2.log"; fail "second run"; }
diff -r "$T/after1" "$T/work" >/dev/null || { diff -rq "$T/after1" "$T/work" | head; fail "second run changed files"; }
ok "idempotent (second run is a no-op)"

# 5 ---- undo returns the exact original tree
bash "$KIT/zellige.sh" "$T/work" undo >"$T/undo.log" 2>&1 || { cat "$T/undo.log"; fail "undo"; }
diff -r "$T/pristine" "$T/work" >/dev/null || { diff -rq "$T/pristine" "$T/work" | head; fail "undo is not byte-exact"; }
ok "undo restores the original tree byte-for-byte"

# 6 ---- legacy: a tree already patched by the old inject-ai.sh can be adopted and undone
if [ -f "${LEGACY_SCRIPT:-}" ]; then
  cp -a "$T/pristine" "$T/legacy"
  bash "$LEGACY_SCRIPT" "$T/legacy" >/dev/null 2>&1 || true
  bash "$KIT/zellige.sh" "$T/legacy" >/dev/null 2>&1 || fail "adopt legacy"
  bash "$KIT/zellige.sh" "$T/legacy" undo >/dev/null 2>&1 || fail "undo legacy"
  # the old script saved its backups through Python text mode, which dropped CRs: ignore them here
  diff -r --strip-trailing-cr "$T/pristine" "$T/legacy" >/dev/null || { diff -rq --strip-trailing-cr "$T/pristine" "$T/legacy" | head; fail "legacy undo not exact"; }
  ok "tree patched by old inject-ai.sh: adopted and undone (modulo CR the old script had already dropped)"
fi
echo "ALL PASSED"
