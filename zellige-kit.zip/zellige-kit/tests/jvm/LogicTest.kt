import com.itsaky.androidide.ai.ConsoleLogic
import com.itsaky.androidide.ai.GitLite
import java.io.File
import java.nio.file.Files

/** اختبارات المنطق الصافي للواجهات الجديدة (C5/C6/C9) على JVM، ومقارنة GitLite مع git الحقيقي. */
object LogicTest {
    private var checks = 0
    private fun eq(what: String, got: Any?, want: Any?) {
        checks++
        if (got != want) { println("❌ $what\n   got : $got\n   want: $want"); throw AssertionError(what) }
    }
    private fun yes(what: String, c: Boolean) = eq(what, c, true)

    private fun sh(dir: File, vararg cmd: String): String {
        val p = ProcessBuilder(*cmd).directory(dir).redirectErrorStream(true).start()
        val out = p.inputStream.readBytes().toString(Charsets.UTF_8)
        check(p.waitFor() == 0) { "${cmd.joinToString(" ")} failed:\n$out" }
        return out
    }
    private fun git(dir: File, vararg a: String) =
        sh(dir, "git", "-c", "user.name=t", "-c", "user.email=t@t", "-c", "core.autocrlf=false", *a)

    private fun write(f: File, s: String) { f.parentFile.mkdirs(); f.writeText(s) }

    // ---------------------------------------------------------------- terminal: build failure detection
    private fun terminal() {
        eq("no failure", ConsoleLogic.detect("> Task :app:compileKotlin\nBUILD SUCCESSFUL in 3s\n"), null)
        eq("empty", ConsoleLogic.detect(""), null)
        val failed = """
            > Task :app:compileDebugKotlin FAILED
            e: file:///sdcard/p/app/src/main/java/Main.kt:12:5 Unresolved reference: foo
            e: file:///sdcard/p/app/src/main/java/Main.kt:20:1 Type mismatch
            /sdcard/p/app/src/main/java/A.java:10: error: cannot find symbol
            warning: something harmless
            FAILURE: Build failed with an exception.
            BUILD FAILED in 4s
        """.trimIndent()
        val f = ConsoleLogic.detect(failed)!!
        eq("3 errors", f.errors.size, 3)
        yes("kotlin error kept", f.errors.any { it.startsWith("e: file:///sdcard/p/app/src/main/java/Main.kt:12:5") })
        yes("java error kept", f.errors.any { it.contains("A.java:10: error: cannot find symbol") })
        yes("warning ignored", f.errors.none { it.contains("harmless") })
        yes("tail has FAILED", f.tail.contains("BUILD FAILED"))
        eq("failure then success", ConsoleLogic.detect(failed + "\n\$ ./gradlew assembleDebug\nBUILD SUCCESSFUL in 9s\n"), null)
        val again = ConsoleLogic.detect("BUILD SUCCESSFUL in 1s\n$failed")!!
        eq("same failure keeps id", again.id, f.id)
        val second = ConsoleLogic.detect(failed + "\n\$ ./gradlew assembleDebug\n$failed")!!
        yes("a new failure gets a new id (card re-appears after dismiss)", second.id != f.id)
        // very long transcripts: the tail is bounded
        val big = "x\n".repeat(50_000) + failed
        yes("tail bounded", ConsoleLogic.detect(big)!!.tail.length <= 2600)
        eq("FAILURE only (no BUILD FAILED)", ConsoleLogic.detect("FAILURE: Build failed with an exception.")?.errors, emptyList<String>())
    }

    // ---------------------------------------------------------------- editor helpers
    private fun editor(tmp: File) {
        val root = File(tmp, "proj"); root.mkdirs()
        val a = File(root, "app/src/main/java/Main.kt"); write(a, "x")
        val b = File(root, "app/src/main/res/layout/main.xml"); write(b, "x")
        val c = File(root, "build.gradle.kts"); write(c, "x")
        val junk = File(root, "app/build/out.kt"); write(junk, "x")
        val git = File(root, ".git/x.kt"); write(git, "x")
        val bin = File(root, "app/icon.png"); write(bin, "x")
        a.setLastModified(1_000_000); b.setLastModified(3_000_000); c.setLastModified(2_000_000)
        junk.setLastModified(9_000_000); git.setLastModified(9_000_000); bin.setLastModified(9_000_000)
        eq("recent: ordered, skips build/.git/binary", ConsoleLogic.recentFiles(root).map { it.name }, listOf("main.xml", "build.gradle.kts", "Main.kt"))
        eq("recent: max", ConsoleLogic.recentFiles(root, 2).size, 2)
        // XML layouts
        val land = File(root, "app/src/main/res/layout-land/main.xml"); write(land, "x"); land.setLastModified(4_000_000)
        val vals = File(root, "app/src/main/res/values/strings.xml"); write(vals, "x")
        val buildLayout = File(root, "app/build/res/layout/gen.xml"); write(buildLayout, "x")
        yes("isLayoutXml layout", ConsoleLogic.isLayoutXml(b))
        yes("isLayoutXml layout-land", ConsoleLogic.isLayoutXml(land))
        yes("isLayoutXml not values", !ConsoleLogic.isLayoutXml(vals))
        yes("isLayoutXml not kt", !ConsoleLogic.isLayoutXml(a))
        yes("isLayoutXml null", !ConsoleLogic.isLayoutXml(null))
        eq("layoutFiles: newest first, skips build", ConsoleLogic.layoutFiles(root).map { it.parentFile.name + "/" + it.name }, listOf("layout-land/main.xml", "layout/main.xml"))
        // per-project chat ids
        val id1 = ConsoleLogic.chatId("/storage/emulated/0/AndroidIDEProjects/My App")
        eq("chatId stable", ConsoleLogic.chatId("/storage/emulated/0/AndroidIDEProjects/My App"), id1)
        yes("chatId differs per project", id1 != ConsoleLogic.chatId("/storage/emulated/0/AndroidIDEProjects/Notes"))
        yes("chatId same name, other folder differs", ConsoleLogic.chatId("/a/Notes") != ConsoleLogic.chatId("/b/Notes"))
        yes("chatId filename-safe", id1.all { it.isLetterOrDigit() || it == '-' || it == '_' })
        yes("chatId readable", id1.startsWith("MyApp-"))
        yes("chatId arabic name ok", ConsoleLogic.chatId("/x/مشروعي").all { it.isLetterOrDigit() || it == '-' || it == '_' })
        yes("slash /xml", ConsoleLogic.expandSlash("/xml شاشة دخول").endsWith(": شاشة دخول"))
        eq("moduleOf nested", ConsoleLogic.moduleOf(root, a), "app")
        eq("moduleOf root file", ConsoleLogic.moduleOf(root, c), null)
        eq("moduleOf outside the project", ConsoleLogic.moduleOf(root, File(tmp, "other/x.kt")), null)
        eq("lang kt", ConsoleLogic.langName(a), "Kotlin")
        eq("lang kts", ConsoleLogic.langName(c), "Gradle KTS")
        eq("lang unknown ext", ConsoleLogic.langName(File("a.rs")), "RS")
        eq("lang no ext", ConsoleLogic.langName(File("Makefile")), "Makefile")

        eq("slash plain", ConsoleLogic.expandSlash("  hello  "), "hello")
        eq("slash unknown", ConsoleLogic.expandSlash("/nope x"), "/nope x")
        yes("slash /fix", ConsoleLogic.expandSlash("/fix").startsWith("افحص الملف المفتوح"))
        yes("slash /edit appends the request", ConsoleLogic.expandSlash("/edit غيّر اللون للأحمر").endsWith("مباشرة: غيّر اللون للأحمر"))
        yes("slash /explain keeps extra text", ConsoleLogic.expandSlash("/explain بالتفصيل").endsWith("باختصار. بالتفصيل"))
        yes("slash /edit alone", ConsoleLogic.expandSlash("/edit").endsWith(": "))
    }

    // ---------------------------------------------------------------- GitLite vs real git
    private fun gitlite(tmp: File) {
        val repo = File(tmp, "repo"); repo.mkdirs()
        git(repo, "init", "-q", "-b", "main")
        eq("branch on empty repo", GitLite.branch(repo), "main")
        // أسماء بأطوال مختلفة باش نجرّبو المحاذاة على 8 بايت + يونيكود
        val names = listOf("a", "bb", "ccc", "build.gradle.kts", "app/src/main/java/com/example/very/long/path/to/Something.kt",
            "app/src/main/res/values/strings.xml", "docs/ملف.md", "x/y/z/w.txt", "README.md", "settings.gradle.kts")
        for ((i, n) in names.withIndex()) write(File(repo, n), "content $i\n".repeat(i + 1))
        git(repo, "add", "-A"); git(repo, "commit", "-q", "-m", "init")

        val idx = GitLite.index(repo)!!
        eq("index keys", idx.keys.sorted(), git(repo, "-c", "core.quotepath=false", "ls-files").lines().filter { it.isNotBlank() }.sorted())
        // SHA كاملة كتطابق
        for (l in git(repo, "-c", "core.quotepath=false", "ls-files", "-s").lines().filter { it.isNotBlank() }) {
            val meta = l.substringBefore('\t').split(' ')
            val name = l.substringAfter('\t')
            eq("sha of $name", idx[name]?.sha, meta[1])
        }
        eq("branch", GitLite.branch(repo), "main")
        git(repo, "checkout", "-q", "-b", "feature/x")
        eq("branch after checkout", GitLite.branch(repo), "feature/x")

        // نبدّلو: تعديل بنفس الحجم داخل نفس الثانية (racy) + تعديل بحجم مختلف + ملف جديد + مجلد build مُتجاهَل
        val racy = File(repo, "ccc"); val before = racy.length()
        racy.writeText(racy.readText().replace('c', 'k'))
        eq("racy edit keeps size", racy.length(), before)
        write(File(repo, "bb"), "changed and longer\n")
        write(File(repo, "brand-new.kt"), "new")
        write(File(repo, "app/build/gen.kt"), "ignored")
        File(repo, "x/y/z/w.txt").let { it.writeText(it.readText()) }   // نفس المحتوى، mtime جديد ← ما يجي حتى M

        val porcelain = git(repo, "status", "--porcelain", "-uall").lines().filter { it.isNotBlank() }
        val want = HashMap<String, Char>()
        for (l in porcelain) {
            val x = l.substring(0, 2); val n = l.substring(3)
            if (x == "??") want[n] = 'A' else if (x[1] == 'M') want[n] = 'M'
        }
        want.keys.removeAll { it.startsWith("app/build/") }          // GitLite كيتجاهل build/ (ماشي فـ .gitignore هنا، تجاهل خاص بالدرج)
        val got = HashMap<String, Char>()
        repo.walkTopDown().filter { it.isFile && !it.path.contains("/.git/") }.forEach { f ->
            GitLite.fileStatus(repo, f)?.let { got[f.relativeTo(repo).path] = it }
        }
        eq("status matches git (worktree vs index)", got.toSortedMap().toString(), want.toSortedMap().toString())
        yes("racy edit detected", got["ccc"] == 'M')
        yes("untouched rewrite not reported", got["x/y/z/w.txt"] == null)
        yes("build/ ignored", got.keys.none { it.startsWith("app/build/") })

        // بعد add → ما بقى شي «تغيير» فالـ worktree
        git(repo, "add", "-A")
        repo.walkTopDown().filter { it.isFile && !it.path.contains("/.git/") && !it.path.contains("/build/") }.forEach {
            eq("after add: ${it.relativeTo(repo)}", GitLite.fileStatus(repo, it), null)
        }
        // رجوع المحتوى الأصلي بعد تعديل → null
        val ff = File(repo, "README.md"); val orig = ff.readText()
        ff.writeText("zzz"); eq("modified", GitLite.fileStatus(repo, ff), 'M')
        ff.writeText(orig); eq("reverted content", GitLite.fileStatus(repo, ff), null)

        // v4 غير مدعومة ← null (ماشي crash)
        git(repo, "update-index", "--index-version", "4")
        eq("index v4 unsupported", GitLite.index(repo), null)
        eq("status with unsupported index", GitLite.fileStatus(repo, ff), null)
        // garbage
        eq("garbage index", GitLite.parseIndex(ByteArray(40) { 7 }), null)
        eq("truncated index", try { GitLite.parseIndex("DIRC".toByteArray() + byteArrayOf(0, 0, 0, 2, 0, 0, 0, 5)) } catch (e: Throwable) { null }?.size ?: 0, 0)
        eq("no repo", GitLite.branch(File(tmp, "nothing")), null)
    }

    @JvmStatic
    fun main(args: Array<String>) {
        val tmp = Files.createTempDirectory("zl-logic").toFile()
        try {
            terminal(); editor(tmp); gitlite(tmp)
            println("OK LogicTest: $checks checks passed")
        } finally { tmp.deleteRecursively() }
    }
}
