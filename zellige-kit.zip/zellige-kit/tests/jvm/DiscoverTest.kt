import com.itsaky.androidide.ai.DiscoverLogic
import com.itsaky.androidide.ai.DiscoverLogic.Outcome
import com.itsaky.androidide.ai.GitHubClient
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.nio.file.Files
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** اختبارات قسم «اكتشف» (المنطق الصافي): استعلام، JSON، zip آمن، كشف التطبيق، SPEC.md، التثبيت الكامل بـ zip فالذاكرة. */
object DiscoverTest {
    private var checks = 0
    private fun eq(what: String, got: Any?, want: Any?) {
        checks++
        if (got != want) { println("❌ $what\n   got : $got\n   want: $want"); throw AssertionError(what) }
    }
    private fun yes(what: String, c: Boolean) = eq(what, c, true)
    private fun has(what: String, text: String, vararg parts: String) {
        for (p in parts) { checks++; if (!text.contains(p)) { println("❌ $what: missing «$p» in\n$text"); throw AssertionError(what) } }
    }
    private fun lacks(what: String, text: String, vararg parts: String) {
        for (p in parts) { checks++; if (text.contains(p)) { println("❌ $what: unexpected «$p»"); throw AssertionError(what) } }
    }
    private fun <T : Throwable> boom(what: String, cls: Class<T>, f: () -> Unit) {
        checks++
        try { f() } catch (t: Throwable) {
            if (cls.isInstance(t)) return
            println("❌ $what: threw ${t.javaClass.name}: ${t.message}"); throw AssertionError(what)
        }
        println("❌ $what: nothing thrown"); throw AssertionError(what)
    }

    private fun zip(entries: Map<String, String?>): ByteArray {
        val bo = ByteArrayOutputStream()
        ZipOutputStream(bo).use { z ->
            for ((n, c) in entries) {
                z.putNextEntry(ZipEntry(n))
                if (c != null) z.write(c.toByteArray())
                z.closeEntry()
            }
        }
        return bo.toByteArray()
    }

    private fun write(f: File, s: String) { f.parentFile.mkdirs(); f.writeText(s) }

    private val repo = DiscoverLogic.Repo(
        full = "acme/notes-app", description = "A tiny notes app", stars = 1234, forks = 10, language = "Kotlin",
        license = "MIT", sizeKb = 3500, url = "https://github.com/acme/notes-app", branch = "main",
        topics = listOf("android-app", "compose"), avatar = "", pushed = "2026-01-01T00:00:00Z"
    )

    // ------------------------------------------------------------------ fixtures
    private const val MANIFEST = """<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.CAMERA"/>
    <application android:label="@string/app_name">
        <activity android:name=".MainActivity" android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
        <activity android:name=".SettingsActivity" />
    </application>
</manifest>"""

    private const val APP_GRADLE = """plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.acme.notes"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.acme.notes"
        minSdk = 24
        targetSdk = 34
        versionCode = 7
        versionName = "1.4.0"
    }
    buildFeatures { compose = true }
}
dependencies {
    implementation("com.squareup.retrofit2:retrofit:2.9.0")
    implementation("androidx.room:room-runtime:2.6.1")
    implementation("com.google.dagger:hilt-android:2.51")
    implementation("androidx.compose.ui:ui:1.6.0")
}
"""

    private const val README = """# Notes

[![Build](https://img.shields.io/badge/build-passing-green.svg)](https://ci)
![logo](logo.png)

A tiny offline-first notes app with **markdown** support and tags.

Syncs nothing, tracks nothing.

## Features

- Markdown editing with live preview
- Tags and full-text search
* Dark theme

## Build

```
./gradlew assembleDebug
```
"""

    /** مشروع Gradle صالح فـ dir (مع أو بلا بادئة). */
    private fun fixtureApp(root: File, withReadme: Boolean = true) {
        write(File(root, "settings.gradle.kts"), "rootProject.name = \"notes\"\ninclude(\":app\")\n")
        write(File(root, "build.gradle.kts"), "plugins { id(\"com.android.application\") version \"8.5.0\" apply false }\n")
        write(File(root, "gradle/libs.versions.toml"), "[versions]\nagp = \"8.5.0\"\nkotlin = \"1.9.24\"\n")
        write(File(root, "gradle/wrapper/gradle-wrapper.properties"), "distributionUrl=https\\://services.gradle.org/distributions/gradle-8.7-bin.zip\n")
        write(File(root, "app/build.gradle.kts"), APP_GRADLE)
        write(File(root, "app/src/main/AndroidManifest.xml"), MANIFEST)
        write(File(root, "app/src/main/res/values/strings.xml"), "<resources><string name=\"app_name\">Notes</string></resources>")
        write(File(root, "app/src/main/res/layout/a.xml"), "<x/>")
        write(File(root, "app/src/main/java/com/acme/notes/MainActivity.kt"),
            "package com.acme.notes\n@Composable\nfun HomeScreen() {}\n@Composable\ninternal fun EditorScreen(x: Int) {}\n@Composable fun Helper() {}\n")
        write(File(root, "app/src/main/java/com/acme/notes/data/Db.kt"), "package x")
        write(File(root, "app/src/main/java/com/acme/notes/ui/Ui.java"), "class U{}")
        if (withReadme) write(File(root, "README.md"), README)
    }

    private fun zipOfDir(dir: File, prefix: String): ByteArray {
        val m = LinkedHashMap<String, String?>()
        m["$prefix/"] = null
        dir.walkTopDown().filter { it != dir }.forEach { f ->
            val rel = prefix + "/" + f.relativeTo(dir).path.replace(File.separatorChar, '/')
            if (f.isDirectory) m["$rel/"] = null else m[rel] = f.readText()
        }
        return zip(m)
    }

    // ------------------------------------------------------------------ pure helpers
    private fun query() {
        val q = DiscoverLogic.buildQuery("", "")
        has("query default", q, "topic:android-app", "archived:false", "fork:false", "stars:>=20")
        lacks("no text → no in:", q, "in:name")
        val q2 = DiscoverLogic.buildQuery("  notes   app ", "topic:jetpack-compose")
        yes("text first", q2.startsWith("notes app in:name,description "))
        has("chip + stars", q2, "topic:jetpack-compose", "stars:>=3")
        eq("long query truncated", DiscoverLogic.buildQuery("x".repeat(500), "").substringBefore(" in:").length, 80)
        yes("chips start with all", DiscoverLogic.CHIPS.first().q.isEmpty())

        eq("compact 0", DiscoverLogic.compact(0), "0")
        eq("compact 999", DiscoverLogic.compact(999), "999")
        eq("compact 1000", DiscoverLogic.compact(1000), "1k")
        eq("compact 1234", DiscoverLogic.compact(1234), "1.2k")
        eq("compact 15300", DiscoverLogic.compact(15300), "15k")
        eq("compact 1.2M", DiscoverLogic.compact(1_200_000), "1.2M")
        eq("size KB", DiscoverLogic.sizeLabel(500), "500 KB")
        eq("size 1 MB", DiscoverLogic.sizeLabel(1024), "1 MB")
        eq("size 3.4 MB", DiscoverLogic.sizeLabel(3500), "3.4 MB")

        eq("zipUrl", DiscoverLogic.zipUrl(repo), "https://codeload.github.com/acme/notes-app/zip/refs/heads/main")
        val br = DiscoverLogic.Repo("a/b", "", 0, 0, "", "", 0, "", "feature/new ui", emptyList(), "", "")
        eq("zipUrl branch slash kept", DiscoverLogic.zipUrl(br), "https://codeload.github.com/a/b/zip/refs/heads/feature/new+ui")
        eq("owner", repo.owner, "acme"); eq("name", repo.name, "notes-app")

        eq("safeName", DiscoverLogic.safeName("My App!! v2"), "My-App-v2")
        eq("safeName dots", DiscoverLogic.safeName("..//.."), "project")
        eq("safeName empty", DiscoverLogic.safeName(""), "project")
        eq("safeName unicode", DiscoverLogic.safeName("تطبيق"), "project")
    }

    private fun json() {
        val v = DiscoverLogic.Json.parse("""{"a":[1,2.5,-3,true,false,null,"x\nA\"y"],"b":{"c":"é"},"e":[],"o":{}}""") as Map<*, *>
        eq("array", v["a"], listOf(1L, 2.5, -3L, true, false, null, "x\nA\"y"))
        eq("nested", (v["b"] as Map<*, *>)["c"], "é")
        eq("empty arr", v["e"], emptyList<Any>()); eq("empty obj", v["o"], emptyMap<String, Any>())
        boom("bad json", IllegalArgumentException::class.java) { DiscoverLogic.Json.parse("{\"a\":") }
        boom("bad json 2", IllegalArgumentException::class.java) { DiscoverLogic.Json.parse("[1,]") }
        boom("bad json 3", IllegalArgumentException::class.java) { DiscoverLogic.Json.parse("{a:1}") }

        val payload = """{"total_count":2,"items":[
          {"full_name":"acme/notes-app","description":"Notes — offline","stargazers_count":1234,"forks_count":9,"language":"Kotlin",
           "license":{"spdx_id":"MIT","name":"MIT License"},"size":3500,"html_url":"https://github.com/acme/notes-app","default_branch":"develop",
           "topics":["android-app","compose"],"owner":{"avatar_url":"https://avatars.githubusercontent.com/u/1?v=4"},"pushed_at":"2026-05-01T10:00:00Z"},
          {"full_name":"bad","stargazers_count":1},
          {"full_name":"x/y","description":null,"language":null,"license":{"spdx_id":"NOASSERTION","name":"Other"},"owner":null}
        ]}"""
        val rs = DiscoverLogic.parseSearch(payload)
        eq("2 repos (one invalid skipped)", rs.size, 2)
        val r = rs[0]
        eq("full", r.full, "acme/notes-app"); eq("desc unicode", r.description, "Notes — offline"); eq("stars", r.stars, 1234)
        eq("branch", r.branch, "develop"); eq("license", r.license, "MIT"); eq("topics", r.topics, listOf("android-app", "compose"))
        eq("avatar", r.avatar, "https://avatars.githubusercontent.com/u/1?v=4")
        val r2 = rs[1]
        eq("null desc", r2.description, ""); eq("null lang", r2.language, ""); eq("NOASSERTION", r2.license, "")
        eq("default branch", r2.branch, "main"); eq("url fallback", r2.url, "https://github.com/x/y")
        eq("garbage → empty", DiscoverLogic.parseSearch("[]"), emptyList<DiscoverLogic.Repo>())
        eq("no items", DiscoverLogic.parseSearch("{\"message\":\"x\"}"), emptyList<DiscoverLogic.Repo>())
    }

    private fun client() {
        val rl = GitHubClient.explain(403, "0", null, "1060", false, 1000, "")
        has("rate limit secs", rl, "60 ثانية", "🔑")
        has("rate limit minutes", GitHubClient.explain(403, "0", null, "1300", true, 1000, ""), "5 دقيقة")
        lacks("with token no hint", GitHubClient.explain(403, "0", null, "1300", true, 1000, ""), "🔑")
        has("429 retry-after", GitHubClient.explain(429, null, "30", null, false, 0, ""), "30 ثانية")
        has("403 body says rate limit", GitHubClient.explain(403, null, null, null, false, 0, "API rate limit exceeded"), "حدّ GitHub")
        has("403 plain", GitHubClient.explain(403, "5", null, null, false, 0, "Forbidden"), "403")
        has("401", GitHubClient.explain(401, null, null, null, true, 0, ""), "رمز")
        has("404", GitHubClient.explain(404, null, null, null, false, 0, ""), "404")
        has("422", GitHubClient.explain(422, null, null, null, false, 0, ""), "422")
        has("503", GitHubClient.explain(503, null, null, null, false, 0, ""), "مؤقت")
        has("offline message", GitHubClient.message(java.net.UnknownHostException("x")), "إنترنت")
        has("timeout message", GitHubClient.message(java.net.SocketTimeoutException()), "بطيء")
    }

    // ------------------------------------------------------------------ zip
    private fun unzip(tmp: File) {
        val d = File(tmp, "unzip"); d.mkdirs()
        val z = zip(linkedMapOf("o-r-abc/" to null, "o-r-abc/README.md" to "hi", "o-r-abc/app/Main.kt" to "fun main(){}", "o-r-abc/empty/" to null, "pax_global_header" to null))
        var seen = 0
        val n = DiscoverLogic.extractZip(ByteArrayInputStream(z), d) { f, _ -> seen = f }
        eq("2 files", n, 2); eq("progress called", seen, 2)
        eq("README stripped prefix", File(d, "README.md").readText(), "hi")
        yes("nested dir", File(d, "app/Main.kt").isFile)
        yes("empty dir kept", File(d, "empty").isDirectory)

        val d2 = File(tmp, "unzip2")
        DiscoverLogic.extractZip(ByteArrayInputStream(z), d2, stripFirst = false)
        yes("no strip keeps prefix", File(d2, "o-r-abc/README.md").isFile)

        // zip-slip
        val evil = File(tmp, "evil.txt")
        boom("zip slip ..", SecurityException::class.java) {
            DiscoverLogic.extractZip(ByteArrayInputStream(zip(linkedMapOf("o-r/../../evil.txt" to "x"))), File(tmp, "slip1"))
        }
        boom("zip slip backslash", SecurityException::class.java) {
            DiscoverLogic.extractZip(ByteArrayInputStream(zip(linkedMapOf("o-r\\..\\..\\evil.txt" to "x"))), File(tmp, "slip2"))
        }
        boom("zip slip absolute", SecurityException::class.java) {
            DiscoverLogic.extractZip(ByteArrayInputStream(zip(linkedMapOf("o-r//../../../evil.txt" to "x"))), File(tmp, "slip3"), stripFirst = true)
        }
        yes("nothing escaped", !evil.exists() && !File(tmp, "slip1").parentFile.resolve("evil.txt").exists())

        boom("too many files", IllegalStateException::class.java) {
            DiscoverLogic.extractZip(ByteArrayInputStream(zip(linkedMapOf("r/a" to "1", "r/b" to "2", "r/c" to "3"))), File(tmp, "many"), true, 1000, 2)
        }
        boom("too big", IllegalStateException::class.java) {
            DiscoverLogic.extractZip(ByteArrayInputStream(zip(linkedMapOf("r/a" to "x".repeat(5000)))), File(tmp, "big"), true, 1000, 10)
        }
        boom("cancel from progress", DiscoverLogic.Cancelled::class.java) {
            DiscoverLogic.extractZip(ByteArrayInputStream(zip(linkedMapOf("r/a" to "1"))), File(tmp, "cancel")) { _, _ -> throw DiscoverLogic.Cancelled() }
        }

        val p = File(tmp, "uniq"); p.mkdirs()
        eq("unique free", DiscoverLogic.uniqueDir(p, "app").name, "app")
        File(p, "app").mkdirs()
        eq("unique 2", DiscoverLogic.uniqueDir(p, "app").name, "app-2")
        File(p, "app-2").mkdirs()
        eq("unique 3", DiscoverLogic.uniqueDir(p, "app").name, "app-3")
    }

    // ------------------------------------------------------------------ detection
    private fun detection(tmp: File) {
        val ok = File(tmp, "det-app"); fixtureApp(ok)
        val d = DiscoverLogic.detectAndroidApp(ok)
        yes("app detected", d.isApp); eq("root", d.root, ok); eq("app module", d.app?.name, "app")
        eq("modules", DiscoverLogic.modulesOf(ok).map { it.name }, listOf("app"))

        val nested = File(tmp, "det-nested"); fixtureApp(File(nested, "android-app"))
        write(File(nested, "docs/readme.txt"), "x")
        val dn = DiscoverLogic.detectAndroidApp(nested)
        yes("nested detected", dn.isApp); eq("nested root", dn.root?.name, "android-app")

        val deep = File(tmp, "det-deep"); fixtureApp(File(deep, "mobile/android"))
        eq("depth 2 root", DiscoverLogic.detectAndroidApp(deep).root?.name, "android")

        val lib = File(tmp, "det-lib")
        write(File(lib, "settings.gradle"), "include ':lib'")
        write(File(lib, "lib/build.gradle"), "plugins { id 'com.android.library' }")
        write(File(lib, "lib/src/main/AndroidManifest.xml"), "<manifest/>")
        val dl = DiscoverLogic.detectAndroidApp(lib)
        yes("library rejected", !dl.isApp); has("library reason", dl.reason, "مكتبة")

        val flutter = File(tmp, "det-flutter"); write(File(flutter, "pubspec.yaml"), "name: x"); fixtureApp(File(flutter, "android"))
        val df = DiscoverLogic.detectAndroidApp(flutter)
        yes("flutter rejected", !df.isApp); has("flutter reason", df.reason, "Flutter")

        val rn = File(tmp, "det-rn"); write(File(rn, "package.json"), "{}"); fixtureApp(File(rn, "android"))
        yes("react native rejected", !DiscoverLogic.detectAndroidApp(rn).isApp)

        val none = File(tmp, "det-none"); write(File(none, "main.py"), "print(1)")
        has("no gradle", DiscoverLogic.detectAndroidApp(none).reason, "settings.gradle")

        val alias = File(tmp, "det-alias")
        write(File(alias, "settings.gradle.kts"), "include(\":composeApp\", \":shared\")")
        write(File(alias, "composeApp/build.gradle.kts"), "plugins { alias(libs.plugins.android.application) }")
        write(File(alias, "shared/build.gradle.kts"), "plugins { alias(libs.plugins.android.library) }")
        eq("version-catalog alias", DiscoverLogic.detectAndroidApp(alias).app?.name, "composeApp")

        val manifestOnly = File(tmp, "det-manifest")
        write(File(manifestOnly, "settings.gradle"), "include ':app'")
        write(File(manifestOnly, "app/build.gradle"), "apply from: 'common.gradle'")
        write(File(manifestOnly, "app/src/main/AndroidManifest.xml"), MANIFEST)
        yes("LAUNCHER fallback", DiscoverLogic.detectAndroidApp(manifestOnly).isApp)

        val buildDirOnly = File(tmp, "det-skip")
        write(File(buildDirOnly, "settings.gradle"), "include ':lib'")
        write(File(buildDirOnly, "lib/build.gradle"), "plugins { id 'com.android.library' }")
        write(File(buildDirOnly, "build/app/build.gradle"), "plugins { id 'com.android.application' }")
        yes("build/ ignored", !DiscoverLogic.detectAndroidApp(buildDirOnly).isApp)
    }

    // ------------------------------------------------------------------ spec
    private fun spec(tmp: File) {
        eq("readme intro skips badges", DiscoverLogic.readmeIntro(README),
            "A tiny offline-first notes app with markdown support and tags.\n\nSyncs nothing, tracks nothing.")
        eq("features", DiscoverLogic.readmeFeatures(README), listOf("Markdown editing with live preview", "Tags and full-text search", "Dark theme"))
        eq("empty readme", DiscoverLogic.readmeIntro(""), "")
        yes("intro capped", DiscoverLogic.readmeIntro("word ".repeat(400), 100).length <= 101)

        val root = File(tmp, "spec-app"); fixtureApp(root)
        val det = DiscoverLogic.detectAndroidApp(root)
        val f = DiscoverLogic.collectFacts(root, det.root!!, det.app)
        eq("label", f.appName, "Notes"); eq("pkg", f.packageName, "com.acme.notes"); eq("versionName", f.versionName, "1.4.0")
        eq("versionCode", f.versionCode, "7"); eq("minSdk", f.minSdk, "24"); eq("target", f.targetSdk, "34"); eq("compile", f.compileSdk, "34")
        eq("agp from toml", f.agp, "8.5.0"); eq("kotlin from toml", f.kotlin, "1.9.24"); eq("gradle wrapper", f.gradle, "8.7")
        eq("launcher", f.launcher, ".MainActivity"); eq("activities", f.activities, listOf(".MainActivity", ".SettingsActivity"))
        eq("permissions", f.permissions, listOf("INTERNET", "CAMERA")); yes("compose", f.compose)
        eq("screens", f.screens, listOf("HomeScreen", "EditorScreen"))
        eq("kt", f.ktFiles, 2); eq("java", f.javaFiles, 1); eq("xml", f.xmlFiles, 3)
        eq("libs", f.libs.toString(), f.libs.toString()); yes("libs " + f.libs, f.libs.containsAll(listOf("Retrofit (واجهات الشبكة)", "Room (قاعدة بيانات محلية)", "Hilt (حقن التبعيات)", "Jetpack Compose (واجهة)")))
        eq("packages", f.packages, listOf("data", "ui"))
        eq("modules", f.modules, listOf("app"))

        val md = DiscoverLogic.renderSpec(repo, f, "2026-10-09")
        has("spec", md, "# Notes — مواصفات المشروع", "2026-10-09", "https://github.com/acme/notes-app", "A tiny notes app",
            "A tiny offline-first notes app", "Markdown editing with live preview", "**.MainActivity**", "`HomeScreen`، `EditorScreen`",
            "`INTERNET` — الاتصال بالإنترنت", "`CAMERA` — الكاميرا", "| Package | `com.acme.notes` |", "| النسخة | 1.4.0 (7) |",
            "24 / 34 / 34", "AGP 8.5.0 · Kotlin 1.9.24 · Gradle 8.7", "Jetpack Compose", "Retrofit", "1.2k ⭐", "MIT",
            "كيفاش نبنيه", "▶")
        lacks("no warnings section for clean project", md, "نقاط انتباه")

        // مشروع بلا README ولا وصف ولا manifest كامل
        val bare = File(tmp, "spec-bare")
        write(File(bare, "settings.gradle"), "include ':app'")
        write(File(bare, "app/build.gradle"), "plugins { id 'com.android.application' }\nandroid { compileSdk 35 }\napply plugin: 'com.google.gms.google-services'\n")
        val bd = DiscoverLogic.detectAndroidApp(bare)
        val bf = DiscoverLogic.collectFacts(bare, bd.root!!, bd.app)
        val bare2 = DiscoverLogic.Repo("z/bare", "", 5, 0, "", "", 10, "https://github.com/z/bare", "main", emptyList(), "", "")
        val bm = DiscoverLogic.renderSpec(bare2, bf, "2026-10-09")
        has("bare spec", bm, "# bare — مواصفات المشروع", "ما لقيتش وصف", "google-services.json", "compileSdk 35")
    }

    // ------------------------------------------------------------------ install end-to-end (fetch فالذاكرة)
    private fun install(tmp: File) {
        val src = File(tmp, "inst-src"); fixtureApp(src)
        val z = zipOfDir(src, "acme-notes-app-1a2b3c")
        val projects = File(tmp, "projects")
        var asked = ""
        val fetch = { url: String -> asked = url; ByteArrayInputStream(z) as java.io.InputStream }
        var prog = 0

        val o1 = DiscoverLogic.install(repo, projects, false, "2026-10-09", fetch) { f, _ -> prog = f }
        eq("fetched codeload", asked, "https://codeload.github.com/acme/notes-app/zip/refs/heads/main")
        o1 as Outcome.Ok
        eq("dest name", o1.dir.name, "notes-app"); yes("project files", File(o1.dir, "app/build.gradle.kts").isFile)
        eq("no spec by default", o1.specFile, null); yes("no SPEC.md", !File(o1.dir, "SPEC.md").exists())
        yes("files counted", o1.files > 5 && prog > 0)
        eq("no temp left", projects.list()!!.filter { it.startsWith(".zl-dl-") }, emptyList<String>())

        val o2 = DiscoverLogic.install(repo, projects, true, "2026-10-09", fetch) { _, _ -> } as Outcome.Ok
        eq("second copy suffix", o2.dir.name, "notes-app-2")
        yes("SPEC.md written", o2.specFile != null && o2.specFile!!.name == "SPEC.md" && o2.specFile!!.readText().contains("# Notes — مواصفات المشروع"))

        // SPEC.md موجود فـ repo → ما نكتبوش فوقو
        val src3 = File(tmp, "inst-src3"); fixtureApp(src3); write(File(src3, "SPEC.md"), "mine")
        val o3 = DiscoverLogic.install(repo, projects, true, "d", { ByteArrayInputStream(zipOfDir(src3, "p")) }) { _, _ -> } as Outcome.Ok
        eq("own SPEC.md kept", File(o3.dir, "SPEC.md").readText(), "mine"); eq("alt name", o3.specFile?.name, "ZELLIGE_SPEC.md")

        // Gradle root داخل مجلد فرعي ← كيتحط كجذر المشروع
        val src4 = File(tmp, "inst-src4"); fixtureApp(File(src4, "android-app")); write(File(src4, "README.md"), "root readme"); write(File(src4, "docs/a.md"), "d")
        val o4 = DiscoverLogic.install(repo, projects, true, "d", { ByteArrayInputStream(zipOfDir(src4, "p")) }) { _, _ -> } as Outcome.Ok
        yes("nested root re-rooted", File(o4.dir, "settings.gradle.kts").isFile && !File(o4.dir, "docs").exists())
        yes("temp removed after re-root", projects.list()!!.none { it.startsWith(".zl-dl-") })

        // مكتبة ← NotApp، المجلد المؤقت كيبقى حتى يقرر المستعمل
        val lib = File(tmp, "inst-lib")
        write(File(lib, "settings.gradle"), "include ':lib'"); write(File(lib, "lib/build.gradle"), "plugins { id 'com.android.library' }")
        val o5 = DiscoverLogic.install(repo, projects, true, "d", { ByteArrayInputStream(zipOfDir(lib, "p")) }) { _, _ -> }
        o5 as Outcome.NotApp
        yes("tmp kept for decision", o5.tmp.isDirectory); yes("hidden from project list", o5.tmp.name.startsWith("."))
        val kept = DiscoverLogic.finish(repo, projects, o5.tmp, DiscoverLogic.Detection(true, null, null, ""), false, "d", o5.files) as Outcome.Ok
        yes("kept as folder", kept.dir.isDirectory && File(kept.dir, "settings.gradle").isFile && !o5.tmp.exists())

        // أخطاء: كيتنظف المؤقت
        boom("fetch fails", java.io.IOException::class.java) {
            DiscoverLogic.install(repo, projects, false, "d", { throw java.io.IOException("offline") }) { _, _ -> }
        }
        boom("evil zip", SecurityException::class.java) {
            DiscoverLogic.install(repo, projects, false, "d", { ByteArrayInputStream(zip(linkedMapOf("p/../../x.txt" to "x"))) }) { _, _ -> }
        }
        boom("empty zip", IllegalStateException::class.java) {
            DiscoverLogic.install(repo, projects, false, "d", { ByteArrayInputStream(zip(linkedMapOf("p/" to null))) }) { _, _ -> }
        }
        boom("cancelled", DiscoverLogic.Cancelled::class.java) {
            DiscoverLogic.install(repo, projects, false, "d", { ByteArrayInputStream(z) }) { _, _ -> throw DiscoverLogic.Cancelled() }
        }
        eq("no temp after failures", projects.list()!!.filter { it.startsWith(".zl-dl-") }, emptyList<String>())
        yes("nothing escaped projects dir", !File(tmp, "x.txt").exists())

        // بقايا قديمة
        val old = File(projects, ".zl-dl-old"); old.mkdirs(); old.setLastModified(System.currentTimeMillis() - 3 * 3600_000L)
        val fresh = File(projects, ".zl-dl-fresh"); fresh.mkdirs()
        DiscoverLogic.cleanStale(projects)
        yes("stale removed", !old.exists()); yes("fresh kept", fresh.exists())
    }

    @JvmStatic
    fun main(args: Array<String>) {
        val tmp = Files.createTempDirectory("zl-discover").toFile()
        try {
            query(); json(); client(); unzip(tmp); detection(tmp); spec(tmp); install(tmp)
            println("OK DiscoverTest: $checks checks passed")
        } finally { tmp.deleteRecursively() }
    }
}
