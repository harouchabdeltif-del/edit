import com.itsaky.androidide.ai.AgentParse

/** Parsing of model replies — the cases that used to produce EMPTY .kt/.java files. */
object AgentTest {
    private var pass = 0
    private var fail = 0
    private fun eq(name: String, got: Any?, want: Any?) {
        if (got == want) pass++ else { fail++; println("✗ $name\n   got:  $got\n   want: $want") }
    }

    @JvmStatic
    fun main(args: Array<String>) {
        // 1. normal body
        val r1 = """Creating it.
<tool name="write_file" path="app/src/main/java/a/MainActivity.kt">
package a
class MainActivity
</tool>"""
        val c1 = AgentParse.parse(r1)
        eq("normal: one call", c1.size, 1)
        eq("normal: body", c1[0].body, "package a\nclass MainActivity")
        eq("normal: path", c1[0].path, "app/src/main/java/a/MainActivity.kt")
        eq("normal: strip", AgentParse.strip(r1), "Creating it.")

        // 2. self-closed tag + fenced code right after  → body taken from the fence (was: EMPTY FILE + code in chat)
        val r2 = """<tool name="write_file" path="app/src/main/java/a/Main.java"/>
```java
package a;
public class Main {}
```
<tool name="write_file" path="app/src/main/res/layout/activity_main.xml" />
```xml
<LinearLayout/>
```
Done."""
        val c2 = AgentParse.parse(r2)
        eq("self-closed: 2 calls", c2.size, 2)
        eq("self-closed: java body", c2[0].body, "package a;\npublic class Main {}")
        eq("self-closed: xml body", c2[1].body, "<LinearLayout/>")
        eq("self-closed: strip removes consumed code", AgentParse.strip(r2), "Done.")
        eq("self-closed: not a code dump", AgentParse.hasCodeDump(r2), false)

        // 3. empty open/close tag + fence after it
        val r3 = "<tool name=\"write_file\" path=\"X.kt\"></tool>\n```kotlin\nfun x() = 1\n```"
        eq("empty pair + fence", AgentParse.parse(r3)[0].body, "fun x() = 1")

        // 4. content attribute
        val r4 = "<tool name=\"write_file\" path=\"Y.kt\" content=\"fun y() {\\n  println()\\n}\"/>"
        eq("content attr", AgentParse.parse(r4)[0].body, "fun y() {\n  println()\n}")

        // 5. a fence far away (an explanation paragraph) is NOT stolen
        val far = "x".repeat(300)
        val r5 = "<tool name=\"write_file\" path=\"Z.kt\"/>\n$far\n```kotlin\nfun z() = 1\nval a = 2\nval b = 3\nval c = 4\n```"
        eq("far fence not taken", AgentParse.parse(r5)[0].body, "")

        // 6. fence after a non-body tool is left alone
        val r6 = "<tool name=\"read_file\" path=\"A.kt\"/>\n```\nnot mine\n```"
        eq("read_file keeps empty body", AgentParse.parse(r6)[0].body, "")

        // 7. truncated reply (max tokens) → detected with its path
        val r7 = "<tool name=\"write_file\" path=\"ok.kt\">\nval ok = 1\n</tool>\n<tool name=\"write_file\" path=\"cut/Long.kt\">\npackage cut\nclass Lo"
        eq("truncated: parsed complete one", AgentParse.parse(r7).size, 1)
        eq("truncated: detected path", AgentParse.truncatedCall(r7)?.path, "cut/Long.kt")
        eq("truncated: none when closed", AgentParse.truncatedCall(r1), null)
        eq("truncated: none for self-closed", AgentParse.truncatedCall(r2), null)

        // 8. placeholders are not code
        eq("placeholder omitted", AgentParse.isPlaceholder("[content omitted]"), true)
        eq("placeholder dots", AgentParse.isPlaceholder("..."), true)
        eq("placeholder todo", AgentParse.isPlaceholder("// TODO"), true)
        eq("placeholder earlier", AgentParse.isPlaceholder("(earlier: write_file a.kt — 40 lines)"), true)
        eq("real code with TODO later is fine", AgentParse.isPlaceholder("package a\n// TODO later\nclass A"), false)
        eq("long file starting with TODO is fine", AgentParse.isPlaceholder("// TODO\n" + (1..10).joinToString("\n") { "val v$it = $it" }), false)
        eq("empty is not placeholder (handled separately)", AgentParse.isPlaceholder(""), false)

        // 9. unfence
        eq("unfence", AgentParse.unfence("```kotlin\nval a = 1\n```"), "val a = 1")
        eq("unfence plain", AgentParse.unfence("val a = 1"), "val a = 1")

        // 10. code dump in chat still detected
        eq("code dump", AgentParse.hasCodeDump("Here:\n```kotlin\na\nb\nc\nd\n```"), true)

        // 11. must-have-body extensions
        eq("kt must have body", "kt" in AgentParse.mustHaveBody, true)
        eq("pro may be empty", "pro" in AgentParse.mustHaveBody, false)

        println(if (fail == 0) "AgentTest OK ($pass checks)" else "AgentTest FAILED: $fail of ${pass + fail}")
        if (fail > 0) kotlin.system.exitProcess(1)
    }
}
