#!/usr/bin/env bash
# Runs the pure-Kotlin logic tests on the JVM (no Android device needed).
#   KOTLINC=/path/kotlinc ANDROID_JAR=/path/android.jar bash tests/jvm/run.sh
set -euo pipefail
KIT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
KC="${KOTLINC:-kotlinc}"
: "${ANDROID_JAR:?set ANDROID_JAR (GitLite.kt only needs the android.jar types to compile)}"
T="$(mktemp -d)"; trap 'rm -rf "$T"' EXIT
LIB="$(dirname "$(command -v "$KC")")/../lib/kotlin-stdlib.jar"
P="$KIT/payload/kotlin"
"$KC" -cp "$ANDROID_JAR" -d "$T/out" "$P/AiDiff.kt" "$P/ConsoleLogic.kt" "$P/GitLite.kt" \
  "$KIT/tests/jvm/DiffTest.kt" "$KIT/tests/jvm/LogicTest.kt" 2>&1 | grep -v '^Picked up\|warning:' || true
java -cp "$T/out:$LIB:$ANDROID_JAR" DiffTestKt
java -cp "$T/out:$LIB:$ANDROID_JAR" LogicTest
