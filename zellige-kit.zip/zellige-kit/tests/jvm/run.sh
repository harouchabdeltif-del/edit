#!/usr/bin/env bash
# Runs the pure-Kotlin logic tests on the JVM (no Android device needed).
#   KOTLINC=/path/kotlinc ANDROID_JAR=/path/android.jar bash tests/jvm/run.sh
set -euo pipefail
KIT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
KC="${KOTLINC:-kotlinc}"
: "${ANDROID_JAR:?set ANDROID_JAR (GitLite.kt only needs the android.jar types to compile)}"
T="$(mktemp -d)"; trap 'rm -rf "$T"' EXIT
LIB="$(dirname "$(command -v "$KC")")/../lib/kotlin-stdlib.jar"
P="$KIT/payload/kotlin"
"$KC" -cp "$ANDROID_JAR" -d "$T/out" "$P/AiDiff.kt" "$P/ConsoleLogic.kt" "$P/GitLite.kt" "$P/DiscoverLogic.kt" "$P/GitHubClient.kt" "$P/AgentParse.kt" \
  "$KIT/tests/jvm/DiffTest.kt" "$KIT/tests/jvm/LogicTest.kt" "$KIT/tests/jvm/DiscoverTest.kt" "$KIT/tests/jvm/AgentTest.kt" 2>&1 | grep -v '^Picked up\|warning:' || true
java -Dfile.encoding=UTF-8 -Dstdout.encoding=UTF-8 -cp "$T/out:$LIB:$ANDROID_JAR" DiffTestKt
java -Dfile.encoding=UTF-8 -Dstdout.encoding=UTF-8 -cp "$T/out:$LIB:$ANDROID_JAR" LogicTest
java -Dfile.encoding=UTF-8 -Dstdout.encoding=UTF-8 -cp "$T/out:$LIB:$ANDROID_JAR" DiscoverTest
java -Dfile.encoding=UTF-8 -Dstdout.encoding=UTF-8 -cp "$T/out:$LIB:$ANDROID_JAR" AgentTest
