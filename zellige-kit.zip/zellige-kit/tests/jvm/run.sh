#!/usr/bin/env bash
# Runs the pure-Kotlin logic tests on the JVM (no Android needed).
#   KOTLINC=/path/kotlinc bash tests/jvm/run.sh
set -euo pipefail
KIT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
KC="${KOTLINC:-kotlinc}"
T="$(mktemp -d)"; trap 'rm -rf "$T"' EXIT
"$KC" -d "$T/out" "$KIT/payload/kotlin/AiDiff.kt" "$KIT/tests/jvm/DiffTest.kt" 2>&1 | grep -v '^Picked up\|warning:' || true
java -cp "$T/out:$("$KC" -version >/dev/null 2>&1; dirname "$KC")/../lib/kotlin-stdlib.jar" DiffTestKt
