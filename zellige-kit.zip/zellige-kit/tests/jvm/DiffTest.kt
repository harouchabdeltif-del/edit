import com.itsaky.androidide.ai.AiDiff
import com.itsaky.androidide.ai.EditSink
import kotlin.random.Random

/** محرر وهمي: نفس دلالة Content.replace(line,col,line,col,text) فـ Sora. */
class FakeEditor(var text: String, private val cancelAfter: Int = Int.MAX_VALUE) : EditSink {
    var ops = 0
    private fun idx(line: Int, col: Int): Int {
        var i = 0
        repeat(line) { val nl = text.indexOf('\n', i); require(nl >= 0) { "line $line out of range" }; i = nl + 1 }
        val lineEnd = text.indexOf('\n', i).let { if (it < 0) text.length else it }
        require(i + col <= lineEnd) { "col $col out of range on line $line" }
        return i + col
    }
    override fun select(l1: Int, c1: Int, l2: Int, c2: Int) { idx(l1, c1); idx(l2, c2) }
    override fun replace(l1: Int, c1: Int, l2: Int, c2: Int, text: String) {
        ops++
        val a = idx(l1, c1); val b = idx(l2, c2)
        require(a <= b)
        this.text = this.text.substring(0, a) + text + this.text.substring(b)
    }
    override fun move(line: Int, col: Int) { idx(line, col) }
    override fun pause(ms: Long) {}
    override fun alive() = ops < cancelAfter
}

fun main() {
    val rnd = Random(42)
    val alphabet = listOf("a", "b", "\n", "\n", " ", "x\n", "class A {\n", "}\n", "é", "")
    fun gen(n: Int) = buildString { repeat(n) { append(alphabet[rnd.nextInt(alphabet.size)]) } }
    var n = 0
    repeat(4000) {
        val old = gen(rnd.nextInt(0, 40))
        val new = if (rnd.nextInt(3) == 0) gen(rnd.nextInt(0, 40)) else {
            // edit of old: mutate a slice
            val a = rnd.nextInt(0, old.length + 1); val b = rnd.nextInt(a, old.length + 1)
            old.substring(0, a) + gen(rnd.nextInt(0, 12)) + old.substring(b)
        }
        val ed = FakeEditor(old, cancelAfter = if (rnd.nextInt(5) == 0) rnd.nextInt(1, 4) else Int.MAX_VALUE)
        AiDiff.animate(ed, old, new)
        check(ed.text == new) { "mismatch\nold=${old.replace("\n","\\n")}\nnew=${new.replace("\n","\\n")}\ngot=${ed.text.replace("\n","\\n")}" }
        n++
    }
    // big file: bounded number of frames
    val big = (1..5000).joinToString("\n") { "line $it" }
    val ed = FakeEditor("")
    AiDiff.animate(ed, "", big)
    check(ed.text == big) { "big mismatch" }
    check(ed.ops <= 100) { "too many frames: ${ed.ops}" }
    println("OK AiDiff: $n random edits + big file ok (frames for 5000 lines = ${ed.ops})")
}
