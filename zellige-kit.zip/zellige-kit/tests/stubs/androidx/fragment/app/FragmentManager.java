package androidx.fragment.app;
import java.util.List;
public abstract class FragmentManager {
    public List<Fragment> getFragments() { return null; }
}
