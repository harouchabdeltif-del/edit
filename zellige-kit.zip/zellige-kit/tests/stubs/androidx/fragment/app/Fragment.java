package androidx.fragment.app;
public class Fragment {
    public FragmentManager getChildFragmentManager() { return null; }
}
