package androidx.core.widget;
import android.content.Context;
import android.widget.FrameLayout;
/** Test stub: only members the kit relies on (real class: androidx.core:core). */
public class NestedScrollView extends FrameLayout {
    public NestedScrollView(Context c) { super(c); }
}
