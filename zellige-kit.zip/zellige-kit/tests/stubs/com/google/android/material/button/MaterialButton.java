package com.google.android.material.button;
import android.content.Context;
import android.content.res.ColorStateList;
import android.widget.Button;
public class MaterialButton extends Button {
    public MaterialButton(Context c) { super(c); }
    public int getCornerRadius() { return 0; }
    public void setCornerRadius(int r) {}
    public void setStrokeWidth(int w) {}
    public int getStrokeWidth() { return 0; }
    public void setStrokeColor(ColorStateList c) {}
    public ColorStateList getStrokeColor() { return null; }
    public void setBackgroundTintList(ColorStateList c) {}
    public void setIconResource(int r) {}
}
