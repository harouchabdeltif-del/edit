package com.google.android.material.bottomsheet;
import android.view.View;
public class BottomSheetBehavior<V extends View> {
    public static final int STATE_EXPANDED = 3;
    public boolean getSkipCollapsed() { return false; }
    public void setSkipCollapsed(boolean b) {}
    public boolean isFitToContents() { return true; }
    public void setFitToContents(boolean b) {}
    public int getState() { return 0; }
    public void setState(int s) {}
}
