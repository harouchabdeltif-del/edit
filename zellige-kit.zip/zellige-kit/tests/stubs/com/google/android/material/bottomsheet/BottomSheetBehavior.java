package com.google.android.material.bottomsheet;
import android.view.View;
public class BottomSheetBehavior<V extends View> {
    public static final int STATE_DRAGGING = 1;
    public static final int STATE_SETTLING = 2;
    public static final int STATE_EXPANDED = 3;
    public static final int STATE_COLLAPSED = 4;
    public static abstract class BottomSheetCallback {
        public abstract void onStateChanged(View bottomSheet, int newState);
        public abstract void onSlide(View bottomSheet, float slideOffset);
    }
    public boolean getSkipCollapsed() { return false; }
    public void setSkipCollapsed(boolean b) {}
    public boolean isFitToContents() { return true; }
    public void setFitToContents(boolean b) {}
    public int getState() { return 0; }
    public void setState(int s) {}
    public int getPeekHeight() { return 0; }
    public void setPeekHeight(int h) {}
    public int getExpandedOffset() { return 0; }
    public void addBottomSheetCallback(BottomSheetCallback c) {}
}
