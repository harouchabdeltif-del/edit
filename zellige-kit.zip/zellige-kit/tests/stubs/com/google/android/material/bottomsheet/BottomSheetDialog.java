package com.google.android.material.bottomsheet;
import android.content.Context;
import android.widget.FrameLayout;
public class BottomSheetDialog extends android.app.Dialog {
    public BottomSheetDialog(Context c) { super(c); }
    public BottomSheetBehavior<FrameLayout> getBehavior() { return null; }
}
