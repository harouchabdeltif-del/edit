package com.google.android.material.chip;
import android.content.Context;
import android.content.res.ColorStateList;
public class Chip extends android.widget.CompoundButton {
    public Chip(Context c) { super(c); }
    public ColorStateList getChipBackgroundColor() { return null; }
    public void setChipBackgroundColor(ColorStateList c) {}
    public ColorStateList getChipStrokeColor() { return null; }
    public void setChipStrokeColor(ColorStateList c) {}
    public float getChipStrokeWidth() { return 0f; }
    public void setChipStrokeWidth(float w) {}
    public boolean isCheckable() { return false; }
    public void setCheckable(boolean b) {}
}
