package com.itsaky.androidide.ai

import java.io.File
import java.io.InputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream

/**
 * منطق صافي (بلا Android) لقسم «اكتشف»: بناء استعلام GitHub، قراءة JSON، فك zip بأمان، التحقق بلي المشروع تطبيق أندرويد،
 * وتوليد ملف المواصفات (SPEC.md) من الكود نفسو. كلشي قابل للاختبار على JVM (tests/jvm/LogicTest.kt).
 */
object DiscoverLogic {

    // ------------------------------------------------------------------ model
    class Repo(
        val full: String,
        val description: String,
        val stars: Int,
        val forks: Int,
        val language: String,
        val license: String,
        val sizeKb: Int,
        val url: String,
        val branch: String,
        val topics: List<String>,
        val avatar: String,
        val pushed: String
    ) {
        val owner: String get() = full.substringBefore('/')
        val name: String get() = full.substringAfter('/')
    }

    // ------------------------------------------------------------------ search query
    class Chip(val id: String, val label: String, val q: String)

    val CHIPS = listOf(
        Chip("all", "الكل", ""),
        Chip("compose", "Compose", "topic:jetpack-compose"),
        Chip("kotlin", "Kotlin", "language:Kotlin"),
        Chip("java", "Java", "language:Java"),
        Chip("games", "ألعاب", "topic:game"),
        Chip("productivity", "إنتاجية", "topic:productivity")
    )

    /**
     * كنبحثو غير فتطبيقات أندرويد: topic:android-app (المكتبات كتستعمل android-library) + بلا forks ولا أرشيف + حد أدنى من النجوم.
     * التحقق النهائي (com.android.application) كيتدار مللي نحمّلو المشروع.
     */
    fun buildQuery(text: String, chipQuery: String): String {
        val clean = text.trim().replace(Regex("\\s+"), " ").take(80)
        val sb = StringBuilder()
        if (clean.isNotEmpty()) sb.append(clean).append(" in:name,description ")
        sb.append("topic:android-app archived:false fork:false ")
        if (chipQuery.isNotBlank()) sb.append(chipQuery.trim()).append(' ')
        sb.append(if (clean.isEmpty()) "stars:>=20" else "stars:>=3")
        return sb.toString().trim()
    }

    /** 1234 → 1.2k · 15300 → 15k · 1_200_000 → 1.2M */
    fun compact(n: Int): String = when {
        n < 1000 -> n.toString()
        n < 10_000 -> String.format(java.util.Locale.US, "%.1fk", n / 1000.0).replace(".0k", "k")
        n < 1_000_000 -> (n / 1000).toString() + "k"
        else -> String.format(java.util.Locale.US, "%.1fM", n / 1_000_000.0).replace(".0M", "M")
    }

    fun sizeLabel(kb: Int): String = when {
        kb < 1024 -> "$kb KB"
        else -> String.format(java.util.Locale.US, "%.1f MB", kb / 1024.0).replace(".0 MB", " MB")
    }

    // ------------------------------------------------------------------ tiny JSON (بلا org.json باش نختبرو على JVM)
    object Json {
        fun parse(s: String): Any? {
            val p = Parser(s)
            p.ws()
            val v = p.value()
            return v
        }

        private class Parser(val s: String) {
            var i = 0
            fun ws() { while (i < s.length && s[i].isWhitespace()) i++ }
            fun fail(m: String): Nothing = throw IllegalArgumentException("JSON: $m @$i")

            fun value(): Any? {
                ws()
                if (i >= s.length) fail("eof")
                return when (val c = s[i]) {
                    '{' -> obj()
                    '[' -> arr()
                    '"' -> str()
                    't' -> lit("true", true)
                    'f' -> lit("false", false)
                    'n' -> lit("null", null)
                    else -> if (c == '-' || c.isDigit()) num() else fail("unexpected '$c'")
                }
            }

            fun lit(w: String, v: Any?): Any? {
                if (!s.startsWith(w, i)) fail("bad literal")
                i += w.length
                return v
            }

            fun num(): Any {
                val st = i
                if (s[i] == '-') i++
                while (i < s.length && (s[i].isDigit() || s[i] in ".eE+-")) i++
                val t = s.substring(st, i)
                return t.toLongOrNull() ?: t.toDoubleOrNull() ?: fail("bad number")
            }

            fun str(): String {
                i++ // "
                val sb = StringBuilder()
                while (true) {
                    if (i >= s.length) fail("unterminated string")
                    val c = s[i++]
                    when (c) {
                        '"' -> return sb.toString()
                        '\\' -> {
                            if (i >= s.length) fail("bad escape")
                            when (val e = s[i++]) {
                                'n' -> sb.append('\n'); 't' -> sb.append('\t'); 'r' -> sb.append('\r')
                                'b' -> sb.append('\b'); 'f' -> sb.append('\u000c')
                                'u' -> {
                                    if (i + 4 > s.length) fail("bad \\u")
                                    sb.append(s.substring(i, i + 4).toInt(16).toChar()); i += 4
                                }
                                else -> sb.append(e)
                            }
                        }
                        else -> sb.append(c)
                    }
                }
            }

            fun arr(): List<Any?> {
                i++ // [
                val out = ArrayList<Any?>()
                ws()
                if (i < s.length && s[i] == ']') { i++; return out }
                while (true) {
                    out.add(value())
                    ws()
                    if (i >= s.length) fail("eof in array")
                    if (s[i] == ',') { i++; continue }
                    if (s[i] == ']') { i++; return out }
                    fail("expected , or ]")
                }
            }

            fun obj(): Map<String, Any?> {
                i++ // {
                val out = LinkedHashMap<String, Any?>()
                ws()
                if (i < s.length && s[i] == '}') { i++; return out }
                while (true) {
                    ws()
                    if (i >= s.length || s[i] != '"') fail("expected key")
                    val k = str()
                    ws()
                    if (i >= s.length || s[i] != ':') fail("expected :")
                    i++
                    out[k] = value()
                    ws()
                    if (i >= s.length) fail("eof in object")
                    if (s[i] == ',') { i++; continue }
                    if (s[i] == '}') { i++; return out }
                    fail("expected , or }")
                }
            }
        }
    }

    private fun str(x: Any?): String = if (x == null) "" else x.toString()
    private fun int(x: Any?): Int = (x as? Number)?.toInt() ?: 0

    /** استجابة `/search/repositories` ← مستودعات. */
    fun parseSearch(json: String): List<Repo> {
        val root = Json.parse(json) as? Map<*, *> ?: return emptyList()
        val items = root["items"] as? List<*> ?: return emptyList()
        return items.mapNotNull { (it as? Map<*, *>)?.let(::repoOf) }
    }

    internal fun repoOf(o: Map<*, *>): Repo? {
        val full = str(o["full_name"])
        if (full.isEmpty() || !full.contains('/')) return null
        val lic = o["license"] as? Map<*, *>
        val owner = o["owner"] as? Map<*, *>
        val topics = (o["topics"] as? List<*>)?.map { str(it) } ?: emptyList()
        return Repo(
            full = full,
            description = str(o["description"]).trim(),
            stars = int(o["stargazers_count"]),
            forks = int(o["forks_count"]),
            language = str(o["language"]),
            license = str(lic?.get("spdx_id")).ifBlank { str(lic?.get("name")) }.let { if (it == "NOASSERTION") "" else it },
            sizeKb = int(o["size"]),
            url = str(o["html_url"]).ifBlank { "https://github.com/$full" },
            branch = str(o["default_branch"]).ifBlank { "main" },
            topics = topics,
            avatar = str(owner?.get("avatar_url")),
            pushed = str(o["pushed_at"])
        )
    }

    /** رابط تحميل zip للفرع (codeload ما كيحسبش ضمن حدّ الـ API). */
    fun zipUrl(repo: Repo): String =
        "https://codeload.github.com/${repo.full}/zip/refs/heads/" + repo.branch.split('/').joinToString("/") { java.net.URLEncoder.encode(it, "UTF-8") }

    // ------------------------------------------------------------------ safe unzip
    class Cancelled : RuntimeException("cancelled")

    const val MAX_BYTES = 250L * 1024 * 1024
    const val MAX_FILES = 40_000

    /**
     * يفك zip فـ dest. إلا stripFirst كيتحيّد المجلد الأول (zip ديال GitHub: owner-repo-sha/).
     * محميّ من zip-slip، وكيرمي إلا تجاوز الحجم/عدد الملفات. `progress(files, bytes)` كيتنادى باستمرار (ويقدر يرمي Cancelled).
     */
    fun extractZip(
        input: InputStream,
        dest: File,
        stripFirst: Boolean = true,
        maxBytes: Long = MAX_BYTES,
        maxFiles: Int = MAX_FILES,
        progress: (Int, Long) -> Unit = { _, _ -> }
    ): Int {
        dest.mkdirs()
        val root = dest.canonicalFile
        var files = 0
        var bytes = 0L
        var reported = 0L
        val buf = ByteArray(64 * 1024)
        ZipInputStream(input).use { zin ->
            var e: ZipEntry? = zin.nextEntry
            while (e != null) {
                var name = e.name.replace('\\', '/')
                if (stripFirst) name = name.substringAfter('/', "")
                if (name.isNotEmpty()) {
                    val target = File(root, name).canonicalFile
                    if (target != root && !target.path.startsWith(root.path + File.separator)) {
                        throw SecurityException("مسار مشبوه داخل الـ zip: ${e.name}")
                    }
                    if (e.isDirectory) {
                        target.mkdirs()
                    } else {
                        if (++files > maxFiles) throw IllegalStateException("المشروع فيه ملفات بزاف (> $maxFiles)")
                        target.parentFile?.mkdirs()
                        target.outputStream().use { out ->
                            while (true) {
                                val n = zin.read(buf)
                                if (n < 0) break
                                bytes += n
                                if (bytes > maxBytes) throw IllegalStateException("المشروع كبير بزاف (> ${maxBytes / 1024 / 1024} MB)")
                                out.write(buf, 0, n)
                                if (bytes - reported > 512 * 1024) { reported = bytes; progress(files, bytes) }
                            }
                        }
                        if (files % 25 == 0) progress(files, bytes)
                    }
                }
                zin.closeEntry()
                e = zin.nextEntry
            }
        }
        progress(files, bytes)
        return files
    }

    // ------------------------------------------------------------------ naming
    /** اسم مجلد آمن من اسم المستودع. */
    fun safeName(s: String): String {
        val n = s.replace(Regex("[^A-Za-z0-9._-]+"), "-").trim('-', '.', '_')
        return n.ifEmpty { "project" }.take(60)
    }

    /** مجلد غير موجود فـ parent (name، name-2، name-3…). */
    fun uniqueDir(parent: File, base: String): File {
        var f = File(parent, base)
        var i = 2
        while (f.exists()) { f = File(parent, "$base-$i"); i++ }
        return f
    }

    // ------------------------------------------------------------------ android detection
    private val SKIP = setOf("build", ".git", ".gradle", ".idea", "node_modules", ".github", ".cxx")
    private val APP_PLUGIN = Regex("com\\.android\\.application|android\\.application|androidApplication")

    class Detection(val isApp: Boolean, val root: File?, val app: File?, val reason: String)

    private fun hasSettings(d: File) = File(d, "settings.gradle").isFile || File(d, "settings.gradle.kts").isFile

    private fun buildFile(d: File): File? = listOf("build.gradle.kts", "build.gradle").map { File(d, it) }.firstOrNull { it.isFile }

    private fun readCapped(f: File, max: Int = 300_000): String =
        try { f.inputStream().use { String(it.readNBytesCompat(max), Charsets.UTF_8) } } catch (t: Throwable) { "" }

    private fun InputStream.readNBytesCompat(max: Int): ByteArray {
        val out = java.io.ByteArrayOutputStream()
        val buf = ByteArray(8192)
        var left = max
        while (left > 0) {
            val n = read(buf, 0, minOf(buf.size, left))
            if (n < 0) break
            out.write(buf, 0, n); left -= n
        }
        return out.toByteArray()
    }

    private fun gradleText(d: File): String = buildFile(d)?.let { readCapped(it) }.orEmpty()

    /** وحدات settings.gradle: include(":app", ":feature:home") ← مجلدات. */
    fun modulesOf(root: File): List<File> {
        val sf = listOf("settings.gradle.kts", "settings.gradle").map { File(root, it) }.firstOrNull { it.isFile } ?: return emptyList()
        val txt = readCapped(sf)
        val out = LinkedHashSet<File>()
        val inc = Regex("""include\s*\(?\s*((?:["'][^"']+["']\s*,?\s*)+)""")
        for (m in inc.findAll(txt)) {
            for (q in Regex("""["']:?([^"']+)["']""").findAll(m.groupValues[1])) {
                val rel = q.groupValues[1].trim(':').replace(':', '/')
                val d = File(root, rel)
                if (d.isDirectory) out.add(d)
            }
        }
        return out.toList()
    }

    /** وحدة التطبيق: اللي فيها plugin ديال application (أو manifest فيه LAUNCHER + ملف build). */
    fun findAppModule(root: File): File? {
        val cands = LinkedHashSet<File>()
        File(root, "app").takeIf { it.isDirectory }?.let { cands.add(it) }
        cands.addAll(modulesOf(root))
        cands.add(root)
        root.listFiles()?.filter { it.isDirectory && !it.name.startsWith(".") && it.name !in SKIP }?.sortedBy { it.name }?.let { cands.addAll(it) }
        for (m in cands) {
            val t = gradleText(m)
            if (t.isEmpty()) continue
            if (APP_PLUGIN.containsMatchIn(t)) return m
        }
        for (m in cands) {
            val mf = File(m, "src/main/AndroidManifest.xml")
            if (!mf.isFile || buildFile(m) == null) continue
            val x = readCapped(mf, 200_000)
            if (x.contains("android.intent.action.MAIN") && x.contains("android.intent.category.LAUNCHER")) return m
        }
        return null
    }

    /** هل المجلد المفكوك مشروع تطبيق أندرويد (Gradle)؟ كيقلّب فالجذر وفالمجلدات الفرعية (عمق ≤ 2). */
    fun detectAndroidApp(top: File): Detection {
        if (File(top, "pubspec.yaml").isFile) return Detection(false, null, null, "هادا مشروع Flutter: ما كيتبناش بـ Gradle هنا")
        if (File(top, "package.json").isFile && File(top, "android").isDirectory && !hasSettings(top))
            return Detection(false, null, null, "هادا مشروع React Native/Cordova: ما كيتبناش بـ Gradle هنا")
        val roots = ArrayList<File>()
        if (hasSettings(top)) roots.add(top)
        top.listFiles()?.filter { it.isDirectory && !it.name.startsWith(".") && it.name !in SKIP }?.sortedBy { it.name }?.forEach { d ->
            if (hasSettings(d)) roots.add(d)
            else d.listFiles()?.filter { it.isDirectory && !it.name.startsWith(".") && it.name !in SKIP }?.sortedBy { it.name }
                ?.forEach { d2 -> if (hasSettings(d2)) roots.add(d2) }
        }
        if (roots.isEmpty()) return Detection(false, null, null, "ما لقيتش settings.gradle: هادا ماشي مشروع Gradle")
        for (r in roots) {
            val app = findAppModule(r)
            if (app != null) return Detection(true, r, app, "")
        }
        return Detection(false, null, null, "مشروع Gradle بلا وحدة تطبيق (com.android.application)، غالبا مكتبة")
    }

    // ------------------------------------------------------------------ spec facts
    class Facts(
        val appName: String?,
        val packageName: String?,
        val versionName: String?,
        val versionCode: String?,
        val minSdk: String?,
        val targetSdk: String?,
        val compileSdk: String?,
        val agp: String?,
        val kotlin: String?,
        val gradle: String?,
        val modules: List<String>,
        val activities: List<String>,
        val launcher: String?,
        val screens: List<String>,
        val permissions: List<String>,
        val libs: List<String>,
        val compose: Boolean,
        val ktFiles: Int,
        val javaFiles: Int,
        val xmlFiles: Int,
        val packages: List<String>,
        val warnings: List<String>,
        val readmeIntro: String,
        val features: List<String>
    )

    private fun firstGroup(re: Regex, text: String): String? = re.find(text)?.groupValues?.get(1)

    private val DEPS: List<Pair<Regex, String>> = listOf(
        Regex("androidx\\.compose|compose-bom|compose\\.ui|androidx-compose", RegexOption.IGNORE_CASE) to "Jetpack Compose (واجهة)",
        Regex("androidx\\.room|room-runtime|room-ktx|room\\.runtime", RegexOption.IGNORE_CASE) to "Room (قاعدة بيانات محلية)",
        Regex("retrofit", RegexOption.IGNORE_CASE) to "Retrofit (واجهات الشبكة)",
        Regex("okhttp", RegexOption.IGNORE_CASE) to "OkHttp (شبكة)",
        Regex("ktor", RegexOption.IGNORE_CASE) to "Ktor (شبكة)",
        Regex("dagger\\.hilt|hilt-android|hilt\\.android|androidx\\.hilt|\\bhilt\\b", RegexOption.IGNORE_CASE) to "Hilt (حقن التبعيات)",
        Regex("koin", RegexOption.IGNORE_CASE) to "Koin (حقن التبعيات)",
        Regex("kotlinx[-.]coroutines|kotlinx-coroutines", RegexOption.IGNORE_CASE) to "Kotlin Coroutines (عمليات غير متزامنة)",
        Regex("firebase", RegexOption.IGNORE_CASE) to "Firebase (خدمات سحابية)",
        Regex("io\\.coil-kt|coil-compose|\\bcoil\\b", RegexOption.IGNORE_CASE) to "Coil (تحميل الصور)",
        Regex("glide", RegexOption.IGNORE_CASE) to "Glide (تحميل الصور)",
        Regex("picasso", RegexOption.IGNORE_CASE) to "Picasso (تحميل الصور)",
        Regex("androidx\\.navigation|navigation-compose|navigation-fragment", RegexOption.IGNORE_CASE) to "Navigation (التنقل بين الشاشات)",
        Regex("datastore", RegexOption.IGNORE_CASE) to "DataStore (تخزين الإعدادات)",
        Regex("androidx\\.work|workmanager|work-runtime", RegexOption.IGNORE_CASE) to "WorkManager (مهام بالخلفية)",
        Regex("androidx\\.paging|paging-runtime|paging-compose", RegexOption.IGNORE_CASE) to "Paging (قوائم كبيرة)",
        Regex("media3|exoplayer", RegexOption.IGNORE_CASE) to "Media3/ExoPlayer (صوت وفيديو)",
        Regex("maplibre|mapbox|osmdroid|play-services-maps|maps-compose", RegexOption.IGNORE_CASE) to "خرائط",
        Regex("play-services-ads|admob|unity-ads|applovin", RegexOption.IGNORE_CASE) to "إعلانات",
        Regex("sqldelight|realm|objectbox", RegexOption.IGNORE_CASE) to "قاعدة بيانات (SQLDelight/Realm/ObjectBox)",
        Regex("moshi|gson|kotlinx[-.]serialization|jackson", RegexOption.IGNORE_CASE) to "معالجة JSON",
        Regex("camerax|androidx\\.camera", RegexOption.IGNORE_CASE) to "CameraX (الكاميرا)",
        Regex("mlkit|ml-kit|tensorflow|tflite|onnx|mediapipe", RegexOption.IGNORE_CASE) to "ذكاء اصطناعي على الجهاز (ML Kit/TensorFlow Lite)",
        Regex("com\\.google\\.android\\.material|material3|androidx\\.compose\\.material3", RegexOption.IGNORE_CASE) to "Material Design",
        Regex("lottie", RegexOption.IGNORE_CASE) to "Lottie (حركات)",
        Regex("timber", RegexOption.IGNORE_CASE) to "Timber (سجلات)",
        Regex("androidx\\.biometric", RegexOption.IGNORE_CASE) to "البصمة (Biometric)"
    )

    private val PERMS: Map<String, String> = mapOf(
        "INTERNET" to "الاتصال بالإنترنت", "ACCESS_NETWORK_STATE" to "معرفة حالة الشبكة", "CAMERA" to "الكاميرا",
        "RECORD_AUDIO" to "الميكروفون", "READ_EXTERNAL_STORAGE" to "قراءة الملفات", "WRITE_EXTERNAL_STORAGE" to "كتابة الملفات",
        "MANAGE_EXTERNAL_STORAGE" to "الوصول لكل الملفات", "READ_MEDIA_IMAGES" to "قراءة الصور", "READ_MEDIA_VIDEO" to "قراءة الفيديو",
        "READ_MEDIA_AUDIO" to "قراءة الصوتيات", "ACCESS_FINE_LOCATION" to "الموقع الدقيق", "ACCESS_COARSE_LOCATION" to "الموقع التقريبي",
        "ACCESS_BACKGROUND_LOCATION" to "الموقع بالخلفية", "POST_NOTIFICATIONS" to "الإشعارات", "VIBRATE" to "الاهتزاز",
        "FOREGROUND_SERVICE" to "خدمة تعمل بالمقدمة", "WAKE_LOCK" to "منع الجهاز من النوم", "RECEIVE_BOOT_COMPLETED" to "التشغيل مع بداية الجهاز",
        "READ_CONTACTS" to "قراءة جهات الاتصال", "WRITE_CONTACTS" to "كتابة جهات الاتصال", "READ_PHONE_STATE" to "حالة الهاتف",
        "CALL_PHONE" to "الاتصال الهاتفي", "SEND_SMS" to "إرسال رسائل SMS", "READ_SMS" to "قراءة رسائل SMS", "BLUETOOTH_CONNECT" to "بلوتوث",
        "BLUETOOTH_SCAN" to "بحث بلوتوث", "BLUETOOTH" to "بلوتوث", "SYSTEM_ALERT_WINDOW" to "الرسم فوق التطبيقات",
        "REQUEST_INSTALL_PACKAGES" to "تثبيت تطبيقات", "QUERY_ALL_PACKAGES" to "قراءة قائمة التطبيقات", "USE_BIOMETRIC" to "البصمة",
        "USE_FINGERPRINT" to "البصمة", "NFC" to "NFC", "READ_CALENDAR" to "قراءة التقويم", "WRITE_CALENDAR" to "كتابة التقويم",
        "ACTIVITY_RECOGNITION" to "النشاط البدني", "SCHEDULE_EXACT_ALARM" to "منبهات دقيقة", "BODY_SENSORS" to "حساسات الجسم"
    )

    private fun versionOf(text: String, vararg keys: String): String? {
        for (k in keys) {
            firstGroup(Regex("""\b$k\s*=\s*["']([\d][\w.\-]*)["']"""), text)?.let { return it }
        }
        return null
    }

    private fun cleanMd(s: String): String = s
        .replace(Regex("!\\[[^\\]]*]\\([^)]*\\)"), "")
        .replace(Regex("\\[!\\[[^\\]]*]\\([^)]*\\)]\\([^)]*\\)"), "")
        .replace(Regex("<[^>]+>"), "")
        .replace(Regex("\\[([^\\]]+)]\\([^)]*\\)"), "$1")
        .replace("**", "").replace("__", "").replace("`", "")
        .replace(Regex("\\s+"), " ").trim()

    /** أول فقرتين وصفيتين من README (بلا شارات/صور/كود/جداول). */
    fun readmeIntro(md: String, max: Int = 800): String {
        val paras = ArrayList<String>()
        var cur = StringBuilder()
        var inCode = false
        fun flush() { val t = cleanMd(cur.toString()); if (t.length >= 30) paras.add(t); cur = StringBuilder() }
        for (raw in md.lines()) {
            val l = raw.trim()
            if (l.startsWith("```") || l.startsWith("~~~")) { inCode = !inCode; flush(); continue }
            if (inCode) continue
            if (l.isEmpty() || l.startsWith("#") || l.startsWith("|") || l.startsWith("---") || l.startsWith("===") || l.startsWith("<!--")) { flush(); continue }
            if (Regex("^[-*+]\\s").containsMatchIn(l) || Regex("^\\d+[.)]\\s").containsMatchIn(l)) { flush(); continue }
            cur.append(l).append(' ')
            if (paras.size >= 2) break
        }
        flush()
        val text = paras.take(2).joinToString("\n\n")
        return if (text.length <= max) text else text.take(max).substringBeforeLast(' ') + "…"
    }

    /** نقاط الميزات: الأسطر تحت عنوان فيه Features/ميزات… (حتى 10). */
    fun readmeFeatures(md: String): List<String> {
        val out = ArrayList<String>()
        var on = false
        val head = Regex("^#{1,4}\\s*.*(features?|ميزات|مميزات|functionalit|highlights|capabilit|what it does|fonctionnalit).*$", RegexOption.IGNORE_CASE)
        for (raw in md.lines()) {
            val l = raw.trimEnd()
            if (l.trimStart().startsWith("#")) { on = head.matches(l.trim()); continue }
            if (!on) continue
            val m = Regex("^\\s*[-*+]\\s+(.+)$").find(l) ?: continue
            val t = cleanMd(m.groupValues[1])
            if (t.length >= 4) out.add(t.take(140))
            if (out.size >= 10) break
        }
        return out
    }

    private fun readmeOf(top: File): String {
        val f = top.listFiles()?.firstOrNull { it.isFile && it.name.lowercase().startsWith("readme") } ?: return ""
        return readCapped(f, 40_000)
    }

    /** يقرا الحقائق من المشروع المفكوك (كلشي بالـ regex، بلا تنفيذ أي كود). */
    fun collectFacts(top: File, root: File, app: File?): Facts {
        val mod = app ?: root
        val gradleApp = gradleText(mod)
        val gradleRoot = gradleText(root)
        val toml = File(root, "gradle/libs.versions.toml").takeIf { it.isFile }?.let { readCapped(it) }.orEmpty()
        val allGradle = gradleApp + "\n" + gradleRoot + "\n" + toml
        val manifestFile = File(mod, "src/main/AndroidManifest.xml")
        val manifest = if (manifestFile.isFile) readCapped(manifestFile, 200_000) else ""

        val pkg = firstGroup(Regex("""applicationId\s*=?\s*["']([^"']+)["']"""), gradleApp)
            ?: firstGroup(Regex("""namespace\s*=?\s*["']([^"']+)["']"""), gradleApp)
            ?: firstGroup(Regex("""package\s*=\s*"([^"]+)""""), manifest)
        fun sdk(vararg names: String): String? {
            for (n in names) firstGroup(Regex("""\b$n\s*=?\s*(\d{2})\b"""), gradleApp)?.let { return it }
            return null
        }
        val vName = firstGroup(Regex("""versionName\s*=?\s*["']([^"']+)["']"""), gradleApp)
        val vCode = firstGroup(Regex("""versionCode\s*=?\s*(\d+)"""), gradleApp)

        val strings = File(mod, "src/main/res/values/strings.xml").takeIf { it.isFile }?.let { readCapped(it, 200_000) }.orEmpty()
        val label = firstGroup(Regex("""<string\s+name="app_name"[^>]*>([^<]*)</string>"""), strings)?.trim()

        val agp = firstGroup(Regex("""com\.android\.tools\.build:gradle:([\d.]+)"""), allGradle)
            ?: versionOf(allGradle, "agp", "androidGradlePlugin", "android-gradle-plugin")
            ?: firstGroup(Regex("""com\.android\.application["']\)?\s*version\s*["']([\d.]+)["']"""), allGradle)
        val kotlin = versionOf(allGradle, "kotlin", "kotlinVersion", "kotlin_version")
            ?: firstGroup(Regex("""org\.jetbrains\.kotlin\.android["']\)?\s*version\s*["']([\d.]+)["']"""), allGradle)
        val wrapper = File(root, "gradle/wrapper/gradle-wrapper.properties").takeIf { it.isFile }?.let { readCapped(it, 10_000) }.orEmpty()
        val gradle = firstGroup(Regex("""gradle-([\d.]+)-(?:bin|all)\.zip"""), wrapper)

        val acts = Regex("""<activity[^>]*android:name\s*=\s*"([^"]+)"""").findAll(manifest).map { it.groupValues[1] }.toList()
        var launcher: String? = null
        for (m in Regex("""<activity[\s\S]*?</activity>""").findAll(manifest)) {
            if (m.value.contains("android.intent.category.LAUNCHER")) {
                launcher = firstGroup(Regex("""android:name\s*=\s*"([^"]+)""""), m.value); break
            }
        }
        val perms = Regex("""<uses-permission[^>]*android:name\s*=\s*"([^"]+)"""").findAll(manifest)
            .map { it.groupValues[1].substringAfterLast('.') }.distinct().toList()

        val libs = DEPS.filter { it.first.containsMatchIn(allGradle) }.map { it.second }
        var compose = Regex("""compose\s*=?\s*true|buildFeatures\s*\{[^}]*compose|androidx\.compose""").containsMatchIn(allGradle)

        // عدّ الملفات + الشاشات (Composable *Screen)
        var kt = 0; var java = 0; var xml = 0; var visited = 0
        val screens = LinkedHashSet<String>()
        val reScreen = Regex("""@Composable\s+(?:internal\s+|private\s+|public\s+)?fun\s+([A-Z]\w*Screen\w*)""")
        var scanned = 0
        fun walk(d: File, depth: Int) {
            if (depth > 12 || visited > 20_000) return
            for (k in d.listFiles() ?: return) {
                visited++
                if (k.isDirectory) { if (k.name !in SKIP) walk(k, depth + 1); continue }
                when (k.extension.lowercase()) {
                    "kt" -> {
                        kt++
                        if (scanned < 500 && screens.size < 24) {
                            scanned++
                            val t = readCapped(k, 60_000)
                            if (!compose && t.contains("@Composable")) compose = true
                            for (m in reScreen.findAll(t)) { screens.add(m.groupValues[1]); if (screens.size >= 24) break }
                        }
                    }
                    "java" -> java++
                    "xml" -> xml++
                }
            }
        }
        walk(mod, 0)

        // حزم الكود الأساسية: ننزلو فسلسلة المجلدات الوحيدة حتى نوصلو لتفرّع
        var pkgs: List<String> = emptyList()
        for (srcName in listOf("java", "kotlin")) {
            var d: File? = File(mod, "src/main/$srcName").takeIf { it.isDirectory }
            var guard = 0
            while (d != null && guard++ < 8) {
                val kids = d.listFiles()?.filter { !it.name.startsWith(".") } ?: break
                val dirs = kids.filter { it.isDirectory }
                if (dirs.size == 1 && kids.none { it.isFile }) d = dirs[0] else {
                    pkgs = dirs.map { it.name }.sorted().take(14)
                    break
                }
            }
            if (pkgs.isNotEmpty()) break
        }

        val warns = ArrayList<String>()
        if (Regex("google-services|gms\\.google-services").containsMatchIn(allGradle) &&
            !File(mod, "google-services.json").isFile
        ) warns.add("المشروع كيستعمل Firebase ومافيهش `google-services.json`: الـ build غادي يفشل حتى تحط ملفك أنت.")
        if (Regex("""(?i)(api[_-]?key|secret|token)\s*=""").containsMatchIn(gradleApp) ||
            Regex("""local\.properties""").containsMatchIn(gradleApp)
        ) warns.add("كيقرا مفاتيح/إعدادات من `local.properties` أو متغيرات: تأكد بلي عندك القيم (ماشي موجودة فالمستودع).")
        val compileN = sdk("compileSdk", "compileSdkVersion")
        if (compileN != null && (compileN.toIntOrNull() ?: 0) >= 35) warns.add("compileSdk $compileN: خاصك SDK Platform $compileN فـ AndroidIDE.")
        if (agp != null && (agp.substringBefore('.').toIntOrNull() ?: 0) >= 9) warns.add("AGP $agp جديد: تأكد بلي نسخة Gradle/JDK متوافقة.")

        val readme = readmeOf(top)
        return Facts(
            appName = label, packageName = pkg, versionName = vName, versionCode = vCode,
            minSdk = sdk("minSdk", "minSdkVersion"), targetSdk = sdk("targetSdk", "targetSdkVersion"), compileSdk = compileN,
            agp = agp, kotlin = kotlin, gradle = gradle,
            modules = modulesOf(root).map { it.relativeTo(root).path.replace(File.separatorChar, ':') }.take(20),
            activities = acts.map { it.removePrefix(pkg ?: "\u0000") }.take(20), launcher = launcher?.removePrefix(pkg ?: "\u0000"),
            screens = screens.toList(), permissions = perms, libs = libs, compose = compose,
            ktFiles = kt, javaFiles = java, xmlFiles = xml, packages = pkgs, warnings = warns,
            readmeIntro = readmeIntro(readme), features = readmeFeatures(readme)
        )
    }

    /** ملف المواصفات (Markdown) بالعربية: شنو التطبيق، شنو كيدير، التقنيات، الأذونات، وكيفاش نبنيه. */
    fun renderSpec(repo: Repo, f: Facts, date: String): String {
        val sb = StringBuilder()
        val title = f.appName?.takeIf { it.isNotBlank() } ?: repo.name
        sb.append("# ").append(title).append(" — مواصفات المشروع\n\n")
        sb.append("> ولّدها زليج تلقائيا من الكود (بلا تنفيذ) · ").append(date)
            .append(" · المصدر: ").append(repo.url).append("\n\n")

        sb.append("## شنو هاد التطبيق؟\n\n")
        if (repo.description.isNotBlank()) sb.append(repo.description).append("\n\n")
        if (f.readmeIntro.isNotBlank()) sb.append(f.readmeIntro).append("\n\n")
        if (repo.description.isBlank() && f.readmeIntro.isBlank()) sb.append("ما لقيتش وصف فالمستودع ولا فـ README.\n\n")

        if (f.features.isNotEmpty()) {
            sb.append("## شنو كيدير؟ (من README)\n\n")
            f.features.forEach { sb.append("- ").append(it).append('\n') }
            sb.append('\n')
        }
        if (f.launcher != null || f.screens.isNotEmpty() || f.activities.isNotEmpty()) {
            sb.append("## الشاشات\n\n")
            f.launcher?.let { sb.append("- **").append(it).append("** — الشاشة الأولى اللي كتتفتح (Launcher)\n") }
            f.activities.filter { it != f.launcher }.take(12).forEach { sb.append("- ").append(it).append('\n') }
            if (f.screens.isNotEmpty()) {
                sb.append("- شاشات Compose: ").append(f.screens.joinToString("، ") { "`$it`" }).append('\n')
            }
            sb.append('\n')
        }
        if (f.permissions.isNotEmpty()) {
            sb.append("## الأذونات\n\n")
            f.permissions.forEach { p ->
                val g = PERMS[p]
                sb.append("- `").append(p).append('`')
                if (g != null) sb.append(" — ").append(g)
                sb.append('\n')
            }
            sb.append('\n')
        }

        sb.append("## معلومات تقنية\n\n")
        sb.append("| | |\n|---|---|\n")
        fun row(k: String, v: String?) { if (!v.isNullOrBlank()) sb.append("| ").append(k).append(" | ").append(v).append(" |\n") }
        row("Package", f.packageName?.let { "`$it`" })
        row("النسخة", listOfNotNull(f.versionName, f.versionCode?.let { "($it)" }).joinToString(" ").ifBlank { null })
        row("minSdk / targetSdk / compileSdk", listOfNotNull(f.minSdk, f.targetSdk, f.compileSdk).takeIf { it.isNotEmpty() }?.joinToString(" / "))
        val total = (f.ktFiles + f.javaFiles).coerceAtLeast(1)
        row("اللغة", buildString {
            if (f.ktFiles > 0) append("Kotlin ${f.ktFiles * 100 / total}% (${f.ktFiles} ملف)")
            if (f.javaFiles > 0) { if (isNotEmpty()) append(" · "); append("Java ${f.javaFiles * 100 / total}% (${f.javaFiles} ملف)") }
        }.ifBlank { repo.language.ifBlank { null } })
        row("الواجهة", if (f.compose) "Jetpack Compose" + (if (f.xmlFiles > 0) " (+ ${f.xmlFiles} ملف XML)" else "") else "XML Views (${f.xmlFiles} ملف XML)")
        row("Build", listOfNotNull(f.agp?.let { "AGP $it" }, f.kotlin?.let { "Kotlin $it" }, f.gradle?.let { "Gradle $it" }).takeIf { it.isNotEmpty() }?.joinToString(" · "))
        row("الوحدات", f.modules.takeIf { it.isNotEmpty() }?.joinToString("، ") { "`$it`" })
        row("الرخصة", repo.license.ifBlank { null })
        row("النجوم", compact(repo.stars) + " ⭐")
        if (repo.topics.isNotEmpty()) row("Topics", repo.topics.take(10).joinToString("، "))
        sb.append('\n')

        if (f.libs.isNotEmpty()) {
            sb.append("## التقنيات والمكتبات\n\n")
            f.libs.forEach { sb.append("- ").append(it).append('\n') }
            sb.append('\n')
        }
        if (f.packages.isNotEmpty()) {
            sb.append("## هيكل الكود\n\n")
            sb.append(f.packages.joinToString("، ") { "`$it/`" }).append("\n\n")
        }

        sb.append("## كيفاش نبنيه فزليج\n\n")
        sb.append("1. افتح المشروع فالمحرر (تفتح تلقائيا بعد التنزيل) وانتظر مزامنة Gradle.\n")
        sb.append("2. دوز على ▶ فالشريط العلوي باش يبني ويثبّت التطبيق (Debug).\n")
        sb.append("3. إلا فشل: افتح الترمنال، وبطاقة «فشل البناء» كتعاون الذكاء يصلّح الأخطاء.\n\n")
        if (f.warnings.isNotEmpty()) {
            sb.append("## نقاط انتباه\n\n")
            f.warnings.forEach { sb.append("- ").append(it).append('\n') }
            sb.append('\n')
        }
        sb.append("---\nهاد الملف مولّد بالقواعد من الكود والـ manifest والـ README؛ إلا بغيتي شرح أعمق، طلب من الذكاء «اشرح هيكل المشروع».\n")
        return sb.toString()
    }

    // ------------------------------------------------------------------ download + install (الشبكة كتجي من `fetch` باش نختبروه)
    sealed class Outcome {
        class Ok(val dir: File, val specFile: File?, val files: Int) : Outcome()
        /** نزل لكن ماشي تطبيق أندرويد: المجلد المؤقت كيبقى حتى يقرر المستعمل. */
        class NotApp(val tmp: File, val reason: String, val files: Int) : Outcome()
    }

    /**
     * ينزّل zip (عبر `fetch`)، يفكّو فمجلد مؤقت مخفي داخل projectsDir، يتحقق بلي تطبيق أندرويد، ثم يحطّو فمجلد نهائي باسم المستودع.
     * إلا الـ Gradle root داخل مجلد فرعي (android/ مثلا) كيرفعو للأعلى. `withSpec` ← كيكتب SPEC.md فالجذر.
     */
    fun install(
        repo: Repo,
        projectsDir: File,
        withSpec: Boolean,
        date: String,
        fetch: (String) -> InputStream,
        progress: (Int, Long) -> Unit
    ): Outcome {
        projectsDir.mkdirs()
        cleanStale(projectsDir)
        val tmp = File(projectsDir, ".zl-dl-" + System.nanoTime())
        try {
            val files = fetch(zipUrl(repo)).use { extractZip(it, tmp, true, MAX_BYTES, MAX_FILES, progress) }
            if (files == 0) throw IllegalStateException("الـ zip فارغ")
            val det = detectAndroidApp(tmp)
            if (!det.isApp) return Outcome.NotApp(tmp, det.reason, files)
            return finish(repo, projectsDir, tmp, det, withSpec, date, files)
        } catch (t: Throwable) {
            tmp.deleteRecursively()
            throw t
        }
    }

    /** كيمسح بقايا تنزيلات قديمة (التطبيق تسدّ وسط التنزيل). */
    fun cleanStale(projectsDir: File, olderThanMs: Long = 60L * 60 * 1000, now: Long = System.currentTimeMillis()) {
        projectsDir.listFiles()?.forEach {
            if (it.isDirectory && it.name.startsWith(".zl-dl-") && now - it.lastModified() > olderThanMs) it.deleteRecursively()
        }
    }

    /** يكمّل التثبيت من مجلد مؤقت مفكوك (كيستعمل حتى مللي المستعمل يقرر يحتفظ بمشروع ماشي تطبيق). */
    fun finish(repo: Repo, projectsDir: File, tmp: File, det: Detection, withSpec: Boolean, date: String, files: Int): Outcome {
        val root = det.root ?: tmp
        val spec = if (withSpec) {
            try { renderSpec(repo, collectFacts(tmp, root, det.app), date) } catch (t: Throwable) { null }
        } else null
        val dest = uniqueDir(projectsDir, safeName(repo.name))
        if (root == tmp) {
            if (!tmp.renameTo(dest)) { tmp.copyRecursively(dest, true); tmp.deleteRecursively() }
        } else {
            if (!root.renameTo(dest)) root.copyRecursively(dest, true)
            tmp.deleteRecursively()
        }
        var specFile: File? = null
        if (spec != null) {
            val sf = if (File(dest, "SPEC.md").exists()) File(dest, "ZELLIGE_SPEC.md") else File(dest, "SPEC.md")
            sf.writeText(spec)
            specFile = sf
        }
        return Outcome.Ok(dest, specFile, files)
    }
}
