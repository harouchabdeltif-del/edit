package com.itsaky.androidide.ai

import android.app.Activity
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.StateListDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.RelativeLayout
import android.widget.TextView
import java.io.File
import java.lang.ref.WeakReference
import java.util.WeakHashMap

/**
 * هيكل المحرر بتصميم C5، كله وقت التشغيل فوق شاشة AndroidIDE الأصلية (ما كنبدلو لا layout ولا كود):
 *
 *  1. شريط علوي 48dp: ☰ · اسم الملف + «المشروع · الموديل» · زر الذكاء · ▶ تشغيل · تراجع · ⋮  (الأزرار كتشغّل نفس actions الأصلية)
 *  2. تبويبات الملفات 36dp: نقطة، حد عنبري فوق التبويب النشط، × للإغلاق
 *  3. شاشة المحرر الفارغة: بدل «Open the left drawer…» أزرار (الملفات / الذكاء / المخرجات) + آخر الملفات
 *  4. الشريط السفلي: شريط الرموز + تبويبات المخرجات/السجلات/المشاكل(عدد)/الذكاء + شريط حالة 24dp (سطر:عمود · لغة · UTF-8 · LF · فرع git · عدد المشاكل)
 *
 * كل خطوة معزولة بـ try/catch: إلا فشلت وحدة، كتبقى الأصلية فمكانها خدّامة.
 */
object EditorShell {

    private const val TOP_TAG = "zl_top"
    private const val STATUS_TAG = "zl_status"
    private const val EMPTY_TAG = "zl_empty"
    private const val EXTRA_TAG = "zl_sheet_extra"
    private const val HEADER_DP = 40      // شريط الرموز / حالة البناء
    private const val TABS_DP = 52
    private const val STATUS_DP = 24

    private const val ACTION_RUN = "ide.editor.build.quickRun"
    private const val ACTION_UNDO = "ide.editor.code.text.undo"
    private val ui = Handler(Looper.getMainLooper())

    // INDICATOR_GRAVITY_* من TabLayout
    private const val GRAVITY_TOP = 2
    private const val GRAVITY_STRETCH = 3

    private class S(val a: Activity) {
        var top: LinearLayout? = null
        var title: TextView? = null
        var sub: TextView? = null
        var run: ImageView? = null
        var undo: ImageView? = null
        var empty: LinearLayout? = null
        var emptyList: LinearLayout? = null
        var emptyAt = 0L
        var emptyBusy = false
        var emptySig = ""
        var status: LinearLayout? = null
        var stLeft: TextView? = null
        var stRight: TextView? = null
        var extra: LinearLayout? = null
        var tick: Runnable? = null
        // مراجع الشيت (كنحفظوها باش ما نقلّبوش بالاسم فكل tick)
        var sheet: ViewGroup? = null
        var rel: ViewGroup? = null
        var header: View? = null
        var tabsV: ViewGroup? = null
        var cover: View? = null
        var beh: Any? = null
        var navInset = 0
        var state = 4
        var cbOn = false
        var inGeometry = false
        var lastFile: String = ""
        var eol = "LF"
        var branch: String? = null
        var branchRoot: String = ""
        var branchAt = 0L
        var diagRef: WeakReference<View>? = null
        var diagAt = 0L
        var problems = 0
        var badgeN = -1
        var probAt = 0L
        var probSig = -1
        var running = false
        var rootCache: File? = null
        var rootAt = 0L
    }

    private var cur: S? = null

    // ------------------------------------------------------------------ lifecycle
    fun install(a: Activity) {
        val s = cur?.takeIf { it.a === a } ?: S(a).also { cur = it }
        step("top") { topBar(s) }
        step("tabs") { fileTabs(s) }
        step("empty") { emptyState(s) }
        step("sheet") { sheet(s) }
        s.tick?.let { ui.removeCallbacks(it) }
        val r = object : Runnable {
            override fun run() {
                if (cur !== s) return
                step("tick") { tick(s) }
                ui.postDelayed(this, 500)
            }
        }
        s.tick = r
        ui.post(r)
    }

    fun stop() { cur?.tick?.let { ui.removeCallbacks(it) }; cur?.tick = null }
    fun destroyed(a: Activity) { if (cur?.a === a) { stop(); cur = null } }

    private fun step(name: String, f: () -> Unit) {
        try { f() } catch (t: Throwable) { /* $name: الأصلية كتبقى */ }
    }

    // ------------------------------------------------------------------ 1. top bar
    private fun topBar(s: S) {
        val a = s.a
        val appbar = Con.find<ViewGroup>(a, "editor_appBarLayout") ?: return
        if (s.top?.parent === appbar) return
        appbar.findViewWithTag<View>(TOP_TAG)?.let { appbar.removeView(it) }
        val p = Con.pal(a)
        val mono = Con.mono(a)
        fun dp(v: Int) = Con.dp(a, v)

        val bar = LinearLayout(a).apply {
            tag = TOP_TAG
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(p.page)
            setPadding(dp(4), 0, dp(6), 0)
        }
        bar.addView(Con.squareButton(a, "zl_ic_menu", "الملفات", p.dim, 0, 0, 40, 40, 10, 22) { openDrawer(a) })

        val block = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL }
        val title = Con.text(a, "Zellige", 13.5f, p.text, Typeface.create(mono, Typeface.NORMAL)).apply {
            setSingleLine(); ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
            textDirection = View.TEXT_DIRECTION_LTR; textAlignment = View.TEXT_ALIGNMENT_VIEW_START
        }
        val sub = Con.text(a, "", 10.5f, p.muted, mono).apply {
            setSingleLine(); ellipsize = android.text.TextUtils.TruncateAt.END
            textDirection = View.TEXT_DIRECTION_LTR; textAlignment = View.TEXT_ALIGNMENT_VIEW_START
        }
        block.addView(title)
        block.addView(sub, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(1) })
        bar.addView(block, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(4); marginEnd = dp(6) })

        bar.addView(Con.squareButton(a, "zl_ic_sparkle", "الذكاء", p.amber, 0, p.amber, 36, 36, 9, 18) { AiChat.open(a, null, false) })
        val run = Con.squareButton(a, "zl_ic_play", "تشغيل", p.onAmber, p.amber, 0, 36, 36, 9, 19) { trigger(a, ACTION_RUN) }
        (run.layoutParams as LinearLayout.LayoutParams).apply { marginStart = dp(4); marginEnd = dp(4) }
        bar.addView(run)
        val undo = Con.squareButton(a, "zl_ic_undo", "تراجع", p.dim, 0, 0, 34, 36, 9, 19) { trigger(a, ACTION_UNDO) }
        bar.addView(undo)
        bar.addView(Con.squareButton(a, "zl_ic_more", "المزيد", p.dim, 0, 0, 30, 36, 9, 18) { v -> overflow(a, v) })

        appbar.addView(bar, 0, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)))
        appbar.addView(Con.hairline(a, p.line), 1, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1).coerceAtLeast(1)))
        // الـ toolbar الأصلي كيبقى فالمكان (actions ديالو هي اللي كنشغّلو) ولكن مخبّي
        Con.find<View>(a, "editor_toolbar")?.visibility = View.GONE
        s.top = bar; s.title = title; s.sub = sub; s.run = run; s.undo = undo
        updateTitle(s, null)
    }

    private fun openDrawer(a: Activity) {
        Con.call(Con.find<View>(a, "editor_drawerLayout"), "openDrawer", Gravity.START)
    }

    private fun toolbarMenu(a: Activity): Menu? = Con.call(Con.find<View>(a, "editor_toolbar"), "getMenu") as? Menu

    /**
     * يشغّل action الأصلي (بنفس المعرّف اللي كيستعملو AndroidIDE: id.hashCode()).
     * مهم: عناصر القائمة عندها OnMenuItemClickListener ديالها (ActionsRegistry.fillMenu) ولا كاين حتى override لـ onOptionsItemSelected،
     * فالنداء الصحيح هو `menu.performIdentifierAction` (هو اللي كيعيّط المستمع). النداء القديم لـ onOptionsItemSelected ما كان كيدير والو.
     */
    private fun trigger(a: Activity, actionId: String) {
        val menu = toolbarMenu(a)
        val item = menu?.findItem(actionId.hashCode())
        if (menu == null || item == null) {
            a.invalidateOptionsMenu()                       // القائمة ما تعمّراتش بعد (المشروع كيتحمّل)
            android.widget.Toast.makeText(a, "المشروع كيتحضّر… عاود بعد ثواني", android.widget.Toast.LENGTH_SHORT).show()
            return
        }
        if (!item.isEnabled) {
            android.widget.Toast.makeText(a, "غير متاح دابا", android.widget.Toast.LENGTH_SHORT).show()
            return
        }
        menu.performIdentifierAction(item.itemId, 0)
    }

    private fun overflow(a: Activity, anchor: View) {
        val src = toolbarMenu(a) ?: return
        val pm = PopupMenu(a, anchor)
        val skip = setOf(ACTION_RUN.hashCode(), ACTION_UNDO.hashCode())
        fun fill(from: Menu, to: Menu) {
            for (i in 0 until from.size()) {
                val it = from.getItem(i)
                if (!it.isVisible || it.title.isNullOrBlank() || it.itemId in skip) continue
                if (it.hasSubMenu()) {
                    val sm = to.addSubMenu(0, it.itemId, i, it.title)
                    fill(it.subMenu!!, sm)
                } else {
                    to.add(0, it.itemId, i, it.title).isEnabled = it.isEnabled
                }
            }
        }
        fill(src, pm.menu)
        pm.menu.add(0, 9001, 999, "إعدادات الذكاء")
        pm.setOnMenuItemClickListener { m ->
            if (m.itemId == 9001) AiChat.showSettings(a)
            else src.performIdentifierAction(m.itemId, 0)
            true
        }
        pm.show()
    }

    /** جذر المشروع النشط (مخبّأ 5 ثواني: activeRoot فيه reflection). */
    private fun activeRoot(s: S): File? {
        val now = System.currentTimeMillis()
        if (now - s.rootAt > 5000) {
            s.rootAt = now
            s.rootCache = runCatching { AiIde.activeRoot(s.a, null) }.getOrNull()
        }
        return s.rootCache
    }

    private fun updateTitle(s: S, ed: EditorAccess?) {
        val f = ed?.file()
        val root = (if (f != null) AiIde.gradleRootOfCached(f) else null) ?: activeRoot(s)
        Con.setTextIfChanged(s.title, f?.name ?: (root?.name ?: "Zellige"))
        val module = if (f != null && root != null) ConsoleLogic.moduleOf(root, f) else null
        Con.setTextIfChanged(s.sub, when {
            f == null -> "لا ملف مفتوح"
            root == null -> f.parentFile?.name.orEmpty()
            module != null -> "${root.name} · $module"
            else -> root.name
        })
    }

    // ------------------------------------------------------------------ 2. file tabs
    private fun fileTabs(s: S) {
        val a = s.a
        val appbar = Con.find<ViewGroup>(a, "editor_appBarLayout") ?: return
        val tabs = Con.find<ViewGroup>(appbar, a, "tabs") ?: return
        if (Con.seen(tabs, "ft")) return
        val p = Con.pal(a)
        tabs.setBackgroundColor(p.bar)
        tabs.layoutParams?.let { it.height = Con.dp(a, 36); tabs.layoutParams = it }
        Con.call(tabs, "setSelectedTabIndicator", ColorDrawable(Color.TRANSPARENT))
        Con.call(tabs, "setSelectedTabIndicatorColor", Color.TRANSPARENT)
        Con.call(tabs, "setTabRippleColor", null)
        val idx = appbar.indexOfChild(tabs)
        appbar.addView(Con.hairline(a, p.line), idx + 1, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Con.dp(a, 1).coerceAtLeast(1)))
    }

    private fun stateful(sel: Int, normal: Int): ColorStateList =
        ColorStateList(arrayOf(intArrayOf(android.R.attr.state_selected), intArrayOf()), intArrayOf(sel, normal))

    private fun dotColor(p: Con.P, name: String): Int = when (name.removePrefix("*").substringAfterLast('.', "").lowercase()) {
        "xml" -> p.green
        "kts", "gradle" -> p.blue
        "java" -> p.orange
        "kt" -> p.purple
        "json", "md", "txt" -> p.muted
        else -> p.dim
    }

    private fun fileTabView(s: S, tab: Any?): View {
        val a = s.a
        val p = Con.pal(a)
        fun dp(v: Int) = Con.dp(a, v)
        val name = (Con.call(tab, "getText") as? CharSequence)?.toString().orEmpty()
        val cell = LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            minimumHeight = dp(36)
            setPadding(dp(12), 0, dp(8), 0)
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            val on = LayerDrawable(arrayOf<Drawable>(ColorDrawable(p.page), ColorDrawable(p.amber))).also {
                it.setLayerGravity(1, Gravity.TOP); it.setLayerHeight(1, dp(2))
            }
            val off = LayerDrawable(arrayOf<Drawable>(ColorDrawable(p.bar), ColorDrawable(p.line))).also {
                it.setLayerGravity(1, Gravity.END); it.setLayerWidth(1, dp(1).coerceAtLeast(1))
            }
            background = StateListDrawable().apply {
                addState(intArrayOf(android.R.attr.state_selected), on)
                addState(intArrayOf(), off)
            }
        }
        val dot = View(a).apply {
            background = StateListDrawable().apply {
                addState(intArrayOf(android.R.attr.state_selected), GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(p.amber) })
                addState(intArrayOf(), GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(dotColor(p, name)) })
            }
        }
        cell.addView(dot, LinearLayout.LayoutParams(dp(6), dp(6)).apply { marginEnd = dp(7) })
        cell.addView(TextView(a).apply {
            id = android.R.id.text1
            textSize = 12f; setSingleLine(); includeFontPadding = false
            isAllCaps = false
            setTextColor(stateful(p.text, p.muted))
            textDirection = View.TEXT_DIRECTION_LTR
        })
        val close = ImageView(a).apply {
            val ic = Con.icon(a, "zl_ic_close", p.muted)
            setImageDrawable(StateListDrawable().apply {
                if (ic != null) addState(intArrayOf(android.R.attr.state_selected), ic)
                addState(intArrayOf(), ColorDrawable(Color.TRANSPARENT))
            })
            setPadding(dp(2), dp(2), dp(2), dp(2))
            isClickable = true
            setOnClickListener {
                if (!cell.isSelected) return@setOnClickListener
                val pos = (Con.call(tab, "getPosition") as? Int) ?: return@setOnClickListener
                Con.call(s.a, "closeFile", pos, { })
            }
        }
        cell.addView(close, LinearLayout.LayoutParams(dp(18), dp(18)).apply { marginStart = dp(6) })
        return cell
    }

    private fun customizeFileTabs(s: S) {
        val a = s.a
        val appbar = Con.find<ViewGroup>(a, "editor_appBarLayout") ?: return
        val tabs = Con.find<ViewGroup>(appbar, a, "tabs") ?: return
        val n = (Con.call(tabs, "getTabCount") as? Int) ?: return
        for (i in 0 until n) {
            val tab = Con.call(tabs, "getTabAt", i) ?: continue
            if (Con.call(tab, "getCustomView") != null) continue
            Con.call(tab, "setCustomView", fileTabView(s, tab))
            (Con.field(tab, "view") as? View)?.let { it.setPadding(0, 0, 0, 0); it.minimumHeight = 0 }
        }
    }

    // ------------------------------------------------------------------ 3. empty state
    private fun emptyState(s: S) {
        val a = s.a
        val title = Con.find<View>(a, "no_editor_title") ?: return
        val parent = title.parent as? ViewGroup ?: return
        if (s.empty?.parent === parent) return
        parent.findViewWithTag<View>(EMPTY_TAG)?.let { parent.removeView(it) }
        val p = Con.pal(a)
        val mono = Con.mono(a)
        fun dp(v: Int) = Con.dp(a, v)

        val col = LinearLayout(a).apply {
            tag = EMPTY_TAG
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(p.page)
            setPadding(dp(20), dp(36), dp(20), dp(24))
            isClickable = true
        }
        col.addView(Con.iconView(a, "zl_ic_star8", p.amber, 34))
        col.addView(Con.text(a, "Zellige", 20f, p.text, mono, true), LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(12) })
        col.addView(Con.text(a, "افتح ملفا من الدرج، أو اطلب من الذكاء.", 13f, p.muted).apply { gravity = Gravity.CENTER },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6) })

        val chips = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        fun chip(icon: String, label: String, accent: Boolean, f: () -> Unit): View = LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), 0, dp(14), 0)
            background = Con.ripple(
                if (accent) Con.rounded(p.amber, Con.dpf(a, 9f)) else Con.rounded(Color.TRANSPARENT, Con.dpf(a, 9f), p.border, dp(1)),
                Con.dpf(a, 9f)
            )
            isClickable = true; isFocusable = true
            setOnClickListener { f() }
            addView(Con.iconView(a, icon, if (accent) p.onAmber else p.dim, 16))
            addView(Con.text(a, label, 12.5f, if (accent) p.onAmber else p.text2, null, accent), LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginStart = dp(7) })
        }
        fun lp() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(38)).apply { marginStart = dp(4); marginEnd = dp(4) }
        chips.addView(chip("zl_ic_menu", "الملفات", false) { openDrawer(a) }, lp())
        chips.addView(chip("zl_ic_sparkle", "الذكاء", true) { AiChat.open(a, null, false) }, lp())
        chips.addView(chip("zl_ic_terminal", "المخرجات", false) { expandSheet(a) }, lp())
        col.addView(chips, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(20) })

        val recentHead = Con.text(a, "آخر الملفات", 10.5f, p.faint, mono).apply {
            textAlignment = View.TEXT_ALIGNMENT_VIEW_START
            letterSpacing = 0.08f
        }
        col.addView(recentHead, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(30); marginStart = dp(4) })
        col.addView(Con.hairline(a, p.line), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1).coerceAtLeast(1)).apply { topMargin = dp(8) })
        val list = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        col.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        parent.addView(col, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        title.visibility = View.GONE
        Con.find<View>(a, "no_editor_summary")?.visibility = View.GONE
        s.empty = col; s.emptyList = list; s.emptyAt = 0
    }

    private fun behavior(sheet: View): Any? = try {
        Class.forName("com.google.android.material.bottomsheet.BottomSheetBehavior").getMethod("from", View::class.java).invoke(null, sheet)
    } catch (t: Throwable) { null }

    private fun behavior(s: S): Any? {
        s.beh?.let { return it }
        val sh = s.sheet ?: Con.find<View>(s.a, "bottom_sheet") ?: return null
        return behavior(sh).also { s.beh = it }
    }

    private fun expandSheet(a: Activity) {
        val sheet = Con.find<View>(a, "bottom_sheet") ?: return
        Con.call(behavior(sheet), "setState", 3)    // STATE_EXPANDED
    }

    private fun badgeColor(p: Con.P, ext: String): Int = when (ext) {
        "kt" -> p.purple; "xml" -> p.blue; "kts", "gradle" -> p.green; "java" -> p.orange; else -> p.muted
    }

    private fun refreshEmpty(s: S) {
        val col = s.empty ?: return
        val list = s.emptyList ?: return
        if (!col.isShown || s.emptyBusy) return
        val now = System.currentTimeMillis()
        if (now - s.emptyAt < 6000) return
        s.emptyAt = now
        val root = activeRoot(s)
        s.emptyBusy = true
        // مشي المجلدات (listFiles/isDirectory) كان كيتدار على الـ UI thread؛ دابا فthread خلفي وكنبدّلو الـ views غير إلا تبدّلات اللائحة
        Thread {
            val files = try { if (root != null && root.isDirectory) ConsoleLogic.recentFiles(root) else emptyList() } catch (t: Throwable) { emptyList() }
            val sig = files.joinToString("|") { it.path + ":" + it.lastModified() }
            ui.post {
                s.emptyBusy = false
                if (cur === s && sig != s.emptySig) { s.emptySig = sig; renderEmpty(s, list, files) }
            }
        }.also { it.isDaemon = true }.start()
    }

    private fun renderEmpty(s: S, list: LinearLayout, files: List<File>) {
        val a = s.a
        val p = Con.pal(a)
        val mono = Con.mono(a)
        fun dp(v: Int) = Con.dp(a, v)
        list.removeAllViews()
        if (files.isEmpty()) {
            list.addView(Con.text(a, "ما كاين حتى ملف بعد.", 12f, p.muted).apply { setPadding(dp(4), dp(12), dp(4), 0) })
            return
        }
        for (f in files) {
            val ext = f.extension.lowercase()
            val row = LinearLayout(a).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                layoutDirection = View.LAYOUT_DIRECTION_LTR
                setPadding(dp(4), 0, dp(4), 0)
                background = Con.ripple(null, 0f)
                isClickable = true; isFocusable = true
                setOnClickListener { Con.call(a, "openFile", f, null) }
            }
            row.addView(Con.text(a, ext.take(3), 10f, badgeColor(p, ext), mono, true).apply { gravity = Gravity.START },
                LinearLayout.LayoutParams(dp(30), ViewGroup.LayoutParams.WRAP_CONTENT))
            row.addView(Con.text(a, f.name, 13f, p.text2).apply { setSingleLine(); ellipsize = android.text.TextUtils.TruncateAt.MIDDLE },
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(Con.text(a, f.parentFile?.name.orEmpty(), 10.5f, p.faint, mono).apply {
                setSingleLine(); ellipsize = android.text.TextUtils.TruncateAt.START
            }, LinearLayout.LayoutParams(dp(96), ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginStart = dp(8) })
            list.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(40)))
            list.addView(Con.hairline(a, p.line))
        }
    }

    // ------------------------------------------------------------------ 4. bottom: symbols + tabs + status
    private val TITLES = mapOf(
        "Build output" to "المخرجات", "App Logs" to "السجلات", "IDE Logs" to "سجل IDE",
        "Diagnostics" to "المشاكل", "Search results" to "البحث"
    )

    private fun sheet(s: S) {
        val a = s.a
        val sheet = Con.find<ViewGroup>(a, "bottom_sheet") ?: return
        val pager = Con.find<View>(sheet, a, "pager") ?: return
        val rel = pager.parent as? RelativeLayout ?: return
        val tabs = Con.find<ViewGroup>(rel, a, "tabs") ?: return
        if (s.status?.parent === rel) return
        rel.findViewWithTag<View>(STATUS_TAG)?.let { rel.removeView(it) }
        rel.findViewWithTag<View>(EXTRA_TAG)?.let { rel.removeView(it) }
        val p = Con.pal(a)
        val mono = Con.mono(a)
        fun dp(v: Int) = Con.dp(a, v)

        // ---- شريط الحالة 24dp بين التبويبات والمحتوى
        val status = LinearLayout(a).apply {
            tag = STATUS_TAG
            id = View.generateViewId()
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            background = LayerDrawable(arrayOf<Drawable>(ColorDrawable(p.bar), ColorDrawable(p.line))).also {
                it.setLayerGravity(1, Gravity.TOP); it.setLayerHeight(1, dp(1).coerceAtLeast(1))
            }
            setPadding(dp(10), 0, dp(10), 0)
        }
        val left = Con.text(a, "—", 10.5f, p.muted, mono).apply { setSingleLine(); ellipsize = android.text.TextUtils.TruncateAt.END }
        val right = Con.text(a, "● 0", 10.5f, p.muted, mono).apply { setSingleLine() }
        status.addView(left, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        status.addView(right)
        val slp = RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(24))
        slp.addRule(RelativeLayout.BELOW, tabs.id)
        rel.addView(status, slp)
        (pager.layoutParams as? RelativeLayout.LayoutParams)?.let { it.addRule(RelativeLayout.BELOW, status.id); pager.layoutParams = it }

        // ---- «الذكاء» + ⋮ فنهاية صف التبويبات
        val extra = LinearLayout(a).apply {
            tag = EXTRA_TAG
            id = View.generateViewId()
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(p.bar)
            setPadding(dp(2), 0, dp(6), 0)
        }
        extra.addView(LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), 0, dp(10), 0)
            background = Con.ripple(null, Con.dpf(a, 7f))
            isClickable = true; isFocusable = true
            setOnClickListener { AiChat.open(a, null, false) }
            addView(Con.iconView(a, "zl_ic_sparkle", p.amber, 13))
            addView(Con.text(a, "الذكاء", 12.5f, p.amber), LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginStart = dp(6) })
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(34)))
        extra.addView(Con.squareButton(a, "zl_ic_more", "المزيد", p.muted, 0, 0, 34, 34, 8, 20) { v -> sheetMenu(a, v) })
        val elp = RelativeLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(52))
        elp.addRule(RelativeLayout.ALIGN_TOP, tabs.id)
        elp.addRule(RelativeLayout.ALIGN_PARENT_END)
        rel.addView(extra, elp)

        // ---- تبويبات الشيت
        tabs.setBackgroundColor(p.bar)
        (tabs.layoutParams as? RelativeLayout.LayoutParams)?.let {
            it.height = dp(52); it.addRule(RelativeLayout.START_OF, extra.id); tabs.layoutParams = it
        }
        Con.call(tabs, "setSelectedTabIndicator", ColorDrawable(Color.TRANSPARENT))
        Con.call(tabs, "setSelectedTabIndicatorColor", Color.TRANSPARENT)
        Con.call(tabs, "setTabRippleColor", null)

        // ---- شريط حافة النظام (كيغطي منطقة الـ gesture bar تحت الحالة فقط وقت الشيت مطوي)
        val cover = View(a).apply {
            id = View.generateViewId()
            setBackgroundColor(p.bar)
            visibility = View.GONE
        }
        val clp = RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0)
        clp.addRule(RelativeLayout.BELOW, status.id)
        rel.addView(cover, clp)
        (pager.layoutParams as? RelativeLayout.LayoutParams)?.let { it.addRule(RelativeLayout.BELOW, cover.id); pager.layoutParams = it }

        // ---- الهيدر (شريط الرموز / حالة البناء)
        Con.find<View>(sheet, a, "header_container")?.setBackgroundColor(p.field)

        s.status = status; s.stLeft = left; s.stRight = right; s.extra = extra; s.cover = cover
        s.sheet = sheet; s.rel = rel; s.header = Con.find(sheet, a, "header_container"); s.tabsV = tabs
        step("tame") { tameOriginal(s) }
        step("headerStyle") { styleHeader(s) }
        step("callback") { watchState(s) }
    }

    /**
     * الشيت الأصلي كيحسب ارتفاع الهيدر من `collapsedHeight` (56dp) + حافة النظام، وكيعاود يكتبو فكل onSlide.
     * فتصميم C5 الهيدر 40dp والحافة كتمشي لشريط تحت الحالة، فكنخلّيوه 40dp وكنصفّرو `windowInsets` ديالو (reflection، وإلا فشل كنصحّحو بالقياس).
     */
    private fun tameOriginal(s: S) {
        val sheet = s.sheet ?: return
        Con.setField(sheet, "collapsedHeight\$delegate", lazyOf(Con.dpf(s.a, HEADER_DP.toFloat())))
        Con.setField(sheet, "windowInsets", null)
    }

    /** حالة البناء فالهيدر: سطر واحد بخط mono (بلا «swipe up» اللي كيدخّل 56dp)، منسجم مع صف التبويبات. */
    private fun styleHeader(s: S) {
        val a = s.a
        val header = s.header as? ViewGroup ?: return
        val bs = Con.find<View>(header, a, "build_status") ?: return
        if (Con.seen(bs, "bs")) return
        val p = Con.pal(a)
        (bs.layoutParams)?.let { it.height = ViewGroup.LayoutParams.MATCH_PARENT; bs.layoutParams = it }
        Con.find<View>(bs, a, "swipe_hint")?.visibility = View.GONE
        (Con.find<View>(bs, a, "statusText") as? TextView)?.apply {
            typeface = Con.mono(a); textSize = 11.5f; setTextColor(p.muted)
            setSingleLine(); ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
        }
    }

    /** مستمع لحالة الشيت: كنصحّحو الهندسة (الهيدر/الشريط/الـ peek) فنفس الإطار اللي كتتبدّل فيه الحالة، بلا وميض. */
    private fun watchState(s: S) {
        if (s.cbOn) return
        val b = behavior(s) as? com.google.android.material.bottomsheet.BottomSheetBehavior<*> ?: return
        b.addBottomSheetCallback(object : com.google.android.material.bottomsheet.BottomSheetBehavior.BottomSheetCallback() {
            override fun onStateChanged(bottomSheet: View, newState: Int) {
                s.state = newState
                step("geo") { geometry(s) }
            }
            override fun onSlide(bottomSheet: View, slideOffset: Float) {}
        })
        s.cbOn = true
    }

    private fun sheetMenu(a: Activity, anchor: View) {
        val pm = PopupMenu(a, anchor)
        pm.menu.add(0, 1, 0, "توسيع / طيّ المخرجات")
        pm.menu.add(0, 2, 1, "إعدادات الذكاء")
        pm.setOnMenuItemClickListener { m ->
            when (m.itemId) {
                1 -> {
                    val sheet = Con.find<View>(a, "bottom_sheet")
                    val b = if (sheet != null) behavior(sheet) else null
                    val st = (Con.call(b, "getState") as? Int) ?: 4
                    Con.call(b, "setState", if (st == 3) 4 else 3)
                }
                2 -> AiChat.showSettings(a)
            }
            true
        }
        pm.show()
    }

    private fun sheetTabView(s: S, tab: Any?, isDiag: Boolean): View {
        val a = s.a
        val p = Con.pal(a)
        val mono = Con.mono(a)
        fun dp(v: Int) = Con.dp(a, v)
        val cell = LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            minimumHeight = dp(34)
            setPadding(dp(12), 0, dp(12), 0)
            background = StateListDrawable().apply {
                addState(intArrayOf(android.R.attr.state_selected), Con.rounded(p.chipHi, Con.dpf(a, 7f)))
                addState(intArrayOf(), ColorDrawable(Color.TRANSPARENT))
            }
        }
        cell.addView(TextView(a).apply {
            id = android.R.id.text1
            textSize = 12.5f; setSingleLine(); includeFontPadding = false
            isAllCaps = false
            setTextColor(stateful(p.amber, p.muted))
        })
        if (isDiag) {
            cell.addView(Con.text(a, "0", 10.5f, p.onRed, mono, true).apply {
                gravity = Gravity.CENTER
                minWidth = dp(17); minHeight = dp(17)
                setPadding(dp(4), 0, dp(4), 0)
                background = Con.rounded(p.red, Con.dpf(a, 5f))
                visibility = View.GONE
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(17)).apply { marginStart = dp(6) })
        }
        return cell
    }

    private fun customizeSheetTabs(s: S) {
        val a = s.a
        val sheet = Con.find<ViewGroup>(a, "bottom_sheet") ?: return
        val pager = Con.find<View>(sheet, a, "pager") ?: return
        val rel = pager.parent as? ViewGroup ?: return
        val tabs = Con.find<ViewGroup>(rel, a, "tabs") ?: return
        val n = (Con.call(tabs, "getTabCount") as? Int) ?: return
        for (i in 0 until n) {
            val tab = Con.call(tabs, "getTabAt", i) ?: continue
            val txt = (Con.call(tab, "getText") as? CharSequence)?.toString().orEmpty()
            val ar = TITLES[txt]
            if (ar != null) Con.call(tab, "setText", ar as CharSequence)
            if (Con.call(tab, "getCustomView") != null) continue
            val diag = txt == "Diagnostics" || txt == "المشاكل"
            Con.call(tab, "setCustomView", sheetTabView(s, tab, diag))
            (Con.field(tab, "view") as? View)?.let { it.setPadding(dp4(a), 0, dp4(a), 0); it.minimumHeight = 0 }
        }
    }

    private fun dp4(a: Activity) = Con.dp(a, 2)

    /** أزرار شريط الرموز: مربعات 32×28 بزوايا 6dp (نفس C5). */
    private fun styleSymbols(s: S) {
        val a = s.a
        val sheet = Con.find<ViewGroup>(a, "bottom_sheet") ?: return
        val sym = Con.find<ViewGroup>(sheet, a, "symbol_input") ?: return
        val p = Con.pal(a)
        val mono = Con.mono(a)
        fun dp(v: Int) = Con.dp(a, v)
        for (i in 0 until sym.childCount) {
            val b = sym.getChildAt(i) as? Button ?: continue
            if (Con.seen(b, "sym")) continue
            b.typeface = mono
            b.textSize = 13.5f
            b.isAllCaps = false
            b.setTextColor(p.dim)
            b.background = Con.ripple(Con.rounded(p.chip, Con.dpf(a, 6f)), Con.dpf(a, 6f))
            b.minWidth = 0; b.minimumWidth = 0; b.minHeight = 0; b.minimumHeight = 0
            b.setPadding(dp(6), 0, dp(6), 0)
            val lp = b.layoutParams as? ViewGroup.MarginLayoutParams ?: continue
            lp.width = ViewGroup.LayoutParams.WRAP_CONTENT
            lp.height = dp(28)
            lp.setMargins(dp(2), dp(6), dp(2), dp(6))
            b.layoutParams = lp
        }
    }

    // ------------------------------------------------------------------ tick
    private fun tick(s: S) {
        val ed = EditorAccess.find(s.a)
        updateTitle(s, ed)
        runState(s)
        customizeFileTabs(s)
        customizeSheetTabs(s)
        styleSymbols(s)
        refreshEmpty(s)
        geometry(s)
        updateStatus(s, ed)
    }

    /** ▶ ↔ ■ حسب مؤشر التقدم ديال البناء؛ وتراجع باهت إلا ما كانش متاح. */
    private fun runState(s: S) {
        val a = s.a
        val p = Con.pal(a)
        val building = Con.find<View>(a, "progress_indicator")?.visibility == View.VISIBLE
        if (building != s.running) {
            s.running = building
            s.run?.setImageDrawable(Con.icon(a, if (building) "zl_ic_stop" else "zl_ic_play"))
            s.run?.imageTintList = ColorStateList.valueOf(p.onAmber)
        }
        val u = toolbarMenu(a)?.findItem(ACTION_UNDO.hashCode())
        s.undo?.alpha = if (u != null && u.isEnabled) 1f else 0.4f
    }

    /** ارتفاع شريط/مؤشر التنقل اللي الشيت كيتداخل معاه فعلاً (0 إلا كانت النافذة ما كتغطّيهش). */
    private fun navInset(s: S, sheet: View): Int {
        @Suppress("DEPRECATION")
        val nav = sheet.rootWindowInsets?.stableInsetBottom ?: 0
        if (nav <= 0) return 0
        return try {
            val rc = Con.find<View>(s.a, "realContainer") ?: return nav
            val loc = IntArray(2)
            rc.getLocationInWindow(loc)
            val gap = (sheet.rootView.height - (loc[1] + rc.height)).coerceAtLeast(0)
            (nav - gap).coerceAtLeast(0)
        } catch (t: Throwable) { nav }
    }

    /**
     * هندسة الشريط السفلي (C5): هيدر 40dp ← تبويبات 52dp ← حالة 24dp ← شريط الحافة (حسب gesture bar).
     * الـ peek = مجموع اللي كيبان؛ والكود (editor_container) كيبقى فوق منو. مللي الكيبورد كيبان (شريط الرموز) كنخبّيو التبويبات والحالة.
     */
    private fun geometry(s: S) {
        if (s.inGeometry) return
        s.inGeometry = true
        try {
            val a = s.a
            val sheet = s.sheet ?: return
            val header = s.header ?: return
            val b = behavior(s) ?: return
            val st = (Con.call(b, "getState") as? Int) ?: s.state
            s.state = st
            val expanded = st == 3
            val typing = (Con.call(header, "getDisplayedChild") as? Int) == 1
            val stack = expanded || !typing
            val vis = if (stack) View.VISIBLE else View.GONE

            // حافة النظام السفلية (stable: ما كتتأثّرش بالكيبورد)
            val inset = if (typing) 0 else navInset(s, sheet)
            s.navInset = inset

            Con.setVisible(s.tabsV, vis); Con.setVisible(s.extra, vis); Con.setVisible(s.status, vis)
            val coverOn = stack && st == 4 && inset > 0
            s.cover?.let { c ->
                Con.setVisible(c, if (coverOn) View.VISIBLE else View.GONE)
                (c.layoutParams)?.let { if (it.height != inset) { it.height = inset; c.layoutParams = it } }
            }

            // الهيدر: مللي الشيت مطوي (أو الكيبورد) كنثبّتو 40dp بلا حشو؛ فالسحب الأصلي هو اللي كيتحكّم
            if (st == 4 || typing) {
                val h = Con.dp(a, HEADER_DP)
                (header.layoutParams)?.let { if (it.height != h) { it.height = h; header.layoutParams = it } }
                if (header.paddingBottom != 0) header.setPadding(header.paddingLeft, header.paddingTop, header.paddingRight, 0)
            }
            Con.setField(sheet, "windowInsets", null)

            // ارتفاع الـ peek
            val want = Con.dp(a, HEADER_DP) + if (stack) Con.dp(a, TABS_DP + STATUS_DP) + (if (coverOn) inset else 0) else 0
            val peek = (Con.call(b, "getPeekHeight") as? Int) ?: return
            if (peek != want) Con.call(b, "setPeekHeight", want)

            // حشو أسفل الشيت المفتوح: نفس الأصلي (anchorOffset) + حافة النظام
            val rel = s.rel
            val eo = (Con.call(b, "getExpandedOffset") as? Int) ?: 0
            if (rel != null && eo > 0) {
                val padB = eo + navInset(s, sheet)
                if (rel.paddingBottom != padB) rel.setPadding(rel.paddingLeft, rel.paddingTop, rel.paddingRight, padB)
            }

            // الكود ما يتغطاش (نفس العلاقة الأصلية: view_container.marginBottom + editor_container.marginBottom = peek)
            val vc = Con.find<View>(a, "view_container")
            val ec = Con.find<View>(a, "editor_container")
            val vcMargin = (vc?.layoutParams as? ViewGroup.MarginLayoutParams)?.bottomMargin ?: 0
            (ec?.layoutParams as? ViewGroup.MarginLayoutParams)?.let {
                val w = (want - vcMargin).coerceAtLeast(0)
                if (it.bottomMargin != w) { it.bottomMargin = w; ec.layoutParams = it }
            }
        } finally { s.inGeometry = false }
    }

    private fun updateStatus(s: S, ed: EditorAccess?) {
        val a = s.a
        val left = s.stLeft ?: return
        val right = s.stRight ?: return
        if (s.status?.visibility != View.VISIBLE) return          // مخبّي (الكيبورد مفتوح): ما كاين علاش نحسبو
        val p = Con.pal(a)
        val f = ed?.file()
        if (ed == null || f == null) {
            Con.setTextIfChanged(left, "—")
        } else {
            if (f.path != s.lastFile) { s.lastFile = f.path; s.eol = detectEol(f) }
            val root = AiIde.gradleRootOfCached(f)
            val now = System.currentTimeMillis()
            if (root != null && (root.path != s.branchRoot || now - s.branchAt > 8000)) {
                s.branchRoot = root.path; s.branchAt = now; s.branch = GitLite.branch(root)
            }
            val br = s.branch?.let { " · ⎇ $it" }.orEmpty()
            Con.setTextIfChanged(left, "${ed.cursorLine() + 1}:${ed.cursorColumn() + 1} · ${ConsoleLogic.langName(f)} · UTF-8 · ${s.eol}$br")
        }
        val n = countProblems(s)
        Con.setTextIfChanged(right, "● $n")
        val col = if (n > 0) p.red else p.muted
        if (right.currentTextColor != col) right.setTextColor(col)
        badge(s, n)
    }

    private fun badge(s: S, n: Int) {
        if (n == s.badgeN) return
        val a = s.a
        val tabs = s.tabsV ?: return
        val cnt = (Con.call(tabs, "getTabCount") as? Int) ?: return
        var applied = false
        for (i in 0 until cnt) {
            val tab = Con.call(tabs, "getTabAt", i) ?: continue
            val txt = (Con.call(tab, "getText") as? CharSequence)?.toString()
            if (txt != "المشاكل") continue
            val cell = Con.call(tab, "getCustomView") as? ViewGroup ?: continue
            val bd = cell.getChildAt(1) as? TextView ?: continue
            Con.setTextIfChanged(bd, if (n > 99) "99+" else n.toString())
            Con.setVisible(bd, if (n > 0) View.VISIBLE else View.GONE)
            applied = true
        }
        if (applied) s.badgeN = n
    }

    /** عدد مشاكل التشخيص: كنقراو DiagnosticsAdapter ديال لوحة المشاكل (reflection)، مرة فكل 2.5ث وبحد أقصى 600 عنصر. */
    private fun countProblems(s: S): Int {
        val a = s.a
        val now = System.currentTimeMillis()
        if (now - s.probAt < 2500) return s.problems
        s.probAt = now
        var rv = s.diagRef?.get()
        if (rv == null || !rv.isAttachedToWindow) {
            val sheet = s.sheet ?: return s.problems
            rv = Con.firstOf(sheet) { v -> v is ViewGroup && Con.call(v, "getAdapter")?.javaClass?.simpleName == "DiagnosticsAdapter" }
            s.diagRef = rv?.let { WeakReference(it) }
        }
        val adapter = Con.call(rv, "getAdapter") ?: return s.problems
        val groups = Con.field(adapter, "diagnostics") as? List<*> ?: return s.problems
        var errors = 0
        var all = 0
        loop@ for (g in groups) {
            val items = Con.field(g, "diagnostics") as? List<*> ?: continue
            for (d in items) {
                all++
                if (all > 600) break@loop
                if (Con.call(d, "getSeverity")?.toString() == "ERROR") errors++
            }
        }
        s.problems = if (errors > 0) errors else all
        return s.problems
    }

    private fun detectEol(f: File): String = try {
        f.inputStream().use { ins ->
            val buf = ByteArray(65536)
            val n = ins.read(buf)
            var crlf = false
            for (i in 0 until n) if (buf[i] == '\r'.code.toByte()) { crlf = true; break }
            if (crlf) "CRLF" else "LF"
        }
    } catch (t: Throwable) { "LF" }

}
