package com.itsaky.androidide.ai

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.MediaScannerConnection
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.fragment.app.FragmentActivity
import androidx.fragment.app.FragmentManager
import java.io.File

/**
 * الجسر بين المساعد والمحرك: المشروع النشط، تحديث شجرة الملفات، فتح المشاريع، وبيئة الترمنال.
 * كل شيء عبر reflection وكل خطوة محمية بـ try/catch، فلو تغيّرت أسماء الكلاسات فـ نسخة معيّنة
 * ما كينكسر لا البناء ولا التطبيق (كيبقى المساعد خدّام، وغير الربط هو اللي كيتعطّل).
 */
object AiIde {

    private val handler = Handler(Looper.getMainLooper())
    @Volatile private var autoOpenTried = false
    private var pendingTree: Runnable? = null

    private const val EVENT_PKG = "com.itsaky.androidide.eventbus.events.file."
    private const val ENV_CLASS = "com.itsaky.androidide.utils.Environment"
    private val PM_CLASSES = arrayOf(
        "com.itsaky.androidide.projects.IProjectManager",
        "com.itsaky.androidide.projects.ProjectManagerImpl",
        "com.itsaky.androidide.projects.ProjectManager"
    )
    private val EDITOR_CLASSES = arrayOf(
        "com.itsaky.androidide.activities.editor.EditorActivityKt",
        "com.itsaky.androidide.activities.editor.EditorActivity",
        "com.itsaky.androidide.activities.EditorActivityKt"
    )
    private val TREE_METHODS = arrayOf(
        "listProjectFiles", "refreshFileTree", "refreshTree", "reloadTree", "refresh", "reload"
    )

    // ------------------------------------------------------------ reflection helpers
    fun cls(vararg names: String): Class<*>? {
        for (n in names) {
            try { return Class.forName(n) } catch (t: Throwable) { /* نجرب الاسم الموالي */ }
        }
        return null
    }

    /** يجيب الـ singleton سواء كان getInstance() ثابت، أو INSTANCE، أو Companion.getInstance(). */
    fun singleton(c: Class<*>): Any? {
        try { c.getMethod("getInstance").invoke(null)?.let { return it } } catch (t: Throwable) { }
        try { c.getField("INSTANCE").get(null)?.let { return it } } catch (t: Throwable) { }
        try {
            val comp = c.getField("Companion").get(null)
            comp?.javaClass?.getMethod("getInstance")?.invoke(comp)?.let { return it }
        } catch (t: Throwable) { }
        return null
    }

    private fun projectManagers(): List<Any> =
        PM_CLASSES.mapNotNull { n -> cls(n)?.let { singleton(it) } }

    /** ينادي أول دالة بلا وسائط موجودة (حتى لو private) ويرجع اسمها، أو null. */
    private fun callNoArg(o: Any, vararg names: String): String? {
        var c: Class<*>? = o.javaClass
        while (c != null && c != Any::class.java) {
            for (n in names) {
                try {
                    val m = c.getDeclaredMethod(n)
                    m.isAccessible = true
                    m.invoke(o)
                    return n
                } catch (e: NoSuchMethodException) {
                    // جرّب الاسم الموالي
                } catch (t: Throwable) {
                    return null
                }
            }
            c = c.superclass
        }
        return null
    }

    // ------------------------------------------------------------ المجلدات والمشروع النشط
    fun storageRoot(): File = Environment.getExternalStorageDirectory()

    const val PROJECTS_FOLDER = "ZelligeProjects"
    private const val LEGACY_FOLDER = "AndroidIDEProjects"

    /** مجلد المشاريع: الإعداد اليدوي، وإلا مجلد المحرك (ZelligeProjects بعد الـ rebrand)، وإلا ZelligeProjects. */
    fun projectsDir(ctx: Context): File {
        val custom = AiPrefs(ctx).workspace.trim()
        if (custom.isNotEmpty()) return File(custom)
        val env = cls(ENV_CLASS)
        if (env != null) {
            try { (env.getField("PROJECTS_DIR").get(null) as? File)?.let { return it } } catch (t: Throwable) { }
            try { (env.getMethod("getPROJECTS_DIR").invoke(singleton(env)) as? File)?.let { return it } } catch (t: Throwable) { }
        }
        return File(storageRoot(), PROJECTS_FOLDER)
    }

    /** المجلد القديم إلا مازال فيه مشاريع (النقل ما تدارش) — باش حتى مشروع ما يختفي من القائمة. */
    fun legacyProjectsDir(): File? =
        File(storageRoot(), LEGACY_FOLDER).takeIf { d -> d.isDirectory && d.listFiles()?.any { it.isDirectory && !it.name.startsWith(".") } == true }

    /**
     * مرة وحدة: AndroidIDEProjects → ZelligeProjects (rename فنفس الذاكرة: فوري وما كيتنسخ والو)، مع تصحيح المسارات المحفوظة
     * (المشروع النشط، آخر مشروع، ملفات الشات، التبويبات المفتوحة). ما كيدار والو إلا كان المجلد الجديد فيه مشاريع من قبل.
     */
    fun migrateProjectsFolder(ctx: Context) {
        val prefs = AiPrefs(ctx)
        if (prefs.projectsMigrated) return
        try {
            // غير إلا المحرك نفسو ولّى كيستعمل ZelligeProjects (rebrand مطبّق)؛ وإلا نخليو كلشي فبلاصتو
            val env = cls(ENV_CLASS)
            val engine = try { env?.getField("PROJECTS_DIR")?.get(null) as? File } catch (t: Throwable) { null }
            if (engine == null || engine.name != PROJECTS_FOLDER) return
            val root = engine.parentFile ?: storageRoot()
            val old = File(root, LEGACY_FOLDER)
            val neu = File(root, PROJECTS_FOLDER)
            if (!old.isDirectory) { if (root.listFiles() != null) prefs.projectsMigrated = true; return }
            val oldKids = old.listFiles() ?: return                  // ما كايناش صلاحية التخزين بعد: نعاودو من بعد
            if (oldKids.isEmpty()) { prefs.projectsMigrated = true; return }
            if (neu.exists()) {
                val nk = neu.listFiles() ?: return
                if (nk.isNotEmpty()) { prefs.projectsMigrated = true; return }   // فيه حاجة: ما نلمسو والو (كنعرضو بجوج)
                if (!neu.delete()) return
            }
            if (!old.renameTo(neu)) return
            val from = old.path
            val to = neu.path
            fun fix(v: String) = if (v == from || v.startsWith("$from/")) to + v.substring(from.length) else v
            prefs.activeProject = fix(prefs.activeProject)
            prefs.lastOpened = fix(prefs.lastOpened)
            if (prefs.workspace.isNotBlank()) prefs.workspace = fix(prefs.workspace)
            try {
                val sp = ctx.getSharedPreferences(ctx.packageName + "_preferences", Context.MODE_PRIVATE)
                val last = sp.getString("ide_last_project", null)
                if (last != null && fix(last) != last) sp.edit().putString("ide_last_project", fix(last)).apply()
            } catch (t: Throwable) { }
            // التبويبات المفتوحة ديال كل مشروع (مسارات مطلقة)
            neu.listFiles()?.forEach { pd ->
                val f = File(pd, ".androidide/editor/openedFiles.json")
                try { if (f.isFile && f.length() < 512_000) { val t = f.readText(); if (t.contains(from)) f.writeText(t.replace(from, to)) } } catch (t: Throwable) { }
            }
            AiPlugin.migrateChats(ctx, from, to)
            prefs.projectsMigrated = true
        } catch (t: Throwable) { }
    }

    /** المشروع المفتوح حاليا داخل IDE (إن أمكن معرفته). */
    fun ideProjectDir(): File? {
        for (pm in projectManagers()) {
            for (m in arrayOf("getProjectDir", "getProjectDirPath", "getProjectPath", "getRootProjectDir")) {
                try {
                    val r = pm.javaClass.getMethod(m).invoke(pm) ?: continue
                    val f = when (r) {
                        is File -> r
                        is String -> File(r)
                        is java.nio.file.Path -> r.toFile()
                        else -> null
                    } ?: continue
                    if (f.isDirectory) return f
                } catch (t: Throwable) { }
            }
        }
        return null
    }

    fun isGradleProject(d: File): Boolean =
        File(d, "settings.gradle").exists() || File(d, "settings.gradle.kts").exists()

    /** جذر مشروع Gradle الذي ينتمي إليه الملف (أو مجلده إن لم يوجد). */
    fun gradleRootOf(f: File?): File? {
        val first = f?.parentFile
        var d = first
        while (d != null) {
            if (isGradleProject(d)) return d
            d = d.parentFile
        }
        return first
    }

    private val rootMemo = HashMap<String, Pair<Long, File?>>()

    /** نفس gradleRootOf لكن مخبّأة 6 ثواني (كتتنادى فكل tick من الواجهات، وكل نداء كيطلع فالمجلدات بـ exists()). */
    fun gradleRootOfCached(f: File?): File? {
        val key = f?.parent ?: return null
        val now = android.os.SystemClock.uptimeMillis()
        synchronized(rootMemo) { rootMemo[key]?.let { if (now - it.first < 6000) return it.second } }
        val r = gradleRootOf(f)
        synchronized(rootMemo) { if (rootMemo.size > 64) rootMemo.clear(); rootMemo[key] = now to r }
        return r
    }

    /** مجلد عمل الوكيل: مشروع الملف المفتوح ← آخر مشروع محفوظ ← مشروع IDE ← مجلد المشاريع. */
    fun activeRoot(ctx: Context, editorFile: File?): File {
        gradleRootOf(editorFile)?.takeIf { it.isDirectory }?.let { return it }
        val saved = AiPrefs(ctx).activeProject.trim()
        if (saved.isNotEmpty()) File(saved).takeIf { it.isDirectory }?.let { return it }
        ideProjectDir()?.let { return it }
        return projectsDir(ctx)
    }

    /** كل المشاريع الظاهرة للمستعمل: محتوى مجلد المشاريع + آخر مشروع نشط/مفتوح. */
    fun findProjects(ctx: Context): List<File> {
        val out = LinkedHashSet<File>()
        projectsDir(ctx).listFiles()?.forEach { if (it.isDirectory && !it.name.startsWith(".")) out.add(it) }
        legacyProjectsDir()?.listFiles()?.forEach { if (it.isDirectory && !it.name.startsWith(".")) out.add(it) }
        val prefs = AiPrefs(ctx)
        for (p in listOf(prefs.activeProject, prefs.lastOpened)) {
            if (p.isNotBlank()) File(p).takeIf { it.isDirectory }?.let { out.add(it) }
        }
        return out.sortedByDescending { it.lastModified() }
    }

    /** يحفظ المشروع كـ«نشط» و«آخر مفتوح» (يبقى بعد إغلاق التطبيق). */
    fun remember(ctx: Context, dir: File) {
        try {
            val prefs = AiPrefs(ctx)
            val p = dir.path
            if (prefs.activeProject != p) prefs.activeProject = p
            if (prefs.lastOpened != p) prefs.lastOpened = p
        } catch (t: Throwable) { }
    }

    /** كتنادى كل ما تظهر شاشة المحرر: كنتتبعو المشروع اللي فتحو المستعمل بنفسو. */
    fun onEditorResumed(a: Activity) {
        try {
            val d = ideProjectDir() ?: gradleRootOf(EditorAccess.find(a)?.file())
            if (d != null && d.isDirectory) remember(a, d)
            AiPrefs(a).autoOpenPending = false   // الفتح نجح: نلغي حارس حلقة الانهيار
        } catch (t: Throwable) { }
    }

    // ------------------------------------------------------------ تحديث شجرة الملفات
    private fun post(event: Any): Boolean {
        val bus = cls("org.greenrobot.eventbus.EventBus") ?: return false
        return try {
            val inst = bus.getMethod("getDefault").invoke(null)
            bus.getMethod("post", Any::class.java).invoke(inst, event)
            true
        } catch (t: Throwable) { false }
    }

    private fun fileEvent(name: String, f: File): Any? {
        val c = cls(EVENT_PKG + name) ?: return null
        return try { c.getConstructor(File::class.java).newInstance(f) } catch (t: Throwable) { null }
    }

    private fun walkFragments(fm: FragmentManager, visit: (Any) -> Unit) {
        for (f in fm.fragments) {
            visit(f)
            try { walkFragments(f.childFragmentManager, visit) } catch (t: Throwable) { }
        }
    }

    /** نص تبويب «المخرجات» (مخرجات Gradle) فالمحرر. من الـ UI thread. */
    fun buildOutput(a: Activity): String? {
        val fa = a as? FragmentActivity ?: return null
        var out: String? = null
        try {
            walkFragments(fa.supportFragmentManager) { f ->
                if (out == null && f.javaClass.simpleName == "BuildOutputFragment")
                    out = try { f.javaClass.getMethod("getContent").invoke(f) as? String } catch (t: Throwable) { null }
            }
        } catch (t: Throwable) { }
        return out
    }

    /** آخر بناء فشل (null = نجح أو ما تبناش): الأخطاء كتدخل فسياق الذكاء. */
    @Volatile var lastBuildFail: ConsoleLogic.Fail? = null

    /** واش المشروع كيستعمل Jetpack Compose (باش الذكاء يحترم نفس الطريقة)؛ وإلا XML. */
    fun usesCompose(root: File): Boolean {
        for (m in listOf("app", ".")) for (n in listOf("build.gradle.kts", "build.gradle")) {
            val f = File(File(root, m), n)
            if (!f.isFile || f.length() > 400_000) continue
            val t = try { f.readText() } catch (e: Throwable) { continue }
            if (Regex("compose\\s*(=|\\()\\s*true").containsMatchIn(t) || t.contains("androidx.compose") || t.contains("libs.androidx.compose") || t.contains("kotlin.plugin.compose")) return true
        }
        return false
    }

    /** يعيد بناء شجرة الملفات عبر FileTreeFragment (بعد تأخير قصير لتجميع التغييرات). */
    private fun scheduleTreeRefresh(a: Activity) {
        pendingTree?.let { handler.removeCallbacks(it) }
        val r = Runnable { refreshFragments(a) }
        pendingTree = r
        handler.postDelayed(r, 350)
    }

    fun refreshFragments(a: Activity): Boolean {
        val fa = a as? FragmentActivity ?: return false
        var done = false
        try {
            walkFragments(fa.supportFragmentManager) { f ->
                if (f.javaClass.name.contains("FileTree", ignoreCase = true) &&
                    callNoArg(f, *TREE_METHODS) != null
                ) done = true
            }
        } catch (t: Throwable) { }
        return done
    }

    /** تحديث كامل للشجرة (من أي thread). */
    fun refreshAll(a: Activity) {
        a.runOnUiThread { scheduleTreeRefresh(a) }
    }

    /** يخبر IDE بالملفات الجديدة/المحذوفة ويحدّث الشجرة. من أي thread. */
    fun refresh(a: Activity, created: Collection<File>, deleted: Collection<File>, touched: Collection<File>, full: Boolean) {
        if (created.isEmpty() && deleted.isEmpty() && touched.isEmpty() && !full) return
        try {
            val paths = (created.flatMap { c -> c.walkTopDown().filter { it.isFile }.take(200).toList() } +
                touched.filter { it.isFile }).map { it.path }.distinct().take(300)
            if (paths.isNotEmpty()) MediaScannerConnection.scanFile(a.applicationContext, paths.toTypedArray(), null, null)
        } catch (t: Throwable) { }
        a.runOnUiThread {
            try {
                created.forEach { f -> fileEvent("FileCreationEvent", f)?.let { post(it) } }
                deleted.forEach { f -> fileEvent("FileDeletionEvent", f)?.let { post(it) } }
            } catch (t: Throwable) { }
            scheduleTreeRefresh(a)
        }
    }

    /** يفرغ التغييرات المتراكمة فـ Run ويرسلها لـ IDE. */
    fun sync(a: Activity, run: AiAgent.Run) {
        val created = run.created.toList()
        val deleted = run.deleted.toList()
        val touched = run.touched.toList()
        val full = run.full
        run.created.clear(); run.deleted.clear(); run.touched.clear(); run.full = false
        refresh(a, created, deleted, touched, full)
    }

    /** نهاية المهمة: اكتشاف مشروع جديد وفتحه فـ IDE (أو الفتح الصريح عبر open_project). */
    fun finish(a: Activity, run: AiAgent.Run) {
        sync(a, run)
        val prefs = AiPrefs(a)
        var open = run.openAfter
        val fresh = run.newFiles
            .filter { it.name == "settings.gradle" || it.name == "settings.gradle.kts" }
            .mapNotNull { it.parentFile }
            .firstOrNull()
        if (fresh != null) {
            remember(a, fresh)
            if (open == null && prefs.autoOpenNew) open = fresh
        }
        val target = open ?: return
        if (ideProjectDir()?.path == target.path && a.javaClass.simpleName.contains("Editor")) return
        run.openAfter = target          // باش الشات يتنقل معاه (AiPlugin.handOver)
        a.runOnUiThread {
            val err = try { openProject(a, target) } catch (t: Throwable) { t.message ?: "خطأ" }
            if (err != null) Toast.makeText(a, err, Toast.LENGTH_LONG).show()
        }
    }

    // ------------------------------------------------------------ فتح مشروع
    /** يفتح المشروع داخل IDE. من الـ UI thread. يرجع null عند النجاح، وإلا نص الخطأ. */
    fun openProject(a: Activity, dir: File): String? {
        if (!dir.isDirectory) return "المجلد غير موجود: ${dir.path}"
        remember(a, dir)
        val editor = cls(*EDITOR_CLASSES) ?: return "ما لقيتش شاشة المحرر فـ IDE (راجع «تشخيص»)"
        var set = false
        for (pm in projectManagers()) {
            val tries = listOf<Pair<String, Any>>(
                "openProject" to dir, "openProject" to dir.path,
                "setProjectDir" to dir, "setProjectPath" to dir.path
            )
            for ((name, arg) in tries) {
                val m = pm.javaClass.methods.firstOrNull {
                    it.name == name && it.parameterTypes.size == 1 && it.parameterTypes[0].isAssignableFrom(arg.javaClass)
                } ?: continue
                try { m.invoke(pm, arg); set = true; break } catch (t: Throwable) { }
            }
            if (set) break
        }
        if (!set) return "تعذّر تحديد المشروع داخل IDE (راجع «تشخيص»). المسار: ${dir.path}"
        a.startActivity(Intent(a, editor))
        return null
    }

    /** عند تشغيل التطبيق من جديد: يرجع لآخر مشروع (مع حارس ضد حلقة الانهيار). */
    fun maybeAutoOpen(a: Activity) {
        if (autoOpenTried) return
        autoOpenTried = true
        val prefs = AiPrefs(a)
        if (prefs.autoOpenPending) { prefs.autoOpenPending = false; return }
        if (!prefs.autoOpenLast) return
        val last = prefs.lastOpened.trim()
        if (last.isEmpty()) return
        val dir = File(last)
        if (!dir.isDirectory || !isGradleProject(dir)) return
        prefs.autoOpenPending = true
        handler.postDelayed({
            try {
                val err = openProject(a, dir)
                if (err != null) {
                    prefs.autoOpenPending = false
                    Toast.makeText(a, err, Toast.LENGTH_LONG).show()
                }
            } catch (t: Throwable) {
                prefs.autoOpenPending = false
            }
        }, 600)
    }

    // ------------------------------------------------------------ الترمنال
    /** يطبّق نفس متغيرات بيئة ترمنال IDE (PATH, JAVA_HOME, ANDROID_HOME, HOME, PREFIX…). */
    fun applyTerminalEnv(env: MutableMap<String, String>): Boolean {
        val c = cls(ENV_CLASS) ?: return false
        return try {
            val m = c.methods.firstOrNull { it.name == "putEnvironment" && it.parameterTypes.size == 2 } ?: return false
            m.invoke(singleton(c), env, false)
            true
        } catch (t: Throwable) { false }
    }

    /** نفس bash اللي كيستعملو الترمنال داخل IDE. */
    fun terminalShell(): File? {
        val c = cls(ENV_CLASS) ?: return null
        try { (c.getField("BASH_SHELL").get(null) as? File)?.takeIf { it.canExecute() }?.let { return it } } catch (t: Throwable) { }
        try { (c.getMethod("getBASH_SHELL").invoke(singleton(c)) as? File)?.takeIf { it.canExecute() }?.let { return it } } catch (t: Throwable) { }
        return null
    }

    // ------------------------------------------------------------ تشخيص
    private fun treeFragmentName(a: Activity): String? {
        val fa = a as? FragmentActivity ?: return null
        var name: String? = null
        try {
            walkFragments(fa.supportFragmentManager) { f ->
                if (name == null && f.javaClass.name.contains("FileTree", ignoreCase = true)) name = f.javaClass.simpleName
            }
        } catch (t: Throwable) { }
        return name
    }

    fun report(a: Activity): String = buildString {
        fun line(ok: Boolean, s: String) { appendLine((if (ok) "✔ " else "✘ ") + s) }
        val pms = projectManagers()
        line(pms.isNotEmpty(), "إدارة المشاريع" + (pms.firstOrNull()?.let { " (" + it.javaClass.simpleName + ")" } ?: ""))
        val pd = ideProjectDir()
        line(pd != null, "مشروع IDE المفتوح: " + (pd?.path ?: "—"))
        line(cls("org.greenrobot.eventbus.EventBus") != null && cls(EVENT_PKG + "FileCreationEvent") != null, "أحداث الملفات (EventBus)")
        val tree = treeFragmentName(a)
        line(tree != null, "شجرة الملفات" + (tree?.let { " ($it)" } ?: " (تظهر فقط داخل المحرر)"))
        line(cls(*EDITOR_CLASSES) != null, "شاشة المحرر")
        line(cls(ENV_CLASS) != null, "بيئة الترمنال")
        appendLine()
        appendLine("مجلد المشاريع: " + projectsDir(a).path)
        val act = try { activeRoot(a, EditorAccess.find(a)?.file()).path } catch (t: Throwable) { "—" }
        appendLine("المشروع النشط: $act")
    }
}
