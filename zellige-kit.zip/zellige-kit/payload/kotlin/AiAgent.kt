package com.itsaky.androidide.ai

import android.app.Activity
import android.app.AlertDialog
import android.os.Environment
import android.os.Looper
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * منفّذ الأدوات: النموذج يرسل وسوم <tool .../> والوكيل ينفّذها (قراءة/كتابة/تعديل/إنشاء/حذف/نقل/بحث/تنفيذ أمر)
 * داخل مجلد العمل أو التخزين المشترك، مع إمكانية التراجع عن آخر تنفيذ.
 */
object AiAgent {

    data class Call(val name: String, val attrs: Map<String, String>, val body: String) {
        val path: String get() = attrs["path"].orEmpty()
    }

    data class StepResult(val call: Call, val ok: Boolean, val text: String)

    class Denied : RuntimeException()

    class Run {
        val undo = mutableListOf<Pair<File, String?>>()
        /** أعلى مجلد/ملف تخلق فهاد المهمة (لإشعار IDE). */
        val created = LinkedHashSet<File>()
        val deleted = LinkedHashSet<File>()
        val touched = LinkedHashSet<File>()
        /** كل الملفات الجديدة بالضبط (لاكتشاف المشاريع الجديدة). */
        val newFiles = LinkedHashSet<File>()
        @Volatile var full = false
        @Volatile var openAfter: File? = null
        /** true بعد ما بدا التطبيق المباشر فالمحرر (الشات تسدّ وظهر الـ HUD). */
        @Volatile var live = false
        /** كترجع false إلا أوقف المستعمل المهمة. */
        @Volatile var alive: () -> Boolean = { true }
    }

    /** مجلد العمل: المسارات النسبية كتبدا منو، والمطلقة مسموحة داخل التخزين المشترك (/storage/emulated/0). */
    class Workspace(val root: File, val projects: File) {
        fun resolve(p: String): File {
            val t = p.trim().ifEmpty { "." }
            val f = if (t.startsWith("/")) File(t) else File(root, t)
            val c = f.canonicalFile
            val ok = listOf(root, projects, Environment.getExternalStorageDirectory()).any {
                val r = it.canonicalFile
                c == r || c.path.startsWith(r.path + File.separator)
            }
            if (!ok) throw SecurityException("المسار خارج التخزين المسموح: $p")
            return c
        }

        fun rel(f: File): String {
            val r = root.canonicalFile.path
            return if (f.path.startsWith(r + File.separator)) f.path.substring(r.length + 1) else f.path
        }
    }

    // ------------------------------------------------------------------ parsing
    private val toolRe = Regex("<tool\\s+([^>]*?)\\s*(?:/>|>([\\s\\S]*?)</tool>)")
    private val attrRe = Regex("(\\w+)\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)')")
    private val editRe = Regex("<find>([\\s\\S]*?)</find>\\s*<replace>([\\s\\S]*?)</replace>")
    private val resultRe = Regex("<result ok=\"(true|false)\" label=\"([^\"]*)\">\\r?\\n([\\s\\S]*?)\\r?\\n</result>")

    private fun trimNl(s: String) =
        s.removePrefix("\r\n").removePrefix("\n").removeSuffix("\r\n").removeSuffix("\n")

    fun parse(reply: String): List<Call> = toolRe.findAll(reply).map { m ->
        val attrs = attrRe.findAll(m.groupValues[1]).associate {
            it.groupValues[1] to (it.groups[2]?.value ?: it.groups[3]?.value ?: "")
        }
        Call(attrs["name"].orEmpty(), attrs, trimNl(m.groupValues[2]))
    }.toList()

    fun strip(reply: String): String = toolRe.replace(reply, "").trim()

    private val fencedRe = Regex("```[A-Za-z0-9_+#.-]*[ \\t]*\\r?\\n([\\s\\S]*?)```")

    /** كود طويل (4 أسطر فأكثر) كتبو النموذج فـ الشات بدل ما يطبّقو بالأدوات. */
    fun hasCodeDump(reply: String): Boolean =
        fencedRe.findAll(strip(reply)).any { it.groupValues[1].trim().lines().size >= 4 }

    /** يقصّ محتوى الملفات الكبيرة فالرسائل القديمة باش السياق ما يتضخمش. */
    fun compact(m: AiClient.Msg): AiClient.Msg {
        if (m.role == "assistant" && m.content.contains("<tool")) {
            val c = toolRe.replace(m.content) { r ->
                val body = r.groupValues[2]
                if (body.length > 300) "<tool " + r.groupValues[1] + ">\n[content omitted]\n</tool>" else r.value
            }
            return AiClient.Msg(m.role, c)
        }
        if (isResults(m) && m.content.length > 1500) return AiClient.Msg(m.role, m.content.take(1500) + "\n[…]\n</tool_results>")
        return m
    }

    fun isResults(m: AiClient.Msg) = m.role == "user" && m.content.startsWith("<tool_results>")

    fun parseResults(content: String): List<Triple<Boolean, String, String>> =
        resultRe.findAll(content).map {
            Triple(it.groupValues[1] == "true", it.groupValues[2], it.groupValues[3].lineSequence().firstOrNull().orEmpty())
        }.toList()

    fun describe(c: Call): String {
        val p = c.path.ifBlank { "." }
        return when (c.name) {
            "write_file" -> "كتابة $p"
            "edit_file" -> "تعديل $p"
            "insert" -> "إدراج كود فـ " + c.path.ifBlank { "الملف المفتوح" }
            "open_file" -> "فتح $p"
            "read_file" -> "قراءة $p"
            "list_dir" -> "عرض المجلد $p"
            "create_dir" -> "إنشاء المجلد $p"
            "delete" -> "حذف $p"
            "open_project" -> "فتح المشروع $p"
            "move" -> "نقل $p"
            "search" -> "بحث «${c.attrs["query"].orEmpty()}»"
            "run" -> "تنفيذ أمر: " + c.body.trim().lineSequence().firstOrNull().orEmpty().take(48)
            else -> c.name
        }
    }

    fun formatResults(rs: List<StepResult>): String = buildString {
        appendLine("<tool_results>")
        rs.forEach { r ->
            appendLine("<result ok=\"${r.ok}\" label=\"${describe(r.call).replace('"', '\'')}\">")
            appendLine(r.text)
            appendLine("</result>")
        }
        append("</tool_results>")
    }

    // ------------------------------------------------------------------ undo
    private val stack = ArrayDeque<List<Pair<File, String?>>>()

    fun end(r: Run) {
        if (r.undo.isEmpty()) return
        synchronized(stack) {
            stack.addLast(r.undo.toList())
            while (stack.size > 10) stack.removeFirst()
        }
    }

    /** يجب استدعاؤها من الـ UI thread. */
    fun undoLast(a: Activity): String {
        val last = synchronized(stack) { stack.removeLastOrNull() } ?: return "لا يوجد تنفيذ سابق للتراجع عنه"
        var n = 0
        for ((f, old) in last.asReversed()) {
            try {
                if (old == null) f.delete() else put(a, f, old)
                n++
            } catch (t: Throwable) { /* نكمّل الباقي */ }
        }
        runCatching { AiIde.refreshAll(a) }
        return "تم التراجع عن $n ملف"
    }

    private fun remember(run: Run, f: File, old: String?) {
        if (run.undo.none { it.first == f }) run.undo.add(f to old)
    }

    // ------------------------------------------------------------------ UI-thread helpers
    internal fun <T> onUi(a: Activity, f: () -> T): T {
        if (Looper.myLooper() == Looper.getMainLooper()) return f()
        val latch = CountDownLatch(1)
        var res: Result<T>? = null
        a.runOnUiThread { res = runCatching(f); latch.countDown() }
        latch.await()
        return res!!.getOrThrow()
    }

    private fun confirm(a: Activity, title: String, msg: String): Boolean {
        val latch = CountDownLatch(1)
        var yes = false
        a.runOnUiThread {
            AlertDialog.Builder(a).setTitle(title).setMessage(msg)
                .setPositiveButton("تنفيذ") { _, _ -> yes = true; latch.countDown() }
                .setNegativeButton("رفض") { _, _ -> latch.countDown() }
                .setOnCancelListener { latch.countDown() }
                .show()
        }
        latch.await()
        return yes
    }

    private fun guard(a: Activity, ask: Boolean, title: String, what: String) {
        if (ask && !confirm(a, title, what)) throw Denied()
    }

    private fun sameFile(ed: EditorAccess, f: File): Boolean =
        try { ed.file()?.canonicalFile == f.canonicalFile } catch (t: Throwable) { false }

    /** يكتب على القرص، ولو الملف مفتوح فالمحرر يحدّثه هو كذلك. */
    private fun put(a: Activity, f: File, text: String) {
        f.parentFile?.mkdirs()
        f.writeText(text)
        onUi(a) {
            val ed = EditorAccess.find(a)
            if (ed != null && sameFile(ed, f)) ed.replaceAll(text)
        }
    }

    /**
     * يطبّق النص على الملف: مباشرة فالمحرر قدام المستعمل (AiLive) إن أمكن، وإلا كتابة عادية على القرص.
     * فالحالتين الملف كيتكتب على القرص فالأخير.
     */
    private fun commit(a: Activity, run: Run, f: File, old: String?, text: String) {
        val live = try { AiLive.apply(a, run, f, old, text) } catch (t: Throwable) { false }
        if (!live) put(a, f, text)
    }

    /** النص الحالي: من المحرر إن كان الملف مفتوحا (قد يحتوي تعديلات غير محفوظة)، وإلا من القرص. */
    private fun current(a: Activity, f: File): String? {
        val fromEditor: String? = onUi(a) {
            val ed = EditorAccess.find(a)
            if (ed != null && sameFile(ed, f)) ed.allText() else null
        }
        if (fromEditor != null) return fromEditor
        if (!f.isFile) return null
        require(f.length() <= 2_000_000) { "الملف كبير جدا" }
        return f.readText()
    }

    private fun cap(s: String) = if (s.length > 12000) s.take(12000) + "\n…[تم الاقتطاع]" else s

    /** أعلى مجلد ناقص فـ المسار (يُحسب قبل الكتابة) — هو اللي كنخبرو بيه IDE أنه تخلق. */
    private fun topMissing(f: File): File {
        var t = f
        var p = f.parentFile
        while (p != null && !p.exists()) { t = p; p = p.parentFile }
        return t
    }

    // ------------------------------------------------------------------ tools
    fun execute(a: Activity, run: Run, ws: Workspace, c: Call, ask: Boolean): StepResult =
        try {
            StepResult(c, true, cap(dispatch(a, run, ws, c, ask)))
        } catch (d: Denied) {
            StepResult(c, false, "رفض المستخدم هذا الإجراء. لا تكرّره؛ اسأله ماذا يريد.")
        } catch (t: Throwable) {
            StepResult(c, false, t.message ?: t.javaClass.simpleName)
        }

    private val skipDirs = setOf("build", ".gradle", ".git", ".idea", ".cxx", ".kotlin", "node_modules")
    private val binExt = setOf(
        "png", "jpg", "jpeg", "webp", "gif", "jar", "aar", "apk", "so", "zip",
        "ttf", "otf", "mp3", "mp4", "class", "dex", "keystore", "jks"
    )

    private fun dispatch(a: Activity, run: Run, ws: Workspace, c: Call, ask: Boolean): String = when (c.name) {

        "list_dir" -> {
            val d = ws.resolve(c.path)
            if (!d.isDirectory) throw IllegalArgumentException("ليس مجلدا: ${c.path}")
            val items = d.listFiles()?.sortedWith(compareBy({ !it.isDirectory }, { it.name.lowercase() })) ?: emptyList()
            if (items.isEmpty()) "(فارغ)"
            else items.take(300).joinToString("\n") { if (it.isDirectory) it.name + "/" else it.name }
        }

        "read_file" -> {
            val f = ws.resolve(c.path)
            current(a, f) ?: throw IllegalArgumentException("الملف غير موجود: ${c.path}")
        }

        "write_file" -> {
            val f = ws.resolve(c.path)
            require(!f.isDirectory) { "هذا مجلد وليس ملفا: ${c.path}" }
            val old = current(a, f)
            val content = unfence(c.body)
            guard(a, ask, "كتابة ملف", ws.rel(f))
            remember(run, f, old)
            val top = if (old == null && !f.exists()) topMissing(f) else null
            commit(a, run, f, old, content)
            run.touched.add(f)
            if (top != null) { run.created.add(top); run.newFiles.add(f) }
            (if (old == null) "تم إنشاء " else "تم تحديث ") + ws.rel(f) + " (" + content.lines().size + " سطر)"
        }

        "edit_file" -> {
            val f = ws.resolve(c.path)
            val orig = current(a, f) ?: throw IllegalArgumentException("الملف غير موجود: ${c.path}")
            val edits = editRe.findAll(c.body).toList()
            require(edits.isNotEmpty()) { "edit_file يحتاج <find> و <replace>" }
            var text = orig
            for ((i, m) in edits.withIndex()) {
                val find = trimNl(m.groupValues[1])
                val rep = trimNl(m.groupValues[2])
                require(find.isNotEmpty()) { "تعديل رقم ${i + 1}: <find> فارغ" }
                val first = text.indexOf(find)
                require(first >= 0) { "تعديل رقم ${i + 1}: النص غير موجود بالضبط فالملف — اقرأ الملف من جديد وانسخ النص حرفيا" }
                require(text.indexOf(find, first + 1) < 0) { "تعديل رقم ${i + 1}: النص يتكرر أكثر من مرة — زد سياقا أكثر" }
                text = text.substring(0, first) + rep + text.substring(first + find.length)
            }
            guard(a, ask, "تعديل ملف", ws.rel(f))
            remember(run, f, orig)
            commit(a, run, f, orig, text)
            run.touched.add(f)
            "تم تعديل " + ws.rel(f) + " (" + edits.size + " تعديل)"
        }

        "insert" -> {
            val f = if (c.path.isBlank()) {
                onUi(a) { EditorAccess.find(a)?.file() }
                    ?: throw IllegalArgumentException("ما كاين حتى ملف مفتوح فالمحرر — حدّد path")
            } else ws.resolve(c.path)
            require(!f.isDirectory) { "هذا مجلد وليس ملفا: ${ws.rel(f)}" }
            val old = current(a, f)
            val code = unfence(c.body)
            require(code.isNotEmpty()) { "insert يحتاج كودا داخل الوسم" }
            val base = (old ?: "").replace("\r\n", "\n")
            var ins = code
            val lineAttr = c.attrs["line"]?.trim()?.toIntOrNull()
            val at = c.attrs["at"].orEmpty().trim().lowercase()
            val idx: Int
            when {
                lineAttr != null -> {
                    val n = lineAttr.coerceAtLeast(1)
                    val start = lineStartIndex(base, n - 1)
                    if (start >= 0) {
                        idx = start
                    } else {
                        idx = base.length
                        if (base.isNotEmpty() && !base.endsWith("\n")) ins = "\n" + ins
                    }
                    if (!ins.endsWith("\n")) ins += "\n"
                }
                at == "start" -> { idx = 0; if (!ins.endsWith("\n")) ins += "\n" }
                at == "end" -> {
                    idx = base.length
                    if (base.isNotEmpty() && !base.endsWith("\n")) ins = "\n" + ins
                    if (!ins.endsWith("\n")) ins += "\n"
                }
                else -> {
                    val cur = onUi(a) { EditorAccess.find(a)?.takeIf { sameFile(it, f) }?.cursorIndex() }
                    idx = (cur ?: base.length).coerceIn(0, base.length)
                }
            }
            guard(a, ask, "إدراج كود", ws.rel(f))
            val top = if (old == null && !f.exists()) topMissing(f) else null
            val newText = base.substring(0, idx) + ins + base.substring(idx)
            remember(run, f, old)
            commit(a, run, f, if (old == null) null else base, newText)
            run.touched.add(f)
            if (top != null) { run.created.add(top); run.newFiles.add(f) }
            val lineNo = base.substring(0, idx).count { it == '\n' } + 1
            "تم إدراج " + ins.trimEnd('\n').lines().size + " سطر فـ " + ws.rel(f) + " (السطر " + lineNo + ")"
        }

        "open_file" -> {
            val f = ws.resolve(c.path)
            require(f.isFile) { "الملف غير موجود: ${c.path}" }
            val line = c.attrs["line"]?.trim()?.toIntOrNull()
            val ed = AiLive.open(a, run, f, line)
            if (ed == null) {
                run.touched.add(f)
                "الملف موجود: " + ws.rel(f) + " (ما فتحتوش فالمحرر لأنك لست داخل شاشة المحرر)"
            } else "تم فتح " + ws.rel(f) + (if (line != null) " عند السطر $line" else "")
        }

        "create_dir" -> {
            val d = ws.resolve(c.path)
            guard(a, ask, "إنشاء مجلد", ws.rel(d))
            val top = if (!d.exists()) topMissing(d) else null
            if (d.isDirectory || d.mkdirs()) {
                if (top != null) {
                    run.created.add(top)
                    AiLive.showTree(a, run)
                }
                "تم إنشاء " + ws.rel(d)
            } else throw IllegalStateException("تعذّر إنشاء المجلد")
        }

        "delete" -> {
            val f = ws.resolve(c.path)
            require(f.exists()) { "غير موجود: ${c.path}" }
            require(
                f != ws.root.canonicalFile && f != ws.projects.canonicalFile &&
                    f != Environment.getExternalStorageDirectory().canonicalFile
            ) { "لا يمكن حذف مجلد العمل نفسه" }
            if (ask && !confirm(a, "حذف", ws.rel(f))) throw Denied()
            if (f.isFile && f.length() < 1_000_000) remember(run, f, try { f.readText() } catch (t: Throwable) { null })
            if (f.deleteRecursively()) {
                run.deleted.add(f)
                "تم حذف " + ws.rel(f)
            } else throw IllegalStateException("تعذّر الحذف")
        }

        "move" -> {
            val src = ws.resolve(c.path)
            val dst = ws.resolve(c.attrs["to"].orEmpty())
            require(src.exists()) { "غير موجود: ${c.path}" }
            require(!dst.exists()) { "الوجهة موجودة مسبقا" }
            guard(a, ask, "نقل", ws.rel(src) + "\n← " + ws.rel(dst))
            val top = topMissing(dst)
            dst.parentFile?.mkdirs()
            if (!src.renameTo(dst)) {
                src.copyRecursively(dst)
                src.deleteRecursively()
            }
            run.created.add(top); run.deleted.add(src); if (dst.isFile) run.newFiles.add(dst)
            "تم النقل إلى " + ws.rel(dst)
        }

        "search" -> {
            val q = c.attrs["query"].orEmpty()
            require(q.isNotBlank()) { "query مطلوب" }
            val base = ws.resolve(c.path.ifBlank { "." })
            val out = mutableListOf<String>()
            fun walk(f: File) {
                if (out.size >= 60) return
                if (f.isDirectory) {
                    if (f.name in skipDirs) return
                    f.listFiles()?.forEach { walk(it) }
                } else if (f.extension.lowercase() !in binExt && f.length() < 500_000) {
                    try {
                        f.useLines { lines ->
                            lines.forEachIndexed { i, l ->
                                if (out.size < 60 && l.contains(q, ignoreCase = true)) out.add(ws.rel(f) + ":" + (i + 1) + ": " + l.trim().take(200))
                            }
                        }
                    } catch (t: Throwable) { /* ملف غير نصي */ }
                }
            }
            walk(base)
            if (out.isEmpty()) "لا نتائج" else out.joinToString("\n")
        }

        "run" -> {
            val cmd = c.body.trim().ifEmpty { c.attrs["cmd"].orEmpty().trim() }
            require(cmd.isNotEmpty()) { "run يحتاج أمرا" }
            val dir = if (c.attrs["dir"].isNullOrBlank()) ws.root.canonicalFile else ws.resolve(c.attrs["dir"].orEmpty())
            // الوضع التلقائي: ينفّذ مباشرة. التأكيد فقط إذا فعّل المستعمل «اسأل قبل كل تعديل».
            if (ask && !confirm(a, "تنفيذ أمر", cmd.take(600) + "\n\n(المجلد: " + ws.rel(dir) + ")")) throw Denied()
            val timeout = (c.attrs["timeout"]?.toIntOrNull() ?: 120).coerceIn(5, 1800)
            run.full = true
            run.touched.add(dir)
            runShell(a, cmd, dir, timeout)
        }

        "open_project" -> {
            val d = ws.resolve(c.path)
            require(d.isDirectory) { "المجلد غير موجود: ${c.path}" }
            run.openAfter = d
            AiIde.remember(a, d)
            "سيتم فتح " + ws.rel(d) + " داخل IDE عند انتهاء المهمة"
        }

        else -> throw IllegalArgumentException("أداة غير معروفة: ${c.name}")
    }

    /** فهرس بداية السطر رقم line0 (يبدأ من 0)، أو -1 إلا كان خارج الملف. */
    private fun lineStartIndex(text: String, line0: Int): Int {
        if (line0 == 0) return 0
        var idx = 0
        var l = 0
        while (l < line0) {
            val nl = text.indexOf('\n', idx)
            if (nl < 0) return -1
            idx = nl + 1
            l++
        }
        return if (idx <= text.length) idx else -1
    }

    /** إذا وضع النموذج المحتوى داخل ``` بالغلط، نشيلو باش ما يدخلش فالملف. */
    private val fenceRe = Regex("^```[A-Za-z0-9_+#.-]*[ \\t]*\\r?\\n([\\s\\S]*?)\\r?\\n?```\\s*$")

    private fun unfence(s: String): String {
        val t = s.trim()
        if (!t.startsWith("```")) return s
        return fenceRe.find(t)?.groupValues?.get(1) ?: s
    }

    /** ينفّذ أمر shell فمجلد معين (مهلة افتراضية 120 ثانية). كيستعمل نفس bash وبيئة ترمنال AndroidIDE. */
    private fun runShell(a: Activity, cmd: String, dir: File, timeoutSec: Int): String {
        dir.mkdirs()
        val usr = File(a.filesDir, "usr")
        val bash = File(usr, "bin/bash")
        val sh = AiIde.terminalShell()?.path ?: if (bash.canExecute()) bash.path else "/system/bin/sh"
        val pb = ProcessBuilder(sh, "-c", cmd).directory(dir).redirectErrorStream(true)
        val env = pb.environment()
        val bin = File(usr, "bin")
        if (bin.isDirectory) {
            env["PATH"] = bin.path + ":" + (env["PATH"] ?: "/system/bin")
            env["PREFIX"] = usr.path
            val home = File(a.filesDir, "home")
            if (home.isDirectory) env["HOME"] = home.path
            val tmp = File(usr, "tmp")
            if (tmp.isDirectory) env["TMPDIR"] = tmp.path
            if (!env.containsKey("LANG")) env["LANG"] = "en_US.UTF-8"
        }
        AiIde.applyTerminalEnv(env)   // نفس بيئة ترمنال IDE (PATH, JAVA_HOME, ANDROID_HOME…)
        val proc = pb.start()
        val out = StringBuffer()
        val reader = Thread {
            try {
                proc.inputStream.bufferedReader().use { r ->
                    val buf = CharArray(4096)
                    while (true) {
                        val n = r.read(buf)
                        if (n < 0) break
                        if (out.length < 20000) out.append(buf, 0, n)
                    }
                }
            } catch (t: Throwable) { /* انتهى الـ process */ }
        }
        reader.start()
        val finished = proc.waitFor(timeoutSec.toLong(), TimeUnit.SECONDS)
        if (!finished) {
            proc.destroyForcibly()
            reader.join(500)
            throw IllegalStateException("انتهت المهلة ($timeoutSec ثانية)\n" + out.toString().trim().take(3000))
        }
        reader.join(1500)
        val text = out.toString().trim().ifEmpty { "(لا مخرجات)" }
        val code = proc.exitValue()
        if (code != 0) throw IllegalStateException("exit=$code\n" + text)
        return "exit=0\n" + text
    }
}
