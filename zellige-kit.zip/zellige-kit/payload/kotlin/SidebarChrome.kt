package com.itsaky.androidide.ai

import android.app.Activity
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.util.WeakHashMap

/**
 * درج الملفات بتصميم C6 (عرض 340dp): رأس المشروع («● gradle ready» + إغلاق) · 4 تبويبات أيقونات · خانة تصفية ·
 * شجرة بصفوف 34dp (شارات kt/xml/kts، أدلة المسافات البادئة، الملف المفتوح بحد عنبري، M/A من git وشارة AI) ·
 * تذييل («gradle ✓ / N معدّل · M بالذكاء» + «+ ملف» + «إغلاق المشروع»).
 *
 * كلشي وقت التشغيل: الدرج والـ NavigationRail والشجرة الأصلية كتبقى هي اللي كتخدم (التبويبات والأزرار كتضغط على نفس أزرار الـ rail)،
 * وإلا فشل شي حاجة كتبقى الواجهة الأصلية.
 */
object SidebarChrome {

    private const val SHELL_TAG = "zl_side_shell"
    private val ui = Handler(Looper.getMainLooper())

    private const val ID_TREE = "ide.editor.sidebar.fileTree"
    private const val ID_VARIANTS = "ide.editor.sidebar.buildVariants"
    private const val ID_TERMINAL = "ide.editor.sidebar.terminal"
    private const val ID_PREFS = "ide.editor.sidebar.preferences"
    private const val ID_CLOSE = "ide.editor.sidebar.closeProject"

    private class Row(val level: Int, val isDir: Boolean, val name: TextView, val status: TextView, val ai: TextView, val row: LinearLayout) {
        var sig = ""
    }

    /** حالة ملف محسوبة فthread خلفي: git (M/A) وشارة الذكاء. */
    private class Stat(val st: Char?, val ai: Char?)

    private class S(val a: Activity) {
        var shell: LinearLayout? = null
        var nameTv: TextView? = null
        var stateTv: TextView? = null
        var tabs: List<Pair<String, ImageView>> = emptyList()
        var tabLines: List<View> = emptyList()
        var footLeft1: TextView? = null
        var footLeft2: TextView? = null
        var filter: EditText? = null
        var query = ""
        var tick: Runnable? = null
        var rowsAt = 0L
        var footAt = 0L
        var changed = -1
        var changedBusy = false
        var changedAt = 0L
        var rows = WeakHashMap<View, Row>()
        var nav: ViewGroup? = null
        var open = false
        var filtered = false
        val stats = HashMap<String, Stat>()
        var statBusy = false
        var statAt = 0L
        var statKey = ""
        var aiCount = 0
        var root: File? = null
        var rootAt = 0L
        var lastOpen: String = ""
    }

    private var cur: S? = null

    fun install(a: Activity) {
        val s = cur?.takeIf { it.a === a } ?: S(a).also { cur = it }
        try { build(s) } catch (t: Throwable) { /* الدرج الأصلي كيبقى */ }
        s.tick?.let { ui.removeCallbacks(it) }
        val r = object : Runnable {
            override fun run() {
                if (cur !== s) return
                try { tick(s) } catch (t: Throwable) { }
                ui.postDelayed(this, if (s.open) 450L else 1200L)
            }
        }
        s.tick = r
        ui.post(r)
    }

    fun stop() { cur?.tick?.let { ui.removeCallbacks(it) }; cur?.tick = null }
    fun destroyed(a: Activity) { if (cur?.a === a) { stop(); cur = null } }

    // ------------------------------------------------------------------ build
    private fun railItemId(id: String) = id.hashCode()

    private fun rail(a: Activity): View? = Con.find(a, "navigation")

    /**
     * كيفعّل زر من أزرار الـ rail الأصلي: أولاً عبر القائمة (`performIdentifierAction` كيعيّط نفس مستمع الزر الأصلي)،
     * وإلا ما لقاش العنصر فالقائمة كيضغط على الـ view ديالو، وإلا فشل كلشي كيبان Toast (ماشي صمت).
     */
    private fun pressRail(a: Activity, id: String) {
        val iid = railItemId(id)
        val r = rail(a)
        var done = false
        try {
            val m = Con.call(r, "getMenu") as? android.view.Menu
            if (m != null && m.findItem(iid) != null) { m.performIdentifierAction(iid, 0); done = true }
        } catch (t: Throwable) { }
        if (!done) try {
            val mv = Con.call(r, "getMenuView") as? ViewGroup
            val v = mv?.findViewById<View>(iid)
            if (v != null) { v.performClick(); done = true }
        } catch (t: Throwable) { }
        if (!done && id == ID_PREFS) try {
            a.startActivity(android.content.Intent().setClassName(a, "com.itsaky.androidide.activities.PreferencesActivity"))
            done = true
        } catch (t: Throwable) { }
        if (!done) { Toast.makeText(a, "ما قدرتش نفتح هاد الزر", Toast.LENGTH_SHORT).show(); return }
        // الترمنال/الإعدادات كيفتحو شاشة أخرى: نسدّو الدرج باش نلقاوه مسدود فالرجوع
        if (id == ID_TERMINAL || id == ID_PREFS || id == ID_CLOSE) Con.call(drawerLayout(a), "closeDrawers")
    }

    private fun railChecked(a: Activity, id: String): Boolean {
        val m = Con.call(rail(a), "getMenu") as? android.view.Menu ?: return false
        return m.findItem(railItemId(id))?.isChecked == true
    }

    private fun drawerLayout(a: Activity): View? = Con.find(a, "editor_drawerLayout")

    private fun build(s: S) {
        val a = s.a
        val nav = Con.find<ViewGroup>(a, "startNav") ?: return
        val container = Con.find<ViewGroup>(a, "drawer_sidebar") ?: return
        if (s.shell?.parent === nav) return
        nav.findViewWithTag<View>(SHELL_TAG)?.let { return }
        if (container.parent !== nav) return
        val p = Con.pal(a)
        val mono = Con.mono(a)
        fun dp(v: Int) = Con.dp(a, v)

        val shell = LinearLayout(a).apply {
            tag = SHELL_TAG
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(p.bar)
        }

        // ---------------- الرأس 60dp
        val head = LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(14), 0, dp(14), 0)
        }
        val tile = FrameLayout(a).apply {
            background = Con.rounded(p.field, Con.dpf(a, 9f), p.border, dp(1))
        }
        tile.addView(View(a).apply { background = Con.rounded(0xFF3DDC84.toInt(), Con.dpf(a, 6f)) },
            FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER))
        tile.addView(View(a).apply {
            background = GradientDrawable().apply {
                setColor(0xFF0B3D1F.toInt())
                cornerRadii = floatArrayOf(Con.dpf(a, 7f), Con.dpf(a, 7f), Con.dpf(a, 7f), Con.dpf(a, 7f), 0f, 0f, 0f, 0f)
            }
        }, FrameLayout.LayoutParams(dp(13), dp(7), Gravity.CENTER))
        head.addView(tile, LinearLayout.LayoutParams(dp(36), dp(36)))
        val info = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        val nameTv = Con.text(a, "Zellige", 14f, p.text, mono).apply {
            setSingleLine(); ellipsize = TextUtils.TruncateAt.MIDDLE
            textDirection = View.TEXT_DIRECTION_LTR; textAlignment = View.TEXT_ALIGNMENT_VIEW_START
        }
        val stateTv = Con.text(a, "● gradle ready", 10.5f, p.green, mono).apply {
            textDirection = View.TEXT_DIRECTION_LTR; textAlignment = View.TEXT_ALIGNMENT_VIEW_START
        }
        info.addView(nameTv)
        info.addView(stateTv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(2) })
        head.addView(info, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(12); marginEnd = dp(8) })
        head.addView(Con.squareButton(a, "zl_ic_close", "إغلاق الدرج", p.dim, 0, p.border, 32, 32, 8, 16) {
            Con.call(drawerLayout(a), "closeDrawers")
        })
        shell.addView(head, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(60)))
        shell.addView(Con.hairline(a, p.line))

        // ---------------- تبويبات الأيقونات 40dp
        val tabsRow = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        val defs = listOf(ID_TREE to "zl_ic_folder_open", ID_VARIANTS to "zl_ic_layers", ID_TERMINAL to "zl_ic_terminal", ID_PREFS to "zl_ic_settings")
        val icons = ArrayList<Pair<String, ImageView>>()
        val lines = ArrayList<View>()
        for ((id, ic) in defs) {
            val cell = FrameLayout(a).apply {
                isClickable = true; isFocusable = true
                background = Con.ripple(null, 0f)
                setOnClickListener { pressRail(a, id); if (id != ID_TREE) { /* الوجهة الجديدة كتعوّض الشجرة */ } }
            }
            val img = Con.iconView(a, ic, p.muted, 19)
            cell.addView(img, FrameLayout.LayoutParams(dp(19), dp(19), Gravity.CENTER))
            val line = View(a).apply { setBackgroundColor(Color.TRANSPARENT) }
            cell.addView(line, FrameLayout.LayoutParams(dp(30), dp(2), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL))
            tabsRow.addView(cell, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
            icons.add(id to img); lines.add(line)
        }
        shell.addView(tabsRow, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(40)))
        shell.addView(Con.hairline(a, p.line))

        // ---------------- خانة التصفية
        val box = LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            background = Con.rounded(p.field, Con.dpf(a, 8f), p.border, dp(1))
            setPadding(dp(10), 0, dp(10), 0)
        }
        box.addView(Con.iconView(a, "zl_ic_search", p.faint, 15))
        val filter = EditText(a).apply {
            hint = "filter files…"
            setHintTextColor(p.faint); setTextColor(p.text)
            typeface = mono; textSize = 12f
            background = null
            setSingleLine()
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_DONE
            textDirection = View.TEXT_DIRECTION_LTR
            setPadding(dp(8), 0, dp(4), 0)
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(x: CharSequence?, st: Int, c: Int, af: Int) {}
                override fun onTextChanged(x: CharSequence?, st: Int, b: Int, c: Int) {}
                override fun afterTextChanged(e: Editable?) { s.query = e?.toString().orEmpty().trim(); applyFilter(s) }
            })
        }
        box.addView(filter, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        box.addView(Con.text(a, "/", 10f, p.faint, mono).apply {
            setPadding(dp(5), 0, dp(5), 0); gravity = Gravity.CENTER
            background = Con.rounded(Color.TRANSPARENT, Con.dpf(a, 4f), p.border, dp(1))
        })
        val boxWrap = FrameLayout(a).apply { setPadding(dp(12), dp(10), dp(12), dp(8)) }
        boxWrap.addView(box, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(36)))
        shell.addView(boxWrap, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // ---------------- المحتوى الأصلي (الـ fragment كما هو)
        nav.removeView(container)
        shell.addView(container, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        // ---------------- التذييل 62dp
        shell.addView(Con.hairline(a, p.border))
        val foot = LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(p.bar)
            setPadding(dp(12), 0, dp(12), 0)
        }
        val fl = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_LTR }
        val f1 = Con.text(a, "gradle ✓", 10.5f, p.green, mono).apply { textDirection = View.TEXT_DIRECTION_LTR }
        val f2 = Con.text(a, "", 10.5f, p.muted, mono).apply { textDirection = View.TEXT_DIRECTION_LTR }
        fl.addView(f1); fl.addView(f2, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(2) })
        foot.addView(fl, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        fun btn(label: String, icon: String?, fill: Boolean, f: () -> Unit): View = LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), 0, dp(12), 0)
            background = Con.ripple(
                if (fill) Con.rounded(p.chipHi, Con.dpf(a, 9f)) else Con.rounded(Color.TRANSPARENT, Con.dpf(a, 9f), p.border, dp(1)),
                Con.dpf(a, 9f)
            )
            isClickable = true; isFocusable = true
            setOnClickListener { f() }
            if (icon != null) addView(Con.iconView(a, icon, p.text2, 14), LinearLayout.LayoutParams(dp(14), dp(14)).apply { marginEnd = dp(6) })
            addView(Con.text(a, label, 12.5f, p.text2, null, true))
        }
        foot.addView(btn("ملف", "zl_ic_add", false) { newFile(s) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(38)).apply { marginEnd = dp(8) })
        foot.addView(btn("إغلاق المشروع", null, true) { pressRail(a, ID_CLOSE) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(38)))
        shell.addView(foot, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(62)))

        // مهم: NavigationView فيه طبقة فارغة (NavigationMenuView، match_parent) كتاكل اللمسات إلا كانت فوق المحتوى.
        // الـ shell خاصو يكون آخر ولد (فوق) والطبقة الفارغة كتتخبّى.
        for (i in 0 until nav.childCount) {
            val c = nav.getChildAt(i)
            if (c !== shell && c !== container && Con.isA(c, "NavigationMenuView")) c.visibility = View.GONE
        }
        nav.addView(shell, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        nav.setBackgroundColor(p.bar)
        (nav.layoutParams)?.let {
            val w = a.resources.displayMetrics.widthPixels
            it.width = minOf(dp(340), (w * 0.92f).toInt())
            nav.layoutParams = it
        }

        // الـ rail والعنوان الأصليين مخبّيين (التبويبات ديالنا كتضغط عليهم)
        rail(a)?.visibility = View.GONE
        Con.find<View>(a, "title")?.visibility = View.GONE

        s.shell = shell; s.nameTv = nameTv; s.stateTv = stateTv; s.tabs = icons; s.tabLines = lines
        s.footLeft1 = f1; s.footLeft2 = f2; s.filter = filter
    }

    // ------------------------------------------------------------------ new file
    private fun newFile(s: S) {
        val a = s.a
        val root = activeRoot(s) ?: return
        val et = EditText(a).apply {
            hint = "app/src/main/java/Foo.kt"
            setSingleLine(); typeface = Con.mono(a); textSize = 13f
            textDirection = View.TEXT_DIRECTION_LTR
        }
        android.app.AlertDialog.Builder(a)
            .setTitle("ملف جديد")
            .setMessage(root.name)
            .setView(et)
            .setPositiveButton("إنشاء") { _, _ ->
                val rel = et.text.toString().trim().trim('/')
                if (rel.isEmpty() || rel.contains("..")) { Toast.makeText(a, "اسم غير صالح", Toast.LENGTH_SHORT).show(); return@setPositiveButton }
                val f = File(root, rel)
                try {
                    if (f.exists()) { Toast.makeText(a, "كاين من قبل", Toast.LENGTH_SHORT).show(); return@setPositiveButton }
                    f.parentFile?.mkdirs()
                    f.createNewFile()
                    runCatching { AiIde.refreshAll(a) }
                    Con.call(drawerLayout(a), "closeDrawers")
                    ui.postDelayed({ Con.call(a, "openFile", f, null) }, 350)
                } catch (t: Throwable) {
                    Toast.makeText(a, "تعذّر الإنشاء: " + (t.message ?: ""), Toast.LENGTH_LONG).show()
                }
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    // ------------------------------------------------------------------ tick
    private fun activeRoot(s: S): File? {
        val now = System.currentTimeMillis()
        if (now - s.rootAt > 4000) {
            s.rootAt = now
            val ed = EditorAccess.find(s.a)
            s.root = AiIde.gradleRootOfCached(ed?.file())?.takeIf { it.isDirectory }
                ?: runCatching { AiIde.activeRoot(s.a, null) }.getOrNull()
        }
        return s.root
    }

    private fun tick(s: S) {
        val a = s.a
        val nav = s.nav?.takeIf { it.isAttachedToWindow } ?: Con.find<ViewGroup>(a, "startNav")?.also { s.nav = it } ?: return
        build(s)
        s.open = nav.isShown && nav.width > 0
        if (!s.open) return
        val p = Con.pal(a)
        val shell = s.shell ?: return
        // حواف النظام
        val ins = nav.rootWindowInsets
        @Suppress("DEPRECATION")
        val top = ins?.stableInsetTop ?: 0
        @Suppress("DEPRECATION")
        val bottom = ins?.stableInsetBottom ?: 0
        if (shell.paddingTop != top || shell.paddingBottom != bottom) shell.setPadding(0, top, 0, bottom)

        val root = activeRoot(s)
        Con.setTextIfChanged(s.nameTv, root?.name ?: "Zellige")
        val working = Con.find<View>(a, "progress_indicator")?.visibility == View.VISIBLE
        Con.setTextIfChanged(s.stateTv, if (working) "● working…" else "● gradle ready")
        val sc = if (working) p.amber else p.green
        if (s.stateTv?.currentTextColor != sc) s.stateTv?.setTextColor(sc)

        // التبويب النشط
        for ((i, pair) in s.tabs.withIndex()) {
            val on = railChecked(a, pair.first)
            val c = if (on) p.amber else p.muted
            if (pair.second.tag != c) {
                pair.second.tag = c
                pair.second.imageTintList = android.content.res.ColorStateList.valueOf(c)
                s.tabLines.getOrNull(i)?.setBackgroundColor(if (on) p.amber else Color.TRANSPARENT)
            }
        }
        val treeVisible = Con.find<View>(a, "horizontal_croll")?.isShown == true
        (s.filter?.parent as? View)?.let { val al = if (treeVisible) 1f else 0.4f; if (it.alpha != al) it.alpha = al }

        val now = System.currentTimeMillis()
        val openPath = EditorAccess.find(a)?.file()?.path.orEmpty()
        if (treeVisible && (now - s.rowsAt > 1800 || openPath != s.lastOpen)) {
            s.rowsAt = now; s.lastOpen = openPath
            styleRows(s, root, openPath)
        }
        if (now - s.footAt > 3000) { s.footAt = now; footer(s, root) }
    }

    private fun footer(s: S, root: File?) {
        val a = s.a
        val p = Con.pal(a)
        val hasGit = root != null && GitLite.gitDir(root) != null
        if (root != null) refreshCounts(s, root, hasGit)
        val ai = s.aiCount
        val sb = android.text.SpannableStringBuilder()
        if (hasGit && s.changed >= 0) sb.append("${s.changed} changed · ")
        val st = sb.length
        sb.append("$ai by AI")
        val aiStart = sb.length - "AI".length
        sb.setSpan(android.text.style.ForegroundColorSpan(p.amber), aiStart, sb.length, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        val tv = s.footLeft2
        if (tv != null && !TextUtils.equals(tv.text, sb)) tv.text = sb
        Con.setVisible(tv, if (st == 0 && ai == 0 && !hasGit) View.GONE else View.VISIBLE)
    }

    /**
     * عدد الملفات المتغيّرة حسب git + عدد ملفات الذكاء، فthread خلفي (مشي مجلدات + exists()/canonicalFile كانو كيتدارو على الـ UI thread)،
     * كل 20 ثانية بحد أقصى 4000 ملف.
     */
    private fun refreshCounts(s: S, root: File, hasGit: Boolean) {
        val now = System.currentTimeMillis()
        if (s.changedBusy || now - s.changedAt < 20000) return
        s.changedBusy = true; s.changedAt = now
        Thread {
            var n = 0
            var ai = 0
            try { ai = AiTrack.countIn(root) } catch (t: Throwable) { }
            if (hasGit) try {
                var visited = 0
                fun walk(d: File, depth: Int) {
                    if (depth > 9 || visited > 4000) return
                    for (k in d.listFiles() ?: return) {
                        visited++
                        if (k.isDirectory) {
                            if (k.name in SKIP) continue
                            walk(k, depth + 1)
                        } else if (GitLite.fileStatus(root, k) != null) n++
                    }
                }
                walk(root, 0)
            } catch (t: Throwable) { n = -1 }
            ui.post { s.changed = if (hasGit) n else -1; s.aiCount = ai; s.changedBusy = false; s.footAt = 0 }
        }.also { it.isDaemon = true }.start()
    }

    private val SKIP = setOf(".git", "build", ".gradle", ".idea", "node_modules", ".cxx")

    // ------------------------------------------------------------------ rows
    private fun nodeHeaderId(a: Activity) = Con.id(a, "node_header")

    /**
     * مسار الصف: كنطلعو من الصف لـ node_header ← wrapper ← node_items ديال الأب ← wrapper ديال الأب… وكنجمعو الأسماء
     * (الجذر الخفي اسمو فارغ كيتجاهل؛ أول اسم = مجلد المشروع).
     */
    private fun pathOf(a: Activity, nameView: TextView, root: File?): File? {
        if (root == null) return null
        val hdr = nodeHeaderId(a)
        val items = Con.id(a, "node_items")
        val nid = Con.id(a, "filetree_name")
        if (hdr == 0 || items == 0 || nid == 0) return null
        fun headerOf(v: View): View? {
            var x: View? = v
            while (x != null) { if (x.id == hdr) return x; x = x.parent as? View }
            return null
        }
        val names = ArrayList<String>()
        var h = headerOf(nameView)
        var guard = 0
        while (h != null && guard++ < 40) {
            val n = h.findViewById<TextView>(nid)?.text?.toString() ?: return null
            if (n.isNotEmpty()) names.add(0, n)
            val wrapper = h.parent as? View ?: break
            val box = wrapper.parent as? View ?: break
            if (box.id != items) break
            val upper = box.parent as? ViewGroup ?: break
            h = upper.getChildAt(0)?.takeIf { it.id == hdr }
        }
        if (names.isEmpty()) return null
        val rel = if (names[0] == root.name) names.drop(1) else names
        var f = root
        for (n in rel) f = File(f, n)
        return f
    }

    private fun levelOf(a: Activity, row: View): Int {
        val unit = Con.dp(a, 15).coerceAtLeast(1)
        val base = Con.dp(a, 8)
        val ps = row.paddingStart
        return ((ps - base + unit / 2) / unit).coerceAtLeast(0)
    }

    private class Guides(private val lines: Int, lineColor: Int, private val step: Int, private val offset: Int) : Drawable() {
        private val paint = Paint().apply { color = lineColor; strokeWidth = 1f }
        override fun draw(c: Canvas) {
            val b = bounds
            for (i in 0 until lines) {
                val x = b.left + offset + i * step
                c.drawLine(x.toFloat(), b.top.toFloat(), x.toFloat(), b.bottom.toFloat(), paint)
            }
        }
        override fun setAlpha(alpha: Int) { paint.alpha = alpha }
        override fun setColorFilter(cf: ColorFilter?) { paint.colorFilter = cf }
        @Suppress("OVERRIDE_DEPRECATION")
        override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
    }

    private fun badgeColor(p: Con.P, ext: String): Int = when (ext) {
        "kt" -> p.purple; "xml" -> p.blue; "kts", "gradle" -> p.green; "java" -> p.orange
        "json", "md", "txt", "properties", "toml", "yml", "yaml" -> p.gold
        else -> p.muted
    }

    private fun styleRows(s: S, root: File?, openPath: String) {
        val a = s.a
        val tree = Con.find<View>(a, "horizontal_croll") ?: return
        val p = Con.pal(a)
        val mono = Con.mono(a)
        fun dp(v: Int) = Con.dp(a, v)
        val nameId = Con.id(a, "filetree_name")
        if (nameId == 0) return
        // الشجرة LTR (كما فالتصميم) وبدون حشو جانبي
        if (tree.layoutDirection != View.LAYOUT_DIRECTION_LTR) tree.layoutDirection = View.LAYOUT_DIRECTION_LTR
        (tree.parent as? View)?.let { if (it.paddingLeft != 0 || it.paddingRight != 0) it.setPadding(0, it.paddingTop, 0, it.paddingBottom) }

        val names = Con.allOf(tree, { it.id == nameId && it is TextView })
        val wanted = ArrayList<String>()
        for (nv in names) {
            val name = nv as TextView
            val row = name.parent as? LinearLayout ?: continue
            var info = s.rows[row]
            val file = pathOf(a, name, root)
            if (info == null) {
                val chevron = row.findViewById<ImageView>(Con.id(a, "filetree_chevron"))
                val icon = row.findViewById<ImageView>(Con.id(a, "filetree_icon"))
                val sw = row.findViewById<View>(Con.id(a, "chevronLoadingSwitcher"))
                val isDir = chevron != null && chevron.visibility == View.VISIBLE
                val level = levelOf(a, row)
                row.setPaddingRelative(dp(10) + level * dp(16), 0, dp(12), 0)
                row.minimumHeight = dp(34)
                (sw?.layoutParams as? ViewGroup.MarginLayoutParams)?.let { it.width = dp(14); it.height = dp(14); it.marginEnd = dp(6); sw.layoutParams = it }
                chevron?.imageTintList = android.content.res.ColorStateList.valueOf(p.muted)
                if (isDir) {
                    icon?.setImageDrawable(Con.icon(a, "zl_ic_folder"))
                    icon?.imageTintList = android.content.res.ColorStateList.valueOf(p.dim)
                    (icon?.layoutParams as? ViewGroup.MarginLayoutParams)?.let { it.width = dp(15); it.height = dp(15); it.marginEnd = dp(6); icon.layoutParams = it }
                } else {
                    icon?.visibility = View.GONE
                    val ext = name.text.toString().substringAfterLast('.', "").lowercase()
                    val badge = Con.text(a, ext.take(4), 10f, badgeColor(p, ext), mono, true).apply {
                        textDirection = View.TEXT_DIRECTION_LTR; gravity = Gravity.START
                    }
                    val at = row.indexOfChild(name)
                    row.addView(badge, at, LinearLayout.LayoutParams(dp(28), ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginEnd = dp(4) })
                }
                name.typeface = mono
                name.textSize = 12.5f
                name.setSingleLine(); name.ellipsize = TextUtils.TruncateAt.MIDDLE
                (name.layoutParams as? LinearLayout.LayoutParams)?.let { it.width = 0; it.weight = 1f; name.layoutParams = it }
                val st = Con.text(a, "", 11f, p.gold, mono, true).apply { visibility = View.GONE; setPadding(dp(8), 0, 0, 0) }
                val ai = Con.text(a, "AI", 10f, p.amber, mono, true).apply {
                    visibility = View.GONE
                    setPadding(dp(6), 0, dp(6), 0); gravity = Gravity.CENTER
                    background = Con.rounded(p.amberSoft, Con.dpf(a, 5f), p.amber and 0x8CFFFFFF.toInt() or 0x8C000000.toInt(), dp(1))
                }
                row.addView(st, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
                row.addView(ai, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(18)).apply { marginStart = dp(8) })
                info = Row(level, isDir, name, st, ai, row)
                s.rows[row] = info
            }
            if (file != null && !info.isDir) wanted.add(file.path)
            // الحالة: من الكاش فقط (الحساب الحقيقي فthread خلفي)
            val selected = isOpen(file, openPath)
            applyRowState(a, p, info, s.stats[file?.path], selected)
        }
        if (s.query.isNotEmpty() || s.filtered) { applyFilter(s); s.filtered = s.query.isNotEmpty() }
        requestStats(s, root, wanted)
    }

    /** M/A + شارة الذكاء للملفات الظاهرة، فthread خلفي (stat/canonicalFile/هاش)، وكنعاودو نرسمو غير إلا وصلت نتيجة. */
    private fun requestStats(s: S, root: File?, paths: List<String>) {
        if (root == null || s.statBusy) return
        val key = paths.joinToString("\u0000")
        val now = System.currentTimeMillis()
        if (key == s.statKey && now - s.statAt < 6000) return
        s.statKey = key; s.statAt = now; s.statBusy = true
        val openPath = s.lastOpen
        Thread {
            val out = HashMap<String, Stat>()
            try {
                val noGit = GitLite.gitDir(root) == null
                for (path in paths) {
                    val f = File(path)
                    val git = GitLite.fileStatus(root, f)
                    val ai = AiTrack.kind(f)
                    out[path] = Stat(if (git == null && ai != null && noGit) ai else git, ai)
                }
            } catch (t: Throwable) { }
            ui.post {
                s.statBusy = false
                if (cur !== s) return@post
                s.stats.clear(); s.stats.putAll(out)
                if (s.open) styleRowsFromCache(s, root, openPath)
            }
        }.also { it.isDaemon = true }.start()
    }

    private fun styleRowsFromCache(s: S, root: File?, openPath: String) {
        val a = s.a
        val tree = Con.find<View>(a, "horizontal_croll") ?: return
        val nameId = Con.id(a, "filetree_name")
        val p = Con.pal(a)
        for (nv in Con.allOf(tree, { it.id == nameId && it is TextView })) {
            val name = nv as TextView
            val row = name.parent as? LinearLayout ?: continue
            val info = s.rows[row] ?: continue
            val file = pathOf(a, name, root)
            val selected = isOpen(file, openPath)
            applyRowState(a, p, info, s.stats[file?.path], selected)
        }
    }

    /** نفس الملف المفتوح؟ مقارنة نصية، وإلا (نفس الاسم فقط) canonical لتفادي اختلاف /sdcard و /storage/emulated/0. */
    private fun isOpen(f: File?, openPath: String): Boolean {
        if (f == null || openPath.isEmpty()) return false
        if (f.path == openPath) return true
        if (f.name != openPath.substringAfterLast('/')) return false
        return try { f.canonicalPath == File(openPath).canonicalPath } catch (t: Throwable) { false }
    }

    private fun applyRowState(a: Activity, p: Con.P, r: Row, stat: Stat?, selected: Boolean) {
        val st = stat?.st
        val aiKind = stat?.ai
        val sig = "$selected|$st|$aiKind|${p.dark}"
        if (sig == r.sig) return                       // ما تبدّل والو: ما نعاودوش نبنيو drawables
        r.sig = sig
        fun dp(v: Int) = Con.dp(a, v)
        val guides = Guides(r.level, p.guide, dp(16), dp(17))
        val base: Drawable = if (selected) {
            val ld = LayerDrawable(arrayOf<Drawable>(ColorDrawable(p.sel), ColorDrawable(p.amber), guides))
            ld.setLayerGravity(1, Gravity.START or Gravity.CENTER_VERTICAL)
            ld.setLayerWidth(1, dp(2)); ld.setLayerHeight(1, dp(22))
            ld
        } else LayerDrawable(arrayOf<Drawable>(ColorDrawable(Color.TRANSPARENT), guides))
        r.row.background = Con.ripple(base, 0f)
        r.name.setTextColor(
            if (selected) (if (p.dark) Color.WHITE else p.text)
            else if (r.isDir) p.text else p.text2
        )
        if (st != null && !r.isDir) {
            r.status.text = st.toString()
            r.status.setTextColor(if (st == 'A') p.green else p.gold)
            r.status.visibility = View.VISIBLE
        } else r.status.visibility = View.GONE
        r.ai.visibility = if (aiKind != null && !r.isDir) View.VISIBLE else View.GONE
    }

    // ------------------------------------------------------------------ filter
    /** تصفية الصفوف المحمّلة: wrapper كيبان إلا اسمو أو أحد أبنائو كيطابق. */
    private fun applyFilter(s: S) {
        val a = s.a
        val tree = Con.find<View>(a, "horizontal_croll") ?: return
        val q = s.query.lowercase()
        val nameId = Con.id(a, "filetree_name")
        val hdr = nodeHeaderId(a)
        val items = Con.id(a, "node_items")
        if (nameId == 0 || hdr == 0 || items == 0) return
        fun visit(w: ViewGroup): Boolean {
            val h = w.findViewById<ViewGroup>(hdr)?.takeIf { it.parent === w }
            val own = h?.findViewById<TextView>(nameId)?.text?.toString()?.lowercase().orEmpty()
            var any = q.isEmpty() || own.contains(q)
            val box = w.findViewById<ViewGroup>(items)?.takeIf { it.parent === w }
            if (box != null) for (i in 0 until box.childCount) {
                val c = box.getChildAt(i) as? ViewGroup ?: continue
                if (visit(c)) any = true
            }
            w.visibility = if (any) View.VISIBLE else View.GONE
            return any
        }
        // الـ wrappers العليا: أبناء LinearLayout ديال viewTreeItems اللي فيه node_header
        val tops = Con.allOf(tree, { v -> v is ViewGroup && v.findViewById<View>(hdr)?.parent === v && !(v.parent is ViewGroup && (v.parent as View).id == items) })
        for (t in tops) visit(t as ViewGroup)
    }
}
