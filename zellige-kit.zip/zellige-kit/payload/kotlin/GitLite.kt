package com.itsaky.androidide.ai

import android.content.Context
import org.json.JSONObject
import java.io.DataInputStream
import java.io.File
import java.security.MessageDigest

/**
 * قراءة بسيطة (بلا مكتبات) لحالة git: اسم الفرع من `.git/HEAD` وحالة الملفات (M معدّل / A جديد) من `.git/index`
 * (صيغة DIRC النسخة 2 و3؛ النسخة 4 غير مدعومة ← كنرجعو null وما كتبانش الشارات).
 * كتستعمل فقط لعرض الشارات فدرج الملفات وشريط الحالة، ما كتكتب والو.
 */
object GitLite {

    fun gitDir(root: File): File? {
        val g = File(root, ".git")
        if (g.isDirectory) return g
        if (g.isFile) {                              // worktree / submodule: "gitdir: <path>"
            val t = try { g.readText().trim() } catch (e: Throwable) { return null }
            if (t.startsWith("gitdir:")) {
                val p = File(t.removePrefix("gitdir:").trim())
                val d = if (p.isAbsolute) p else File(root, p.path)
                return d.takeIf { it.isDirectory }
            }
        }
        return null
    }

    fun branch(root: File): String? {
        val d = gitDir(root) ?: return null
        val head = try { File(d, "HEAD").readText().trim() } catch (e: Throwable) { return null }
        return if (head.startsWith("ref:")) head.removePrefix("ref:").trim().removePrefix("refs/heads/")
        else head.take(7).ifEmpty { null }
    }

    class Entry(val size: Long, val mtime: Long, val sha: String)

    private class Cached(val stamp: Long, val len: Long, val map: Map<String, Entry>?)
    private val cache = HashMap<String, Cached>()

    /** مسار نسبي (بـ /) ← مدخل index. null إلا ما كاينش git أو الصيغة غير مدعومة. */
    fun index(root: File): Map<String, Entry>? {
        val d = gitDir(root) ?: return null
        val f = File(d, "index")
        if (!f.isFile) return null
        synchronized(cache) {
            val c = cache[f.path]
            if (c != null && c.stamp == f.lastModified() && c.len == f.length()) return c.map
        }
        val m = try { parseIndex(f.readBytes()) } catch (e: Throwable) { null }
        synchronized(cache) { cache[f.path] = Cached(f.lastModified(), f.length(), m) }
        return m
    }

    internal fun parseIndex(b: ByteArray): Map<String, Entry>? {
        val ins = DataInputStream(b.inputStream())
        val magic = ByteArray(4); ins.readFully(magic)
        if (String(magic, Charsets.US_ASCII) != "DIRC") return null
        val version = ins.readInt()
        if (version != 2 && version != 3) return null
        val count = ins.readInt()
        val out = HashMap<String, Entry>(count * 2)
        var pos = 12
        repeat(count) {
            if (pos + 62 > b.size) return out
            fun u32(o: Int): Long = ((b[o].toLong() and 0xff) shl 24) or ((b[o + 1].toLong() and 0xff) shl 16) or
                ((b[o + 2].toLong() and 0xff) shl 8) or (b[o + 3].toLong() and 0xff)
            val mtime = u32(pos + 8)
            val size = u32(pos + 36)
            val sha = StringBuilder(40)
            for (k in 0 until 20) sha.append(String.format("%02x", b[pos + 40 + k].toInt() and 0xff))
            val flags = ((b[pos + 60].toInt() and 0xff) shl 8) or (b[pos + 61].toInt() and 0xff)
            var nameStart = pos + 62
            if (version >= 3 && (flags and 0x4000) != 0) nameStart += 2
            var e = nameStart
            while (e < b.size && b[e].toInt() != 0) e++
            val name = String(b, nameStart, e - nameStart, Charsets.UTF_8)
            out[name] = Entry(size, mtime, sha.toString())
            val len = (e - pos) + 1                    // مع NUL
            pos += (len + 7) / 8 * 8                   // محاذاة 8 بايت
        }
        return out
    }

    private fun blobSha(f: File): String? = try {
        val md = MessageDigest.getInstance("SHA-1")
        md.update("blob ${f.length()}\u0000".toByteArray(Charsets.US_ASCII))
        f.inputStream().use { ins ->
            val buf = ByteArray(65536)
            while (true) { val n = ins.read(buf); if (n < 0) break; md.update(buf, 0, n) }
        }
        md.digest().joinToString("") { String.format("%02x", it.toInt() and 0xff) }
    } catch (e: Throwable) { null }

    private val IGNORED = Regex("(^|/)(build|\\.gradle|\\.idea|\\.cxx|node_modules|\\.zellige|\\.androidide)(/|$)")
    private val memo = HashMap<String, Pair<String, Char?>>()

    /** 'M' معدّل · 'A' جديد (غير متتبَّع وغير مُتجاهَل بالقواعد الشائعة) · null بلا تغيير/غير معروف. */
    fun fileStatus(root: File, f: File): Char? {
        val idx = index(root) ?: return null
        val rel = try { f.canonicalFile.relativeTo(root.canonicalFile).path.replace(File.separatorChar, '/') } catch (e: Throwable) { return null }
        if (rel.startsWith("..")) return null
        if (IGNORED.containsMatchIn(rel)) return null
        val e = idx[rel] ?: return 'A'
        if (!f.isFile) return null
        val stamp = "${f.lastModified()}:${f.length()}:${e.sha}"
        synchronized(memo) { memo[f.path]?.let { if (it.first == stamp) return it.second } }
        // «racy git»: ملف تبدّل فنفس الثانية اللي تكتب فيها الـ index ← ما نثقوش فـ mtime ونحسبو الهاش
        val idxSec = gitDir(root)?.let { File(it, "index").lastModified() / 1000 } ?: Long.MAX_VALUE
        val racy = f.lastModified() / 1000 >= idxSec
        val st: Char? = if (!racy && f.length() == e.size && f.lastModified() / 1000 == e.mtime) null
        else if (f.length() > 8_000_000) 'M'
        else if (blobSha(f) == e.sha) null else 'M'
        synchronized(memo) { memo[f.path] = stamp to st }
        return st
    }
}

/**
 * ملفات لمسها الذكاء (للشارة «AI» فدرج الملفات وعدّاد «N بالذكاء»). كتتخزن فـ SharedPreferences:
 * مسار ← (A إلا خلقو، M إلا عدّلو، ووقت اللمسة). كتنتهي بعد 14 يوم.
 */
object AiTrack {
    private const val KEY = "ai_touched"
    private const val TTL = 14L * 24 * 3600 * 1000
    @Volatile private var ctx: Context? = null
    private var map: MutableMap<String, Pair<Char, Long>>? = null

    @JvmStatic
    fun init(c: Context) { ctx = c.applicationContext }

    private fun sp() = ctx?.getSharedPreferences("ai_assistant", Context.MODE_PRIVATE)

    @Synchronized
    private fun load(): MutableMap<String, Pair<Char, Long>> {
        map?.let { return it }
        val m = HashMap<String, Pair<Char, Long>>()
        try {
            val raw = sp()?.getString(KEY, null)
            if (!raw.isNullOrBlank()) {
                val o = JSONObject(raw)
                val it = o.keys()
                val now = System.currentTimeMillis()
                while (it.hasNext()) {
                    val k = it.next()
                    val v = o.getJSONArray(k)
                    val t = v.getLong(1)
                    if (now - t < TTL) m[k] = v.getString(0)[0] to t
                }
            }
        } catch (e: Throwable) { /* ملف تالف: نبداو من جديد */ }
        map = m
        return m
    }

    @Synchronized
    private fun save() {
        val m = map ?: return
        try {
            val o = JSONObject()
            m.entries.sortedByDescending { it.value.second }.take(400).forEach {
                o.put(it.key, org.json.JSONArray().put(it.value.first.toString()).put(it.value.second))
            }
            sp()?.edit()?.putString(KEY, o.toString())?.apply()
        } catch (e: Throwable) { }
    }

    /** كتنادى من AiAgent مللي الذكاء يبدّل ملف (old == null ← جديد). */
    @Synchronized
    fun note(f: File, created: Boolean) {
        val m = load()
        val key = try { f.canonicalPath } catch (e: Throwable) { f.path }
        val prev = m[key]
        // ملف خلقو الذكاء كيبقى «A» حتى لو عدّلو من بعد
        val kind = if (created || prev?.first == 'A') 'A' else 'M'
        m[key] = kind to System.currentTimeMillis()
        save()
    }

    @Synchronized
    fun kind(f: File): Char? {
        val key = try { f.canonicalPath } catch (e: Throwable) { f.path }
        return load()[key]?.first
    }

    /** عدد ملفات المشروع اللي لمسها الذكاء. */
    @Synchronized
    fun countIn(root: File): Int {
        val base = try { root.canonicalPath } catch (e: Throwable) { root.path }
        return load().keys.count { it.startsWith("$base/") && File(it).exists() }
    }
}
