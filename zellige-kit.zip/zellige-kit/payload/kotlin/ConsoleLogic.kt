package com.itsaky.androidide.ai

import java.io.File

/**
 * منطق صافي (بلا أي اعتماد على Android) تابع للواجهات الجديدة: كيتجرّب على JVM فـ tests/jvm.
 * ما فيه لا View ولا Activity، غير نصوص وملفات.
 */
object ConsoleLogic {

    class Fail(val id: Int, val errors: List<String>, val tail: String)

    /** يحلل مخرجات gradle: آخر «BUILD FAILED» بدون «BUILD SUCCESSFUL» بعدو. */
    fun detect(text: String): Fail? {
        val failIdx = maxOf(text.lastIndexOf("BUILD FAILED"), text.lastIndexOf("FAILURE: Build failed"))
        if (failIdx < 0) return null
        if (text.lastIndexOf("BUILD SUCCESSFUL") > failIdx) return null
        val id = Regex("BUILD FAILED").findAll(text).count() * 31 + Regex("FAILURE: Build failed").findAll(text).count()
        val from = (failIdx - 7000).coerceAtLeast(0)
        val seg = text.substring(from, minOf(text.length, failIdx + 900))
        val errs = LinkedHashSet<String>()
        for (raw in seg.lineSequence()) {
            val l = raw.trim()
            if (l.startsWith("e: ") || Regex("^[^\\s]+\\.(java|kt|xml):\\d+(:\\d+)?:? (error|e):", RegexOption.IGNORE_CASE).containsMatchIn(l) ||
                Regex("\\berror:", RegexOption.IGNORE_CASE).containsMatchIn(l) && l.contains(".java")
            ) errs.add(l)
        }
        return Fail(id, errs.toList(), seg.takeLast(2600))
    }


    fun moduleOf(root: File, f: File): String? {
        val rel = try { f.canonicalFile.relativeTo(root.canonicalFile).path } catch (t: Throwable) { return null }
        val parts = rel.split(File.separatorChar)
        return if (parts.size >= 2 && parts[0] != "..") parts[0] else null
    }


    private val SRC_EXT = setOf("kt", "java", "xml", "kts", "gradle", "json", "md", "py", "js", "ts", "html", "css", "txt", "properties", "toml", "yml", "yaml")
    private val SKIP_DIRS = setOf("build", ".git", ".gradle", ".idea", "node_modules", "out", ".cxx", ".zellige", ".androidide")

    /** آخر الملفات المعدّلة فالمشروع (حد أقصى 4)، بحث محدود العمق باش ما يتقل الجهاز. */
    fun recentFiles(root: File, max: Int = 4): List<File> {
        val found = ArrayList<File>()
        var visited = 0
        fun walk(d: File, depth: Int) {
            if (depth > 7 || visited > 5000) return
            val kids = d.listFiles() ?: return
            for (k in kids) {
                visited++
                if (k.isDirectory) { if (k.name !in SKIP_DIRS) walk(k, depth + 1) }
                else if (k.extension.lowercase() in SRC_EXT) found.add(k)
            }
        }
        walk(root, 0)
        return found.sortedByDescending { it.lastModified() }.take(max)
    }


    /** ملف واجهة Android: res/layout/x.xml وأخواتها (layout-land، layout-v26…). */
    fun isLayoutXml(f: File?): Boolean {
        if (f == null || !f.name.endsWith(".xml", ignoreCase = true)) return false
        val dir = f.parentFile ?: return false
        return dir.name.startsWith("layout") && dir.parentFile?.name == "res"
    }

    /** ملفات واجهات XML ديال المشروع (الأحدث أولاً) — باش المستعمل يلقاهم ويعاينهم بسهولة. */
    fun layoutFiles(root: File, max: Int = 8): List<File> {
        val found = ArrayList<File>()
        var visited = 0
        fun walk(d: File, depth: Int) {
            if (depth > 8 || visited > 6000) return
            val kids = d.listFiles() ?: return
            for (k in kids) {
                visited++
                if (k.isDirectory) {
                    if (k.name in SKIP_DIRS) continue
                    walk(k, depth + 1)
                } else if (isLayoutXml(k)) found.add(k)
            }
        }
        walk(root, 0)
        return found.sortedWith(compareByDescending<File> { it.lastModified() }.thenBy { it.name }).take(max)
    }

    /** معرّف ثابت وقصير لملف الشات ديال مشروع (من المسار ديالو). */
    fun chatId(projectPath: String): String {
        val md = java.security.MessageDigest.getInstance("SHA-1").digest(projectPath.toByteArray(Charsets.UTF_8))
        val name = projectPath.trimEnd('/').substringAfterLast('/').filter { it.isLetterOrDigit() || it == '-' || it == '_' }.take(24)
        return (if (name.isEmpty()) "p" else name) + "-" + md.take(6).joinToString("") { "%02x".format(it) }
    }

    fun langName(f: File): String = when (val e = f.extension.lowercase()) {
        "kt" -> "Kotlin"
        "java" -> "Java"
        "xml" -> "XML"
        "kts" -> "Gradle KTS"
        "gradle" -> "Gradle"
        "json" -> "JSON"
        "md" -> "Markdown"
        "txt" -> "Text"
        "" -> f.name
        else -> e.uppercase()
    }

    /** أوامر سريعة (شريحة /edit): ← (نص يتكتب فالخانة, الأمر الكامل اللي كيتبعت للوكيل). */
    val SLASH = listOf(
        Triple("/edit", "عدّل الملف المفتوح", "عدّل الملف المفتوح بالطريقة التالية وطبّق التعديل مباشرة: "),
        Triple("/fix", "صلّح أخطاء الملف", "افحص الملف المفتوح وأصلح الأخطاء فيه وطبّق الإصلاح مباشرة."),
        Triple("/explain", "اشرح الملف", "اشرح لي الملف المفتوح باختصار."),
        Triple("/test", "اكتب اختبارات", "اكتب unit tests مناسبة للملف المفتوح وأنشئها فأماكنها الصحيحة."),
        Triple("/xml", "واجهة XML + معاينة", "صمّم واجهة XML (res/layout) مع الـ Activity ديالها وسجّلها فالـ Manifest، ومن بعد افتح معاينة XML: ")
    )

    fun expandSlash(raw: String): String {
        val t = raw.trim()
        if (!t.startsWith("/")) return t
        val cmd = t.substringBefore(' ')
        val arg = t.substringAfter(' ', "").trim()
        val hit = SLASH.firstOrNull { it.first == cmd } ?: return t
        return if (hit.first == "/edit" || hit.first == "/xml") hit.third + arg else hit.third + (if (arg.isEmpty()) "" else " $arg")
    }

}
