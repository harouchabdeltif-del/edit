package com.itsaky.androidide.ai

import android.app.Activity
import android.app.Dialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Outline
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.SystemClock
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.util.LruCache
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.Window
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import java.io.File
import java.net.HttpURLConnection
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

/**
 * قسم «اكتشف»: بحث فمستودعات GitHub ديال تطبيقات أندرويد ← بطاقات (2 فكل صف) ← ورقة سفلية فيها خيارين:
 * «تنزيل المشروع» / «تنزيل المشروع + المواصفات». بعد التنزيل كيتحقق من الكود بلي تطبيق أندرويد (Gradle) وكيتفتح فالمحرر.
 *
 * الشبكة والتنزيل كلهم فـ threads خلفية؛ الـ UI كيبني غير بطاقات الصفحة الحالية (20 فكل طلب).
 * المنطق الصافي (استعلام، zip، كشف التطبيق، SPEC.md) فـ DiscoverLogic، والاتصال فـ GitHubClient.
 */
internal class DiscoverPage(private val h: ZelligeHome.Home) {

    private val a: Activity = h.a
    private val t: ZelligeHome.Tone = h.t
    private fun dp(v: Int) = h.dp(v)

    private class Cached(val at: Long, val items: List<DiscoverLogic.Repo>)

    private class Job {
        @Volatile var cancelled = false
        @Volatile var conn: HttpURLConnection? = null
        fun cancel() {
            cancelled = true
            val c = conn
            if (c != null) Thread { try { c.disconnect() } catch (e: Throwable) { } }.start()
        }
    }

    companion object {
        private val avatarPool = Executors.newFixedThreadPool(3)
        private val avatars = object : LruCache<String, Bitmap>(6 * 1024 * 1024) {
            override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
        }
        private val pageCache = HashMap<String, Cached>()
        private const val TTL = 5 * 60 * 1000L
        private const val MAX_PAGES = 10

        private fun langColor(l: String): Int = when (l) {
            "Kotlin" -> Color.parseColor("#A97BFF")
            "Java" -> Color.parseColor("#B07219")
            "Dart" -> Color.parseColor("#00B4AB")
            "C++", "C" -> Color.parseColor("#F34B7D")
            "JavaScript" -> Color.parseColor("#F1E05A")
            "TypeScript" -> Color.parseColor("#3178C6")
            "Python" -> Color.parseColor("#3572A5")
            "Rust" -> Color.parseColor("#DEA584")
            "Go" -> Color.parseColor("#00ADD8")
            else -> Color.parseColor("#8A93A3")
        }
    }

    // ------------------------------------------------------------------ state
    private var query = ""
    private var chip = 0
    private var pageNo = 1
    private var gen = 0
    private var loading = false
    private var hasMore = false
    private var started = false
    private var busy = false
    private var have: Set<String> = emptySet()
    private val items = ArrayList<DiscoverLogic.Repo>()
    private var lastRow: LinearLayout? = null

    private lateinit var search: EditText
    private lateinit var clear: View
    private lateinit var scroll: ScrollView
    private lateinit var grid: LinearLayout
    private lateinit var statusBox: LinearLayout
    private lateinit var moreBtn: TextView
    private val chipViews = ArrayList<TextView>()

    private val roundOutline = object : ViewOutlineProvider() {
        override fun getOutline(v: View, o: Outline) {
            o.setRoundRect(0, 0, v.width, v.height, dp(9).toFloat())
        }
    }

    private fun alive() = !a.isFinishing && !a.isDestroyed && h.isAttached()

    // ------------------------------------------------------------------ build
    fun build(): View {
        val keyBtn = h.squareBtn("zl_ic_key", "رمز GitHub") { tokenDialog() }
        val head = h.header("zl_ic_explore", t.amber, "اكتشف", false, keyBtn)

        // البحث
        val box = LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = h.boxed(t.s2, 12)
            setPadding(dp(12), 0, dp(6), 0)
        }
        box.addView(h.icon("zl_ic_search", t.muted, 18))
        search = EditText(a).apply {
            hint = "ابحث فتطبيقات أندرويد مفتوحة المصدر…"
            setHintTextColor(t.muted); setTextColor(t.text); textSize = 13.5f
            typeface = ZelligeHome.face(400)
            background = null
            setSingleLine()
            inputType = InputType.TYPE_CLASS_TEXT
            imeOptions = EditorInfo.IME_ACTION_SEARCH
            textDirection = View.TEXT_DIRECTION_ANY_RTL
            setPadding(dp(10), 0, dp(8), 0)
            setOnFocusChangeListener { _, f ->
                box.background = h.boxed(t.s2, 12, if (f) t.amber else t.line)
                h.watchKeyboard()
            }
            setOnClickListener { h.watchKeyboard() }
            setOnEditorActionListener { _, id, _ -> if (id == EditorInfo.IME_ACTION_SEARCH) { submit(); true } else false }
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, af: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {
                    val v = if (s.isNullOrEmpty()) View.GONE else View.VISIBLE
                    if (clear.visibility != v) clear.visibility = v
                }
                override fun afterTextChanged(s: Editable?) {}
            })
        }
        box.addView(search, LinearLayout.LayoutParams(0, h.MATCH, 1f))
        clear = FrameLayout(a).apply {
            visibility = View.GONE
            background = h.ripple(Color.TRANSPARENT, 9)
            isClickable = true; isFocusable = true; contentDescription = "مسح"
            setOnClickListener { search.setText(""); submit() }
            addView(h.icon("zl_ic_close", t.muted, 16).apply { layoutParams = FrameLayout.LayoutParams(dp(16), dp(16), Gravity.CENTER) })
        }
        box.addView(clear, h.lp(dp(32), dp(32)))
        val searchWrap = FrameLayout(a).apply { setPadding(dp(12), dp(2), dp(12), dp(10)) }
        searchWrap.addView(box, FrameLayout.LayoutParams(h.MATCH, dp(46)))

        // الشرائح
        val chips = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(12), 0, dp(12), dp(10)) }
        DiscoverLogic.CHIPS.forEachIndexed { i, c ->
            val tv = h.txt(c.label, 12.5f, t.muted, 500).apply {
                gravity = Gravity.CENTER
                setPadding(dp(14), 0, dp(14), 0)
                isClickable = true; isFocusable = true
                setOnClickListener { if (chip != i) { chip = i; styleChips(); reload() } }
            }
            chipViews.add(tv)
            chips.addView(tv, h.lp(h.WRAP, dp(32)).apply { marginEnd = dp(8) })
        }
        val chipsScroll = HorizontalScrollView(a).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(chips)
        }
        styleChips()

        // المحتوى
        grid = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(6), dp(8), 0) }
        statusBox = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(36), dp(24), dp(10))
            visibility = View.GONE
        }
        moreBtn = h.txt("عرض المزيد", 13f, t.text, 500).apply {
            gravity = Gravity.CENTER
            background = h.ripple(t.s1, 12, stroke = true)
            isClickable = true; isFocusable = true
            visibility = View.GONE
            setOnClickListener { fetch() }
        }
        val col = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            addView(statusBox, h.lp(h.MATCH, h.WRAP))
            addView(grid, h.lp(h.MATCH, h.WRAP))
            addView(moreBtn, h.lp(h.MATCH, dp(44)).apply { setMargins(dp(16), dp(10), dp(16), dp(18)) })
        }
        scroll = h.scrolling(col)
        scroll.setOnScrollChangeListener { v, _, y, _, _ ->
            val c = (v as ScrollView).getChildAt(0)
            if (hasMore && !loading && c != null && c.height - (y + v.height) < dp(320)) fetch()
        }
        val filters = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            addView(searchWrap, h.lp(h.MATCH, h.WRAP))
            addView(chipsScroll, h.lp(h.MATCH, h.WRAP))
            addView(h.hair(t.line2), h.lp(h.MATCH, dp(1)))
        }
        return h.page(head, filters, scroll)
    }

    private fun styleChips() {
        chipViews.forEachIndexed { i, tv ->
            val on = i == chip
            tv.background = if (on) h.ripple(t.amber, 16) else h.ripple(t.s1, 16, stroke = true)
            tv.setTextColor(if (on) t.onAmber else t.muted)
        }
    }

    // ------------------------------------------------------------------ lifecycle
    fun onShown() {
        if (!started) { started = true; reload() }
    }

    fun onHidden() {
        try {
            search.clearFocus()
            (a.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(search.windowToken, 0)
        } catch (e: Throwable) { }
    }

    private fun submit() {
        onHidden()
        query = search.text.toString().trim()
        reload()
    }

    // ------------------------------------------------------------------ loading
    private fun reload() {
        gen++
        loading = false
        items.clear(); grid.removeAllViews(); lastRow = null
        pageNo = 1; hasMore = false
        moreBtn.visibility = View.GONE
        scroll.scrollTo(0, 0)
        fetch()
    }

    private fun installedNames(): Set<String> = try { AiIde.projectsDir(a).list()?.toSet() ?: emptySet() } catch (e: Throwable) { emptySet() }

    private fun fetch() {
        if (loading) return
        loading = true
        val g = gen
        val page = pageNo
        val q = DiscoverLogic.buildQuery(query, DiscoverLogic.CHIPS[chip].q)
        val tok = h.prefs.githubToken
        if (items.isEmpty()) showStatus(null, "كنقلب فـ GitHub…", null, false, true)
        else { moreBtn.text = "كنجيب المزيد…"; moreBtn.isEnabled = false }
        Thread {
            var res: List<DiscoverLogic.Repo> = emptyList()
            var err: String? = null
            try {
                val key = "$q|$page"
                val now = System.currentTimeMillis()
                val c = synchronized(pageCache) { pageCache[key] }
                res = if (c != null && now - c.at < TTL) c.items else {
                    val got = GitHubClient.search(q, page, tok)
                    synchronized(pageCache) { if (pageCache.size > 40) pageCache.clear(); pageCache[key] = Cached(now, got) }
                    got
                }
            } catch (e: Throwable) {
                err = GitHubClient.message(e)
            }
            val names = installedNames()
            a.runOnUiThread {
                if (g != gen || !alive()) return@runOnUiThread
                loading = false
                have = names
                moreBtn.isEnabled = true; moreBtn.text = "عرض المزيد"
                if (err != null) {
                    if (items.isEmpty()) showStatus("zl_ic_info", "ما قدرناش نجيبو المشاريع", err, true, false)
                    else { h.toast(err, true); moreBtn.text = "عاود"; moreBtn.visibility = View.VISIBLE }
                    return@runOnUiThread
                }
                val known = items.mapTo(HashSet()) { it.full }
                val fresh = res.filter { known.add(it.full) }
                items.addAll(fresh)
                addCards(fresh)
                hasMore = res.size >= GitHubClient.PER_PAGE && pageNo < MAX_PAGES
                pageNo++
                if (items.isEmpty()) showStatus("zl_ic_search", "ما لقيت والو", "جرّب كلمات أخرى، أو رجع للشريحة «الكل».", false, false)
                else hideStatus()
                moreBtn.visibility = if (hasMore) View.VISIBLE else View.GONE
            }
        }.start()
    }

    private fun hideStatus() { statusBox.removeAllViews(); statusBox.visibility = View.GONE }

    private fun showStatus(ic: String?, title: String, sub: String?, retry: Boolean, spinner: Boolean) {
        statusBox.removeAllViews()
        statusBox.visibility = View.VISIBLE
        if (spinner) {
            statusBox.addView(ProgressBar(a).apply { indeterminateTintList = ColorStateList.valueOf(t.amber) }, h.lp(dp(28), dp(28)))
        } else if (ic != null) {
            statusBox.addView(h.icon(ic, t.muted, 28))
        }
        statusBox.addView(h.txt(title, 15f, t.text, 500).apply { gravity = Gravity.CENTER; setPadding(0, dp(14), 0, 0) })
        if (sub != null) statusBox.addView(h.txt(sub, 12.5f, t.muted).apply { gravity = Gravity.CENTER; setPadding(0, dp(6), 0, 0) })
        if (retry) {
            val b = h.txt("عاود", 13f, t.onAmber, 600).apply {
                gravity = Gravity.CENTER
                background = h.ripple(t.amber, 10)
                isClickable = true; isFocusable = true
                setOnClickListener { reload() }
            }
            statusBox.addView(b, h.lp(dp(110), dp(40)).apply { topMargin = dp(16) })
        }
    }

    // ------------------------------------------------------------------ cards
    private fun addCards(list: List<DiscoverLogic.Repo>) {
        for (r in list) {
            var row = lastRow
            if (row == null || row.childCount >= 2) {
                row = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; weightSum = 2f; isBaselineAligned = false }
                grid.addView(row, h.lp(h.MATCH, h.WRAP))
                lastRow = row
            }
            row.addView(card(r), LinearLayout.LayoutParams(0, h.WRAP, 1f).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) })
        }
    }

    private fun rebuildGrid() {
        grid.removeAllViews(); lastRow = null
        addCards(items)
    }

    private fun isInstalled(r: DiscoverLogic.Repo) = have.contains(DiscoverLogic.safeName(r.name))

    private fun avatarView(url: String, sizeDp: Int): ImageView = ImageView(a).apply {
        scaleType = ImageView.ScaleType.CENTER_CROP
        background = h.round(t.s2, 9)
        outlineProvider = roundOutline
        clipToOutline = true
        layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
        if (url.isNotBlank()) {
            val hit = avatars.get(url)
            if (hit != null) setImageBitmap(hit)
            else {
                tag = url
                val iv = this
                avatarPool.execute {
                    if (!alive()) return@execute
                    val bytes = GitHubClient.avatar(url) ?: return@execute
                    val bmp = try { BitmapFactory.decodeByteArray(bytes, 0, bytes.size) } catch (e: Throwable) { null } ?: return@execute
                    avatars.put(url, bmp)
                    a.runOnUiThread { if (iv.tag == url) iv.setImageBitmap(bmp) }
                }
            }
        }
    }

    private fun card(r: DiscoverLogic.Repo): View {
        val card = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            background = h.ripple(t.s1, 14, stroke = true)
            isClickable = true; isFocusable = true
            setPadding(dp(12), dp(12), dp(12), dp(10))
            minimumHeight = dp(170)
            setOnClickListener { showChoice(r) }
        }
        val top = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(avatarView(r.avatar, 36))
        top.addView(View(a), LinearLayout.LayoutParams(0, 1, 1f))
        if (isInstalled(r)) top.addView(h.icon("zl_ic_check", t.green, 15), h.lp(dp(15), dp(15)).apply { marginEnd = dp(8) })
        top.addView(h.icon("zl_ic_star", t.amber, 13), h.lp(dp(13), dp(13)))
        top.addView(h.txt(DiscoverLogic.compact(r.stars), 11.5f, t.text, m = true).apply { setPadding(dp(4), 0, 0, 0) })
        card.addView(top, h.lp(h.MATCH, h.WRAP))
        card.addView(h.txt(r.name, 13.5f, t.text, m = true).apply {
            setSingleLine(); ellipsize = TextUtils.TruncateAt.END; setPadding(0, dp(10), 0, 0)
        })
        card.addView(h.txt(r.owner, 11f, t.muted, m = true).apply {
            setSingleLine(); ellipsize = TextUtils.TruncateAt.END; setPadding(0, dp(2), 0, 0)
        })
        card.addView(h.txt(r.description.ifBlank { "بلا وصف" }, 12f, t.icon).apply {
            minLines = 2; maxLines = 2; ellipsize = TextUtils.TruncateAt.END; setPadding(0, dp(8), 0, 0)
        })
        card.addView(View(a), h.lp(1, 0).also { it.weight = 1f })
        val foot = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(8), 0, 0) }
        if (r.language.isNotBlank()) {
            foot.addView(View(a).apply { background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(langColor(r.language)) } }, h.lp(dp(8), dp(8)))
            foot.addView(h.txt(r.language, 11f, t.muted, m = true).apply { setSingleLine(); setPadding(dp(5), 0, 0, 0) })
        }
        foot.addView(View(a), LinearLayout.LayoutParams(0, 1, 1f))
        foot.addView(h.txt(DiscoverLogic.sizeLabel(r.sizeKb), 11f, t.muted, m = true).apply { setSingleLine() })
        card.addView(foot, h.lp(h.MATCH, h.WRAP))
        return card
    }

    // ------------------------------------------------------------------ dialogs (نفس ألوان الصفحة)
    private fun cardDialog(content: View, bottom: Boolean, cancelable: Boolean): Dialog {
        val d = Dialog(a)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val r = dp(18).toFloat()
        content.background = GradientDrawable().apply {
            setColor(t.page)
            cornerRadii = if (bottom) floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f) else floatArrayOf(r, r, r, r, r, r, r, r)
            setStroke(dp(1), t.line)
        }
        content.layoutDirection = View.LAYOUT_DIRECTION_RTL
        d.setContentView(content)
        d.setCancelable(cancelable)
        d.setCanceledOnTouchOutside(cancelable)
        d.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setGravity(if (bottom) Gravity.BOTTOM else Gravity.CENTER)
            setLayout(
                if (bottom) WindowManager.LayoutParams.MATCH_PARENT else (a.resources.displayMetrics.widthPixels * 0.9f).toInt(),
                WindowManager.LayoutParams.WRAP_CONTENT
            )
            addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
            attributes = attributes.apply { dimAmount = 0.55f }
        }
        return d
    }

    private fun button(label: String, kind: Int, onClick: () -> Unit): TextView =
        h.txt(label, 13.5f, if (kind == 0) t.onAmber else if (kind == 2) t.red else t.text, 600).apply {
            gravity = Gravity.CENTER
            background = if (kind == 0) h.ripple(t.amber, 11) else h.ripple(t.s1, 11, stroke = true)
            isClickable = true; isFocusable = true
            setOnClickListener { onClick() }
        }

    private fun optionRow(ic: String, tint: Int, title: String, sub: String, onClick: () -> Unit): View {
        val row = LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = h.ripple(t.s1, 14, stroke = true)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            isClickable = true; isFocusable = true
            setOnClickListener { onClick() }
        }
        val tile = FrameLayout(a).apply { background = h.boxed(t.s2, 10) }
        tile.addView(h.icon(ic, tint, 20).apply { layoutParams = FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER) })
        row.addView(tile, h.lp(dp(42), dp(42)))
        val col = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        col.addView(h.txt(title, 14.5f, t.text, 600))
        col.addView(h.txt(sub, 12f, t.muted).apply { setPadding(0, dp(3), 0, 0) })
        row.addView(col, LinearLayout.LayoutParams(0, h.WRAP, 1f).apply { marginStart = dp(12); marginEnd = dp(8) })
        row.addView(h.icon("zl_ic_chevron_left", t.muted, 16))
        return row
    }

    private fun showChoice(r: DiscoverLogic.Repo) {
        if (busy) { h.toast("فيه تنزيل خدام، تسنّى شوية"); return }
        val sheet = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(10), dp(16), dp(22)) }
        val dlg = cardDialog(sheet, true, true)

        sheet.addView(View(a).apply { background = h.round(t.line, 2) }, h.lp(dp(36), dp(4)).apply { gravity = Gravity.CENTER_HORIZONTAL; bottomMargin = dp(14) })
        val head = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(avatarView(r.avatar, 44))
        val names = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        names.addView(h.txt(r.name, 16f, t.text, m = true).apply { setSingleLine(); ellipsize = TextUtils.TruncateAt.MIDDLE })
        names.addView(h.txt(r.owner, 12f, t.muted, m = true).apply { setPadding(0, dp(3), 0, 0) })
        head.addView(names, LinearLayout.LayoutParams(0, h.WRAP, 1f).apply { marginStart = dp(12) })
        sheet.addView(head, h.lp(h.MATCH, h.WRAP))

        val facts = listOfNotNull(
            "★ " + DiscoverLogic.compact(r.stars), r.language.ifBlank { null }, DiscoverLogic.sizeLabel(r.sizeKb), r.license.ifBlank { null }
        ).joinToString("  ·  ")
        sheet.addView(h.txt(facts, 11.5f, t.muted, m = true).apply { setPadding(0, dp(12), 0, 0) })
        if (r.description.isNotBlank()) {
            sheet.addView(h.txt(r.description, 13f, t.icon).apply { maxLines = 4; ellipsize = TextUtils.TruncateAt.END; setPadding(0, dp(10), 0, 0) })
        }

        val gap = dp(10)
        sheet.addView(optionRow("zl_ic_download", t.amber, "تنزيل المشروع", "الكود فقط · كيتفتح فالمحرر وتقدر تبنيه") {
            dlg.dismiss(); startDownload(r, false)
        }, h.lp(h.MATCH, h.WRAP).apply { topMargin = dp(18) })
        sheet.addView(optionRow("zl_ic_doc_text", t.green, "تنزيل المشروع + المواصفات", "كيزيد SPEC.md: شنو هاد التطبيق، الشاشات، الأذونات، المكتبات") {
            dlg.dismiss(); startDownload(r, true)
        }, h.lp(h.MATCH, h.WRAP).apply { topMargin = gap })
        if (isInstalled(r)) {
            sheet.addView(optionRow("zl_ic_folder_open", t.icon, "فتح النسخة الموجودة", "هاد المشروع نزلتيه من قبل") {
                dlg.dismiss(); h.openProject(File(AiIde.projectsDir(a), DiscoverLogic.safeName(r.name)))
            }, h.lp(h.MATCH, h.WRAP).apply { topMargin = gap })
        }

        val foot = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(16), 0, 0) }
        foot.addView(h.txt("هاد الكود ديال ناس آخرين: قرا فيه قبل ما تبني.", 11.5f, t.muted).apply { maxLines = 2 }, LinearLayout.LayoutParams(0, h.WRAP, 1f))
        foot.addView(h.txt("GitHub ↗", 12f, t.amber, m = true).apply {
            setPadding(dp(12), dp(8), dp(4), dp(8))
            isClickable = true; isFocusable = true
            setOnClickListener {
                try { a.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(r.url))) } catch (e: Throwable) { copy(r.url) }
            }
        })
        sheet.addView(foot, h.lp(h.MATCH, h.WRAP))
        dlg.show()
    }

    private fun copy(s: String) {
        try {
            (a.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("url", s))
            h.toast("تم نسخ الرابط")
        } catch (e: Throwable) { h.toast("تعذّر الفتح", true) }
    }

    // ------------------------------------------------------------------ download
    private fun startDownload(r: DiscoverLogic.Repo, withSpec: Boolean) {
        if (busy) return
        busy = true
        val job = Job()

        val box = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(18), dp(20), dp(16)) }
        box.addView(h.txt("كننزّل المشروع", 15f, t.text, 600))
        box.addView(h.txt(r.full, 12f, t.muted, m = true).apply { setSingleLine(); ellipsize = TextUtils.TruncateAt.MIDDLE; setPadding(0, dp(4), 0, 0) })
        box.addView(ProgressBar(a, null, android.R.attr.progressBarStyleHorizontal).apply {
            isIndeterminate = true
            indeterminateTintList = ColorStateList.valueOf(t.amber)
        }, h.lp(h.MATCH, dp(6)).apply { topMargin = dp(16) })
        val stat = h.txt("كنحمّل ونفك الضغط…", 11.5f, t.muted, m = true).apply { setPadding(0, dp(10), 0, 0) }
        box.addView(stat)
        val cancel = button("إلغاء", 1) { job.cancel() }
        box.addView(cancel, h.lp(h.MATCH, dp(44)).apply { topMargin = dp(16) })
        val dlg = cardDialog(box, false, false)
        dlg.show()

        Thread {
            var outcome: DiscoverLogic.Outcome? = null
            var err: String? = null
            val date = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
            val dir = AiIde.projectsDir(a)
            try {
                var lastUi = 0L
                outcome = DiscoverLogic.install(
                    r, dir, withSpec, date,
                    fetch = { url -> GitHubClient.openZip(url) { job.conn = it } },
                    progress = { files, bytes ->
                        if (job.cancelled) throw DiscoverLogic.Cancelled()
                        val now = SystemClock.uptimeMillis()
                        if (now - lastUi > 200) {
                            lastUi = now
                            val s = "$files ملف · " + DiscoverLogic.sizeLabel((bytes / 1024).toInt())
                            a.runOnUiThread { stat.text = s }
                        }
                    }
                )
            } catch (e: Throwable) {
                if (!job.cancelled) err = GitHubClient.message(e)
            }
            val names = installedNames()
            val o = outcome
            a.runOnUiThread {
                busy = false
                try { dlg.dismiss() } catch (e: Throwable) { }
                have = names
                when (o) {
                    is DiscoverLogic.Outcome.Ok -> done(r, o, withSpec)
                    is DiscoverLogic.Outcome.NotApp -> notAppDialog(r, o, date)
                    null -> if (job.cancelled) h.toast("تلغى التنزيل") else errorDialog(r, err ?: "فشل غير معروف")
                }
            }
        }.start()
    }

    private fun done(r: DiscoverLogic.Repo, o: DiscoverLogic.Outcome.Ok, withSpec: Boolean) {
        h.refresh()
        if (::grid.isInitialized) rebuildGrid()
        val msg = "تنزّل ✔ " + o.dir.name + " · " + o.files + " ملف" +
            if (withSpec && o.specFile != null) " · " + o.specFile.name else ""
        h.toast(msg, true)
        if (!alive()) return
        val e = try { AiIde.openProject(a, o.dir) } catch (t: Throwable) { t.message ?: "خطأ" }
        if (e != null) h.toast(e, true)
    }

    private fun errorDialog(r: DiscoverLogic.Repo, err: String) {
        val box = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(18), dp(20), dp(16)) }
        val dlg = cardDialog(box, false, true)
        box.addView(h.txt("فشل التنزيل", 15f, t.red, 600))
        box.addView(h.txt(err, 13f, t.text).apply { setPadding(0, dp(10), 0, 0) })
        val row = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(button("سدّ", 1) { dlg.dismiss() }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(8) })
        row.addView(button("عاود", 0) { dlg.dismiss(); startDownload(r, false) }, LinearLayout.LayoutParams(0, dp(44), 1f))
        box.addView(row, h.lp(h.MATCH, h.WRAP).apply { topMargin = dp(16) })
        dlg.show()
    }

    /** نزل لكن ماشي تطبيق أندرويد قابل للبناء: المستعمل كيقرر. */
    private fun notAppDialog(r: DiscoverLogic.Repo, o: DiscoverLogic.Outcome.NotApp, date: String) {
        val box = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(18), dp(20), dp(16)) }
        val dlg = cardDialog(box, false, false)
        box.addView(h.txt("ماشي تطبيق أندرويد قابل للبناء", 15f, t.text, 600))
        box.addView(h.txt(r.full, 12f, t.muted, m = true).apply { setSingleLine(); ellipsize = TextUtils.TruncateAt.MIDDLE; setPadding(0, dp(4), 0, 0) })
        box.addView(h.txt(o.reason, 13f, t.icon).apply { setPadding(0, dp(12), 0, 0) })
        box.addView(h.txt("قسم «اكتشف» كيقبل غير مشاريع تطبيقات الهاتف. تحب تمسحو؟", 12f, t.muted).apply { setPadding(0, dp(10), 0, 0) })
        val row = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(button("احتفظ به", 1) {
            dlg.dismiss()
            Thread {
                val dir = AiIde.projectsDir(a)
                try { DiscoverLogic.finish(r, dir, o.tmp, DiscoverLogic.Detection(true, null, null, ""), false, date, o.files) } catch (e: Throwable) { }
                a.runOnUiThread { have = installedNames(); h.refresh(); h.toast("تحفظ فالمشاريع") }
            }.start()
        }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(8) })
        row.addView(button("حذف", 2) {
            dlg.dismiss()
            Thread { o.tmp.deleteRecursively() }.start()
            h.toast("تمسح")
        }, LinearLayout.LayoutParams(0, dp(44), 1f))
        box.addView(row, h.lp(h.MATCH, h.WRAP).apply { topMargin = dp(16) })
        dlg.show()
    }

    // ------------------------------------------------------------------ token
    private fun tokenDialog() {
        val box = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(18), dp(20), dp(16)) }
        val dlg = cardDialog(box, false, true)
        val has = h.prefs.githubToken.isNotBlank()
        box.addView(h.txt("رمز GitHub (اختياري)", 15f, t.text, 600))
        box.addView(h.txt(
            "بلا رمز: 10 عمليات بحث فالدقيقة. مع رمز (قراءة المستودعات العامة فقط): 30. الرمز كيتخزن فهاد الجهاز وكيتبعت لـ api.github.com بوحدو. التنزيل ما كيحتاجوش.",
            12f, t.muted
        ).apply { setPadding(0, dp(8), 0, 0) })
        val input = EditText(a).apply {
            hint = if (has) "الرمز محفوظ — كتب واحد جديد باش تبدّلو" else "github_pat_… أو ghp_…"
            setHintTextColor(t.muted); setTextColor(t.text); textSize = 13f
            typeface = ZelligeHome.loadMono(a)
            textDirection = View.TEXT_DIRECTION_LTR
            textAlignment = View.TEXT_ALIGNMENT_VIEW_START
            setSingleLine()
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS or InputType.TYPE_TEXT_VARIATION_PASSWORD
            background = h.boxed(t.s2, 10)
            setPadding(dp(12), 0, dp(12), 0)
        }
        box.addView(input, h.lp(h.MATCH, dp(46)).apply { topMargin = dp(14) })
        val row = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(button("إلغاء", 1) { dlg.dismiss() }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(8) })
        if (has) row.addView(button("مسح", 2) {
            h.prefs.githubToken = ""; dlg.dismiss(); h.toast("تمسح الرمز")
            synchronized(pageCache) { pageCache.clear() }
        }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(8) })
        row.addView(button("حفظ", 0) {
            val v = input.text.toString().trim()
            if (v.isNotEmpty()) {
                h.prefs.githubToken = v
                synchronized(pageCache) { pageCache.clear() }
                h.toast("تحفظ الرمز")
                if (items.isEmpty()) reload()
            }
            dlg.dismiss()
        }, LinearLayout.LayoutParams(0, dp(44), 1f))
        box.addView(row, h.lp(h.MATCH, h.WRAP).apply { topMargin = dp(16) })
        dlg.show()
    }
}
