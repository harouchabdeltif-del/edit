package com.itsaky.androidide.ai

/**
 * قراءة ردّ النموذج: وسوم <tool .../> ومحتواها. منطق صافي (بلا Android) باش يتجرّب على JVM (tests/jvm/AgentTest.kt).
 *
 * علاش كاين: بعض النماذج (خصوصاً الخفيفة) كتسدّ الوسم `<tool name="write_file" path="X.kt"/>` وكتحط الكود من بعدو
 * فـ ``` — قبل كان هادشي كيعطي ملف فارغ + كود فالشات. دابا الكود اللي من بعد الوسم كيتاخد كمحتوى ديالو.
 */
object AgentParse {

    data class ToolCall(val name: String, val attrs: Map<String, String>, val body: String) {
        val path: String get() = attrs["path"].orEmpty()
    }

    val toolRe = Regex("<tool\\s+([^>]*?)\\s*(?:/>|>([\\s\\S]*?)</tool>)")
    val attrRe = Regex("(\\w+)\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)')")
    private val openRe = Regex("<tool\\s+([^>]*?)>")
    private val fencedRe = Regex("```[A-Za-z0-9_+#.-]*[ \\t]*\\r?\\n([\\s\\S]*?)```")
    private val fenceRe = Regex("^```[A-Za-z0-9_+#.-]*[ \\t]*\\r?\\n([\\s\\S]*?)\\r?\\n?```\\s*$")

    /** أدوات المحتوى ديالها هو الكود. */
    val bodyTools = setOf("write_file", "insert")

    /** ملفات كود ماكاينش فيها شي معنى تكون فارغة. */
    val mustHaveBody = setOf("kt", "java", "kts", "gradle", "xml", "json", "toml")

    private val placeholderRe = Regex(
        "^\\s*(\\[content omitted]|\\[\\.\\.\\.]|\\.\\.\\.|…|// ?TODO|<content>|\\(same as before\\)|// ?(rest|existing) (of )?(the )?code|\\(earlier: )",
        RegexOption.IGNORE_CASE
    )

    fun trimNl(s: String) = s.removePrefix("\r\n").removePrefix("\n").removeSuffix("\r\n").removeSuffix("\n")

    private fun attrs(raw: String): Map<String, String> =
        attrRe.findAll(raw).associate { it.groupValues[1] to (it.groups[2]?.value ?: it.groups[3]?.value ?: "") }

    /** المجال ديال ``` اللي كيتبع وسم مسدود فارغ (إلا كان) — كيتحسب جزء من الأداة. */
    private fun trailingFence(reply: String, ms: List<MatchResult>, i: Int): MatchResult? {
        val m = ms[i]
        if (m.groupValues[2].isNotBlank()) return null
        val a = attrs(m.groupValues[1])
        if (a["name"].orEmpty() !in bodyTools) return null
        val end = if (i + 1 < ms.size) ms[i + 1].range.first else reply.length
        val from = m.range.last + 1
        if (from >= end) return null
        val f = fencedRe.find(reply.substring(from, end)) ?: return null
        // غير إلا كان الكود قريب (ماشي فقرة بعيدة فالشرح)
        val gap = reply.substring(from, from + f.range.first)
        if (gap.length > 240) return null
        return f
    }

    fun parse(reply: String): List<ToolCall> {
        val ms = toolRe.findAll(reply).toList()
        return ms.mapIndexed { i, m ->
            val a = attrs(m.groupValues[1])
            val name = a["name"].orEmpty()
            var body = trimNl(m.groupValues[2])
            if (body.isBlank() && name in bodyTools) {
                val fenced = trailingFence(reply, ms, i)?.groupValues?.get(1)
                body = when {
                    !fenced.isNullOrBlank() -> fenced.trimEnd('\n', '\r')
                    !a["content"].isNullOrEmpty() -> a["content"]!!.replace("\\n", "\n").replace("\\t", "\t")
                    else -> body
                }
            }
            ToolCall(name, a, body)
        }
    }

    /** النص بلا وسوم الأدوات (وبلا الكود اللي تاخد كمحتوى لشي أداة) — هذا اللي كيبان فالشات. */
    fun strip(reply: String): String {
        val ms = toolRe.findAll(reply).toList()
        if (ms.isEmpty()) return reply.trim()
        val cut = ArrayList<IntRange>()
        for (i in ms.indices) {
            cut.add(ms[i].range)
            val f = trailingFence(reply, ms, i) ?: continue
            val base = ms[i].range.last + 1
            cut.add((base + f.range.first)..(base + f.range.last))
        }
        val sb = StringBuilder()
        var at = 0
        for (r in cut.sortedBy { it.first }) {
            if (r.first > at) sb.append(reply, at, r.first)
            at = maxOf(at, r.last + 1)
        }
        if (at < reply.length) sb.append(reply, at, reply.length)
        return sb.toString().trim()
    }

    /** وسم بدا وما تسدّش (الرد تقطع بسبب الطول): كيرجع اسم الأداة والمسار. */
    fun truncatedCall(reply: String): ToolCall? {
        val last = toolRe.findAll(reply).lastOrNull()?.range?.last ?: -1
        val open = openRe.findAll(reply).lastOrNull { it.range.first > last } ?: return null
        if (open.groupValues[1].trimEnd().endsWith("/")) return null
        val a = attrs(open.groupValues[1])
        if (a["name"].isNullOrBlank()) return null
        return ToolCall(a["name"].orEmpty(), a, "")
    }

    /** كود طويل (4 أسطر فأكثر) كتبو النموذج فـ الشات بدل ما يطبّقو بالأدوات. */
    fun hasCodeDump(reply: String): Boolean =
        fencedRe.findAll(strip(reply)).any { it.groupValues[1].trim().lines().size >= 4 }

    /** إذا وضع النموذج المحتوى داخل ``` بالغلط، نشيلو باش ما يدخلش فالملف. */
    fun unfence(s: String): String {
        val t = s.trim()
        if (!t.startsWith("```")) return s
        return fenceRe.find(t)?.groupValues?.get(1) ?: s
    }

    /** «[content omitted]»، «...»، «// TODO» بوحدهم: ماشي كود حقيقي. */
    fun isPlaceholder(content: String): Boolean {
        val t = content.trim()
        if (t.isEmpty()) return false
        return placeholderRe.containsMatchIn(t.take(400)) && t.lines().size <= 6
    }
}
