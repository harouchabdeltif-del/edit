package com.itsaky.androidide.ai

import android.app.Activity
import android.content.Context
import android.content.res.ColorStateList
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import java.io.File
import java.lang.ref.WeakReference

/**
 * شريط الذكاء داخل المحرر (اتجاه Console): سطر رفيع تحت تبويبات الملفات فيه نجمة الذكاء وخانة «اطلب تعديلا على هذا الملف…»
 * (Enter ← الطلب كيتنفّذ مباشرة فالملف)، ومن جهة أخرى موضع المؤشر ولغة الملف (17:35 · Kotlin).
 *
 * كيتزاد جوا AppBarLayout الأصلي (آخر ولد) باش المحرر ينزل تحتو تلقائيا بلا ما نلمس أي layout.
 * إلا فشل أي شيء، AiPlugin كيرجع للزر العائم القديم.
 */
object EditorChrome {

    private const val TAG = "ai_bar"
    private val ui = Handler(Looper.getMainLooper())
    private var ref: WeakReference<Activity>? = null
    private var status: WeakReference<TextView>? = null
    private var tick: Runnable? = null

    /** من الـ UI thread. يرجع true إلا الشريط موجود فالشاشة. */
    fun install(a: Activity): Boolean {
        return try {
            val id = a.resources.getIdentifier("editor_appBarLayout", "id", a.packageName)
            if (id == 0) return false
            val appbar = a.findViewById<ViewGroup>(id) ?: return false
            if (appbar.findViewWithTag<View>(TAG) == null) {
                appbar.addView(build(a), ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            }
            start(a)
            true
        } catch (t: Throwable) { false }
    }

    fun stop() {
        tick?.let { ui.removeCallbacks(it) }
        tick = null
    }

    private fun build(a: Activity): View {
        val p = AiChat.pal(a)
        val mono = ZelligeHome.loadMono(a)
        fun dp(v: Int) = AiChat.dp(a, v)

        val box = LinearLayout(a).apply {
            tag = TAG
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(p.surface)
        }
        val row = LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), 0, dp(12), 0)
        }
        val star = ImageView(a).apply {
            setImageDrawable(AiChat.icon(a, "ic_ai_sparkle"))
            imageTintList = ColorStateList.valueOf(p.accent)
            contentDescription = "فتح الشات"
            isClickable = true; isFocusable = true
            setOnClickListener { AiChat.open(a, null, false) }
        }
        row.addView(star, LinearLayout.LayoutParams(dp(18), dp(18)))

        val input = EditText(a).apply {
            hint = "اطلب تعديلا على هذا الملف…"
            setHintTextColor(p.sub); setTextColor(p.text); textSize = 12.5f
            background = null
            setSingleLine()
            inputType = InputType.TYPE_CLASS_TEXT
            imeOptions = EditorInfo.IME_ACTION_SEND
            textDirection = View.TEXT_DIRECTION_ANY_RTL
            setPadding(dp(10), 0, dp(8), 0)
        }
        fun submit() {
            val t = input.text.toString().trim()
            try {
                (a.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(input.windowToken, 0)
            } catch (e: Throwable) { }
            input.clearFocus()
            if (t.isEmpty()) {
                AiChat.open(a, null, false)
            } else {
                input.text.clear()
                AiChat.open(a, t, true)
            }
        }
        input.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) { submit(); true } else false
        }
        row.addView(input, LinearLayout.LayoutParams(0, dp(40), 1f))

        val st = TextView(a).apply {
            typeface = mono; textSize = 10.5f; setTextColor(p.sub)
            textDirection = View.TEXT_DIRECTION_LTR
            setSingleLine()
            text = "—"
        }
        status = WeakReference(st)
        row.addView(st, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        box.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        box.addView(View(a).apply { setBackgroundColor(p.line) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1)))
        return box
    }

    // ------------------------------------------------------------ cursor / language readout
    private fun start(a: Activity) {
        ref = WeakReference(a)
        stop()
        val r = object : Runnable {
            override fun run() {
                val act = ref?.get() ?: return
                try { refresh(act) } catch (t: Throwable) { /* اختياري */ }
                ui.postDelayed(this, 800)
            }
        }
        tick = r
        ui.post(r)
    }

    private fun refresh(a: Activity) {
        val tv = status?.get() ?: return
        val ed = EditorAccess.find(a)
        val f = ed?.file()
        tv.text = if (ed == null || f == null) "—" else "${ed.cursorLine() + 1}:${ed.cursorColumn() + 1} · ${lang(f)}"
    }

    private fun lang(f: File): String = when (val e = f.extension.lowercase()) {
        "kt" -> "Kotlin"
        "java" -> "Java"
        "xml" -> "XML"
        "kts" -> "Gradle KTS"
        "gradle" -> "Gradle"
        "json" -> "JSON"
        "md" -> "Markdown"
        "txt" -> "Text"
        "" -> f.name
        else -> e.uppercase()
    }
}
