package com.itsaky.androidide.ai

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.text.Editable
import android.text.InputType
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.TextUtils
import android.text.TextWatcher
import android.text.style.ForegroundColorSpan
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.util.WeakHashMap

/**
 * الشاشة الرئيسية (اتجاه Console): ترويسة بزر «جديد»، شريط «تابع»، تبويبات (الأخيرة / المثبّتة / مجلدات)،
 * صفوف كثيفة للمشاريع، شريط أوامر ثابت لتحت (ابحث أو اطلب من الذكاء)، وتنقّل سفلي: المشاريع / الذكاء / الأدوات.
 *
 * كتتركّب فوق شاشة AndroidIDE الأصلية (MainFragment) بلا ما نلمس كودها: الأزرار الأصلية (إنشاء مشروع،
 * فتح مجلد، استنساخ Git، الترمنال، الإعدادات…) كنشغّلوها من نفس الـ adapter الأصلي. إلا فشل أي شيء كتبقى الشاشة الأصلية.
 *
 * بلا أزرار عائمة: ما بقاش شي حاجة كتغطّي المشاريع. الشاشة كتحترم شريط الحالة وشريط التنقّل (insets) وكتتفرض RTL.
 */
object ZelligeHome {

    private val homes = WeakHashMap<Activity, Home>()

    const val ACTION_CREATE = 0
    const val ACTION_OPEN = 1
    const val ACTION_CLONE = 2
    const val ACTION_TERMINAL = 3
    const val ACTION_PREFS = 4
    const val ACTION_DOCS = 6

    private fun idOf(a: Activity, name: String): Int = a.resources.getIdentifier(name, "id", a.packageName)

    /** يرجع true إلا تركّبت الشاشة الجديدة (وإلا كتبقى الأصلية). */
    fun attach(a: Activity): Boolean {
        return try {
            val old = homes[a]
            if (old != null && old.isAttached()) {
                old.refresh()
                return true
            }
            // الحاوية الأصلية (FrameLayout فيه MainFragment وقوالب المشاريع): نحط شاشتنا فوقها
            val main = a.findViewById<View>(idOf(a, "main")) ?: return false
            val host = main.parent as? FrameLayout ?: return false
            val h = Home(a, host, main)
            h.install()
            homes[a] = h
            true
        } catch (t: Throwable) { false }
    }

    /** يشغّل زر أصلي من الشاشة الأصلية (نفس الـ lambda اللي ربطها MainFragment). */
    fun runAction(a: Activity, id: Int): Boolean {
        return try {
            val rv = a.findViewById<View>(idOf(a, "actions")) ?: return false
            val adapter = rv.javaClass.getMethod("getAdapter").invoke(rv) ?: return false
            val list = adapter.javaClass.getMethod("getActions").invoke(adapter) as? List<*> ?: return false
            val item = list.firstOrNull { it != null && it.javaClass.getMethod("getId").invoke(it) == id } ?: return false
            val fn = item.javaClass.getMethod("getOnClick").invoke(item) ?: return false
            val fn2 = Class.forName("kotlin.jvm.functions.Function2")
            fn2.getMethod("invoke", Any::class.java, Any::class.java).invoke(fn, item, rv)
            true
        } catch (t: Throwable) {
            Toast.makeText(a, "تعذّر تشغيل الإجراء: " + (t.message ?: t.javaClass.simpleName), Toast.LENGTH_LONG).show()
            false
        }
    }

    // ------------------------------------------------------------------ data
    private class Info(
        val dir: File,
        val title: String,
        val folder: String,
        val version: String?,
        val appId: String?,
        val gradle: Boolean,
        val modified: Long,
        val icon: Bitmap?,
        val branch: String?,
        val built: Boolean
    )

    /** مجلدات كتكون فجذر المشاريع ولكن ماشي مشاريع (مثلا مجلد gradle المشترك). */
    private val hiddenFolders = setOf("gradle", "build", "caches", "cache", "tmp", "temp", "wrapper", "lost+found")

    private val buildFiles = listOf("build.gradle.kts", "build.gradle")
    private val reAppId = Regex("applicationId\\s*=?\\s*[\"']([^\"']+)[\"']")
    private val reNamespace = Regex("namespace\\s*=?\\s*[\"']([^\"']+)[\"']")
    private val reVName = Regex("versionName\\s*=?\\s*[\"']([^\"']+)[\"']")
    private val reVCode = Regex("versionCode\\s*=?\\s*(\\d+)")
    private val reLabel = Regex("<string\\s+name=\"app_name\"[^>]*>([^<]*)</string>")
    private val iconDirs = listOf(
        "mipmap-xxxhdpi", "mipmap-xxhdpi", "mipmap-xhdpi", "mipmap-hdpi", "mipmap-mdpi",
        "drawable-xxxhdpi", "drawable-xxhdpi", "drawable-xhdpi", "drawable"
    )

    private fun buildFileOf(dir: File): File? = buildFiles.map { File(dir, it) }.firstOrNull { it.isFile }

    private fun findAppModule(root: File): File? {
        File(root, "app").takeIf { buildFileOf(it) != null }?.let { return it }
        val subs = root.listFiles()?.filter { it.isDirectory && !it.name.startsWith(".") && it.name != "build" } ?: return null
        for (d in subs.sortedBy { it.name }.take(30)) {
            val bf = buildFileOf(d) ?: continue
            val txt = try { bf.readText().take(200_000) } catch (t: Throwable) { continue }
            if (txt.contains("com.android.application")) return d
        }
        return null
    }

    private fun decodeIcon(mod: File): Bitmap? {
        val res = File(mod, "src/main/res")
        for (dn in iconDirs) for (ext in listOf("png", "webp")) {
            val f = File(res, "$dn/ic_launcher.$ext")
            if (!f.isFile) continue
            try {
                val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(f.path, o)
                var s = 1
                while (o.outWidth / (s * 2) >= 160) s *= 2
                return BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s })
            } catch (t: Throwable) { /* نجرب أيقونة أخرى */ }
        }
        return null
    }

    /** اسم فرع git من .git/HEAD (بلا تشغيل git). */
    private fun gitBranch(dir: File): String? = try {
        val head = File(dir, ".git/HEAD")
        if (!head.isFile) null else {
            val s = head.readText().trim()
            if (s.startsWith("ref:")) s.substringAfterLast('/') else s.take(7)
        }
    } catch (t: Throwable) { null }

    private fun scan(dir: File): Info {
        val gradle = AiIde.isGradleProject(dir)
        var appId: String? = null
        var vName: String? = null
        var vCode: String? = null
        var label: String? = null
        var icon: Bitmap? = null
        var built = false
        if (gradle) {
            try {
                val mod = findAppModule(dir)
                if (mod != null) {
                    val txt = buildFileOf(mod)?.readText()?.take(200_000).orEmpty()
                    appId = reAppId.find(txt)?.groupValues?.get(1) ?: reNamespace.find(txt)?.groupValues?.get(1)
                    vName = reVName.find(txt)?.groupValues?.get(1)
                    vCode = reVCode.find(txt)?.groupValues?.get(1)
                    val strings = File(mod, "src/main/res/values/strings.xml")
                    if (strings.isFile) label = reLabel.find(strings.readText().take(100_000))?.groupValues?.get(1)?.trim()
                    icon = decodeIcon(mod)
                    built = File(mod, "build/outputs/apk").isDirectory
                }
            } catch (t: Throwable) { /* معلومات اختيارية */ }
        }
        val version = when {
            vName != null && vCode != null -> "$vName ($vCode)"
            vName != null -> vName
            else -> null
        }
        val title = label?.takeIf { it.isNotBlank() && !it.startsWith("@") } ?: dir.name
        return Info(dir, title, dir.name, version, appId, gradle, dir.lastModified(), icon, gitBranch(dir), built)
    }

    /** 1m / 3h / 5d … بشكل مضغوط (mono). */
    private fun ago(ms: Long): String {
        val s = ((System.currentTimeMillis() - ms) / 1000).coerceAtLeast(0)
        return when {
            s < 60 -> "now"
            s < 3600 -> "${s / 60}m"
            s < 86400 -> "${s / 3600}h"
            s < 86400 * 14 -> "${s / 86400}d"
            s < 86400 * 90 -> "${s / (86400 * 7)}w"
            else -> "${s / (86400 * 30)}mo"
        }
    }

    // ------------------------------------------------------------------ tokens (Console)
    private fun blend(a: Int, b: Int, t: Float): Int {
        fun ch(x: Int, y: Int) = (x + (y - x) * t).toInt().coerceIn(0, 255)
        return Color.rgb(ch(Color.red(a), Color.red(b)), ch(Color.green(a), Color.green(b)), ch(Color.blue(a), Color.blue(b)))
    }

    /** ألوان من theme التطبيق (اللي رجّعناه Console)، بقيم احتياطية من التصميم. */
    private class Tone(val a: Activity) {
        private fun attr(names: List<String>, fb: Int): Int {
            for (n in names) {
                try {
                    val id = a.resources.getIdentifier(n, "attr", a.packageName)
                    if (id == 0) continue
                    val tv = TypedValue()
                    if (a.theme.resolveAttribute(id, tv, true) &&
                        tv.type >= TypedValue.TYPE_FIRST_COLOR_INT && tv.type <= TypedValue.TYPE_LAST_COLOR_INT
                    ) return tv.data
                } catch (t: Throwable) { /* اسم آخر */ }
            }
            return fb
        }

        val page = attr(listOf("colorSurface", "colorBackground"), Color.parseColor("#0A0C10"))
        val dark = (Color.red(page) * 299 + Color.green(page) * 587 + Color.blue(page) * 114) / 1000 < 128
        val text = attr(listOf("colorOnSurface"), if (dark) Color.parseColor("#D9DDE5") else Color.parseColor("#14171C"))
        val amber = attr(listOf("colorPrimary"), if (dark) Color.parseColor("#FFB454") else Color.parseColor("#9A5B00"))
        val onAmber = attr(listOf("colorOnPrimary"), if (dark) Color.parseColor("#1A1000") else Color.WHITE)
        val green = attr(listOf("colorTertiary"), if (dark) Color.parseColor("#7BD88F") else Color.parseColor("#1E7A3B"))
        val red = attr(listOf("colorError"), if (dark) Color.parseColor("#FF7A7A") else Color.parseColor("#C62828"))
        val icon = attr(listOf("colorOnSurfaceVariant"), if (dark) Color.parseColor("#A5ADBB") else Color.parseColor("#4A5160"))
        val s1 = blend(page, text, 0.045f)
        val s2 = blend(page, text, 0.085f)
        val line = blend(page, text, 0.13f)
        val line2 = blend(page, text, 0.07f)
        val muted = blend(page, text, 0.45f)
        val navBg = blend(page, text, 0.03f)
    }

    internal fun loadMono(a: Activity): Typeface = try {
        Typeface.createFromAsset(a.assets, "fonts/jetbrains-mono.ttf")
    } catch (t: Throwable) { Typeface.MONOSPACE }

    /** وزن الخط: 500/600 كيتطبقو من API 28، وقبلها 600+ = bold. */
    internal fun face(weight: Int): Typeface =
        if (Build.VERSION.SDK_INT >= 28) Typeface.create(Typeface.DEFAULT, weight, false)
        else if (weight >= 600) Typeface.DEFAULT_BOLD else Typeface.DEFAULT

    private val commands = listOf(
        Triple("/new", "أنشئ مشروعا كاملا من وصف", "أنشئ مشروع أندرويد جديد باسم "),
        Triple("/screen", "شاشة جديدة وتسجيلها في المانيفست", "أضف شاشة جديدة للمشروع النشط: "),
        Triple("/fix", "افحص المشروع وأصلح الأخطاء", "افحص المشروع النشط وأصلح الأخطاء الواضحة (imports، manifest، dependencies) وطبّق الإصلاح مباشرة."),
        Triple("/explain", "اشرح هيكل المشروع", "اشرح لي هيكل المشروع النشط وملفاته الأساسية باختصار."),
        Triple("/ui", "حسّن الواجهة بـ Material 3", "حسّن تصميم شاشات المشروع النشط بـ Material 3 وطبّق التعديل مباشرة."),
        Triple("/test", "اكتب unit tests في أماكنها", "اكتب unit tests مناسبة للمشروع النشط وأنشئها فأماكنها الصحيحة.")
    )

    /** أوامر / ← (prompt, send). الأوامر اللي كتحتاج وصفا (new/screen) ما كتتبعتش حتى يكتب المستعمل شي حاجة. */
    private fun expand(raw: String): Pair<String, Boolean> {
        if (!raw.startsWith("/")) return raw to true
        val cmd = raw.substringBefore(' ')
        val arg = raw.substringAfter(' ', "").trim()
        val c = commands.firstOrNull { it.first == cmd } ?: return raw to true
        val needsArg = cmd == "/new" || cmd == "/screen"
        return if (needsArg) (c.third + arg) to arg.isNotEmpty() else (c.third + (if (arg.isEmpty()) "" else " $arg")) to true
    }

    // ------------------------------------------------------------------ the screen
    private class Home(val a: Activity, val host: FrameLayout, val main: View) {

        val t = Tone(a)
        val prefs = AiPrefs(a)
        val monoFace: Typeface = loadMono(a)

        lateinit var frame: FrameLayout
        lateinit var cmdBar: View
        lateinit var cmdInput: EditText
        lateinit var navBox: LinearLayout
        lateinit var listBox: LinearLayout
        lateinit var resumeHolder: FrameLayout
        lateinit var emptyBox: LinearLayout
        lateinit var aiProvider: TextView
        lateinit var aiState: TextView
        lateinit var aiMode: TextView
        lateinit var aiDot: View
        lateinit var aiHistory: LinearLayout
        val pages = mutableListOf<View>()
        val navItems = mutableListOf<Triple<FrameLayout, ImageView, TextView>>()
        val tabCount = mutableListOf<TextView>()
        val tabLabel = mutableListOf<TextView>()
        val tabBar = mutableListOf<View>()
        var cur = 0
        var tab = 0
        var all: List<Info> = emptyList()
        var filter = ""
        var sort = prefs.homeSort
        var token = 0
        var padTop = 0
        var padBottom = 0

        fun dp(v: Int) = AiChat.dp(a, v)
        fun round(c: Int, r: Int) = AiChat.shape(c, dp(r).toFloat())
        fun boxed(c: Int, r: Int, line: Int = t.line) = AiChat.outlined(c, dp(r).toFloat(), line, dp(1))
        fun ripple(c: Int, r: Int, stroke: Boolean = false): android.graphics.drawable.Drawable =
            AiChat.ripple(if (stroke) boxed(c, r) else round(c, r), dp(r).toFloat())

        fun isAttached(): Boolean = ::frame.isInitialized && frame.parent != null

        fun toast(s: String, long: Boolean = false) =
            Toast.makeText(a, s, if (long) Toast.LENGTH_LONG else Toast.LENGTH_SHORT).show()

        /** نص: m = mono (JetBrains Mono)، ltr = اتجاه يسار→يمين لكن محاذى لبداية الـ view (يمين فـ RTL). */
        fun txt(s: CharSequence, sp: Float, color: Int, w: Int = 400, m: Boolean = false, ltr: Boolean = false): TextView =
            TextView(a).apply {
                text = s; textSize = sp; setTextColor(color)
                typeface = if (m) monoFace else face(w)
                includeFontPadding = false
                if (ltr || m) {
                    textDirection = View.TEXT_DIRECTION_LTR
                    textAlignment = View.TEXT_ALIGNMENT_VIEW_START
                } else {
                    textDirection = View.TEXT_DIRECTION_ANY_RTL
                }
            }

        fun icon(name: String, tint: Int, size: Int): ImageView = ImageView(a).apply {
            setImageDrawable(AiChat.icon(a, name))
            imageTintList = ColorStateList.valueOf(tint)
            layoutParams = LinearLayout.LayoutParams(dp(size), dp(size))
        }

        fun lp(w: Int, h: Int) = LinearLayout.LayoutParams(w, h)
        val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
        val MATCH = ViewGroup.LayoutParams.MATCH_PARENT

        fun hair(c: Int = t.line2): View = View(a).apply { setBackgroundColor(c) }

        // -------------------------------------------------------------- install
        fun install() {
            frame = FrameLayout(a).apply {
                tag = "zl_home"
                setBackgroundColor(t.page)
                isClickable = true      // ما نخلّيوش اللمسات توصل للشاشة الأصلية اللي لتحت
                layoutDirection = View.LAYOUT_DIRECTION_RTL
            }
            val column = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
            val pageHost = FrameLayout(a)
            pages.add(projectsPage()); pages.add(aiPage()); pages.add(toolsPage())
            pages.forEachIndexed { i, p ->
                pageHost.addView(p, FrameLayout.LayoutParams(MATCH, MATCH))
                p.visibility = if (i == 0) View.VISIBLE else View.GONE
            }
            column.addView(pageHost, LinearLayout.LayoutParams(MATCH, 0, 1f))
            cmdBar = commandBar()
            column.addView(cmdBar, lp(MATCH, WRAP))
            column.addView(bottomNav(), lp(MATCH, WRAP))
            frame.addView(column, FrameLayout.LayoutParams(MATCH, MATCH))
            host.addView(frame, FrameLayout.LayoutParams(MATCH, MATCH))
            syncToolbar()
            refresh()
        }

        /**
         * شاشتنا كتبان فقط مع الشاشة الرئيسية الأصلية (كتتبع visibility ديالها)،
         * والـ Toolbar الأصلي كيتخبّى فيها وكيبان فشاشات القوالب. وكنحترمو شريط الحالة وشريط التنقّل.
         */
        fun syncToolbar() {
            val appbar = a.findViewById<View>(idOf(a, "appbar")) as? ViewGroup
            val toolbar = appbar?.getChildAt(0)
            val sync = {
                val onMain = main.visibility == View.VISIBLE
                val want = if (onMain) View.VISIBLE else View.GONE
                if (frame.visibility != want) frame.visibility = want
                val tb = if (onMain) View.GONE else View.VISIBLE
                if (toolbar != null && toolbar.visibility != tb) toolbar.visibility = tb
                if (onMain) fitSystemBars()
            }
            sync()
            a.window.decorView.viewTreeObserver.addOnGlobalLayoutListener { sync() }
        }

        /**
         * إلا الشاشة كتترسم تحت شريط الحالة (edge-to-edge) كنزيدو padding فوق، وتحت لشريط التنقّل؛
         * إلا النظام راه حاط المحتوى بعيد على الأشرطة كيبقاو 0. الحساب بالموقع الحقيقي فالنافذة.
         */
        fun fitSystemBars() {
            try {
                val loc = IntArray(2)
                frame.getLocationInWindow(loc)
                val decor = a.window.decorView
                val ins = decor.rootWindowInsets
                val topBar = ins?.stableInsetTop ?: statusBarHeight()
                val botBar = ins?.stableInsetBottom ?: 0
                val top = (topBar - loc[1]).coerceAtLeast(0)
                val bottom = ((loc[1] + frame.height) - (decor.height - botBar)).coerceAtLeast(0)
                if (top != padTop) { padTop = top; frame.setPadding(0, top, 0, 0) }
                if (bottom != padBottom) {
                    padBottom = bottom
                    navBox.setPadding(0, 0, 0, bottom)
                }
            } catch (t: Throwable) { /* بلا insets: التصميم كيخدم عادي */ }
        }

        fun statusBarHeight(): Int {
            val id = a.resources.getIdentifier("status_bar_height", "dimen", "android")
            return if (id > 0) a.resources.getDimensionPixelSize(id) else dp(24)
        }

        fun refresh() {
            refreshResume()
            refreshAiPage()
            val my = ++token
            Thread {
                val infos = try {
                    AiIde.findProjects(a).take(200)
                        .filter { AiIde.isGradleProject(it) || !hiddenFolders.contains(it.name.lowercase()) }
                        .map { scan(it) }
                } catch (t: Throwable) { emptyList() }
                a.runOnUiThread {
                    if (my == token && isAttached()) {
                        all = infos
                        renderList()
                    }
                }
            }.start()
        }

        // -------------------------------------------------------------- bottom: command bar + navigation
        fun commandBar(): View {
            val wrap = FrameLayout(a).apply { setPadding(dp(12), dp(8), dp(12), dp(8)) }
            val box = LinearLayout(a).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                background = boxed(t.s2, 12)
                setPadding(dp(12), 0, dp(8), 0)
            }
            box.addView(icon("ic_ai_sparkle", t.amber, 18))
            cmdInput = EditText(a).apply {
                hint = "ابحث أو اطلب من الذكاء…"
                setHintTextColor(t.muted); setTextColor(t.text); textSize = 13.5f
                typeface = face(400)
                background = null
                setSingleLine()
                inputType = InputType.TYPE_CLASS_TEXT
                imeOptions = EditorInfo.IME_ACTION_SEND
                textDirection = View.TEXT_DIRECTION_ANY_RTL
                setPadding(dp(10), 0, dp(8), 0)
                setOnFocusChangeListener { _, f -> box.background = boxed(t.s2, 12, if (f) t.amber else t.line) }
                setOnEditorActionListener { _, id, _ ->
                    if (id == EditorInfo.IME_ACTION_SEND) { send(); true } else false
                }
                addTextChangedListener(object : TextWatcher {
                    override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, af: Int) {}
                    override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {
                        if (cur == 0) {
                            val q = s?.toString().orEmpty().trim()
                            filter = if (q.startsWith("/")) "" else q
                            renderList()
                        }
                    }
                    override fun afterTextChanged(s: Editable?) {}
                })
            }
            box.addView(cmdInput, LinearLayout.LayoutParams(0, MATCH, 1f))
            val go = FrameLayout(a).apply {
                background = ripple(t.amber, 9)
                isClickable = true; isFocusable = true
                contentDescription = "إرسال للذكاء"
                setOnClickListener { send() }
                addView(ImageView(a).apply {
                    setImageDrawable(AiChat.icon(a, "ic_ai_send"))
                    imageTintList = ColorStateList.valueOf(t.onAmber)
                    scaleX = -1f       // الشاشة RTL: السهم كيمشي لليسار
                }, FrameLayout.LayoutParams(dp(16), dp(16), Gravity.CENTER))
            }
            box.addView(go, lp(dp(34), dp(34)))
            wrap.addView(box, FrameLayout.LayoutParams(MATCH, dp(50)))
            return wrap
        }

        fun send() {
            val raw = cmdInput.text.toString().trim()
            if (raw.isEmpty()) { openChat(); return }
            val (prompt, go) = expand(raw)
            cmdInput.text.clear()
            try {
                (a.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(cmdInput.windowToken, 0)
            } catch (t: Throwable) { }
            openChat(prompt, go)
        }

        fun bottomNav(): View {
            navBox = LinearLayout(a).apply {
                orientation = LinearLayout.VERTICAL
                setBackgroundColor(t.navBg)
            }
            navBox.addView(hair(t.line), lp(MATCH, dp(1)))
            val row = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL }
            val defs = listOf(Triple("zl_ic_projects", "المشاريع", 0), Triple("zl_ic_sparkle", "الذكاء", 1), Triple("zl_ic_tools", "الأدوات", 2))
            for ((ic, label, idx) in defs) {
                val item = FrameLayout(a).apply {
                    isClickable = true; isFocusable = true
                    setOnClickListener { select(idx) }
                    background = AiChat.ripple(round(Color.TRANSPARENT, 0), 0f)
                }
                val bar = View(a).apply { setBackgroundColor(t.amber) }
                item.addView(bar, FrameLayout.LayoutParams(dp(36), dp(2), Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = -dp(1) })
                val col = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
                val ic2 = icon(ic, t.muted, 20)
                col.addView(ic2)
                val tv = txt(label, 11f, t.muted, 400).apply { gravity = Gravity.CENTER; setPadding(0, dp(3), 0, 0) }
                col.addView(tv, lp(WRAP, WRAP))
                item.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))
                row.addView(item, LinearLayout.LayoutParams(0, dp(56), 1f))
                navItems.add(Triple(item, ic2, tv))
            }
            navBox.addView(row)
            updateNav()
            return navBox
        }

        fun updateNav() {
            navItems.forEachIndexed { i, (item, ic, tv) ->
                val on = i == cur
                ic.imageTintList = ColorStateList.valueOf(if (on) t.amber else t.muted)
                tv.setTextColor(if (on) t.amber else t.muted)
                (item.getChildAt(0)).visibility = if (on) View.VISIBLE else View.INVISIBLE
            }
        }

        fun select(i: Int) {
            if (i == cur) return
            val from = pages[cur]
            val to = pages[i]
            cur = i
            to.alpha = 0f
            to.visibility = View.VISIBLE
            to.animate().alpha(1f).setDuration(150).start()
            from.animate().alpha(0f).setDuration(100).withEndAction {
                if (pages[cur] !== from) from.visibility = View.GONE
            }.start()
            cmdBar.visibility = if (i == 2) View.GONE else View.VISIBLE
            cmdInput.hint = if (i == 1) "اكتب طلبا أو / لأمر…" else "ابحث أو اطلب من الذكاء…"
            updateNav()
        }

        // -------------------------------------------------------------- shared pieces
        fun header(ic: String, tint: Int, title: String, ltrTitle: Boolean, vararg actions: View): View {
            val row = LinearLayout(a).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(16), 0, dp(16), 0)
            }
            row.addView(icon(ic, tint, 20))
            row.addView(txt(title, 17f, t.text, 600, ltr = ltrTitle).apply { setSingleLine() },
                LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(8) })
            actions.forEach { row.addView(it, lp(if (it.tag == "wide") WRAP else dp(36), dp(36)).apply { marginStart = dp(8) }) }
            return row
        }

        fun squareBtn(ic: String, desc: String, onClick: () -> Unit): View = FrameLayout(a).apply {
            background = ripple(Color.TRANSPARENT, 10, stroke = true)
            isClickable = true; isFocusable = true; contentDescription = desc
            setOnClickListener { onClick() }
            addView(ImageView(a).apply {
                setImageDrawable(AiChat.icon(a, ic)); imageTintList = ColorStateList.valueOf(t.icon)
            }, FrameLayout.LayoutParams(dp(18), dp(18), Gravity.CENTER))
        }

        fun label(s: String): TextView = txt(s, 11f, t.muted, m = true).apply {
            letterSpacing = 0.12f
            setPadding(dp(16), 0, dp(16), dp(6))
        }

        /** صف قائمة: أيقونة فمربع، عنوان + وصف، سهم. */
        fun listRow(ic: String, tint: Int, title: String, sub: String, subMono: Boolean, onClick: () -> Unit): View {
            val row = LinearLayout(a).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(16), 0, dp(16), 0)
                background = AiChat.ripple(round(Color.TRANSPARENT, 0), 0f)
                isClickable = true; isFocusable = true
                setOnClickListener { onClick() }
            }
            val tile = FrameLayout(a).apply { background = boxed(t.s1, 10) }
            tile.addView(ImageView(a).apply {
                setImageDrawable(AiChat.icon(a, ic)); imageTintList = ColorStateList.valueOf(tint)
            }, FrameLayout.LayoutParams(dp(19), dp(19), Gravity.CENTER))
            row.addView(tile, lp(dp(38), dp(38)))
            val col = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
            col.addView(txt(title, 14.5f, t.text, 500).apply { setSingleLine() })
            col.addView(txt(sub, if (subMono) 11f else 12f, t.muted, m = subMono).apply { setSingleLine(); setPadding(0, dp(3), 0, 0) })
            row.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(14); marginEnd = dp(8) })
            row.addView(icon("zl_ic_chevron_left", t.muted, 16))
            val box = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
            box.addView(row, lp(MATCH, dp(60)))
            box.addView(hair(), lp(MATCH, dp(1)))
            return box
        }

        fun scrolling(content: LinearLayout): ScrollView = ScrollView(a).apply {
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(content, ViewGroup.LayoutParams(MATCH, WRAP))
        }

        fun page(vararg parts: View): LinearLayout = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            parts.forEachIndexed { i, v ->
                if (v is ScrollView) addView(v, LinearLayout.LayoutParams(MATCH, 0, 1f))
                else addView(v, lp(MATCH, if (i == 0) dp(52) else WRAP))
            }
        }

        // -------------------------------------------------------------- page: projects
        fun projectsPage(): View {
            val sortBtn = squareBtn("zl_ic_sort", "فرز") {
                sort = if (sort == "name") "recent" else "name"
                prefs.homeSort = sort
                toast(if (sort == "name") "الترتيب: A–Z" else "الترتيب: الأحدث")
                renderList()
            }
            val add = LinearLayout(a).apply {
                tag = "wide"
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
                background = ripple(t.amber, 10)
                setPadding(dp(14), 0, dp(14), 0)
                isClickable = true; isFocusable = true
                setOnClickListener { runAction(a, ACTION_CREATE) }
                addView(icon("zl_ic_add", t.onAmber, 16))
                addView(txt("جديد", 13f, t.onAmber, 600).apply { setPadding(dp(6), 0, 0, 0) })
            }
            val head = header("zl_ic_star8", t.amber, "Zellige", true, sortBtn, add)

            resumeHolder = FrameLayout(a).apply { setPadding(dp(12), dp(4), dp(12), dp(8)) }

            val tabs = LinearLayout(a).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(dp(16), 0, dp(16), 0)
            }
            val names = listOf("الأخيرة", "المثبّتة", "مجلدات")
            names.forEachIndexed { i, n ->
                val col = LinearLayout(a).apply {
                    orientation = LinearLayout.VERTICAL
                    isClickable = true; isFocusable = true
                    setOnClickListener { tab = i; renderList() }
                }
                val content = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                val l = txt(n, 13.5f, t.muted, 400)
                val c = txt("0", 11.5f, t.muted, m = true).apply { setPadding(dp(6), 0, 0, 0) }
                content.addView(l); content.addView(c)
                val bar = View(a).apply { setBackgroundColor(t.amber) }
                col.addView(content, LinearLayout.LayoutParams(WRAP, dp(38)))
                col.addView(bar, lp(MATCH, dp(2)))
                tabs.addView(col, lp(WRAP, dp(40)).apply { marginEnd = dp(22) })
                tabLabel.add(l); tabCount.add(c); tabBar.add(bar)
            }
            val tabsBox = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
            tabsBox.addView(tabs, lp(MATCH, dp(40)))
            tabsBox.addView(hair(t.line), lp(MATCH, dp(1)))

            listBox = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
            emptyBox = emptyState()
            val col = LinearLayout(a).apply {
                orientation = LinearLayout.VERTICAL
                addView(listBox, lp(MATCH, WRAP))
                addView(emptyBox, lp(MATCH, WRAP))
                setPadding(0, 0, 0, dp(12))
            }
            return page(head, resumeHolder, tabsBox, scrolling(col))
        }

        fun refreshResume() {
            resumeHolder.removeAllViews()
            val last = prefs.lastOpened.trim()
            val dir = if (last.isNotEmpty()) File(last).takeIf { it.isDirectory } else null
            val row = LinearLayout(a).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                background = ripple(t.s1, 12, stroke = true)
                setPadding(dp(14), 0, dp(14), 0)
                isClickable = true; isFocusable = true
            }
            if (dir != null) {
                row.setOnClickListener { openProject(dir) }
                row.addView(icon("zl_ic_history", t.amber, 20))
                row.addView(txt("تابع ⁨${dir.name}⁩", 14f, t.text, 500).apply { setSingleLine(); ellipsize = TextUtils.TruncateAt.MIDDLE },
                    LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(12); marginEnd = dp(8) })
                row.addView(txt(ago(dir.lastModified()), 11.5f, t.muted, m = true))
            } else {
                row.setOnClickListener { runAction(a, ACTION_OPEN) }
                row.addView(icon("zl_ic_folder_open", t.amber, 20))
                row.addView(txt("افتح مشروعا موجودا", 14f, t.text, 500),
                    LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(12); marginEnd = dp(8) })
            }
            row.addView(icon("zl_ic_chevron_left", t.muted, 16).apply {
                (layoutParams as LinearLayout.LayoutParams).marginStart = dp(8)
            })
            resumeHolder.addView(row, FrameLayout.LayoutParams(MATCH, dp(56)))
        }

        fun emptyState(): LinearLayout {
            val col = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(dp(24), dp(40), dp(24), dp(10)) }
            col.addView(icon("zl_ic_star8", t.muted, 28))
            col.addView(txt("لا توجد مشاريع هنا بعد", 15f, t.text, 500).apply { setPadding(0, dp(14), 0, 0); gravity = Gravity.CENTER })
            col.addView(txt("أنشئ مشروعا، أو افتح مجلدا، أو اطلب من الذكاء من الشريط تحت.", 12.5f, t.muted).apply {
                gravity = Gravity.CENTER; setPadding(0, dp(6), 0, 0)
            })
            col.visibility = View.GONE
            return col
        }

        // -------------------------------------------------------------- project list
        fun pinnedSet(): MutableSet<String> = prefs.pinned.split('\n').filter { it.isNotBlank() }.toMutableSet()

        fun togglePin(info: Info) {
            val s = pinnedSet()
            if (!s.remove(info.dir.path)) s.add(info.dir.path)
            prefs.pinned = s.joinToString("\n")
            renderList()
        }

        fun renderList() {
            val pins = pinnedSet()
            val q = filter.lowercase()
            fun match(i: Info) = q.isEmpty() || i.title.lowercase().contains(q) || i.folder.lowercase().contains(q) ||
                (i.appId?.lowercase()?.contains(q) == true)
            val groups = listOf(all.filter { it.gradle }, all.filter { pins.contains(it.dir.path) }, all.filter { !it.gradle })
            groups.forEachIndexed { i, g ->
                tabCount[i].text = g.size.toString()
                val on = i == tab
                tabLabel[i].setTextColor(if (on) t.amber else t.muted)
                tabLabel[i].typeface = face(if (on) 500 else 400)
                tabCount[i].setTextColor(if (on) t.amber else t.muted)
                tabBar[i].visibility = if (on) View.VISIBLE else View.INVISIBLE
            }
            var items = groups[tab].filter { match(it) }
            items = if (sort == "name") items.sortedBy { it.title.lowercase() } else items.sortedByDescending { it.modified }
            listBox.removeAllViews()
            emptyBox.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
            (emptyBox.getChildAt(1) as? TextView)?.text = when {
                all.isEmpty() -> "لا توجد مشاريع هنا بعد"
                q.isNotEmpty() -> "ما لقيت شي حاجة تطابق «$filter»"
                tab == 1 -> "ما كاين حتى مشروع مثبّت (ضغطة مطوّلة على مشروع ← تثبيت)"
                tab == 2 -> "لا توجد مجلدات أخرى"
                else -> "لا توجد مشاريع هنا بعد"
            }
            items.forEach { listBox.addView(projectRow(it, pins.contains(it.dir.path)), lp(MATCH, WRAP)) }
        }

        fun projectRow(info: Info, pinned: Boolean): View {
            val box = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
            val row = LinearLayout(a).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(16), 0, dp(16), 0)
                background = AiChat.ripple(round(Color.TRANSPARENT, 0), 0f)
                isClickable = true; isFocusable = true
                setOnClickListener { openProject(info.dir) }
                setOnLongClickListener { actions(info, pinned); true }
            }
            row.addView(tile(info), lp(dp(40), dp(40)))

            val col = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
            val nameRow = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            nameRow.addView(txt(info.title, 14.5f, t.text, 500, ltr = true).apply { setSingleLine(); ellipsize = TextUtils.TruncateAt.END },
                LinearLayout.LayoutParams(0, WRAP, 1f))
            if (pinned) nameRow.addView(icon("zl_ic_star8", t.amber, 11).apply { (layoutParams as LinearLayout.LayoutParams).marginStart = dp(6) })
            col.addView(nameRow, lp(MATCH, WRAP))
            val sub = listOfNotNull(info.appId ?: info.folder.takeIf { it != info.title }, info.version?.let { "v$it" }).joinToString(" · ")
                .ifEmpty { if (info.gradle) info.folder else "folder" }
            col.addView(txt(sub, 10.5f, t.muted, m = true).apply {
                setSingleLine(); ellipsize = TextUtils.TruncateAt.MIDDLE; setPadding(0, dp(4), 0, 0)
            }, lp(MATCH, WRAP))
            row.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(12); marginEnd = dp(12) })

            val meta = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_LTR }
            val l1 = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            l1.addView(View(a).apply {
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(if (info.built) t.green else t.line) }
            }, lp(dp(6), dp(6)).apply { marginEnd = dp(5) })
            l1.addView(txt(ago(info.modified), 10.5f, t.muted, m = true))
            meta.addView(l1)
            meta.addView(txt(if (info.gradle) (info.branch ?: "no git") else "—", 10.5f, t.muted, m = true).apply { setPadding(0, dp(3), 0, 0) })
            row.addView(meta, lp(WRAP, WRAP))

            box.addView(row, lp(MATCH, dp(64)))
            box.addView(hair(), lp(MATCH, dp(1)))
            return box
        }

        /** مربع الأيقونة: أيقونة التطبيق الحقيقية إلا كانت، وإلا حرف أول mono. */
        fun tile(info: Info): View {
            val tile = FrameLayout(a).apply { background = boxed(t.s1, 10) }
            if (info.icon != null) {
                val img = ImageView(a).apply {
                    setImageBitmap(info.icon)
                    scaleType = ImageView.ScaleType.CENTER_CROP
                    outlineProvider = object : ViewOutlineProvider() {
                        override fun getOutline(v: View, o: android.graphics.Outline) {
                            o.setRoundRect(0, 0, v.width, v.height, dp(6).toFloat())
                        }
                    }
                    clipToOutline = true
                }
                tile.addView(img, FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER))
            } else {
                val ch = info.title.firstOrNull { it.isLetterOrDigit() }?.uppercaseChar()?.toString() ?: "?"
                tile.addView(txt(ch, 16f, if (info.gradle) t.amber else t.icon, m = true).apply { gravity = Gravity.CENTER },
                    FrameLayout.LayoutParams(MATCH, MATCH))
            }
            return tile
        }

        fun actions(info: Info, pinned: Boolean) {
            val labels = arrayOf("فتح", "الذكاء على هذا المشروع", if (pinned) "إلغاء التثبيت" else "تثبيت", "نسخ المسار", "حذف…")
            AlertDialog.Builder(a)
                .setTitle(info.title)
                .setItems(labels) { _, which ->
                    when (which) {
                        0 -> openProject(info.dir)
                        1 -> { AiIde.remember(a, info.dir); toast("المشروع النشط للذكاء: " + info.title); openChat() }
                        2 -> togglePin(info)
                        3 -> copyPath(info.dir)
                        4 -> confirmDelete(info)
                    }
                }
                .show()
        }

        fun openProject(dir: File) {
            val err = try { AiIde.openProject(a, dir) } catch (t: Throwable) { t.message ?: "خطأ" }
            if (err != null) toast(err, true)
        }

        fun copyPath(dir: File) {
            try {
                val cm = a.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("path", dir.path))
                toast("تم نسخ المسار")
            } catch (t: Throwable) { toast("تعذّر النسخ", true) }
        }

        fun confirmDelete(info: Info) {
            AlertDialog.Builder(a)
                .setTitle("حذف «" + info.title + "»؟")
                .setMessage("سيُحذف المجلد نهائيا:\n" + info.dir.path)
                .setPositiveButton("حذف") { _, _ ->
                    Thread {
                        val ok = info.dir.deleteRecursively()
                        a.runOnUiThread {
                            toast(if (ok) "تم الحذف" else "تعذّر الحذف", !ok)
                            if (ok) prefs.pinned = pinnedSet().also { it.remove(info.dir.path) }.joinToString("\n")
                            refresh()
                        }
                    }.start()
                }
                .setNegativeButton("إلغاء", null)
                .show()
        }

        // -------------------------------------------------------------- page: AI
        fun openChat(prompt: String? = null, send: Boolean = false) {
            AiChat.open(a, prompt, send)
        }

        fun kv(vararg p: Triple<String, String, Int>): CharSequence {
            val sb = SpannableStringBuilder()
            p.forEachIndexed { i, (k, v, c) ->
                if (i > 0) sb.append("   ")
                sb.append("$k: ")
                val s = sb.length
                sb.append(v)
                sb.setSpan(ForegroundColorSpan(c), s, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
            return sb
        }

        fun aiPage(): View {
            val head = header("zl_ic_sparkle", t.amber, "الذكاء", false, squareBtn("zl_ic_settings", "إعدادات الذكاء") { AiChat.showSettings(a) })

            val card = LinearLayout(a).apply {
                orientation = LinearLayout.VERTICAL
                layoutDirection = View.LAYOUT_DIRECTION_LTR
                background = ripple(t.s1, 12, stroke = true)
                setPadding(dp(14), dp(12), dp(14), dp(12))
                isClickable = true; isFocusable = true
                setOnClickListener { AiChat.showSettings(a) }
            }
            val r1 = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            aiDot = View(a)
            r1.addView(aiDot, lp(dp(7), dp(7)).apply { marginEnd = dp(8) })
            aiProvider = txt("", 12f, t.text, m = true).apply { setSingleLine(); ellipsize = TextUtils.TruncateAt.END; textAlignment = View.TEXT_ALIGNMENT_VIEW_START }
            r1.addView(aiProvider, LinearLayout.LayoutParams(0, WRAP, 1f))
            aiState = txt("", 12f, t.green, m = true)
            r1.addView(aiState)
            card.addView(r1)
            aiMode = txt("", 12f, t.muted, m = true).apply { setPadding(0, dp(8), 0, 0) }
            card.addView(aiMode)
            val cardBox = FrameLayout(a).apply { setPadding(dp(12), dp(4), dp(12), dp(8)) }
            cardBox.addView(card, FrameLayout.LayoutParams(MATCH, WRAP))

            val col = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(8), 0, dp(12)) }
            col.addView(cardBox)
            col.addView(label("COMMANDS").apply { setPadding(dp(16), dp(10), dp(16), dp(6)) })
            col.addView(hair(t.line2), lp(MATCH, dp(1)))
            for ((cmd, desc, prompt) in commands) {
                val needsArg = cmd == "/new" || cmd == "/screen"
                col.addView(cmdRow(cmd, desc) { openChat(prompt, !needsArg) })
            }
            col.addView(label("HISTORY").apply { setPadding(dp(16), dp(22), dp(16), dp(6)) })
            col.addView(hair(t.line2), lp(MATCH, dp(1)))
            aiHistory = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
            col.addView(aiHistory, lp(MATCH, WRAP))
            return page(head, scrolling(col))
        }

        fun cmdRow(cmd: String, desc: String, onClick: () -> Unit): View {
            val row = LinearLayout(a).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(16), 0, dp(16), 0)
                background = AiChat.ripple(round(Color.TRANSPARENT, 0), 0f)
                isClickable = true; isFocusable = true
                setOnClickListener { onClick() }
            }
            row.addView(txt(cmd, 13.5f, t.amber, m = true), lp(dp(72), WRAP))
            row.addView(txt(desc, 13.5f, t.text).apply { setSingleLine(); ellipsize = TextUtils.TruncateAt.END }, LinearLayout.LayoutParams(0, WRAP, 1f))
            row.addView(icon("zl_ic_chevron_left", t.muted, 16))
            val box = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
            box.addView(row, lp(MATCH, dp(52)))
            box.addView(hair(), lp(MATCH, dp(1)))
            return box
        }

        fun refreshAiPage() {
            val ready = prefs.ready()
            aiDot.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(if (ready) t.green else t.red) }
            aiProvider.text = if (ready) prefs.providerLabel().lowercase() + " / " + prefs.effectiveModel().ifBlank { "—" } else "no api key"
            aiState.text = if (ready) "ready" else "setup"
            aiState.setTextColor(if (ready) t.green else t.red)
            aiMode.text = kv(
                Triple("mode", if (prefs.askBeforeEdit) "ask" else "auto", t.text),
                Triple("live-apply", if (prefs.liveApply) "on" else "off", if (prefs.liveApply) t.amber else t.muted),
                Triple("steps", "≤ ${AiChat.MAX_STEPS}", t.text)
            )
            aiHistory.removeAllViews()
            val recent = AiPlugin.history.filter { it.role == "user" && !AiAgent.isResults(it) }.takeLast(4).reversed()
            if (recent.isEmpty()) {
                aiHistory.addView(txt("لا توجد طلبات بعد. جرّب أحد الأوامر فوق.", 12.5f, t.muted).apply { setPadding(dp(16), dp(14), dp(16), 0) })
            }
            for (m in recent) {
                val row = LinearLayout(a).apply {
                    orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(16), 0, dp(16), 0)
                    background = AiChat.ripple(round(Color.TRANSPARENT, 0), 0f)
                    isClickable = true; isFocusable = true
                    setOnClickListener { openChat() }
                }
                row.addView(txt("›", 14f, t.muted, m = true), lp(dp(18), WRAP))
                row.addView(txt(m.content.trim().lineSequence().firstOrNull().orEmpty().take(90), 13f, t.text).apply {
                    setSingleLine(); ellipsize = TextUtils.TruncateAt.END
                }, LinearLayout.LayoutParams(0, WRAP, 1f))
                aiHistory.addView(row, lp(MATCH, dp(50)))
                aiHistory.addView(hair(), lp(MATCH, dp(1)))
            }
        }

        // -------------------------------------------------------------- page: tools
        fun toolsPage(): View {
            val head = header("zl_ic_tools", t.amber, "الأدوات", false)
            val col = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(8), 0, dp(16)) }
            col.addView(label("WORKSPACE").apply { setPadding(dp(16), dp(4), dp(16), dp(6)) })
            col.addView(hair(t.line2), lp(MATCH, dp(1)))
            col.addView(listRow("zl_ic_terminal", t.green, "الترمنال", "bash · gradle · git", true) { runAction(a, ACTION_TERMINAL) })
            col.addView(listRow("zl_ic_folder_open", t.icon, "فتح مجلد", "افتح مشروعا من التخزين", false) { runAction(a, ACTION_OPEN) })
            col.addView(listRow("zl_ic_git", t.amber, "استنساخ Git", "من رابط مستودع", false) { runAction(a, ACTION_CLONE) })
            col.addView(label("CONFIG").apply { setPadding(dp(16), dp(22), dp(16), dp(6)) })
            col.addView(hair(t.line2), lp(MATCH, dp(1)))
            col.addView(listRow("zl_ic_settings", t.icon, "الإعدادات", "المظهر والمحرر والبناء", false) { runAction(a, ACTION_PREFS) })
            col.addView(listRow("zl_ic_sparkle", t.amber, "إعدادات الذكاء", "المزوّد والمفتاح والموديل", false) { AiChat.showSettings(a) })
            col.addView(label("HELP").apply { setPadding(dp(16), dp(22), dp(16), dp(6)) })
            col.addView(hair(t.line2), lp(MATCH, dp(1)))
            col.addView(listRow("zl_ic_docs", t.icon, "الوثائق", "دليل الاستعمال", false) { runAction(a, ACTION_DOCS) })

            val info = LinearLayout(a).apply {
                orientation = LinearLayout.VERTICAL
                layoutDirection = View.LAYOUT_DIRECTION_LTR
                background = boxed(t.s1, 12)
                setPadding(dp(14), dp(12), dp(14), dp(12))
            }
            info.addView(txt(kv(Triple("projects", AiIde.projectsDir(a).path, t.muted)), 11.5f, t.amber, m = true))
            info.addView(txt(kv(Triple("license", "GPL-3.0 · based on AndroidIDE", t.muted)), 11.5f, t.amber, m = true).apply { setPadding(0, dp(4), 0, 0) })
            val box = FrameLayout(a).apply { setPadding(dp(16), dp(22), dp(16), 0) }
            box.addView(info, FrameLayout.LayoutParams(MATCH, WRAP))
            col.addView(box)
            return page(head, scrolling(col))
        }
    }
}
