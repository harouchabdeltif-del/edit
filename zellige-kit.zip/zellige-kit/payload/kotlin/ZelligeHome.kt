package com.itsaky.androidide.ai

import android.animation.LayoutTransition
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.text.format.DateUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.util.WeakHashMap

/**
 * الشاشة الرئيسية الجديدة (Zellige): بحث، بطاقة «تابع العمل»، بطاقة الذكاء، مشاريعك كبطاقات
 * (أيقونة، اسم، إصدار، package، توسيع)، زر «مشروع جديد»، وتنقّل سفلي: المشاريع / الذكاء / الأدوات.
 *
 * كتتركّب فوق شاشة AndroidIDE الأصلية (MainFragment) بلا ما نلمس كودها: الأزرار الأصلية (إنشاء مشروع،
 * فتح مجلد، استنساخ Git، الترمنال، الإعدادات…) كنشغّلوها من نفس الـ adapter الأصلي. إلا فشل أي شيء كتبقى الشاشة الأصلية.
 */
object ZelligeHome {

    private val homes = WeakHashMap<Activity, Home>()

    const val ACTION_CREATE = 0
    const val ACTION_OPEN = 1
    const val ACTION_CLONE = 2
    const val ACTION_TERMINAL = 3
    const val ACTION_PREFS = 4
    const val ACTION_DOCS = 6

    private fun idOf(a: Activity, name: String): Int = a.resources.getIdentifier(name, "id", a.packageName)

    /** يرجع true إلا تركّبت الشاشة الجديدة (وإلا كتبقى الأصلية). */
    fun attach(a: Activity): Boolean {
        return try {
            val old = homes[a]
            if (old != null && old.isAttached()) {
                old.refresh()
                return true
            }
            // الحاوية الأصلية (FrameLayout فيه MainFragment وقوالب المشاريع): نحط شاشتنا فوقها
            val main = a.findViewById<View>(idOf(a, "main")) ?: return false
            val host = main.parent as? FrameLayout ?: return false
            val h = Home(a, host, main)
            h.install()
            homes[a] = h
            true
        } catch (t: Throwable) { false }
    }

    /** يشغّل زر أصلي من الشاشة الأصلية (نفس الـ lambda اللي ربطها MainFragment). */
    fun runAction(a: Activity, id: Int): Boolean {
        return try {
            val rv = a.findViewById<View>(idOf(a, "actions")) ?: return false
            val adapter = rv.javaClass.getMethod("getAdapter").invoke(rv) ?: return false
            val list = adapter.javaClass.getMethod("getActions").invoke(adapter) as? List<*> ?: return false
            val item = list.firstOrNull { it != null && it.javaClass.getMethod("getId").invoke(it) == id } ?: return false
            val fn = item.javaClass.getMethod("getOnClick").invoke(item) ?: return false
            val fn2 = Class.forName("kotlin.jvm.functions.Function2")
            fn2.getMethod("invoke", Any::class.java, Any::class.java).invoke(fn, item, rv)
            true
        } catch (t: Throwable) {
            Toast.makeText(a, "تعذّر تشغيل الإجراء: " + (t.message ?: t.javaClass.simpleName), Toast.LENGTH_LONG).show()
            false
        }
    }

    // ------------------------------------------------------------------ data
    private class Info(
        val dir: File,
        val title: String,
        val folder: String,
        val version: String?,
        val appId: String?,
        val gradle: Boolean,
        val modified: Long,
        val icon: Bitmap?
    )

    private val buildFiles = listOf("build.gradle.kts", "build.gradle")
    private val reAppId = Regex("applicationId\\s*=?\\s*[\"']([^\"']+)[\"']")
    private val reNamespace = Regex("namespace\\s*=?\\s*[\"']([^\"']+)[\"']")
    private val reVName = Regex("versionName\\s*=?\\s*[\"']([^\"']+)[\"']")
    private val reVCode = Regex("versionCode\\s*=?\\s*(\\d+)")
    private val reLabel = Regex("<string\\s+name=\"app_name\"[^>]*>([^<]*)</string>")
    private val iconDirs = listOf(
        "mipmap-xxxhdpi", "mipmap-xxhdpi", "mipmap-xhdpi", "mipmap-hdpi", "mipmap-mdpi",
        "drawable-xxxhdpi", "drawable-xxhdpi", "drawable-xhdpi", "drawable"
    )

    private fun buildFileOf(dir: File): File? = buildFiles.map { File(dir, it) }.firstOrNull { it.isFile }

    private fun findAppModule(root: File): File? {
        File(root, "app").takeIf { buildFileOf(it) != null }?.let { return it }
        val subs = root.listFiles()?.filter { it.isDirectory && !it.name.startsWith(".") && it.name != "build" } ?: return null
        for (d in subs.sortedBy { it.name }.take(30)) {
            val bf = buildFileOf(d) ?: continue
            val txt = try { bf.readText().take(200_000) } catch (t: Throwable) { continue }
            if (txt.contains("com.android.application")) return d
        }
        return null
    }

    private fun decodeIcon(mod: File): Bitmap? {
        val res = File(mod, "src/main/res")
        for (dn in iconDirs) for (ext in listOf("png", "webp")) {
            val f = File(res, "$dn/ic_launcher.$ext")
            if (!f.isFile) continue
            try {
                val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(f.path, o)
                var s = 1
                while (o.outWidth / (s * 2) >= 160) s *= 2
                return BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s })
            } catch (t: Throwable) { /* نجرب أيقونة أخرى */ }
        }
        return null
    }

    private fun scan(dir: File): Info {
        val gradle = AiIde.isGradleProject(dir)
        var appId: String? = null
        var vName: String? = null
        var vCode: String? = null
        var label: String? = null
        var icon: Bitmap? = null
        if (gradle) {
            try {
                val mod = findAppModule(dir)
                if (mod != null) {
                    val txt = buildFileOf(mod)?.readText()?.take(200_000).orEmpty()
                    appId = reAppId.find(txt)?.groupValues?.get(1) ?: reNamespace.find(txt)?.groupValues?.get(1)
                    vName = reVName.find(txt)?.groupValues?.get(1)
                    vCode = reVCode.find(txt)?.groupValues?.get(1)
                    val strings = File(mod, "src/main/res/values/strings.xml")
                    if (strings.isFile) label = reLabel.find(strings.readText().take(100_000))?.groupValues?.get(1)?.trim()
                    icon = decodeIcon(mod)
                }
            } catch (t: Throwable) { /* معلومات اختيارية */ }
        }
        val version = when {
            vName != null && vCode != null -> "$vName ($vCode)"
            vName != null -> vName
            else -> null
        }
        val title = label?.takeIf { it.isNotBlank() && !it.startsWith("@") } ?: dir.name
        return Info(dir, title, dir.name, version, appId, gradle, dir.lastModified(), icon)
    }

    // ------------------------------------------------------------------ colours
    private fun blend(a: Int, b: Int, t: Float): Int {
        fun ch(x: Int, y: Int) = (x + (y - x) * t).toInt().coerceIn(0, 255)
        return Color.rgb(ch(Color.red(a), Color.red(b)), ch(Color.green(a), Color.green(b)), ch(Color.blue(a), Color.blue(b)))
    }

    private class Tone(val a: Activity) {
        private fun attr(names: List<String>, fb: Int): Int {
            for (n in names) {
                try {
                    val id = a.resources.getIdentifier(n, "attr", a.packageName)
                    if (id == 0) continue
                    val tv = TypedValue()
                    if (a.theme.resolveAttribute(id, tv, true) &&
                        tv.type >= TypedValue.TYPE_FIRST_COLOR_INT && tv.type <= TypedValue.TYPE_LAST_COLOR_INT
                    ) return tv.data
                } catch (t: Throwable) { /* اسم آخر */ }
            }
            return fb
        }

        val page = attr(listOf("colorSurface", "colorBackground"), Color.parseColor("#0F131C"))
        val dark = (Color.red(page) * 299 + Color.green(page) * 587 + Color.blue(page) * 114) / 1000 < 128
        val accent = attr(listOf("colorPrimary"), if (dark) Color.parseColor("#B8C4FF") else Color.parseColor("#3550C8"))
        val onAccent = attr(listOf("colorOnPrimary"), if (dark) Color.parseColor("#0B1F6E") else Color.WHITE)
        val box = attr(listOf("colorPrimaryContainer"), if (dark) Color.parseColor("#1B3FA3") else Color.parseColor("#DCE1FF"))
        val onBox = attr(listOf("colorOnPrimaryContainer"), if (dark) Color.parseColor("#DCE1FF") else Color.parseColor("#00164F"))
        val secBox = attr(listOf("colorSecondaryContainer"), if (dark) Color.parseColor("#3F4565") else Color.parseColor("#DFE1FA"))
        val onSecBox = attr(listOf("colorOnSecondaryContainer"), if (dark) Color.parseColor("#DDE1FB") else Color.parseColor("#171B33"))
        val gold = attr(listOf("colorTertiary"), if (dark) Color.parseColor("#F1C873") else Color.parseColor("#7B5800"))
        val text = attr(listOf("colorOnSurface"), if (dark) Color.parseColor("#E1E2EC") else Color.parseColor("#191B24"))
        val sub = attr(listOf("colorOnSurfaceVariant"), if (dark) Color.parseColor("#C4C7D6") else Color.parseColor("#444653"))
        val error = attr(listOf("colorError"), Color.parseColor("#BA1A1A"))
        val card = if (dark) blend(page, accent, 0.09f) else Color.WHITE
        val tile = if (dark) blend(page, Color.BLACK, 0.30f) else blend(card, accent, 0.07f)
        val line = blend(page, text, 0.11f)
        val navBg = if (dark) blend(page, accent, 0.10f) else Color.WHITE
    }

    private val avatar = listOf("#4C5FD5", "#1FA6A0", "#D99A1E", "#D2603F", "#8A5BD6", "#3FA66B")

    // ------------------------------------------------------------------ the screen
    private class Home(val a: Activity, val host: FrameLayout, val main: View) {

        val t = Tone(a)
        val prefs = AiPrefs(a)
        val rtl = a.resources.configuration.layoutDirection == View.LAYOUT_DIRECTION_RTL

        lateinit var frame: FrameLayout
        lateinit var listBox: LinearLayout
        lateinit var countView: TextView
        lateinit var sortLabel: TextView
        lateinit var resumeHolder: FrameLayout
        lateinit var emptyBox: LinearLayout
        lateinit var aiMeta: TextView
        lateinit var aiBody: LinearLayout
        val pages = mutableListOf<View>()
        val navItems = mutableListOf<Pair<FrameLayout, TextView>>()
        var cur = 0
        var all: List<Info> = emptyList()
        var filter = ""
        var sort = prefs.homeSort
        val expanded = HashSet<String>()
        var animateNext = true
        var token = 0

        fun dp(v: Int) = AiChat.dp(a, v)
        fun round(c: Int, r: Int) = AiChat.shape(c, dp(r).toFloat())
        fun outlined(c: Int, r: Int) = AiChat.outlined(c, dp(r).toFloat(), t.line, dp(1))
        fun ripple(c: Int, r: Int, stroke: Boolean = false): android.graphics.drawable.Drawable =
            AiChat.ripple(if (stroke) outlined(c, r) else round(c, r), dp(r).toFloat())

        fun isAttached(): Boolean = ::frame.isInitialized && frame.parent != null

        fun toast(s: String, long: Boolean = false) =
            Toast.makeText(a, s, if (long) Toast.LENGTH_LONG else Toast.LENGTH_SHORT).show()

        fun txt(s: String, sp: Float, color: Int, bold: Boolean = false, ltr: Boolean = false): TextView = TextView(a).apply {
            text = s; textSize = sp; setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
            textDirection = if (ltr) View.TEXT_DIRECTION_LTR else View.TEXT_DIRECTION_ANY_RTL
        }

        fun icon(name: String, tint: Int, size: Int, flip: Boolean = false): ImageView = ImageView(a).apply {
            setImageDrawable(AiChat.icon(a, "zl_ic_$name"))
            imageTintList = ColorStateList.valueOf(tint)
            if (flip && rtl) scaleX = -1f
            layoutParams = LinearLayout.LayoutParams(dp(size), dp(size))
        }

        fun lp(w: Int, h: Int) = LinearLayout.LayoutParams(w, h)
        val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
        val MATCH = ViewGroup.LayoutParams.MATCH_PARENT

        // -------------------------------------------------------------- install
        fun install() {
            frame = FrameLayout(a).apply {
                tag = "zl_home"
                setBackgroundColor(t.page)
                isClickable = true      // ما نخلّيوش اللمسات توصل للشاشة الأصلية اللي لتحت
            }
            val column = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
            val pageHost = FrameLayout(a)
            pages.add(projectsPage()); pages.add(aiPage()); pages.add(toolsPage())
            pages.forEachIndexed { i, p ->
                pageHost.addView(p, FrameLayout.LayoutParams(MATCH, MATCH))
                p.visibility = if (i == 0) View.VISIBLE else View.GONE
            }
            column.addView(pageHost, LinearLayout.LayoutParams(MATCH, 0, 1f))
            column.addView(bottomNav(), LinearLayout.LayoutParams(MATCH, WRAP))
            frame.addView(column, FrameLayout.LayoutParams(MATCH, MATCH))
            host.addView(frame, FrameLayout.LayoutParams(MATCH, MATCH))
            syncToolbar()
            refresh()
        }

        /**
         * شاشتنا كتبان فقط مع الشاشة الرئيسية الأصلية (كتتبع visibility ديالها)،
         * والـ Toolbar الأصلي كيتخبّى فيها (عندنا شريط البحث) وكيبان فشاشات القوالب.
         */
        fun syncToolbar() {
            val appbar = a.findViewById<View>(idOf(a, "appbar")) as? ViewGroup
            val toolbar = appbar?.getChildAt(0)
            val sync = {
                val onMain = main.visibility == View.VISIBLE
                val want = if (onMain) View.VISIBLE else View.GONE
                if (frame.visibility != want) frame.visibility = want
                val tb = if (onMain) View.GONE else View.VISIBLE
                if (toolbar != null && toolbar.visibility != tb) toolbar.visibility = tb
            }
            sync()
            a.window.decorView.viewTreeObserver.addOnGlobalLayoutListener { sync() }
        }

        fun refresh() {
            refreshResume()
            refreshAiPage()
            val my = ++token
            Thread {
                val infos = try {
                    AiIde.findProjects(a).take(200).map { scan(it) }
                } catch (t: Throwable) { emptyList() }
                a.runOnUiThread {
                    if (my == token && isAttached()) {
                        all = infos
                        animateNext = true
                        renderList()
                    }
                }
            }.start()
        }

        // -------------------------------------------------------------- bottom navigation
        fun bottomNav(): View {
            val bar = LinearLayout(a).apply {
                orientation = LinearLayout.VERTICAL
                setBackgroundColor(t.navBg)
            }
            bar.addView(View(a).apply { setBackgroundColor(t.line) }, lp(MATCH, dp(1)))
            val row = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(8), dp(10), dp(8), dp(12)) }
            val defs = listOf(Triple("projects", "المشاريع", 0), Triple("sparkle", "الذكاء", 1), Triple("tools", "الأدوات", 2))
            for ((ic, label, idx) in defs) {
                val ind = FrameLayout(a).apply { background = round(Color.TRANSPARENT, 16) }
                ind.addView(icon(ic, t.sub, 24).apply {
                    layoutParams = FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER)
                })
                val tv = txt(label, 12.5f, t.sub, bold = false).apply { gravity = Gravity.CENTER; setPadding(0, dp(4), 0, 0) }
                val item = LinearLayout(a).apply {
                    orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
                    isClickable = true; isFocusable = true
                    setOnClickListener { select(idx) }
                }
                item.addView(ind, lp(dp(64), dp(32)))
                item.addView(tv, lp(WRAP, WRAP))
                row.addView(item, LinearLayout.LayoutParams(0, WRAP, 1f))
                navItems.add(ind to tv)
            }
            bar.addView(row)
            updateNav()
            return bar
        }

        fun updateNav() {
            navItems.forEachIndexed { i, (ind, tv) ->
                val on = i == cur
                ind.background = round(if (on) t.secBox else Color.TRANSPARENT, 16)
                (ind.getChildAt(0) as? ImageView)?.imageTintList = ColorStateList.valueOf(if (on) t.onSecBox else t.sub)
                tv.setTextColor(if (on) t.text else t.sub)
                tv.typeface = if (on) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            }
        }

        fun select(i: Int) {
            if (i == cur) return
            val from = pages[cur]
            val to = pages[i]
            cur = i
            to.alpha = 0f
            to.visibility = View.VISIBLE
            to.animate().alpha(1f).setDuration(170).start()
            from.animate().alpha(0f).setDuration(120).withEndAction {
                if (pages[cur] !== from) from.visibility = View.GONE
            }.start()
            updateNav()
        }

        // -------------------------------------------------------------- page: projects
        fun projectsPage(): View {
            val page = FrameLayout(a)
            val col = LinearLayout(a).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(16), dp(10), dp(16), dp(150))
            }
            val scroll = ScrollView(a).apply {
                isVerticalScrollBarEnabled = false
                overScrollMode = View.OVER_SCROLL_NEVER
                isFillViewport = true
                addView(col, ViewGroup.LayoutParams(MATCH, WRAP))
            }
            col.addView(searchPill(), lp(MATCH, dp(56)))

            resumeHolder = FrameLayout(a)
            col.addView(resumeHolder, lp(MATCH, WRAP).apply { topMargin = dp(12) })
            col.addView(aiTeaser(), lp(MATCH, WRAP).apply { topMargin = dp(10) })

            // العنوان + الفرز
            val head = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            head.addView(txt("المشاريع", 30f, t.text, bold = true), LinearLayout.LayoutParams(WRAP, WRAP))
            countView = txt("0", 12.5f, t.onSecBox, bold = true).apply {
                gravity = Gravity.CENTER
                background = round(t.secBox, 12)
                setPadding(dp(10), dp(2), dp(10), dp(2))
            }
            head.addView(countView, lp(WRAP, WRAP).apply { marginStart = dp(10) })
            head.addView(View(a), LinearLayout.LayoutParams(0, 1, 1f))
            val sortBtn = LinearLayout(a).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                background = ripple(t.card, 20, stroke = true)
                setPadding(dp(12), dp(8), dp(14), dp(8))
                isClickable = true; isFocusable = true
                setOnClickListener {
                    sort = if (sort == "name") "recent" else "name"
                    prefs.homeSort = sort
                    animateNext = false
                    renderList()
                }
            }
            sortBtn.addView(icon("sort", t.accent, 18))
            sortLabel = txt("", 13f, t.text, bold = true).apply { setPadding(dp(6), 0, 0, 0) }
            sortBtn.addView(sortLabel)
            head.addView(sortBtn, lp(WRAP, WRAP))
            col.addView(head, lp(MATCH, WRAP).apply { topMargin = dp(22); bottomMargin = dp(12) })

            listBox = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
            col.addView(listBox, lp(MATCH, WRAP))
            emptyBox = emptyState()
            col.addView(emptyBox, lp(MATCH, WRAP))
            page.addView(scroll, FrameLayout.LayoutParams(MATCH, MATCH))

            // الأزرار العائمة
            val fabs = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.END }
            val aiFab = FrameLayout(a).apply {
                background = ripple(t.secBox, 28)
                elevation = dp(4).toFloat()
                isClickable = true; isFocusable = true
                contentDescription = "الذكاء"
                setOnClickListener { openChat() }
                addView(icon("sparkle", t.onSecBox, 24).apply { layoutParams = FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER) })
            }
            fabs.addView(aiFab, lp(dp(52), dp(52)).apply { bottomMargin = dp(12); marginEnd = dp(2) })
            val extLabel = txt("مشروع جديد", 16f, t.onBox, bold = true).apply { setPadding(dp(10), 0, 0, 0) }
            val ext = LinearLayout(a).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                background = ripple(t.box, 20)
                elevation = dp(6).toFloat()
                setPadding(dp(20), 0, dp(24), 0)
                isClickable = true; isFocusable = true
                setOnClickListener { runAction(a, ACTION_CREATE) }
                addView(icon("add", t.onBox, 24))
                addView(extLabel)
            }
            fabs.addView(ext, lp(WRAP, dp(60)))
            page.addView(fabs, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.END).apply {
                bottomMargin = dp(18); marginEnd = dp(16); marginStart = dp(16)
            })
            scroll.setOnScrollChangeListener { _, _, y, _, oy ->
                val want = if (y > oy + 6) View.GONE else if (y < oy - 6) View.VISIBLE else extLabel.visibility
                if (extLabel.visibility != want) {
                    extLabel.visibility = want
                    ext.setPadding(dp(if (want == View.VISIBLE) 20 else 18), 0, dp(if (want == View.VISIBLE) 24 else 18), 0)
                }
            }
            return page
        }

        fun searchPill(): View {
            val row = LinearLayout(a).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                background = round(t.card, 28)
                setPadding(dp(16), 0, dp(8), 0)
            }
            row.addView(icon("star8", t.accent, 26).apply {
                isClickable = true; isFocusable = true
                setOnClickListener { select(2) }
            })
            val input = EditText(a).apply {
                hint = "ابحث في المشاريع…"
                setHintTextColor(t.sub); setTextColor(t.text); textSize = 15.5f
                background = null
                setSingleLine()
                inputType = InputType.TYPE_CLASS_TEXT
                imeOptions = EditorInfo.IME_ACTION_SEARCH
                textDirection = View.TEXT_DIRECTION_ANY_RTL
                setPadding(dp(12), 0, dp(8), 0)
            }
            val trailing = ImageView(a).apply {
                setImageDrawable(AiChat.icon(a, "zl_ic_search"))
                imageTintList = ColorStateList.valueOf(t.sub)
                setPadding(dp(10), dp(10), dp(10), dp(10))
                isClickable = true; isFocusable = true
                setOnClickListener { if (input.text.isNotEmpty()) input.text.clear() }
            }
            input.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, af: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {
                    filter = s?.toString().orEmpty().trim()
                    trailing.setImageDrawable(AiChat.icon(a, if (filter.isEmpty()) "zl_ic_search" else "ic_ai_close"))
                    animateNext = false
                    renderList()
                }
                override fun afterTextChanged(s: Editable?) {}
            })
            row.addView(input, LinearLayout.LayoutParams(0, MATCH, 1f))
            row.addView(trailing, lp(dp(44), dp(44)))
            return row
        }

        // -------------------------------------------------------------- resume + AI teaser
        fun bigCard(
            iconName: String, title: String, subtitle: String, trailing: String?,
            tileColor: Int, tint: Int, onClick: () -> Unit
        ): View {
            val row = LinearLayout(a).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                background = ripple(t.card, 24)
                setPadding(dp(14), dp(14), dp(16), dp(14))
                isClickable = true; isFocusable = true
                setOnClickListener { onClick() }
            }
            val tile = FrameLayout(a).apply { background = round(tileColor, 18) }
            tile.addView(icon(iconName, tint, 28).apply { layoutParams = FrameLayout.LayoutParams(dp(28), dp(28), Gravity.CENTER) })
            row.addView(tile, lp(dp(60), dp(60)))
            val col = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
            col.addView(txt(title, 17f, t.text, bold = true).apply { setSingleLine(); ellipsize = TextUtils.TruncateAt.END })
            col.addView(txt(subtitle, 13.5f, t.sub).apply { maxLines = 2; ellipsize = TextUtils.TruncateAt.END; setPadding(0, dp(2), 0, 0) })
            row.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(14); marginEnd = dp(8) })
            if (trailing != null) row.addView(icon(trailing, t.sub, 24, flip = true))
            return row
        }

        fun refreshResume() {
            resumeHolder.removeAllViews()
            val last = prefs.lastOpened.trim()
            val dir = if (last.isNotEmpty()) File(last).takeIf { it.isDirectory } else null
            val card = if (dir != null) {
                bigCard("history", "تابع من حيث توقّفت", dir.name + " · " + DateUtils.getRelativeTimeSpanString(dir.lastModified()),
                    "chevron_right", t.tile, t.accent) { openProject(dir) }
            } else {
                bigCard("folder_open", "افتح مشروعا موجودا", "اختر مجلد مشروع من التخزين", "chevron_right", t.tile, t.accent) {
                    runAction(a, ACTION_OPEN)
                }
            }
            resumeHolder.addView(card, FrameLayout.LayoutParams(MATCH, WRAP))
        }

        fun aiTeaser(): View {
            val row = LinearLayout(a).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                background = ripple(blend(t.card, t.box, if (t.dark) 0.55f else 0.45f), 24)
                setPadding(dp(14), dp(12), dp(16), dp(12))
                isClickable = true; isFocusable = true
                setOnClickListener { openChat() }
            }
            val tile = FrameLayout(a).apply { background = round(t.box, 16) }
            tile.addView(icon("sparkle", t.onBox, 24).apply { layoutParams = FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER) })
            row.addView(tile, lp(dp(48), dp(48)))
            val col = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
            col.addView(txt("اطلب من الذكاء", 16f, t.text, bold = true))
            col.addView(txt("قل ما تريد وسيُنفَّذ مباشرة داخل مشروعك، مثلا «أنشئ تطبيق ملاحظات»", 12.5f, t.sub).apply {
                maxLines = 2; ellipsize = TextUtils.TruncateAt.END; setPadding(0, dp(2), 0, 0)
            })
            row.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(12); marginEnd = dp(8) })
            row.addView(icon("chevron_right", t.sub, 22, flip = true))
            return row
        }

        // -------------------------------------------------------------- project list
        fun emptyState(): LinearLayout {
            val col = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(0, dp(28), 0, dp(10)) }
            val tile = FrameLayout(a).apply { background = round(t.card, 36) }
            tile.addView(icon("star8", t.accent, 44).apply { layoutParams = FrameLayout.LayoutParams(dp(44), dp(44), Gravity.CENTER) })
            col.addView(tile, lp(dp(96), dp(96)))
            col.addView(txt("لا توجد مشاريع هنا بعد", 18f, t.text, bold = true).apply { setPadding(0, dp(16), 0, 0) })
            col.addView(txt("أنشئ مشروعا جديدا، أو افتح مجلدا موجودا، أو اطلب من الذكاء أن يبنيه لك.", 13.5f, t.sub).apply {
                gravity = Gravity.CENTER; setPadding(dp(24), dp(6), dp(24), 0)
            })
            col.visibility = View.GONE
            return col
        }

        fun renderList() {
            listBox.removeAllViews()
            val q = filter.lowercase()
            var items = all.filter {
                q.isEmpty() || it.title.lowercase().contains(q) || it.folder.lowercase().contains(q) ||
                    (it.appId?.lowercase()?.contains(q) == true)
            }
            items = if (sort == "name") items.sortedBy { it.title.lowercase() } else items.sortedByDescending { it.modified }
            sortLabel.text = if (sort == "name") "A–Z" else "الأحدث"
            countView.text = items.size.toString()
            emptyBox.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
            (emptyBox.getChildAt(1) as? TextView)?.text =
                if (all.isEmpty()) "لا توجد مشاريع هنا بعد" else "ما لقيت مشروعا يطابق «$filter»"
            items.forEachIndexed { i, info ->
                val c = projectCard(info)
                listBox.addView(c, lp(MATCH, WRAP).apply { bottomMargin = dp(12) })
                if (animateNext) {
                    c.alpha = 0f
                    c.translationY = dp(14).toFloat()
                    c.animate().alpha(1f).translationY(0f).setStartDelay((i * 35L).coerceAtMost(350L)).setDuration(220).start()
                }
            }
            animateNext = false
        }

        fun projectCard(info: Info): View {
            val r = 24
            val card = LinearLayout(a).apply {
                orientation = LinearLayout.VERTICAL
                background = ripple(t.card, r)
                layoutTransition = LayoutTransition().apply { enableTransitionType(LayoutTransition.CHANGING) }
            }
            val open = expanded.contains(info.dir.path)

            // الصف الرئيسي
            val head = LinearLayout(a).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(14), dp(14), dp(6), dp(14))
                isClickable = true; isFocusable = true
                setOnClickListener { openProject(info.dir) }
            }
            head.addView(avatarTile(info), lp(dp(64), dp(64)))
            val col = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
            col.addView(txt(info.title, 17.5f, t.text, bold = true).apply { setSingleLine(); ellipsize = TextUtils.TruncateAt.END })
            val l2 = buildList {
                if (info.title != info.folder) add(info.folder)
                if (info.version != null) add("v" + info.version)
                if (!info.gradle) add("مجلد")
            }.joinToString("  ·  ")
            if (l2.isNotEmpty()) col.addView(txt(l2, 13.5f, t.sub).apply { setSingleLine(); ellipsize = TextUtils.TruncateAt.END; setPadding(0, dp(2), 0, 0) })
            if (info.appId != null) col.addView(txt(info.appId, 13f, t.sub, ltr = true).apply { setSingleLine(); ellipsize = TextUtils.TruncateAt.MIDDLE; setPadding(0, dp(1), 0, 0) })
            head.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(14); marginEnd = dp(4) })

            val chev = icon("chevron_down", t.sub, 24).apply { rotation = if (open) 180f else 0f }
            val chevBox = FrameLayout(a).apply {
                isClickable = true; isFocusable = true
                background = AiChat.ripple(round(Color.TRANSPARENT, 22), dp(22).toFloat())
                addView(chev, FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER))
            }
            head.addView(chevBox, lp(dp(44), dp(44)))
            card.addView(head)

            // التفاصيل
            val details = LinearLayout(a).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(16), 0, dp(16), dp(16))
                visibility = if (open) View.VISIBLE else View.GONE
            }
            details.addView(View(a).apply { setBackgroundColor(t.line) }, lp(MATCH, dp(1)))
            details.addView(txt(info.dir.path, 12.5f, t.sub, ltr = true).apply {
                setTextIsSelectable(true); setPadding(0, dp(12), 0, 0)
            })
            val meta = (if (info.gradle) "مشروع Gradle" else "مجلد") + "  ·  آخر تعديل " + DateUtils.getRelativeTimeSpanString(info.modified)
            details.addView(txt(meta, 12.5f, t.sub).apply { setPadding(0, dp(4), 0, dp(12)) })
            val acts = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL }
            fun pill(label: String, ic: String, kind: Int, f: () -> Unit) {
                val bg = when (kind) { 1 -> t.box; else -> t.tile }
                val fg = when (kind) { 1 -> t.onBox; 2 -> t.error; else -> t.text }
                acts.addView(LinearLayout(a).apply {
                    orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
                    background = ripple(bg, 20)
                    isClickable = true; isFocusable = true
                    setOnClickListener { f() }
                    addView(icon(ic, fg, 18))
                    addView(txt(label, 13f, fg, bold = true).apply { setPadding(dp(6), 0, 0, 0); setSingleLine() })
                }, LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginEnd = dp(6) })
            }
            pill("فتح", "open", 1) { openProject(info.dir) }
            pill("الذكاء", "sparkle", 0) {
                AiIde.remember(a, info.dir)
                toast("المشروع النشط للذكاء: " + info.title)
                openChat()
            }
            pill("نسخ", "copy", 0) { copyPath(info.dir) }
            pill("حذف", "delete", 2) { confirmDelete(info) }
            details.addView(acts)
            card.addView(details)

            val toggle = {
                val show = details.visibility != View.VISIBLE
                details.visibility = if (show) View.VISIBLE else View.GONE
                chev.animate().rotation(if (show) 180f else 0f).setDuration(200).start()
                if (show) expanded.add(info.dir.path) else expanded.remove(info.dir.path)
            }
            chevBox.setOnClickListener { toggle() }
            head.setOnLongClickListener { toggle(); true }
            return card
        }

        fun avatarTile(info: Info): View {
            val tile = FrameLayout(a)
            val seed = info.title.lowercase().hashCode()
            val base = Color.parseColor(avatar[Math.floorMod(seed, avatar.size)])
            val bg = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(base, blend(base, Color.BLACK, 0.35f))).apply {
                cornerRadius = dp(18).toFloat()
            }
            if (info.icon != null) {
                tile.background = round(t.tile, 18)
                tile.addView(ImageView(a).apply {
                    setImageBitmap(info.icon)
                    scaleType = ImageView.ScaleType.CENTER_CROP
                    setPadding(dp(6), dp(6), dp(6), dp(6))
                }, FrameLayout.LayoutParams(MATCH, MATCH))
            } else {
                tile.background = bg
                val ch = info.title.firstOrNull { it.isLetterOrDigit() }?.uppercaseChar()?.toString() ?: "؟"
                tile.addView(txt(ch, 28f, Color.WHITE, bold = true).apply { gravity = Gravity.CENTER },
                    FrameLayout.LayoutParams(MATCH, MATCH))
            }
            tile.outlineProvider = ViewOutlineProvider.BACKGROUND
            tile.clipToOutline = true
            return tile
        }

        fun openProject(dir: File) {
            val err = try { AiIde.openProject(a, dir) } catch (t: Throwable) { t.message ?: "خطأ" }
            if (err != null) toast(err, true)
        }

        fun copyPath(dir: File) {
            try {
                val cm = a.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("path", dir.path))
                toast("تم نسخ المسار")
            } catch (t: Throwable) { toast("تعذّر النسخ", true) }
        }

        fun confirmDelete(info: Info) {
            AlertDialog.Builder(a)
                .setTitle("حذف «" + info.title + "»؟")
                .setMessage("سيُحذف المجلد نهائيا:\n" + info.dir.path)
                .setPositiveButton("حذف") { _, _ ->
                    Thread {
                        val ok = info.dir.deleteRecursively()
                        a.runOnUiThread {
                            toast(if (ok) "تم الحذف" else "تعذّر الحذف", !ok)
                            expanded.remove(info.dir.path)
                            refresh()
                        }
                    }.start()
                }
                .setNegativeButton("إلغاء", null)
                .show()
        }

        // -------------------------------------------------------------- page: AI
        fun openChat(prompt: String? = null, send: Boolean = false) {
            AiChat.open(a, prompt, send)
        }

        fun pageScaffold(title: String, subtitle: String): Pair<View, LinearLayout> {
            val col = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(18), dp(16), dp(32)) }
            col.addView(txt(title, 30f, t.text, bold = true))
            col.addView(txt(subtitle, 14f, t.sub).apply { setPadding(0, dp(4), 0, dp(16)) })
            val scroll = ScrollView(a).apply {
                isVerticalScrollBarEnabled = false
                overScrollMode = View.OVER_SCROLL_NEVER
                addView(col, ViewGroup.LayoutParams(MATCH, WRAP))
            }
            return scroll to col
        }

        fun sectionTitle(s: String) = txt(s, 13f, t.sub, bold = true).apply { setPadding(dp(4), dp(20), dp(4), dp(8)) }

        /** شبكة بعمودين من البطاقات الصغيرة. */
        fun grid(items: List<Triple<String, String, Pair<String, () -> Unit>>>): View {
            val box = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
            items.chunked(2).forEach { pair ->
                val row = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL }
                pair.forEachIndexed { i, (title, hint, ic) ->
                    val cell = LinearLayout(a).apply {
                        orientation = LinearLayout.VERTICAL
                        background = ripple(t.card, 22)
                        setPadding(dp(16), dp(16), dp(16), dp(16))
                        isClickable = true; isFocusable = true
                        setOnClickListener { ic.second() }
                    }
                    val tile = FrameLayout(a).apply { background = round(t.tile, 14) }
                    tile.addView(icon(ic.first, t.accent, 22).apply { layoutParams = FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER) })
                    cell.addView(tile, lp(dp(44), dp(44)))
                    cell.addView(txt(title, 15.5f, t.text, bold = true).apply { setPadding(0, dp(12), 0, 0); setSingleLine() })
                    cell.addView(txt(hint, 12.5f, t.sub).apply { setPadding(0, dp(2), 0, 0); maxLines = 2; ellipsize = TextUtils.TruncateAt.END })
                    row.addView(cell, LinearLayout.LayoutParams(0, WRAP, 1f).apply {
                        if (i == 0) marginEnd = dp(5) else marginStart = dp(5)
                    })
                }
                if (pair.size == 1) row.addView(View(a), LinearLayout.LayoutParams(0, 1, 1f))
                box.addView(row, lp(MATCH, WRAP).apply { bottomMargin = dp(10) })
            }
            return box
        }

        fun aiPage(): View {
            val (scroll, col) = pageScaffold("الذكاء", "وكيل برمجي ينفّذ داخل التطبيق: يفتح الملفات ويكتب فيها قدامك")
            val hero = LinearLayout(a).apply {
                orientation = LinearLayout.VERTICAL
                background = ripple(blend(t.card, t.box, if (t.dark) 0.6f else 0.5f), 28)
                setPadding(dp(20), dp(20), dp(20), dp(20))
            }
            val row = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val tile = FrameLayout(a).apply { background = round(t.box, 20) }
            tile.addView(icon("sparkle", t.onBox, 34).apply { layoutParams = FrameLayout.LayoutParams(dp(34), dp(34), Gravity.CENTER) })
            row.addView(tile, lp(dp(64), dp(64)))
            val c = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
            c.addView(txt("وكيل Zellige", 20f, t.text, bold = true))
            aiMeta = txt("", 13f, t.sub, ltr = true).apply { setSingleLine(); ellipsize = TextUtils.TruncateAt.END; setPadding(0, dp(2), 0, 0) }
            c.addView(aiMeta)
            row.addView(c, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(14) })
            hero.addView(row)
            val btns = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(16), 0, 0) }
            fun hb(label: String, filled: Boolean, f: () -> Unit) {
                btns.addView(txt(label, 14f, if (filled) t.onAccent else t.text, bold = true).apply {
                    gravity = Gravity.CENTER
                    background = ripple(if (filled) t.accent else t.tile, 22)
                    isClickable = true; isFocusable = true
                    setOnClickListener { f() }
                }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(8) })
            }
            hb("فتح الشات", true) { openChat() }
            hb("الإعدادات", false) { AiChat.showSettings(a) }
            hero.addView(btns)
            col.addView(hero, lp(MATCH, WRAP))

            col.addView(sectionTitle("ابدأ بسرعة"))
            fun q(prompt: String, send: Boolean) = { openChat(prompt, send) }
            col.addView(grid(listOf(
                Triple("تطبيق جديد", "مشروع كامل من فكرة واحدة", "add" to q("أنشئ مشروع أندرويد جديد باسم ", false)),
                Triple("شاشة جديدة", "واجهة + Activity مسجّلة", "projects" to q("أضف شاشة جديدة للمشروع النشط: ", false)),
                Triple("أصلح الأخطاء", "يفحص ويطبّق الإصلاح", "bug" to q("افحص المشروع النشط وأصلح الأخطاء الواضحة (imports، manifest، dependencies) وطبّق الإصلاح مباشرة.", true)),
                Triple("اشرح المشروع", "ملخص سريع للهيكل", "info" to q("اشرح لي هيكل المشروع النشط وملفاته الأساسية باختصار.", true)),
                Triple("حسّن الواجهة", "Material 3 أجمل", "palette" to q("حسّن تصميم شاشات المشروع النشط بـ Material 3 وطبّق التعديل مباشرة.", true)),
                Triple("اختبارات", "unit tests جاهزة", "bolt" to q("اكتب unit tests مناسبة للمشروع النشط وأنشئها فأماكنها الصحيحة.", true))
            )))

            col.addView(sectionTitle("آخر ما طلبته"))
            aiBody = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
            col.addView(aiBody, lp(MATCH, WRAP))
            return scroll
        }

        fun refreshAiPage() {
            aiMeta.text = if (prefs.ready()) prefs.providerLabel() + " · " + prefs.effectiveModel().ifBlank { "اختر موديل" }
            else "ضع مفتاح API لتفعيل الذكاء"
            aiBody.removeAllViews()
            val recent = AiPlugin.history.filter { it.role == "user" && !AiAgent.isResults(it) }.takeLast(3).reversed()
            if (recent.isEmpty()) {
                aiBody.addView(txt("لا توجد طلبات بعد. جرّب إحدى البطاقات أعلاه.", 13.5f, t.sub).apply { setPadding(dp(4), 0, 0, 0) })
            }
            for (m in recent) {
                aiBody.addView(txt(m.content.trim().lineSequence().firstOrNull().orEmpty().take(90), 14f, t.text).apply {
                    background = ripple(t.card, 18)
                    setPadding(dp(16), dp(14), dp(16), dp(14))
                    setSingleLine(); ellipsize = TextUtils.TruncateAt.END
                    isClickable = true; isFocusable = true
                    setOnClickListener { openChat() }
                }, lp(MATCH, WRAP).apply { bottomMargin = dp(8) })
            }
        }

        // -------------------------------------------------------------- page: tools
        fun toolsPage(): View {
            val (scroll, col) = pageScaffold("الأدوات", "كل ما تحتاجه خارج المحرر")
            col.addView(grid(listOf(
                Triple("الترمنال", "bash و Gradle و Git", "terminal" to { runAction(a, ACTION_TERMINAL); Unit }),
                Triple("فتح مجلد", "افتح مشروعا من التخزين", "folder_open" to { runAction(a, ACTION_OPEN); Unit }),
                Triple("استنساخ Git", "من رابط مستودع", "git" to { runAction(a, ACTION_CLONE); Unit }),
                Triple("الإعدادات", "المظهر والمحرر والبناء", "settings" to { runAction(a, ACTION_PREFS); Unit }),
                Triple("الوثائق", "دليل الاستعمال", "docs" to { runAction(a, ACTION_DOCS); Unit }),
                Triple("إعدادات الذكاء", "المزوّد والمفتاح والموديل", "sparkle" to { AiChat.showSettings(a) })
            )))
            val about = txt(
                "Zellige مبني على AndroidIDE (ترخيص GPL-3.0). الشيفرة المصدرية متاحة لكل من يحصل على نسخة من التطبيق.",
                12.5f, t.sub
            ).apply { setPadding(dp(8), dp(24), dp(8), 0); gravity = Gravity.CENTER }
            col.addView(about)
            return scroll
        }
    }
}
