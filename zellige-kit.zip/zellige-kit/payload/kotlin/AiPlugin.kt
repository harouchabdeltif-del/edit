package com.itsaky.androidide.ai

import android.app.Activity
import android.app.Application
import android.content.Context
import android.content.res.ColorStateList
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.graphics.Rect
import android.widget.FrameLayout
import com.google.android.material.floatingactionbutton.FloatingActionButton
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.CopyOnWriteArrayList
import kotlin.math.abs

/** نقطة الدخول: كتتسجل مرة وحدة من Application.onCreate وكتركّب شريط الذكاء فشاشة المحرر (والزر العائم كاحتياط). */
object AiPlugin {

    private const val MAX_HISTORY = 80

    @Volatile private var installed = false
    val history: MutableList<AiClient.Msg> = CopyOnWriteArrayList()

    @JvmStatic
    fun install(app: Application) {
        if (installed) return
        installed = true
        load(app)
        runCatching { AiTrack.init(app) }
        runCatching { TerminalChrome.prepare(app) }
        app.registerActivityLifecycleCallbacks(object : Application.ActivityLifecycleCallbacks {
            override fun onActivityResumed(a: Activity) {
                val n = a.javaClass.simpleName
                if (n.contains("Editor")) {
                    runCatching { AiIde.onEditorResumed(a) }
                    // شريط الذكاء تحت تبويبات المحرر (Console)، وإلا الزر العائم القديم
                    if (!EditorChrome.install(a)) attachFab(a)
                    // هيكل C5: شريط علوي، تبويبات، شاشة فارغة، شريط سفلي + حالة (كل خطوة معزولة)
                    runCatching { EditorShell.install(a) }
                    runCatching { SidebarChrome.install(a) }
                } else if (n.contains("Terminal")) {
                    runCatching { TerminalChrome.install(a) }
                } else if (n == "PreferencesActivity") {
                    runCatching { SettingsChrome.install(a) }
                } else if (n == "MainActivity") {
                    runCatching { NewProjectChrome.install(a) }
                    // الشاشة الرئيسية الجديدة (فيها زر الذكاء)، وإلا نرجعو للزر العائم القديم
                    if (!ZelligeHome.attach(a)) attachFab(a)
                }
            }
            override fun onActivityCreated(a: Activity, s: Bundle?) {
                if (s == null && a.javaClass.simpleName == "MainActivity") runCatching { AiIde.maybeAutoOpen(a) }
            }
            override fun onActivityStarted(a: Activity) {}
            override fun onActivityPaused(a: Activity) {
                val pn = a.javaClass.simpleName
                if (pn.contains("Editor")) { EditorChrome.stop(); EditorShell.stop(); SidebarChrome.stop() }
                else if (pn.contains("Terminal")) TerminalChrome.stop()
                else if (pn == "PreferencesActivity") SettingsChrome.stop()
                else if (pn == "MainActivity") NewProjectChrome.stop()
            }
            override fun onActivityStopped(a: Activity) {}
            override fun onActivitySaveInstanceState(a: Activity, o: Bundle) {}
            override fun onActivityDestroyed(a: Activity) {
                if (a.javaClass.simpleName.contains("Editor")) { EditorChrome.destroyed(a); EditorShell.destroyed(a); SidebarChrome.destroyed(a) }
                else if (a.javaClass.simpleName.contains("Terminal")) TerminalChrome.destroyed(a)
                else if (a.javaClass.simpleName == "PreferencesActivity") SettingsChrome.destroyed(a)
                else if (a.javaClass.simpleName == "MainActivity") { ZelligeHome.destroyed(a); NewProjectChrome.destroyed(a) }
            }
        })
    }

    // ------------------------------------------------------------ history persistence
    fun load(ctx: Context) {
        try {
            val raw = AiPrefs(ctx).history
            if (raw.isBlank()) return
            val arr = JSONArray(raw)
            history.clear()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                history.add(AiClient.Msg(o.getString("role"), o.getString("content")))
            }
        } catch (t: Throwable) { /* سجل تالف: نتجاهله */ }
    }

    fun save(ctx: Context) {
        try {
            while (history.size > MAX_HISTORY) history.removeAt(0)
            val arr = JSONArray()
            history.forEach { arr.put(JSONObject().put("role", it.role).put("content", it.content)) }
            AiPrefs(ctx).history = arr.toString()
        } catch (t: Throwable) { /* ما نكسرو التطبيق بسبب الحفظ */ }
    }

    // ------------------------------------------------------------ floating button
    private fun attachFab(a: Activity) {
        val content = a.findViewById<ViewGroup>(android.R.id.content) ?: return
        if (content.findViewWithTag<View>("ai_fab") != null) return
        try {
            val d = a.resources.displayMetrics.density
            val st = AiChat.fabStyle(a)
            // FloatingActionButton من Material: يأخذ شكل وظلال وحركة التطبيق تلقائيا
            val fab = FloatingActionButton(a).apply {
                tag = "ai_fab"
                contentDescription = "مساعد الذكاء الاصطناعي"
                backgroundTintList = ColorStateList.valueOf(st[0])
                imageTintList = ColorStateList.valueOf(st[1])
                setImageDrawable(AiChat.icon(a, "ic_ai_sparkle"))
            }
            val lp = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM or Gravity.END
            ).apply {
                bottomMargin = (110 * d).toInt()
                marginEnd = (16 * d).toInt()
            }
            content.addView(fab, lp)

            // لو كاين FAB آخر ظاهر فالشاشة (مثل أزرار لوحة السجلات) نخبّيو الزر ديالنا باش ما يتداخلوش
            val check = Runnable {
                val hide = otherFabOnScreen(content, fab)
                val want = if (hide) View.GONE else View.VISIBLE
                if (fab.visibility != want) fab.visibility = want
            }
            content.viewTreeObserver.addOnGlobalLayoutListener {
                content.removeCallbacks(check)
                content.postDelayed(check, 120)
            }

            // سحب الزر + ضغطة قصيرة تفتح الشات + يلصق مع أقرب حافة
            var sx = 0f; var sy = 0f; var tx = 0f; var ty = 0f; var moved = false
            fab.setOnTouchListener { v, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        sx = e.rawX; sy = e.rawY; tx = v.translationX; ty = v.translationY; moved = false
                        v.animate().scaleX(0.92f).scaleY(0.92f).setDuration(80).start()
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val mx = e.rawX - sx; val my = e.rawY - sy
                        if (abs(mx) > 12 * d || abs(my) > 12 * d) moved = true
                        if (moved) { v.translationX = tx + mx; v.translationY = ty + my }
                        true
                    }
                    MotionEvent.ACTION_UP -> {
                        v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                        if (!moved) {
                            AiChat.show(a)
                        } else {
                            val pw = content.width.toFloat()
                            val ph = content.height.toFloat()
                            val left = v.left.toFloat()
                            val top = v.top.toFloat()
                            val cx = left + v.translationX + v.width / 2f
                            val edge = 8 * d
                            val targetX = if (cx < pw / 2f) edge else pw - v.width - edge
                            val targetY = (top + v.translationY).coerceIn(edge, (ph - v.height - edge).coerceAtLeast(edge))
                            v.animate().translationX(targetX - left).translationY(targetY - top).setDuration(180).start()
                        }
                        true
                    }
                    MotionEvent.ACTION_CANCEL -> {
                        v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                        true
                    }
                    else -> false
                }
            }
        } catch (t: Throwable) { /* ما نكسرو شاشة المحرر إلا وقع مشكل فالـ theme */ }
    }

    private fun otherFabOnScreen(x: View, self: View): Boolean {
        if (x === self || x.visibility != View.VISIBLE) return false
        if (x.javaClass.name.contains("FloatingActionButton") && x.isShown && x.getGlobalVisibleRect(Rect())) return true
        if (x is ViewGroup) for (i in 0 until x.childCount) if (otherFabOnScreen(x.getChildAt(i), self)) return true
        return false
    }
}
