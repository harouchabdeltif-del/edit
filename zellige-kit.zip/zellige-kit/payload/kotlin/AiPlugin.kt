package com.itsaky.androidide.ai

import android.app.Activity
import android.app.Application
import android.content.Context
import android.content.res.ColorStateList
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.graphics.Rect
import android.widget.FrameLayout
import com.google.android.material.floatingactionbutton.FloatingActionButton
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.CopyOnWriteArrayList
import kotlin.math.abs

/** نقطة الدخول: كتتسجل مرة وحدة من Application.onCreate وكتركّب شريط الذكاء فشاشة المحرر (والزر العائم كاحتياط). */
object AiPlugin {

    private const val MAX_HISTORY = 80

    @Volatile private var installed = false
    val history: MutableList<AiClient.Msg> = CopyOnWriteArrayList()

    @JvmStatic
    fun install(app: Application) {
        if (installed) return
        installed = true
        load(app)
        runCatching { AiTrack.init(app) }
        runCatching { TerminalChrome.prepare(app) }
        app.registerActivityLifecycleCallbacks(object : Application.ActivityLifecycleCallbacks {
            override fun onActivityResumed(a: Activity) {
                val n = a.javaClass.simpleName
                if (n.contains("Editor")) {
                    runCatching { AiIde.onEditorResumed(a) }
                    runCatching { bindActive(a) }        // شات المشروع المفتوح
                    // شريط الذكاء تحت تبويبات المحرر (Console)، وإلا الزر العائم القديم
                    if (!EditorChrome.install(a)) attachFab(a)
                    // هيكل C5: شريط علوي، تبويبات، شاشة فارغة، شريط سفلي + حالة (كل خطوة معزولة)
                    runCatching { EditorShell.install(a) }
                    runCatching { SidebarChrome.install(a) }
                } else if (n.contains("Terminal")) {
                    runCatching { TerminalChrome.install(a) }
                } else if (n == "PreferencesActivity") {
                    runCatching { SettingsChrome.install(a) }
                } else if (n == "AboutActivity") {
                    runCatching { AboutChrome.install(a) }
                } else if (n == "MainActivity") {
                    runCatching { AiIde.migrateProjectsFolder(a) }
                    runCatching { bindActive(a) }
                    runCatching { NewProjectChrome.install(a) }
                    // الشاشة الرئيسية الجديدة (فيها زر الذكاء)، وإلا نرجعو للزر العائم القديم
                    if (!ZelligeHome.attach(a)) attachFab(a)
                }
            }
            override fun onActivityCreated(a: Activity, s: Bundle?) {
                if (s == null && a.javaClass.simpleName == "MainActivity") runCatching { AiIde.maybeAutoOpen(a) }
            }
            override fun onActivityStarted(a: Activity) {}
            override fun onActivityPaused(a: Activity) {
                val pn = a.javaClass.simpleName
                if (pn.contains("Editor")) { EditorChrome.stop(); EditorShell.stop(); SidebarChrome.stop() }
                else if (pn.contains("Terminal")) TerminalChrome.stop()
                else if (pn == "PreferencesActivity") SettingsChrome.stop()
                else if (pn == "MainActivity") NewProjectChrome.stop()
            }
            override fun onActivityStopped(a: Activity) {}
            override fun onActivitySaveInstanceState(a: Activity, o: Bundle) {}
            override fun onActivityDestroyed(a: Activity) {
                if (a.javaClass.simpleName.contains("Editor")) { EditorChrome.destroyed(a); EditorShell.destroyed(a); SidebarChrome.destroyed(a) }
                else if (a.javaClass.simpleName.contains("Terminal")) TerminalChrome.destroyed(a)
                else if (a.javaClass.simpleName == "PreferencesActivity") SettingsChrome.destroyed(a)
                else if (a.javaClass.simpleName == "MainActivity") { ZelligeHome.destroyed(a); NewProjectChrome.destroyed(a) }
            }
        })
    }

    // ------------------------------------------------------------ history persistence (شات لكل مشروع)
    /**
     * كل مشروع عندو الشات ديالو: filesDir/zellige/chats/<hash(project)>.json (خارج المشروع، ما كيدخلش لـ git).
     * `chatKey` = المسار الحقيقي ديال المشروع ("" = بلا مشروع). التبديل كيوقع أوتوماتيكياً ملي يتبدّل المشروع النشط،
     * وعمرو ما كيوقع والوكيل خدّام (باش الرسائل ما تمشيش لشات آخر).
     */
    @Volatile var chatKey: String? = null
        private set

    fun keyOf(root: File?): String =
        if (root == null) "" else try { root.canonicalPath } catch (t: Throwable) { root.path }

    private fun chatDir(ctx: Context) = File(ctx.filesDir, "zellige/chats").also { runCatching { it.mkdirs() } }

    private fun chatFile(ctx: Context, key: String): File =
        File(chatDir(ctx), if (key.isEmpty()) "global.json" else ConsoleLogic.chatId(key) + ".json")

    /** الشات اللي خاص يكون معروض للمشروع `root` (من الـ UI thread). كيرجع true إلا تبدّل. */
    fun bind(ctx: Context, root: File?): Boolean {
        if (AiChat.isBusy()) return false
        val key = keyOf(root)
        if (key == chatKey) return false
        if (chatKey != null) save(ctx)
        chatKey = key
        history.clear()
        history.addAll(readChat(ctx, key))
        return true
    }

    /** نفس bind ولكن من المشروع النشط حالياً (المحرر ولا آخر مشروع). */
    fun bindActive(a: Activity) {
        try { bind(a, AiIde.activeRoot(a, EditorAccess.find(a)?.file())) } catch (t: Throwable) { }
    }

    private fun readChat(ctx: Context, key: String): List<AiClient.Msg> {
        return try {
            val f = chatFile(ctx, key)
            if (!f.isFile) return emptyList()
            val o = JSONObject(f.readText())
            val arr = o.optJSONArray("messages") ?: return emptyList()
            (0 until arr.length()).map { i -> arr.getJSONObject(i).let { AiClient.Msg(it.getString("role"), it.getString("content")) } }
        } catch (t: Throwable) { emptyList() }
    }

    private fun writeChat(ctx: Context, key: String, msgs: List<AiClient.Msg>) {
        val f = chatFile(ctx, key)
        if (msgs.isEmpty()) { f.delete(); return }
        val arr = JSONArray()
        msgs.forEach { arr.put(JSONObject().put("role", it.role).put("content", it.content)) }
        val o = JSONObject()
            .put("project", key)
            .put("name", if (key.isEmpty()) "" else File(key).name)
            .put("updated", System.currentTimeMillis())
            .put("messages", arr)
        val tmp = File(f.path + ".tmp")
        tmp.writeText(o.toString())
        if (!tmp.renameTo(f)) { f.writeText(o.toString()); tmp.delete() }
    }

    /** بعد نقل مجلد المشاريع: ملفات الشات كتولّي باسم المسار الجديد. */
    fun migrateChats(ctx: Context, from: String, to: String) {
        try {
            for (f in chatDir(ctx).listFiles() ?: return) {
                if (!f.name.endsWith(".json")) continue
                val o = try { JSONObject(f.readText()) } catch (t: Throwable) { continue }
                val p = o.optString("project")
                if (p != from && !p.startsWith("$from/")) continue
                val np = to + p.substring(from.length)
                o.put("project", np)
                val dst = chatFile(ctx, np)
                if (!dst.exists()) { dst.writeText(o.toString()); f.delete() }
            }
            if (chatKey != null && (chatKey == from || chatKey!!.startsWith("$from/"))) chatKey = null   // نعاودو نربطو
        } catch (t: Throwable) { }
    }

    /** أول تشغيل: الشات القديم (كان واحد للتطبيق كامل) كيولّي شات المشروع النشط. */
    fun load(ctx: Context) {
        try {
            val prefs = AiPrefs(ctx)
            val raw = prefs.history
            val key = keyOf(prefs.activeProject.takeIf { it.isNotBlank() }?.let { File(it) }?.takeIf { it.isDirectory })
            if (raw.isNotBlank()) {
                val arr = JSONArray(raw)
                val old = (0 until arr.length()).map { i -> arr.getJSONObject(i).let { AiClient.Msg(it.getString("role"), it.getString("content")) } }
                if (readChat(ctx, key).isEmpty()) writeChat(ctx, key, old)
                prefs.history = ""
            }
            chatKey = key
            history.clear()
            history.addAll(readChat(ctx, key))
        } catch (t: Throwable) { /* سجل تالف: نتجاهله */ }
    }

    fun save(ctx: Context) {
        try {
            while (history.size > MAX_HISTORY) history.removeAt(0)
            writeChat(ctx, chatKey ?: return, history.toList())
        } catch (t: Throwable) { /* ما نكسرو التطبيق بسبب الحفظ */ }
    }

    /**
     * الوكيل خلق مشروع جديد وغادي يتفتح: المحادثة ديال هاد المهمة كتتنقل لشات المشروع الجديد
     * (باش ملي يتفتح يلقى كيفاش تبنى)، والشات القديم كيبقى فيه غير طلب المستعمل + سطر «تخلق المشروع».
     */
    fun handOver(ctx: Context, from: Int, project: File) {
        try {
            val key = keyOf(project)
            if (key == chatKey) return
            val all = history.toList()
            val moved = all.subList(from.coerceIn(0, all.size), all.size)
            if (moved.isEmpty()) return
            writeChat(ctx, key, (readChat(ctx, key) + moved).takeLast(MAX_HISTORY))
            val keep = all.subList(0, from.coerceIn(0, all.size)).toMutableList()
            moved.firstOrNull { it.role == "user" }?.let { keep.add(it) }
            keep.add(AiClient.Msg("assistant", "تخلق المشروع «" + project.name + "» وتفتح. المحادثة ديالو كتكمّل فالشات ديال المشروع."))
            history.clear(); history.addAll(keep)
            save(ctx)
        } catch (t: Throwable) { }
    }

    // ------------------------------------------------------------ floating button
    private fun attachFab(a: Activity) {
        val content = a.findViewById<ViewGroup>(android.R.id.content) ?: return
        if (content.findViewWithTag<View>("ai_fab") != null) return
        try {
            val d = a.resources.displayMetrics.density
            val st = AiChat.fabStyle(a)
            // FloatingActionButton من Material: يأخذ شكل وظلال وحركة التطبيق تلقائيا
            val fab = FloatingActionButton(a).apply {
                tag = "ai_fab"
                contentDescription = "مساعد الذكاء الاصطناعي"
                backgroundTintList = ColorStateList.valueOf(st[0])
                imageTintList = ColorStateList.valueOf(st[1])
                setImageDrawable(AiChat.icon(a, "ic_ai_sparkle"))
            }
            val lp = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM or Gravity.END
            ).apply {
                bottomMargin = (110 * d).toInt()
                marginEnd = (16 * d).toInt()
            }
            content.addView(fab, lp)

            // لو كاين FAB آخر ظاهر فالشاشة (مثل أزرار لوحة السجلات) نخبّيو الزر ديالنا باش ما يتداخلوش
            val check = Runnable {
                val hide = otherFabOnScreen(content, fab)
                val want = if (hide) View.GONE else View.VISIBLE
                if (fab.visibility != want) fab.visibility = want
            }
            content.viewTreeObserver.addOnGlobalLayoutListener {
                content.removeCallbacks(check)
                content.postDelayed(check, 120)
            }

            // سحب الزر + ضغطة قصيرة تفتح الشات + يلصق مع أقرب حافة
            var sx = 0f; var sy = 0f; var tx = 0f; var ty = 0f; var moved = false
            fab.setOnTouchListener { v, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        sx = e.rawX; sy = e.rawY; tx = v.translationX; ty = v.translationY; moved = false
                        v.animate().scaleX(0.92f).scaleY(0.92f).setDuration(80).start()
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val mx = e.rawX - sx; val my = e.rawY - sy
                        if (abs(mx) > 12 * d || abs(my) > 12 * d) moved = true
                        if (moved) { v.translationX = tx + mx; v.translationY = ty + my }
                        true
                    }
                    MotionEvent.ACTION_UP -> {
                        v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                        if (!moved) {
                            AiChat.show(a)
                        } else {
                            val pw = content.width.toFloat()
                            val ph = content.height.toFloat()
                            val left = v.left.toFloat()
                            val top = v.top.toFloat()
                            val cx = left + v.translationX + v.width / 2f
                            val edge = 8 * d
                            val targetX = if (cx < pw / 2f) edge else pw - v.width - edge
                            val targetY = (top + v.translationY).coerceIn(edge, (ph - v.height - edge).coerceAtLeast(edge))
                            v.animate().translationX(targetX - left).translationY(targetY - top).setDuration(180).start()
                        }
                        true
                    }
                    MotionEvent.ACTION_CANCEL -> {
                        v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                        true
                    }
                    else -> false
                }
            }
        } catch (t: Throwable) { /* ما نكسرو شاشة المحرر إلا وقع مشكل فالـ theme */ }
    }

    private fun otherFabOnScreen(x: View, self: View): Boolean {
        if (x === self || x.visibility != View.VISIBLE) return false
        if (x.javaClass.name.contains("FloatingActionButton") && x.isShown && x.getGlobalVisibleRect(Rect())) return true
        if (x is ViewGroup) for (i in 0 until x.childCount) if (otherFabOnScreen(x.getChildAt(i), self)) return true
        return false
    }
}
