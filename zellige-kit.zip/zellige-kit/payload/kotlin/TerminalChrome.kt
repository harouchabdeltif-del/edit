package com.itsaky.androidide.ai

import android.app.Activity
import android.app.Application
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.GridLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ListAdapter
import android.widget.ListView
import android.widget.PopupMenu
import android.widget.RelativeLayout
import android.widget.TextView
import java.io.File

/**
 * الترمنال بتصميم C9: شريط علوي («الترمنال» + رجوع + ⋮)، شريط جلسات (نقطة خضراء، أمر نشط بخط عنبري، ×، +)،
 * مفاتيح إضافية مدورة بـ mono (CTRL النشط عنبري)، ألوان شاشة سوداء بلوحة Console، بطاقة «فشل البناء… أصلحه» تقرأ
 * مخرجات الجلسة الحالية، ورسالة ترحيب Zellige بدل رسالة AndroidIDE.
 *
 * كلشي كيتبدّل وقت التشغيل على شاشة الترمنال الأصلية (الجلسات والأوامر والمفاتيح كتبقى هي هي، ما كنبدلو لا layout ولا كود Termux)،
 * والوصول لكلاسات Termux بالـ reflection: إلا فشل شي حاجة كتبقى الشاشة الأصلية.
 */
object TerminalChrome {

    private const val TAG = "zl_term_head"
    private const val CARD_TAG = "zl_term_card"
    private const val MARK = "# zellige-console"
    private val ui = Handler(Looper.getMainLooper())

    // ------------------------------------------------------------------ files (background, once per start)
    private const val ESC = "\u001b"

    private val MOTD = ESC + "[38;2;255;180;84m✦ Zellige" + ESC + "[0m " + ESC + "[38;2;123;132;148mterminal" + ESC + "[0m\n" +
        ESC + "[38;2;123;132;148mbash · gradle · git — والذكاء فشريط المحرر" + ESC + "[0m\n"

    private val BASHRC_BLOCK = "\n" + MARK + " >>>\n" +
        "case \$- in *i*) [ -z \"\$ZL_NO_PS1\" ] && PS1='\\[\\e[38;2;123;216;143m\\]\\w\\[\\e[0m\\] \\[\\e[38;2;255;180;84m\\]\$\\[\\e[0m\\] ';; esac\n" +
        MARK + " <<<\n"

    /** ألوان الترمنال (اللوحة ديال Console). السطر الأول علامة باش نقدرو نحدّثو الملف بلا ما نلمسو ملف المستعمل. */
    private val COLORS = MARK + "\n" +
        "background=#000000\nforeground=#D3D6DE\ncursor=#FFB454\n" +
        "color0=#0A0C10\ncolor1=#FF7A7A\ncolor2=#7BD88F\ncolor3=#FFB454\ncolor4=#6AA3FF\ncolor5=#C792EA\ncolor6=#5FD7D7\ncolor7=#D3D6DE\n" +
        "color8=#6B7383\ncolor9=#FF9A9A\ncolor10=#9BE8AB\ncolor11=#FFC878\ncolor12=#8BB8FF\ncolor13=#D9AEFF\ncolor14=#8FE8E8\ncolor15=#FFFFFF\n"

    private fun envDir(name: String): File? {
        val c = AiIde.cls("com.itsaky.androidide.utils.Environment") ?: return null
        try { (c.getField(name).get(null) as? File)?.let { return it } } catch (t: Throwable) { }
        try { (c.getMethod("get$name").invoke(AiIde.singleton(c)) as? File)?.let { return it } } catch (t: Throwable) { }
        return null
    }

    /** يكتب ملفات المظهر (ألوان، motd، prompt). من thread خلفي؛ كل فشل مسموح. */
    @JvmStatic
    fun prepare(app: Application) {
        Thread {
            runCatching {
                val home = envDir("HOME") ?: File(app.filesDir, "home")
                val prefix = envDir("PREFIX") ?: File(app.filesDir, "usr")
                writeColors(home)
                greeting(prefix, home)
                promptBlock(home)
            }
        }.also { it.isDaemon = true; it.name = "zl-term-prepare" }.start()
    }

    private fun writeColors(home: File) {
        if (!home.isDirectory) return
        val dir = File(home, ".termux")
        val f = File(dir, "colors.properties")
        if (f.exists() && !f.readText().startsWith(MARK)) return      // ملف المستعمل: ما نلمسوه
        if (f.exists() && f.readText() == COLORS) return
        dir.mkdirs()
        f.writeText(COLORS)
    }

    /** رسالة الترحيب: motd كامل + أي سطر «Welcome to AndroidIDE Terminal!» فملفات الإعداد الصغيرة. */
    private fun greeting(prefix: File, home: File) {
        val etc = File(prefix, "etc")
        if (!etc.isDirectory) return
        val motd = File(etc, "motd")
        if (motd.isFile && motd.length() < 8192) {
            val t = motd.readText()
            if (t.contains("AndroidIDE") && t != MOTD) motd.writeText(MOTD)
        }
        val files = ArrayList<File>()
        fun scan(d: File, depth: Int) {
            d.listFiles()?.forEach {
                if (it.isFile && it.length() in 1..65536) files.add(it)
                else if (it.isDirectory && depth < 2) scan(it, depth + 1)
            }
        }
        scan(etc, 0)
        File(prefix, "bin").listFiles()?.forEach { if (it.isFile && it.length() in 1..65536) files.add(it) }     // سكربتات login صغيرة
        for (n in listOf(".bashrc", ".profile", ".bash_profile")) File(home, n).takeIf { it.isFile }?.let { files.add(it) }
        for (f in files) {
            if (f.name == "motd") continue
            val raw = try { f.readBytes() } catch (e: Throwable) { continue }
            if (raw.any { it.toInt() == 0 }) continue                      // ملف ثنائي: ما نلمسوه أبدا
            val t = String(raw, Charsets.UTF_8)
            if (!t.contains("Welcome to AndroidIDE Terminal")) continue
            try { f.writeText(t.replace("Welcome to AndroidIDE Terminal!", "Zellige terminal").replace("Welcome to AndroidIDE Terminal", "Zellige terminal")) } catch (e: Throwable) { }
        }
    }

    /** prompt: المسار أخضر و $ عنبري (مثل C9). كيتزاد مرة وحدة فـ ~/.bashrc بين علامتين تقدر تمسحهم. */
    private fun promptBlock(home: File) {
        if (!home.isDirectory) return
        val f = File(home, ".bashrc")
        val t = if (f.exists()) f.readText() else ""
        if (t.contains(MARK)) return
        f.writeText(t + BASHRC_BLOCK)
    }

    // ------------------------------------------------------------------ install
    private class State(val a: Activity) {
        var head: LinearLayout? = null
        var tabs: LinearLayout? = null
        var card: LinearLayout? = null
        var cardTitle: TextView? = null
        var cardSub: TextView? = null
        var lastSig = ""
        var tabSig = ""
        var keysSig = ""
        var failId = 0
        var dismissedId = 0
        var tail = ""
        var tick: Runnable? = null
        var scanAt = 0L
        var tSig = Long.MIN_VALUE
        var tText = ""
        var bgSet = false
    }

    private var cur: State? = null

    /** من الـ UI thread، كل ما يتفتح الترمنال. */
    fun install(a: Activity): Boolean {
        return try {
            val root = Con.find<ViewGroup>(a, "activity_termux_root_view") ?: return false
            val s = cur?.takeIf { it.a === a } ?: State(a).also { cur = it }
            if (s.head == null || s.head?.parent == null) build(a, root, s)
            s.tick?.let { ui.removeCallbacks(it) }
            val r = object : Runnable {
                override fun run() {
                    if (cur !== s) return
                    try { refresh(s) } catch (t: Throwable) { /* اختياري */ }
                    ui.postDelayed(this, 1200)
                }
            }
            s.tick = r
            ui.post(r)
            true
        } catch (t: Throwable) { false }
    }

    fun stop() { cur?.tick?.let { ui.removeCallbacks(it) }; cur?.tick = null }
    fun destroyed(a: Activity) { if (cur?.a === a) { stop(); cur = null } }

    // ------------------------------------------------------------------ build
    private fun build(a: Activity, root: ViewGroup, s: State) {
        val p = Con.pal(a)
        val mono = Con.mono(a)
        fun dp(v: Int) = Con.dp(a, v)
        val bar = 0xFF0A0C10.toInt()
        val bar2 = 0xFF0D0F14.toInt()
        val lineC = 0xFF1A1F29.toInt()

        // الشاشة كلها LTR كما فـ C9 (المفاتيح والمخرجات)، والشريط العلوي RTL
        root.layoutDirection = View.LAYOUT_DIRECTION_LTR
        root.setBackgroundColor(Color.BLACK)
        Con.find<View>(a, "left_drawer")?.setBackgroundColor(bar)
        (Con.find<View>(a, "activity_termux_root_relative_layout")?.layoutParams as? ViewGroup.MarginLayoutParams)?.let {
            it.leftMargin = dp(9); it.rightMargin = dp(9)
        }

        val head = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; tag = TAG }

        // ---- الشريط العلوي: 44dp
        val top = LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(bar)
            setPadding(dp(10), 0, dp(10), 0)
        }
        top.addView(Con.squareButton(a, "zl_ic_open", "رجوع", 0xFFA5ADBB.toInt(), 0, 0, 34, 34, 8, 20) { a.finish() })
        top.addView(Con.text(a, "الترمنال", 16f, 0xFFD9DDE5.toInt(), null, true).apply {
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(6) }
        })
        top.addView(Con.squareButton(a, "zl_ic_more", "قائمة", 0xFFA5ADBB.toInt(), 0, 0, 34, 34, 8, 18) { v -> menu(a, v) })
        head.addView(top, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44)))
        head.addView(Con.hairline(a, lineC))

        // ---- شريط الجلسات: 34dp
        val strip = HorizontalScrollView(a).apply {
            isHorizontalScrollBarEnabled = false
            setBackgroundColor(bar2)
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        val tabs = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL }
        strip.addView(tabs, ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
        head.addView(strip, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(34)))
        head.addView(Con.hairline(a, lineC))

        root.addView(head, 0, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        s.head = head
        s.tabs = tabs

        // ---- بطاقة الذكاء (مخبّية حتى يفشل بناء)
        val card = LinearLayout(a).apply {
            tag = CARD_TAG
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            background = Con.rounded(0xFF161A23.toInt(), Con.dpf(a, 10f), 0xFFFFB454.toInt(), dp(1))
            setPadding(dp(12), dp(10), dp(10), dp(10))
            visibility = View.GONE
            elevation = Con.dpf(a, 6f)
        }
        card.addView(Con.iconView(a, "zl_ic_sparkle", 0xFFFFB454.toInt(), 18))
        val col = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        val title = Con.text(a, "فشل البناء", 13f, 0xFFD9DDE5.toInt(), null, true)
        val sub = Con.text(a, "ask AI · fix · rebuild", 10.5f, 0xFF7B8494.toInt(), mono).apply {
            textDirection = View.TEXT_DIRECTION_LTR; gravity = Gravity.END
        }
        col.addView(title)
        col.addView(sub, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(2) })
        card.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(10); marginEnd = dp(8) })
        val fix = Con.text(a, "أصلحه", 13f, 0xFF1A1000.toInt(), null, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(14), 0, dp(14), 0)
            background = Con.ripple(Con.rounded(0xFFFFB454.toInt(), Con.dpf(a, 8f)), Con.dpf(a, 8f))
            isClickable = true; isFocusable = true
            setOnClickListener { fixWithAi(a, s) }
        }
        card.addView(fix, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(34)))
        card.addView(Con.squareButton(a, "ic_ai_close", "إخفاء", 0xFF7B8494.toInt(), 0, 0, 30, 34, 8, 14) {
            s.dismissedId = s.failId; card.visibility = View.GONE
        })
        val rel = Con.find<ViewGroup>(a, "activity_termux_root_relative_layout")
        val pagerId = Con.id(a, "terminal_toolbar_view_pager")
        if (rel is RelativeLayout) {
            val lp = RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            if (pagerId != 0) lp.addRule(RelativeLayout.ABOVE, pagerId) else lp.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM)
            lp.setMargins(dp(1), 0, dp(1), dp(10))
            rel.addView(card, lp)
        } else {
            (root as? ViewGroup)?.addView(card)
        }
        s.card = card; s.cardTitle = title; s.cardSub = sub
        s.tabSig = ""; s.keysSig = ""
    }

    private fun menu(a: Activity, anchor: View) {
        val pm = PopupMenu(a, anchor)
        pm.menu.add(0, 1, 0, "جلسة جديدة")
        pm.menu.add(0, 2, 1, "قائمة الجلسات")
        pm.menu.add(0, 3, 2, "إظهار / إخفاء الكيبورد")
        pm.menu.add(0, 4, 3, "نسخ كل المخرجات")
        pm.setOnMenuItemClickListener { m ->
            when (m.itemId) {
                1 -> Con.find<View>(a, "new_session_button")?.performClick()
                2 -> Con.call(Con.find<View>(a, "drawer_layout"), "openDrawer", Gravity.START)
                3 -> Con.find<View>(a, "toggle_keyboard_button")?.performClick()
                4 -> copyAll(a)
            }
            true
        }
        pm.show()
    }

    private fun copyAll(a: Activity) {
        val t = fullTranscript(a)
        if (t.isBlank()) { android.widget.Toast.makeText(a, "ما كاين والو للنسخ", android.widget.Toast.LENGTH_SHORT).show(); return }
        val cm = a.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
        cm.setPrimaryClip(android.content.ClipData.newPlainText("terminal", t))
        android.widget.Toast.makeText(a, "تنسخ", android.widget.Toast.LENGTH_SHORT).show()
    }

    // ------------------------------------------------------------------ refresh
    private fun refresh(s: State) {
        val a = s.a
        refreshTabs(s)
        restyleKeys(s)
        scanTranscript(s)
    }

    private fun sessions(a: Activity): List<Any> {
        val lv = Con.find<ListView>(a, "terminal_sessions_list") ?: return emptyList()
        val ad: ListAdapter = lv.adapter ?: return emptyList()
        return (0 until ad.count).mapNotNull { ad.getItem(it) }
    }

    private fun sessionOf(ts: Any?): Any? = Con.call(ts, "getTerminalSession")

    private fun refreshTabs(s: State) {
        val a = s.a
        val tabs = s.tabs ?: return
        val list = sessions(a)
        val curSession = Con.call(Con.find<View>(a, "terminal_view"), "getCurrentSession")
        val parts = list.mapIndexed { i, ts ->
            val ses = sessionOf(ts)
            val name = (Con.field(ses, "mSessionName") as? String).orEmpty().ifBlank { "bash ${i + 1}" }
            val running = Con.call(ses, "isRunning") != false
            Triple(name, running, ses === curSession && ses != null)
        }
        val sig = parts.joinToString("|") { "${it.first}:${it.second}:${it.third}" }
        if (sig == s.tabSig) return
        s.tabSig = sig
        val p = Con.pal(a)
        val mono = Con.mono(a)
        fun dp(v: Int) = Con.dp(a, v)
        tabs.removeAllViews()
        val amber = 0xFFFFB454.toInt()
        val lineC = 0xFF1A1F29.toInt()
        parts.forEachIndexed { i, (name, running, active) ->
            val cell = LinearLayout(a).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(14), 0, dp(14), 0)
                isClickable = true; isFocusable = true
                background = if (active) layerTop(a, Color.BLACK, amber) else Con.ripple(null, 0f)
                setOnClickListener { selectSession(a, i) }
            }
            cell.addView(Con.dot(a, if (running) 0xFF7BD88F.toInt() else 0xFFFF7A7A.toInt()),
                LinearLayout.LayoutParams(dp(6), dp(6)).apply { marginEnd = dp(7) })
            cell.addView(Con.text(a, name, 12f, if (active) 0xFFD9DDE5.toInt() else 0xFF7B8494.toInt(), mono).apply {
                textDirection = View.TEXT_DIRECTION_LTR; setSingleLine()
            })
            if (active) {
                cell.addView(Con.iconView(a, "zl_ic_close", 0xFF7B8494.toInt(), 12).apply {
                    setPadding(dp(0), 0, 0, 0)
                    setOnClickListener { closeSession(a, i) }
                    isClickable = true
                }, LinearLayout.LayoutParams(dp(12), dp(12)).apply { marginStart = dp(7) })
            }
            tabs.addView(cell, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
            tabs.addView(Con.hairline(a, lineC, true))
        }
        tabs.addView(Con.iconView(a, "zl_ic_add", 0xFF7B8494.toInt(), 14).apply {
            setPadding(dp(11), dp(10), dp(11), dp(10))
            layoutParams = LinearLayout.LayoutParams(dp(36), ViewGroup.LayoutParams.MATCH_PARENT)
            isClickable = true; isFocusable = true
            background = Con.ripple(null, 0f)
            setOnClickListener { Con.find<View>(a, "new_session_button")?.performClick() }
        })
    }

    private fun layerTop(a: Context, fill: Int, line: Int): android.graphics.drawable.Drawable {
        val base = Con.rounded(fill, 0f)
        val top = Con.rounded(line, 0f)
        val ld = android.graphics.drawable.LayerDrawable(arrayOf(base, top))
        ld.setLayerInset(1, 0, 0, 0, 0)
        ld.setLayerGravity(1, Gravity.TOP)
        ld.setLayerHeight(1, Con.dp(a, 2))
        return ld
    }

    private fun selectSession(a: Activity, index: Int) {
        val lv = Con.find<ListView>(a, "terminal_sessions_list") ?: return
        val ad = lv.adapter ?: return
        if (index !in 0 until ad.count) return
        lv.performItemClick(null, index, ad.getItemId(index))
    }

    private fun closeSession(a: Activity, index: Int) {
        val ses = sessionOf(sessions(a).getOrNull(index)) ?: return
        Con.call(ses, "finishIfRunning")
    }

    // ------------------------------------------------------------------ extra keys
    private fun restyleKeys(s: State) {
        val a = s.a
        val pager = Con.find<ViewGroup>(a, "terminal_toolbar_view_pager") ?: return
        val keys = Con.firstOf(pager) { Con.isA(it, "ExtraKeysView") } as? GridLayout ?: return
        val sig = "${System.identityHashCode(keys)}:${keys.childCount}"
        if (sig != s.keysSig) {
            s.keysSig = sig
            val mono = Con.mono(a)
            fun dp(v: Int) = Con.dp(a, v)
            val txt = 0xFFA5ADBB.toInt()
            val bg = 0xFF161A23.toInt()
            val amber = 0xFFFFB454.toInt()
            val soft = 0xFF2A2113.toInt()
            // الألوان الجديدة كتطبّق حتى على الأزرار اللي غادي تتعاود (CTRL/ALT النشطين…)
            Con.call(keys, "setButtonColors", txt, amber, bg, soft)
            keys.setPadding(dp(4), dp(6), dp(4), dp(4))
            for (i in 0 until keys.childCount) {
                val b = keys.getChildAt(i) as? Button ?: continue
                b.typeface = mono
                b.textSize = 11.5f
                b.isAllCaps = false
                b.setTextColor(txt)
                b.setBackgroundColor(bg)
                Con.call(b, "setCornerRadius", dp(6))
                Con.call(b, "setInsetTop", 0)
                Con.call(b, "setInsetBottom", 0)
                Con.call(b, "setMinHeight", 0)
                b.minHeight = 0; b.minimumHeight = 0
                (b.layoutParams as? ViewGroup.MarginLayoutParams)?.let {
                    it.setMargins(dp(2), dp(2), dp(2), dp(2)); b.layoutParams = it
                }
            }
        }
        val rows = keys.rowCount.coerceAtLeast(1)
        val want = Con.dp(a, rows * 40 + 10)
        if (!s.bgSet) { s.bgSet = true; pager.setBackgroundColor(0xFF0A0C10.toInt()) }
        val lp = pager.layoutParams
        if (lp != null && pager.visibility == View.VISIBLE && Math.abs(lp.height - want) > Con.dp(a, 2)) {
            lp.height = want
            pager.layoutParams = lp
        }
    }

    // ------------------------------------------------------------------ build failure card
    /** الـ transcript كامل (للنسخ فقط). */
    private fun fullTranscript(a: Activity): String {
        val ses = Con.call(Con.find<View>(a, "terminal_view"), "getCurrentSession") ?: return ""
        val emu = Con.call(ses, "getEmulator") ?: return ""
        val screen = Con.call(emu, "getScreen") ?: return ""
        return (Con.call(screen, "getTranscriptText") as? String).orEmpty()
    }

    /**
     * آخر ~400 سطر من الترمنال فقط (قبل: كل الـ transcript، 100KB+ كل 1.4ث على الـ UI thread مللي كيمشي gradle)،
     * وإلا ما تبدّل والو (نفس عدد الأسطر ومكان المؤشر) كنرجعو النص السابق بلا ما نقراو والو.
     */
    private fun transcript(s: State): String {
        val a = s.a
        val ses = Con.call(Con.find<View>(a, "terminal_view"), "getCurrentSession") ?: return ""
        val emu = Con.call(ses, "getEmulator") ?: return ""
        val screen = Con.call(emu, "getScreen") ?: return ""
        val atr = Con.call(screen, "getActiveTranscriptRows") as? Int
        val cols = Con.field(emu, "mColumns") as? Int
        val rows = Con.field(emu, "mRows") as? Int
        if (atr == null || cols == null || rows == null) return (Con.call(screen, "getTranscriptText") as? String).orEmpty()
        val cr = (Con.call(emu, "getCursorRow") as? Int) ?: 0
        val cc = (Con.call(emu, "getCursorCol") as? Int) ?: 0
        val sig = (atr.toLong() shl 40) xor (cr.toLong() shl 20) xor cc.toLong() xor (System.identityHashCode(ses).toLong() shl 50)
        if (sig == s.tSig) return s.tText
        val t = (Con.call(screen, "getSelectedText", 0, -minOf(atr, 400), cols, rows) as? String)?.trim()
            ?: (Con.call(screen, "getTranscriptText") as? String).orEmpty()
        s.tSig = sig; s.tText = t
        return t
    }

    private fun scanTranscript(s: State) {
        val now = System.currentTimeMillis()
        if (now - s.scanAt < 1400) return
        s.scanAt = now
        val card = s.card ?: return
        val f = ConsoleLogic.detect(transcript(s))
        if (f == null) { card.visibility = View.GONE; s.failId = 0; return }
        s.failId = f.id; s.tail = f.tail
        if (f.id == s.dismissedId) { card.visibility = View.GONE; return }
        s.cardTitle?.text = when (f.errors.size) {
            0 -> "فشل البناء"
            1 -> "فشل البناء بسبب خطأ واحد"
            else -> "فشل البناء بسبب ${f.errors.size} أخطاء"
        }
        if (card.visibility != View.VISIBLE) card.visibility = View.VISIBLE
    }

    private fun fixWithAi(a: Activity, s: State) {
        val prompt = "فشل البناء فالترمنال. هادي آخر مخرجات gradle:\n\n" + s.tail.trim() +
            "\n\nحدّد السبب وصلّح الأخطاء فالمشروع النشط مباشرة (وماتبدّلش شي حاجة ما عندها علاقة)."
        AiChat.open(a, prompt, true)
    }
}
