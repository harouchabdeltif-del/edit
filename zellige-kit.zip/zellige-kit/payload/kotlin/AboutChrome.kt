package com.itsaky.androidide.ai

import android.app.Activity
import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/**
 * «حول Zellige» و«دليل الاستعمال» ديال التطبيق.
 *
 * شاشة «حول» الأصلية كانت كتوجّه المستعمل لمواقع وقنوات ديال مشروع آخر؛ دابا كتعوّضها هاد الصفحة (فوقها، بلا ما نبدّلو كودها).
 * المكان الوحيد فالتطبيق اللي فيه ذكر المكونات مفتوحة المصدر هو قسم «التراخيص» هنا — رخصة GPL-3.0 كتلزم بإشعار الرخصة
 * والإشارة للأصل، وهادشي هو الطريقة الصحيحة والأمينة.
 */
object AboutChrome {

    /** رابط الكود المصدري ديال Zellige (إلا عمّرتيه كيبان زر فصفحة «حول»). GPL كتلزم توفير المصدر لمن وزّعتي ليه التطبيق. */
    const val SOURCE_URL = ""

    private const val TAG = "zl_about"

    private val CREDITS = listOf(
        Triple("AndroidIDE", "Akash Yadav & contributors", "GPL-3.0"),
        Triple("Termux", "Fredrik Fornwall & contributors", "GPL-3.0"),
        Triple("Sora Editor", "Rosemoe", "LGPL-2.1"),
        Triple("Material Components", "Google", "Apache-2.0"),
        Triple("Gradle Tooling API", "Gradle Inc.", "Apache-2.0"),
        Triple("EventBus", "greenrobot", "Apache-2.0")
    )

    /** فوق AboutActivity: الصفحة ديالنا كتغطي الأصلية (زر الرجوع كيرجع عادي). */
    fun install(a: Activity) {
        val content = a.findViewById<ViewGroup>(android.R.id.content) ?: return
        if (content.findViewWithTag<View>(TAG) != null) return
        try {
            val v = page(a) { a.finish() }
            v.tag = TAG
            content.addView(v, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        } catch (t: Throwable) { /* الأصلية كتبقى */ }
    }

    /** نفس الصفحة كـ dialog (من الشاشة الرئيسية / الإعدادات). */
    fun show(a: Activity) {
        try {
            val d = Dialog(a, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
            d.setContentView(page(a) { d.dismiss() })
            d.window?.let { w ->
                w.statusBarColor = Con.pal(a).page
                w.navigationBarColor = Con.pal(a).page
            }
            d.show()
        } catch (t: Throwable) { }
    }

    private fun open(a: Activity, url: String) {
        try { a.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (t: Throwable) { }
    }

    fun page(a: Activity, onBack: () -> Unit): View {
        val p = Con.pal(a)
        val mono = Con.mono(a)
        fun dp(v: Int) = Con.dp(a, v)
        val ver = try { a.packageManager.getPackageInfo(a.packageName, 0).versionName } catch (t: Throwable) { null } ?: "1.0"

        val root = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(p.page)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            isClickable = true
            fitsSystemWindows = true
        }
        val head = LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), 0, dp(16), 0)
        }
        head.addView(Con.squareButton(a, "zl_ic_arrow_forward", "رجوع", p.dim, 0, p.border, 36, 36, 9, 18) { onBack() })
        head.addView(Con.text(a, "حول Zellige", 16f, p.text, null, true), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(12) })
        root.addView(head, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56)))
        root.addView(Con.hairline(a, p.line))

        val col = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(26), dp(18), dp(30))
        }
        col.addView(Con.iconView(a, "zl_ic_star8", p.amber, 46), LinearLayout.LayoutParams(dp(46), dp(46)).apply { gravity = Gravity.CENTER_HORIZONTAL })
        col.addView(Con.text(a, "Zellige", 24f, p.text, mono, true).apply { gravity = Gravity.CENTER },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(12) })
        col.addView(Con.text(a, "v$ver", 12f, p.muted, mono).apply { gravity = Gravity.CENTER; textDirection = View.TEXT_DIRECTION_LTR },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(4) })
        col.addView(Con.text(a, "بيئة تطوير تطبيقات Android على الهاتف، مع وكيل ذكاء اصطناعي كيكتب الكود مباشرة فالملفات، معاينة XML، بناء وتشغيل.", 13.5f, p.dim).apply {
            gravity = Gravity.CENTER; setLineSpacing(0f, 1.25f)
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(14) })

        fun section(t: String) {
            col.addView(Con.text(a, t, 10.5f, p.faint, mono).apply { letterSpacing = 0.1f },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(28) })
            col.addView(Con.hairline(a, p.line), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1).coerceAtLeast(1)).apply { topMargin = dp(8) })
        }
        fun row(icon: String, title: String, sub: String?, tint: Int, f: (() -> Unit)?) {
            val r = LinearLayout(a).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(4), dp(10), dp(4), dp(10))
                if (f != null) { background = Con.ripple(null, 0f); isClickable = true; setOnClickListener { f() } }
            }
            r.addView(Con.iconView(a, icon, tint, 18))
            val t = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
            t.addView(Con.text(a, title, 13.5f, p.text))
            if (sub != null) t.addView(Con.text(a, sub, 11.5f, p.muted).apply { setPadding(0, dp(2), 0, 0) })
            r.addView(t, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(12) })
            if (f != null) r.addView(Con.iconView(a, "zl_ic_chevron_left", p.faint, 16))
            col.addView(r, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }

        section("الاستعمال")
        row("zl_ic_docs", "دليل الاستعمال", "مشروع جديد، الذكاء، XML، البناء", p.amber) { guide(a) }
        row("zl_ic_sparkle", "إعدادات الذكاء", "المزوّد والمفتاح والموديل", p.amber) { AiChat.showSettings(a) }

        section("الترخيص")
        col.addView(Con.text(a, "Zellige برنامج حر تحت رخصة GNU General Public License v3. كتقدر تستعملو وتعدّلو وتوزّعو بنفس الرخصة، بلا أي ضمان.", 12.5f, p.dim).apply {
            setLineSpacing(0f, 1.25f); setPadding(dp(4), dp(10), dp(4), dp(4))
        })
        row("zl_ic_doc_text", "نص الرخصة (GPL-3.0)", "gnu.org/licenses/gpl-3.0", p.blue) { open(a, "https://www.gnu.org/licenses/gpl-3.0.html") }
        if (SOURCE_URL.isNotBlank()) row("zl_ic_code", "الكود المصدري", SOURCE_URL.removePrefix("https://"), p.blue) { open(a, SOURCE_URL) }

        section("مكونات مفتوحة المصدر")
        for ((name, who, lic) in CREDITS) {
            val r = LinearLayout(a).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                layoutDirection = View.LAYOUT_DIRECTION_LTR
                setPadding(dp(4), dp(8), dp(4), dp(8))
            }
            val t = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
            t.addView(Con.text(a, name, 12.5f, p.text2, mono))
            t.addView(Con.text(a, who, 10.5f, p.faint).apply { setSingleLine(); ellipsize = TextUtils.TruncateAt.END })
            r.addView(t, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            r.addView(Con.text(a, lic, 10.5f, p.gold, mono).apply {
                setPadding(dp(7), dp(2), dp(7), dp(2))
                background = Con.rounded(Color.TRANSPARENT, Con.dpf(a, 5f), p.border, dp(1).coerceAtLeast(1))
            })
            col.addView(r)
        }

        val scroll = ScrollView(a).apply { isFillViewport = true; addView(col) }
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        return root
    }

    /** دليل قصير بالدارجة (بدل الوثائق الخارجية). */
    fun guide(a: Activity) {
        val p = Con.pal(a)
        fun dp(v: Int) = Con.dp(a, v)
        val steps = listOf(
            "1 · مشروع جديد" to "من «المشاريع» ← «+ جديد» اختار قالب، ولا كتب للذكاء: «دير ليا تطبيق تسجيل المصاريف» وهو كيخلق المشروع كامل ويفتحو.",
            "2 · الذكاء كيكتب فالملفات" to "الكود ما كيبانش فالشات: الذكاء كيفتح الملف وكيكتب فيه قدامك. كل مشروع عندو الشات ديالو.",
            "3 · واجهات XML والمعاينة" to "الواجهات كتكون فـ res/layout. فتح ملف XML وضغط «معاينة» فالشريط الفوقاني (خاص المشروع يسالي التحميل). جرّب الأمر ‎/xml فالذكاء.",
            "4 · البناء والتشغيل" to "▶ فالشريط الفوقاني كيبني ويثبّت التطبيق. إلا فشل البناء، كتبان بطاقة «صلّح بالذكاء» فوق المخرجات.",
            "5 · الدرج والترمنال" to "☰ كيفتح شجرة الملفات. الترمنال فيه نفس بيئة البناء (git، gradle، java).",
            "6 · اكتشف" to "قسم «اكتشف» كيجيب مشاريع تطبيقات مفتوحة المصدر من GitHub: تنزّلها وتخدم عليها مباشرة."
        )
        val col = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(20), dp(8), dp(20), dp(8))
        }
        for ((t, b) in steps) {
            col.addView(Con.text(a, t, 14f, p.amber, null, true), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(14) })
            col.addView(Con.text(a, b, 13f, p.dim).apply { setLineSpacing(0f, 1.25f) },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(4) })
        }
        val sv = ScrollView(a).apply { addView(col) }
        try {
            android.app.AlertDialog.Builder(a)
                .setTitle("دليل الاستعمال")
                .setView(sv)
                .setPositiveButton("مفهوم", null)
                .show()
        } catch (t: Throwable) { }
    }
}
