package com.itsaky.androidide.ai

import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.URLEncoder
import java.net.UnknownHostException

/**
 * عميل GitHub صغير لقسم «اكتشف» (HttpURLConnection بلا مكتبات):
 *  - البحث فـ api.github.com (الرمز الاختياري كيتبعت لهاد الدومين بوحدو)،
 *  - تنزيل zip ديال الفرع من codeload.github.com (بلا رمز، ما كيحسبش ضمن حدّ الـ API)،
 *  - صور المالكين من avatars.githubusercontent.com.
 * الأخطاء كترجع ApiError برسالة عربية واضحة.
 */
object GitHubClient {

    class ApiError(val code: Int, message: String) : IOException(message)

    private const val UA = "Zellige-Android (discover)"
    private const val API = "https://api.github.com"
    const val PER_PAGE = 20

    private fun open(url: String, token: String?, accept: String, readMs: Int): HttpURLConnection {
        val u = URL(url)
        val host = u.host
        require(u.protocol == "https" && (host == "api.github.com" || host == "codeload.github.com" ||
            host.endsWith(".githubusercontent.com") || host == "github.com")) { "رابط غير مسموح: $host" }
        val c = u.openConnection() as HttpURLConnection
        c.connectTimeout = 12_000
        c.readTimeout = readMs
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", UA)
        c.setRequestProperty("Accept", accept)
        if (!token.isNullOrBlank() && host == "api.github.com") c.setRequestProperty("Authorization", "Bearer " + token.trim())
        if (host == "api.github.com") c.setRequestProperty("X-GitHub-Api-Version", "2022-11-28")
        return c
    }

    /** رسالة عربية من استجابة خطأ (حدّ الطلبات، رمز غير صالح…). */
    internal fun explain(code: Int, remaining: String?, retryAfter: String?, reset: String?, hasToken: Boolean, nowSec: Long, body: String): String {
        val limited = code == 429 || (code == 403 && (remaining == "0" || body.contains("rate limit", ignoreCase = true)))
        if (limited) {
            val wait = retryAfter?.toLongOrNull()
                ?: reset?.toLongOrNull()?.let { (it - nowSec).coerceAtLeast(1) }
                ?: 60L
            val w = if (wait >= 90) "${(wait + 59) / 60} دقيقة" else "$wait ثانية"
            return "وصلتي حدّ GitHub. عاود بعد $w" +
                if (hasToken) "." else "، أو زيد رمز GitHub بزر 🔑 باش يتضاعف الحدّ."
        }
        return when (code) {
            401 -> "رمز GitHub غير صالح أو منتهي. بدّلو أو مسحو من زر 🔑."
            403 -> "GitHub رفض الطلب (403)."
            404 -> "ما تلقاش على GitHub (404)."
            422 -> "GitHub ما قبلش هاد البحث (422). بدّل الكلمات."
            in 500..599 -> "GitHub عندو مشكل مؤقت ($code). عاود شوية بعد."
            else -> "GitHub رجّع خطأ $code."
        }
    }

    /** يحوّل استثناء الشبكة لرسالة عربية قصيرة. */
    fun message(t: Throwable): String = when (t) {
        is ApiError -> t.message ?: "خطأ GitHub"
        is UnknownHostException -> "ما كاين إنترنت (أو GitHub ما وصلناش ليه)."
        is SocketTimeoutException -> "GitHub بطيء بزاف أو الشبكة ضعيفة. عاود."
        is DiscoverLogic.Cancelled -> "تلغى."
        is SecurityException -> t.message ?: "مسار مشبوه"
        else -> t.message?.takeIf { it.isNotBlank() } ?: t.javaClass.simpleName
    }

    private fun fail(c: HttpURLConnection, code: Int, hasToken: Boolean): Nothing {
        val body = try { c.errorStream?.use { String(readCapped(it, 20_000), Charsets.UTF_8) } } catch (t: Throwable) { null }.orEmpty()
        throw ApiError(
            code,
            explain(
                code, c.getHeaderField("X-RateLimit-Remaining"), c.getHeaderField("Retry-After"),
                c.getHeaderField("X-RateLimit-Reset"), hasToken, System.currentTimeMillis() / 1000, body
            )
        )
    }

    private fun readCapped(i: InputStream, max: Int): ByteArray {
        val out = ByteArrayOutputStream()
        val buf = ByteArray(8192)
        var left = max
        while (left > 0) {
            val n = i.read(buf, 0, minOf(buf.size, left))
            if (n < 0) break
            out.write(buf, 0, n); left -= n
        }
        return out.toByteArray()
    }

    /** بحث فالمستودعات (صفحة واحدة). من thread خلفي فقط. */
    fun search(query: String, page: Int, token: String?): List<DiscoverLogic.Repo> {
        val url = API + "/search/repositories?q=" + URLEncoder.encode(query, "UTF-8") +
            "&sort=stars&order=desc&per_page=$PER_PAGE&page=$page"
        val c = open(url, token, "application/vnd.github+json", 20_000)
        try {
            val code = c.responseCode
            if (code !in 200..299) fail(c, code, !token.isNullOrBlank())
            val body = c.inputStream.use { String(readCapped(it, 2_000_000), Charsets.UTF_8) }
            return DiscoverLogic.parseSearch(body)
        } finally {
            c.disconnect()
        }
    }

    /**
     * يفتح تيار zip ديال المستودع. `onOpen` كيعطي الاتصال باش نقدرو نقطعوه عند الإلغاء.
     * إغلاق التيار كيسد الاتصال.
     */
    fun openZip(url: String, onOpen: (HttpURLConnection) -> Unit = {}): InputStream {
        val c = open(url, null, "application/zip", 30_000)
        onOpen(c)
        val code = c.responseCode
        if (code !in 200..299) {
            try { fail(c, code, false) } finally { c.disconnect() }
        }
        val raw = c.inputStream
        return object : InputStream() {
            override fun read(): Int = raw.read()
            override fun read(b: ByteArray, off: Int, len: Int): Int = raw.read(b, off, len)
            override fun available(): Int = raw.available()
            override fun close() { try { raw.close() } finally { c.disconnect() } }
        }
    }

    /** صورة المالك (صغيرة). كترجع null إلا فشل أي شيء. */
    fun avatar(url: String): ByteArray? {
        if (url.isBlank()) return null
        val sized = url + (if (url.contains('?')) "&" else "?") + "s=96"
        val c = try { open(sized, null, "image/*", 12_000) } catch (t: Throwable) { return null }
        return try {
            if (c.responseCode !in 200..299) null else c.inputStream.use { readCapped(it, 400_000) }
        } catch (t: Throwable) {
            null
        } finally {
            c.disconnect()
        }
    }
}
