package com.itsaky.androidide.ai

import android.app.Activity
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.StateListDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewTreeObserver
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/**
 * «مشروع جديد» بتصميم C4 فوق شاشتي القوالب الأصليتين (قائمة القوالب ← تفاصيل المشروع) بلا تعديل layouts:
 *  • ترويسة: زر رجوع مربع + «مشروع جديد» + خط رفيع.
 *  • فوق القائمة مبدّل «من قالب | من وصف» («من وصف» كيفتح شات الذكاء بطلب جاهز لبناء مشروع كامل).
 *  • القوالب صفوف 52dp (دائرة + اسم) عوض البطاقات الكبيرة، وزر «أو صف التطبيق للذكاء ليبنيه لك» عوض «Exit».
 *  • التفاصيل: حقول بحدّ 10dp وخلفية داكنة (اسم الحزمة mono عنبري)، وزر «إنشاء المشروع» عنبري بعرض كامل 52dp.
 * الشاشتان كتبقاو شاشتين (قائمة ثم تفاصيل) بنفس الـ ViewModel والـ recipe؛ ماشي شاشة وحدة كما فالتصميم (للأمانة فالـ README).
 * كلشي بالـ reflection وكل خطوة معزولة: إلا فشل شي حاجة كتبقى الواجهة الأصلية.
 */
object NewProjectChrome {

    private val ui = Handler(Looper.getMainLooper())

    private class S(val a: Activity) {
        var tick: Runnable? = null
        var gl: ViewTreeObserver.OnGlobalLayoutListener? = null
        var obs: ViewTreeObserver? = null
        var styled = false
        var origTitle: CharSequence? = null
        var seg: View? = null
        var hair: View? = null
    }

    private var cur: S? = null
    private const val TITLE = "مشروع جديد"
    private const val DESCRIBE_PROMPT = "أنشئ مشروع أندرويد جديد باسم "

    fun install(a: Activity) {
        val s = cur?.takeIf { it.a === a } ?: S(a).also { cur = it }
        if (s.tick != null) return
        val r = object : Runnable {
            override fun run() {
                if (cur !== s || s.tick !== this) return
                try { apply(s) } catch (t: Throwable) { }
                ui.postDelayed(this, 400)
            }
        }
        s.tick = r
        ui.postDelayed(r, 200)
        try {
            val vto = a.window.decorView.viewTreeObserver
            val gl = ViewTreeObserver.OnGlobalLayoutListener { try { apply(s) } catch (t: Throwable) { } }
            vto.addOnGlobalLayoutListener(gl)
            s.gl = gl; s.obs = vto
        } catch (t: Throwable) { }
    }

    fun stop() {
        val s = cur ?: return
        s.tick?.let { ui.removeCallbacks(it) }
        s.tick = null
        try { s.gl?.let { g -> s.obs?.takeIf { it.isAlive }?.removeOnGlobalLayoutListener(g) } } catch (t: Throwable) { }
        s.gl = null; s.obs = null
    }

    fun destroyed(a: Activity) { if (cur?.a === a) { stop(); cur = null } }

    // ------------------------------------------------------------------ pass
    private fun apply(s: S) {
        val a = s.a
        val list = Con.find<ViewGroup>(a, "template_list")
        val det = Con.find<ViewGroup>(a, "template_details")
        val onList = list != null && list.visibility == View.VISIBLE
        val onDet = det != null && det.visibility == View.VISIBLE
        step { header(s, onList || onDet) }
        step { segment(s, list, onList) }
        if (onList && list != null) step { listScreen(a, list) }
        if (onDet && det != null) step { detailsScreen(a, det) }
    }

    private inline fun step(f: () -> Unit) { try { f() } catch (t: Throwable) { } }

    private fun rtl(a: Activity) = a.resources.configuration.layoutDirection == View.LAYOUT_DIRECTION_RTL

    private fun csl(c: Int) = ColorStateList.valueOf(c)

    private fun setInt(o: Any?, field: String, v: Int) {
        if (o == null) return
        try { o.javaClass.getField(field).setInt(o, v) } catch (t: Throwable) { }
    }

    // ------------------------------------------------------------------ header
    private fun header(s: S, on: Boolean) {
        val a = s.a
        val bar = Con.find<ViewGroup>(a, "appbar") ?: return
        val tb = bar.getChildAt(0) as? ViewGroup ?: return
        val p = Con.pal(a)
        if (s.hair == null) {
            s.hair = Con.hairline(a, p.line)
            bar.addView(s.hair)
        }
        s.hair?.visibility = if (on) View.VISIBLE else View.GONE
        if (!on) {
            if (s.styled) {
                s.styled = false
                Con.call(tb, "setTitle", s.origTitle ?: "")
                Con.call(tb, "setNavigationIcon", null)
                Con.call(tb, "setNavigationOnClickListener", null)
            }
            return
        }
        if (!s.styled) {
            s.styled = true
            s.origTitle = Con.call(tb, "getTitle") as? CharSequence
            bar.setBackgroundColor(p.page)
            bar.elevation = 0f
            bar.stateListAnimator = null
            Con.call(bar, "setLiftOnScroll", false)
            tb.setBackgroundColor(p.page)
            tb.layoutParams?.let { it.height = Con.dp(a, 52); tb.layoutParams = it }
            Con.call(tb, "setTitleCentered", false)
            Con.call(tb, "setTitleMarginStart", Con.dp(a, 10))
        }
        if (Con.call(tb, "getTitle")?.toString() != TITLE) Con.call(tb, "setTitle", TITLE)
        if (Con.call(tb, "getNavigationIcon") == null) {
            Con.call(tb, "setNavigationIcon", Con.icon(a, if (rtl(a)) "zl_ic_arrow_forward" else "zl_ic_arrow_back"))
            @Suppress("DEPRECATION")
            Con.call(tb, "setNavigationOnClickListener", View.OnClickListener { a.onBackPressed() })
        }
        for (v in Con.allOf(tb, { it is TextView })) {
            val t = v as TextView
            if (!Con.seen(t, "np-title")) { t.textSize = 17f; t.setTextColor(p.text); t.typeface = ZelligeHome.face(600) }
        }
        for (v in Con.allOf(tb, { it is ImageButton })) {
            val b = v as ImageButton
            if (Con.seen(b, "np-nav")) continue
            b.imageTintList = csl(p.dim)
            b.background = Con.ripple(Con.rounded(Color.TRANSPARENT, Con.dpf(a, 10f), p.border, Con.dp(a, 1).coerceAtLeast(1)), Con.dpf(a, 10f))
            val pad = Con.dp(a, 8)
            b.setPadding(pad, pad, pad, pad)
            b.layoutParams?.let { it.width = Con.dp(a, 36); it.height = Con.dp(a, 36); b.layoutParams = it }
        }
    }

    // ------------------------------------------------------------------ segmented «من قالب | من وصف»
    private fun segment(s: S, list: ViewGroup?, on: Boolean) {
        val a = s.a
        val host = Con.find<FrameLayout>(a, "fragment_containers_parent") ?: return
        val p = Con.pal(a)
        if (s.seg == null) {
            val row = LinearLayout(a).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                setPadding(Con.dp(a, 3), Con.dp(a, 3), Con.dp(a, 3), Con.dp(a, 3))
                background = Con.rounded(p.field, Con.dpf(a, 10f), p.border, Con.dp(a, 1).coerceAtLeast(1))
            }
            val first = Con.text(a, "من قالب", 13f, p.amber, ZelligeHome.face(500)).apply {
                gravity = Gravity.CENTER
                background = Con.rounded(p.chipHi, Con.dpf(a, 7f))
            }
            val second = LinearLayout(a).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
                background = Con.ripple(null, Con.dpf(a, 7f))
                isClickable = true; isFocusable = true
                setOnClickListener { AiChat.open(a, DESCRIBE_PROMPT, false) }
                addView(Con.iconView(a, "zl_ic_sparkle", p.muted, 14), LinearLayout.LayoutParams(Con.dp(a, 14), Con.dp(a, 14)).apply { marginEnd = Con.dp(a, 6) })
                addView(Con.text(a, "من وصف", 13f, p.muted))
            }
            row.addView(first, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
            row.addView(second, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
            val lp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Con.dp(a, 40), Gravity.TOP).apply {
                setMargins(Con.dp(a, 16), Con.dp(a, 8), Con.dp(a, 16), 0)
            }
            host.addView(row, lp)
            s.seg = row
        }
        s.seg?.visibility = if (on) View.VISIBLE else View.GONE
        list?.let {
            val top = if (on) Con.dp(a, 56) else 0
            if (it.paddingTop != top) it.setPadding(it.paddingLeft, top, it.paddingRight, it.paddingBottom)
        }
    }

    // ------------------------------------------------------------------ template list
    private fun listScreen(a: Activity, box: ViewGroup) {
        val p = Con.pal(a)
        Con.find<TextView>(box, a, "title")?.let { label(a, p, it, "TEMPLATE") }
        val rv = Con.find<ViewGroup>(box, a, "list")
        if (rv != null) {
            if (!Con.seen(rv, "np-rv")) rv.clipToPadding = false
            for (i in 0 until rv.childCount) templateRow(a, p, rv.getChildAt(i))
        }
        Con.find<View>(box, a, "exit_button")?.let { describeLink(a, p, it) }
    }

    /** عنوان القسم: mono 11sp بحروف كبيرة وتباعد؛ `fixed` = نص ثابت (TEMPLATE) وإلا كنكبّرو النص الحالي. */
    private fun label(a: Activity, p: Con.P, t: TextView, fixed: String?) {
        val want = (fixed ?: t.text.toString()).uppercase()
        if (t.text.toString() != want) t.text = want
        if (Con.seen(t, "np-label")) return
        t.textSize = 11f
        t.setTextColor(p.muted)
        t.typeface = Con.mono(a)
        t.letterSpacing = 0.12f
        t.textDirection = View.TEXT_DIRECTION_LTR
        t.textAlignment = View.TEXT_ALIGNMENT_VIEW_START
        (t.layoutParams as? ViewGroup.MarginLayoutParams)?.let {
            it.setMargins(Con.dp(a, 16), Con.dp(a, 14), Con.dp(a, 16), Con.dp(a, 6)); t.layoutParams = it
        }
    }

    private fun templateRow(a: Activity, p: Con.P, card: View) {
        val inner = (card as? ViewGroup)?.getChildAt(0) as? LinearLayout ?: return
        if (!Con.seen(card, "np-row")) {
            Con.call(card, "setStrokeWidth", 0)
            Con.call(card, "setRadius", 0f)
            Con.call(card, "setCardElevation", 0f)
            Con.call(card, "setCardBackgroundColor", Color.TRANSPARENT)
            Con.call(card, "setUseCompatPadding", false)
            Con.call(card, "setPreventCornerOverlap", false)
            inner.orientation = LinearLayout.HORIZONTAL
            inner.gravity = Gravity.CENTER_VERTICAL
            inner.setPaddingRelative(Con.dp(a, 16), 0, Con.dp(a, 16), 0)
            inner.layoutParams?.let { it.width = ViewGroup.LayoutParams.MATCH_PARENT; it.height = ViewGroup.LayoutParams.MATCH_PARENT; inner.layoutParams = it }
            LayerDrawable(arrayOf<android.graphics.drawable.Drawable>(ColorDrawable(Color.TRANSPARENT), ColorDrawable(p.line))).also {
                it.setLayerGravity(1, Gravity.BOTTOM); it.setLayerHeight(1, 1); inner.background = it
            }
            inner.findViewById<View>(Con.id(a, "template_icon"))?.visibility = View.GONE
            inner.findViewById<TextView>(Con.id(a, "template_name"))?.apply {
                setLines(1)
                maxLines = 1
                textSize = 14.5f
                typeface = ZelligeHome.face(500)
                setTextColor(p.text)
                gravity = Gravity.CENTER_VERTICAL or Gravity.START
                textDirection = View.TEXT_DIRECTION_LTR
                textAlignment = View.TEXT_ALIGNMENT_VIEW_START
                (layoutParams as? LinearLayout.LayoutParams)?.let {
                    it.width = 0; it.height = ViewGroup.LayoutParams.WRAP_CONTENT; it.weight = 1f; it.topMargin = 0; layoutParams = it
                }
            }
            // دائرة اختيار فارغة (كتعمّر عنبري مللي كتضغط على الصف)
            val ring = View(a).apply {
                isDuplicateParentStateEnabled = true
                background = StateListDrawable().apply {
                    addState(intArrayOf(android.R.attr.state_pressed), ring(a, p.amber, true))
                    addState(intArrayOf(), ring(a, p.border, false))
                }
            }
            inner.addView(ring, 0, LinearLayout.LayoutParams(Con.dp(a, 20), Con.dp(a, 20)).apply { marginEnd = Con.dp(a, 14) })
        }
        card.layoutParams?.let {
            if (it.width != ViewGroup.LayoutParams.MATCH_PARENT || it.height != Con.dp(a, 52)) {
                it.width = ViewGroup.LayoutParams.MATCH_PARENT; it.height = Con.dp(a, 52); card.layoutParams = it
            }
            (it as? ViewGroup.MarginLayoutParams)?.let { m -> if (m.leftMargin != 0 || m.topMargin != 0) { m.setMargins(0, 0, 0, 0); card.layoutParams = m } }
        }
    }

    private fun ring(a: Activity, c: Int, filled: Boolean): android.graphics.drawable.Drawable {
        val outer = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.TRANSPARENT); setStroke(Con.dp(a, 2), c) }
        if (!filled) return outer
        val dot = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(c) }
        return LayerDrawable(arrayOf(outer, dot)).also { val i = Con.dp(a, 6); it.setLayerInset(1, i, i, i, i) }
    }

    /** «Exit» ← رابط عنبري «✦ أو صف التطبيق للذكاء ليبنيه لك» فوسط أسفل الشاشة. */
    private fun describeLink(a: Activity, p: Con.P, b: View) {
        if (Con.seen(b, "np-ai")) return
        Con.call(b, "setText", "أو صف التطبيق للذكاء ليبنيه لك")
        Con.call(b, "setTextColor", p.amber)
        Con.call(b, "setTextSize", 13f)
        Con.call(b, "setAllCaps", false)
        Con.call(b, "setStrokeWidth", 0)
        Con.call(b, "setBackgroundTintList", csl(Color.TRANSPARENT))
        Con.call(b, "setRippleColor", csl(Color.argb(40, 255, 180, 84)))
        Con.call(b, "setIcon", Con.icon(a, "zl_ic_sparkle"))
        Con.call(b, "setIconTint", csl(p.amber))
        Con.call(b, "setIconSize", Con.dp(a, 15))
        Con.call(b, "setIconPadding", Con.dp(a, 8))
        b.layoutParams?.let {
            setInt(it, "startToStart", 0); setInt(it, "endToEnd", 0)
            (it as? ViewGroup.MarginLayoutParams)?.bottomMargin = Con.dp(a, 24)
            b.layoutParams = it
        }
        b.setOnClickListener { AiChat.open(a, DESCRIBE_PROMPT, false) }
    }

    // ------------------------------------------------------------------ details
    private fun detailsScreen(a: Activity, box: ViewGroup) {
        val p = Con.pal(a)
        Con.find<TextView>(box, a, "title")?.let { label(a, p, it, null) }
        val rv = Con.find<ViewGroup>(box, a, "widgets")
        if (rv != null) {
            if (!Con.seen(rv, "np-rv")) rv.clipToPadding = false
            for (i in 0 until rv.childCount) widgetViews(a, p, rv.getChildAt(i))
        }
        Con.find<View>(box, a, "previous")?.let { prev ->
            if (!Con.seen(prev, "np-prev")) {
                prev.visibility = View.INVISIBLE        // الرجوع كيتم من السهم فالترويسة (نفس الـ back)
                prev.layoutParams?.let { it.height = Con.dp(a, 52); prev.layoutParams = it }
            }
        }
        Con.find<View>(box, a, "finish")?.let { createButton(a, p, it) }
    }

    private fun createButton(a: Activity, p: Con.P, b: View) {
        if (Con.seen(b, "np-fin")) return
        Con.call(b, "setText", "إنشاء المشروع")
        Con.call(b, "setAllCaps", false)
        Con.call(b, "setTextSize", 15.5f)
        Con.call(b, "setTextColor", p.onAmber)
        (b as? TextView)?.typeface = ZelligeHome.face(600)
        Con.call(b, "setBackgroundTintList", csl(p.amber))
        Con.call(b, "setCornerRadius", Con.dp(a, 12))
        Con.call(b, "setIcon", Con.icon(a, if (rtl(a)) "zl_ic_arrow_back" else "zl_ic_arrow_forward"))
        Con.call(b, "setIconTint", csl(p.onAmber))
        Con.call(b, "setIconSize", Con.dp(a, 18))
        Con.call(b, "setIconPadding", Con.dp(a, 8))
        Con.call(b, "setIconGravity", 4)          // ICON_GRAVITY_TEXT_END
        Con.call(b, "setInsetTop", 0)
        Con.call(b, "setInsetBottom", 0)
        b.layoutParams?.let {
            it.width = 0                           // MATCH_CONSTRAINT بين الحافتين
            it.height = Con.dp(a, 52)
            setInt(it, "startToStart", 0); setInt(it, "endToEnd", 0)
            b.layoutParams = it
        }
    }

    /** كل الحقول فصف الويدجت: TextInputLayout (نصية/قائمة) وCheckBox. */
    private fun widgetViews(a: Activity, p: Con.P, row: View) {
        for (v in Con.allOf(row, { it.javaClass.simpleName == "TextInputLayout" })) field(a, p, v)
        for (v in Con.allOf(row, { it.javaClass.simpleName.endsWith("CheckBox") })) {
            if (Con.seen(v, "np-cb")) continue
            Con.call(v, "setButtonTintList", csl(p.amber))
            (v as? TextView)?.apply { setTextColor(p.text2); textSize = 14f }
        }
    }

    private fun field(a: Activity, p: Con.P, til: View) {
        if (Con.seen(til, "np-field")) return
        val r = Con.dpf(a, 10f)
        val stroke = if (p.dark) 0xFF2C3341.toInt() else p.border
        Con.call(til, "setBoxCornerRadii", r, r, r, r)
        Con.call(til, "setBoxBackgroundColor", p.field)
        Con.call(til, "setBoxStrokeColorStateList", ColorStateList(
            arrayOf(intArrayOf(android.R.attr.state_focused), intArrayOf()), intArrayOf(p.amber, stroke)))
        Con.call(til, "setBoxStrokeWidth", Con.dp(a, 1).coerceAtLeast(1))
        Con.call(til, "setBoxStrokeWidthFocused", Con.dp(a, 1).coerceAtLeast(1))
        Con.call(til, "setDefaultHintTextColor", csl(p.muted))
        Con.call(til, "setHintTextColor", csl(p.amber))
        val et = Con.call(til, "getEditText") as? EditText ?: return
        et.setTextColor(p.text)
        et.textSize = 14.5f
        val hint = (Con.call(til, "getHint") as? CharSequence)?.toString().orEmpty().lowercase()
        if (hint.contains("package") || hint.contains("حزمة")) {
            et.typeface = Con.mono(a)
            et.textSize = 13f
            et.setTextColor(p.amber)
            et.textDirection = View.TEXT_DIRECTION_LTR
        }
    }
}
