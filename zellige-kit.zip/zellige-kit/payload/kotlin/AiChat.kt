package com.itsaky.androidide.ai

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.InputType
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.TextUtils
import android.text.TextWatcher
import android.text.style.BackgroundColorSpan
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.text.style.StyleSpan
import android.text.style.TypefaceSpan
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.PopupMenu
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.widget.NestedScrollView
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.button.MaterialButton
import com.google.android.material.chip.Chip
import java.io.File

object AiChat {

    private val ui = Handler(Looper.getMainLooper())
    @Volatile private var busy = false
    @Volatile private var reqId = 0
    @Volatile private var lastError: String? = null
    @Volatile private var status: String = ""
    private var onChange: (() -> Unit)? = null
    private var sheet: BottomSheetDialog? = null

    private var pendingPrompt: String? = null
    private var pendingSend = false

    /** يفتح الشات (مع نص جاهز، وإرساله مباشرة إذا send). */
    fun open(a: Activity, prompt: String?, send: Boolean) {
        pendingPrompt = prompt
        pendingSend = send
        show(a)
    }

    internal fun statusText(): String = status
    internal fun isBusy(): Boolean = busy
    internal fun errorText(): String? = lastError

    /** مراقب خارجي (اللوحة الصغيرة فالمحرر): كيتنادى من الـ UI thread مع كل تغيّر فحالة الوكيل. */
    internal var observer: (() -> Unit)? = null

    /**
     * يشغّل المهمة بلا ما يفتح الشات (من شريط الذكاء فالمحرر): الكود يبقى باين والنتيجة كتبان فاللوحة الصغيرة.
     * من الـ UI thread. يرجع true إلا بدات المهمة.
     */
    fun runDetached(a: Activity, prompt: String): Boolean {
        if (busy) {
            Toast.makeText(a, "الوكيل مازال خدّام، سنّى شويا أو أوقفو", Toast.LENGTH_SHORT).show()
            return false
        }
        if (!AiPrefs(a).ready()) {
            Toast.makeText(a, "ضع مفتاح API أولا", Toast.LENGTH_LONG).show()
            showSettings(a)
            return false
        }
        startRun(a, prompt)
        return true
    }

    /** «كتابة path» ← (write, path): اسم الأداة بخط mono مثل سجل الترمنال. */
    internal fun toolOf(label: String): Pair<String, String> {
        val verb = label.substringBefore(' ')
        val rest = label.substringAfter(' ', "").ifBlank { label }
        val tool = when (verb) {
            "كتابة" -> "write"; "تعديل" -> "edit"; "إدراج" -> "insert"; "فتح" -> "open"; "قراءة" -> "read"
            "عرض" -> "list_dir"; "إنشاء" -> "mkdir"; "حذف" -> "delete"; "نقل" -> "move"; "بحث" -> "search"
            "تنفيذ" -> "run"
            else -> ""
        }
        if (tool.isEmpty()) return "" to label
        return tool to rest.removePrefix("المجلد ").removePrefix("المشروع ").removePrefix("كود فـ ").removePrefix("أمر: ")
    }

    /** يسدّ نافذة الشات (كيتنادى لمّا يبدا التطبيق المباشر باش المستعمل يشوف المحرر). */
    fun dismissSheet() {
        ui.post { runCatching { sheet?.dismiss() } }
    }

    /** إيقاف المهمة الجارية (من زر الشات أو من الـ HUD). */
    fun stop(a: Activity) {
        reqId++; busy = false; status = ""
        val last = AiPlugin.history.lastOrNull()
        if (last != null && last.role == "user" && !AiAgent.isResults(last)) AiPlugin.history.removeAt(AiPlugin.history.lastIndex)
        AiPlugin.save(a)
        notifyChange()
        runCatching { AiHud.hide(a) }
    }

    private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    internal const val MAX_STEPS = 40

    private fun notifyChange() { ui.post { onChange?.invoke(); observer?.invoke(); AiHud.refresh() } }

    // ------------------------------------------------------------------ theme
    /** الألوان كتتجاب من theme ديال التطبيق نفسو (Material) باش المساعد يكون منسجم معاه 100%. */
    internal class Pal(val dark: Boolean, private val a: Activity?, private val useApp: Boolean) {
        private fun c(names: List<String>, fb: Int): Int {
            if (a == null || !useApp) return fb
            for (n in names) {
                try {
                    val id = a.resources.getIdentifier(n, "attr", a.packageName)
                    if (id == 0) continue
                    val tv = TypedValue()
                    if (a.theme.resolveAttribute(id, tv, true) &&
                        tv.type >= TypedValue.TYPE_FIRST_COLOR_INT && tv.type <= TypedValue.TYPE_LAST_COLOR_INT
                    ) return tv.data
                } catch (t: Throwable) { /* نجرب اسم آخر */ }
            }
            return fb
        }

        private fun hex(d: String, l: String) = Color.parseColor(if (dark) d else l)

        val bg = c(listOf("colorSurfaceContainerHigh", "colorSurface"), hex("#0A0C10", "#F7F6F2"))
        val surface = c(listOf("colorSurfaceContainerHighest", "colorSurfaceVariant"), hex("#161A23", "#E9E8E3"))
        val text = c(listOf("colorOnSurface"), hex("#D9DDE5", "#14171C"))
        val sub = c(listOf("colorOnSurfaceVariant"), hex("#A5ADBB", "#4A5160"))
        private fun mix(x: Int, y: Int, t: Float): Int {
            fun ch(p: Int, q: Int) = (p + (q - p) * t).toInt().coerceIn(0, 255)
            return Color.rgb(ch(Color.red(x), Color.red(y)), ch(Color.green(x), Color.green(y)), ch(Color.blue(x), Color.blue(y)))
        }
        /** حدّ رفيع (hairline) مشتق من الخلفية والنص، بدل لون outline الغامق. */
        val line = mix(bg, text, 0.13f)
        val accent = c(listOf("colorPrimary"), Color.parseColor("#FFB454"))
        val onAccent = c(listOf("colorOnPrimary"), hex("#1A1000", "#FFFFFF"))
        val accentBox = c(listOf("colorPrimaryContainer"), hex("#3A290C", "#FFE2B8"))
        val onAccentBox = c(listOf("colorOnPrimaryContainer"), hex("#FFD9A0", "#2D1A00"))
        val danger = c(listOf("colorError"), Color.parseColor("#FF7A7A"))
        val onDanger = c(listOf("colorOnError"), hex("#2A0608", "#FFFFFF"))
        val codeBg = Color.parseColor("#07090D")
        val codeText = Color.parseColor("#D9DDE5")
        val inlineBg = line
        val okColor = c(listOf("colorTertiary"), hex("#7BD88F", "#1E7A3B"))
    }

    private data class Seg(val isCode: Boolean, val text: String, val lang: String = "")

    internal fun pal(a: Activity): Pal {
        val night = (a.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
        val theme = AiPrefs(a).theme
        val dark = when (theme) {
            "dark" -> true
            "light" -> false
            else -> night
        }
        return Pal(dark, a, theme == "auto")
    }

    /** ألوان الزر العائم: نفس ألوان FAB ديال Material 3 (primary container). */
    fun fabStyle(a: Activity): IntArray {
        val p = pal(a)
        return intArrayOf(p.accentBox, p.onAccentBox)
    }

    /** أيقونات vector كيصاوبها السكريبت فـ res/drawable. */
    fun icon(a: Activity, name: String): Drawable? {
        for (pkg in listOf(a.packageName, "com.itsaky.androidide")) {
            val id = a.resources.getIdentifier(name, "drawable", pkg)
            if (id != 0) return a.getDrawable(id)?.mutate()
        }
        return null
    }

    // ------------------------------------------------------------------ view helpers
    internal fun dp(a: Activity, v: Int) = (v * a.resources.displayMetrics.density).toInt()

    internal fun shape(color: Int, radius: Float) = GradientDrawable().apply {
        setColor(color); cornerRadius = radius
    }

    internal fun outlined(color: Int, radius: Float, line: Int, w: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = radius; setStroke(w.coerceAtLeast(1), line)
    }

    internal fun ripple(content: Drawable, radius: Float): Drawable =
        RippleDrawable(ColorStateList.valueOf(Color.argb(70, 150, 150, 160)), content, shape(Color.WHITE, radius))

    internal fun iconButton(
        a: Activity, name: String, desc: String, fg: Int, bgc: Int, sizeDp: Int, onClick: () -> Unit
    ): ImageView {
        val oval = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(bgc) }
        val mask = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.WHITE) }
        return ImageView(a).apply {
            setImageDrawable(icon(a, name))
            imageTintList = ColorStateList.valueOf(fg)
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            val pad = dp(a, sizeDp) * 28 / 100
            setPadding(pad, pad, pad, pad)
            background = RippleDrawable(ColorStateList.valueOf(Color.argb(60, 150, 150, 160)), oval, mask)
            contentDescription = desc
            isClickable = true; isFocusable = true
            setOnClickListener { onClick() }
        }
    }

    private fun materialButton(a: Activity, p: Pal, label: String, filled: Boolean, onClick: () -> Unit): MaterialButton =
        MaterialButton(a).apply {
            text = label
            setAllCaps(false)
            cornerRadius = dp(a, 10)
            if (filled) {
                backgroundTintList = ColorStateList.valueOf(p.accent)
                setTextColor(p.onAccent)
            } else {
                backgroundTintList = ColorStateList.valueOf(Color.TRANSPARENT)
                setTextColor(p.accent)
                strokeWidth = dp(a, 1)
                strokeColor = ColorStateList.valueOf(p.line)
            }
            setOnClickListener { onClick() }
        }

    /** عنصر اختيار بشكل بطاقة (بديل Spinner): كيفتح قائمة اختيار نظيفة. */
    private class Sel(val view: LinearLayout, val label: TextView, var index: Int)

    private fun selector(
        a: Activity, p: Pal, title: String, items: List<String>, start: Int, onPick: (Int) -> Unit
    ): Sel {
        val label = TextView(a).apply {
            setTextColor(p.text); textSize = 14f; setSingleLine()
            ellipsize = TextUtils.TruncateAt.END
            textDirection = View.TEXT_DIRECTION_ANY_RTL
        }
        val chevron = ImageView(a).apply {
            setImageDrawable(icon(a, "ic_ai_chevron"))
            imageTintList = ColorStateList.valueOf(p.sub)
        }
        val view = LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = ripple(outlined(p.surface, dp(a, 10).toFloat(), p.line, dp(a, 1)), dp(a, 10).toFloat())
            setPadding(dp(a, 16), dp(a, 13), dp(a, 12), dp(a, 13))
            isClickable = true; isFocusable = true
            addView(label, LinearLayout.LayoutParams(0, WRAP, 1f))
            addView(chevron, LinearLayout.LayoutParams(dp(a, 22), dp(a, 22)))
        }
        val sel = Sel(view, label, start.coerceIn(0, (items.size - 1).coerceAtLeast(0)))
        label.text = items.getOrElse(sel.index) { "" }
        view.setOnClickListener {
            AlertDialog.Builder(a)
                .setTitle(title)
                .setSingleChoiceItems(items.toTypedArray(), sel.index) { d, which ->
                    sel.index = which
                    label.text = items[which]
                    d.dismiss()
                    onPick(which)
                }
                .show()
        }
        return sel
    }

    /** نافذة اختيار الموديل مع بحث (كتتحمل بلائحة المزوّد كاملة). */
    private fun pickModel(a: Activity, p: Pal, models: List<String>, onPick: (String) -> Unit) {
        val shown = ArrayList<String>(models)
        val ad = object : ArrayAdapter<String>(a, android.R.layout.simple_list_item_1, shown) {
            override fun getView(pos: Int, v: View?, g: ViewGroup): View =
                (super.getView(pos, v, g) as TextView).apply {
                    setTextColor(p.text); textSize = 13.5f
                    textDirection = View.TEXT_DIRECTION_LTR
                }
        }
        val search = EditText(a).apply {
            hint = "ابحث بين ${models.size} موديل…"
            setTextColor(p.text); setHintTextColor(p.sub); setSingleLine()
            textDirection = View.TEXT_DIRECTION_ANY_RTL
        }
        val lv = ListView(a).apply { adapter = ad }
        val col = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(a, 20), dp(a, 8), dp(a, 20), 0)
            addView(search, LinearLayout.LayoutParams(MATCH, WRAP))
            addView(lv, LinearLayout.LayoutParams(MATCH, dp(a, 380)))
        }
        val dlg = AlertDialog.Builder(a).setTitle("اختر الموديل").setView(col).setNegativeButton("إغلاق", null).create()
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, af: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {
                val q = s?.toString().orEmpty().trim()
                ad.clear()
                ad.addAll(if (q.isEmpty()) models else models.filter { it.contains(q, ignoreCase = true) })
                ad.notifyDataSetChanged()
            }
            override fun afterTextChanged(s: Editable?) {}
        })
        lv.setOnItemClickListener { _, _, pos, _ ->
            ad.getItem(pos)?.let { onPick(it) }
            dlg.dismiss()
        }
        dlg.show()
    }

    /** يضبط BottomSheetDialog: يتمدد لأعلى الشاشة، بلا حالة مطوية، والخلفية ديال المحتوى هي اللي كتبان. */
    private fun setupSheet(a: Activity, dialog: BottomSheetDialog, content: View, topOffsetDp: Int) {
        dialog.setContentView(content)
        dialog.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        val off = dp(a, topOffsetDp)
        (content.parent as? View)?.let { sheet ->
            sheet.setBackgroundColor(Color.TRANSPARENT)
            // ارتفاع الـ sheet = ارتفاع النافذة - الهامش العلوي (يتغير مع الكيبورد) باش خانة الكتابة تبقى ظاهرة
            (sheet.parent as? View)?.addOnLayoutChangeListener { _, _, t, _, b, _, _, _, _ ->
                val h = (b - t) - off
                if (h > 0 && sheet.layoutParams.height != h) {
                    sheet.layoutParams.height = h
                    sheet.requestLayout()
                }
            }
        }
        dialog.behavior.apply {
            skipCollapsed = true
            // ارتفاع الـ sheet ثابت (النافذة - الهامش)، فنستعمل fitToContents باش ما يبقاش HALF_EXPANDED كيخبّي خانة الكتابة
            isFitToContents = true
            state = BottomSheetBehavior.STATE_EXPANDED
        }
    }

    private fun sheetBackground(a: Activity, p: Pal) = GradientDrawable().apply {
        setColor(p.bg)
        val r = dp(a, 12).toFloat()
        cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
    }

    // ------------------------------------------------------------------ markdown (خفيف)
    private fun parse(s: String): List<Seg> {
        val out = mutableListOf<Seg>()
        val re = Regex("```([A-Za-z0-9_+#.-]*)[ \\t]*\\r?\\n([\\s\\S]*?)```")
        var last = 0
        for (m in re.findAll(s)) {
            if (m.range.first > last) out.add(Seg(false, s.substring(last, m.range.first)))
            out.add(Seg(true, m.groupValues[2].trimEnd(), m.groupValues[1]))
            last = m.range.last + 1
        }
        if (last < s.length) out.add(Seg(false, s.substring(last)))
        return out.filter { it.isCode || it.text.isNotBlank() }
    }

    /** عناوين # ، **bold** ، `inline code` ، ونقط القوائم. */
    private fun md(p: Pal, s: String): CharSequence {
        val sb = SpannableStringBuilder()
        val inline = Regex("\\*\\*(.+?)\\*\\*|`([^`]+)`")
        val head = Regex("^#{1,6}\\s+(.*)$")
        val bullet = Regex("^\\s*[-*]\\s+")
        val lines = s.trim().split("\n")
        lines.forEachIndexed { idx, raw ->
            var line = raw
            var header = false
            val hm = head.find(line)
            if (hm != null) { line = hm.groupValues[1]; header = true }
            else if (bullet.containsMatchIn(line)) line = line.replace(bullet, "• ")
            val start = sb.length
            var last = 0
            for (m in inline.findAll(line)) {
                sb.append(line.substring(last, m.range.first))
                val st = sb.length
                if (m.groups[1] != null) {
                    sb.append(m.groupValues[1])
                    sb.setSpan(StyleSpan(Typeface.BOLD), st, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                } else {
                    sb.append(m.groupValues[2])
                    sb.setSpan(TypefaceSpan("monospace"), st, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    sb.setSpan(BackgroundColorSpan(p.inlineBg), st, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
                last = m.range.last + 1
            }
            sb.append(line.substring(last))
            if (header) {
                sb.setSpan(StyleSpan(Typeface.BOLD), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                sb.setSpan(RelativeSizeSpan(1.1f), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
            if (idx < lines.lastIndex) sb.append("\n")
        }
        return sb
    }

    // ------------------------------------------------------------------ chat sheet
    fun show(a: Activity) {
        val prefs = AiPrefs(a)
        val p = pal(a)
        val dialog = BottomSheetDialog(a)
        val rtl = a.resources.configuration.layoutDirection == View.LAYOUT_DIRECTION_RTL
        var stickNext = false

        fun toast(s: String, long: Boolean = false) =
            Toast.makeText(a, s, if (long) Toast.LENGTH_LONG else Toast.LENGTH_SHORT).show()

        fun copy(code: String) {
            try {
                val cm = a.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("code", code))
                toast("تم النسخ")
            } catch (t: Throwable) { toast("تعذّر التنفيذ: ${t.message}", true) }
        }

        fun clip(): String? = try {
            val cm = a.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val c = cm.primaryClip
            if (c == null || c.itemCount == 0) null
            else c.getItemAt(0).coerceToText(a)?.toString()?.trim()?.takeIf { it.isNotEmpty() }
        } catch (t: Throwable) { null }

        // ---- القائمة (NestedScrollView + منع الـ BottomSheet من سرقة اللمسات = السكرول يخدم)
        val list = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(a, 8), 0, dp(a, 8))
        }
        val scroll = NestedScrollView(a).apply {
            addView(list)
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            isNestedScrollingEnabled = true
            setOnTouchListener { v, ev ->
                if (ev.action == MotionEvent.ACTION_DOWN || ev.action == MotionEvent.ACTION_MOVE) {
                    v.parent?.requestDisallowInterceptTouchEvent(true)
                }
                false
            }
        }

        val input = EditText(a).apply {
            hint = "اكتب طلبك…"
            setTextColor(p.text); setHintTextColor(p.sub)
            textSize = 14f
            background = outlined(p.surface, dp(a, 10).toFloat(), p.line, dp(a, 1))
            setPadding(dp(a, 14), dp(a, 12), dp(a, 14), dp(a, 12))
            maxLines = 5
            textDirection = View.TEXT_DIRECTION_ANY_RTL
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        }
        val send = iconButton(a, "ic_ai_send", "إرسال", p.onAccent, p.accent, 48) { }
        if (rtl) send.scaleX = -1f
        send.background = ripple(shape(p.accent, dp(a, 10).toFloat()), dp(a, 10).toFloat())
        /** وضع التنفيذ: auto = يطبّق مباشرة، ask = يسأل قبل كل تعديل. */
        val modeChip = TextView(a).apply {
            typeface = ZelligeHome.loadMono(a); textSize = 12f; gravity = Gravity.CENTER
            setPadding(dp(a, 12), 0, dp(a, 12), 0)
            isClickable = true; isFocusable = true
            textDirection = View.TEXT_DIRECTION_LTR
            fun paint() {
                text = if (prefs.askBeforeEdit) "ask" else "auto"
                setTextColor(p.accent)
                background = ripple(outlined(p.surface, dp(a, 10).toFloat(), p.line, dp(a, 1)), dp(a, 10).toFloat())
            }
            paint()
            setOnClickListener {
                prefs.askBeforeEdit = !prefs.askBeforeEdit
                paint()
                toast(if (prefs.askBeforeEdit) "وضع ask: يسألك قبل كل تعديل" else "وضع auto: يطبّق التعديل مباشرة")
            }
        }
        fun updateSend() {
            send.setImageDrawable(icon(a, if (busy) "ic_ai_stop" else "ic_ai_send"))
            send.contentDescription = if (busy) "إيقاف" else "إرسال"
            send.alpha = if (busy || input.text.isNotBlank()) 1f else 0.5f
        }
        input.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, af: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {
                send.alpha = if (busy || !s.isNullOrBlank()) 1f else 0.5f
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        // ---- تطبيق الكود على المحرر
        fun doInsert(code: String) {
            val ed = EditorAccess.find(a) ?: run { toast("ما كاين حتى ملف مفتوح"); return }
            try { ed.replaceSelection(code); toast("تم التطبيق — يمكنك التراجع من المحرر") }
            catch (t: Throwable) { toast("تعذّر التنفيذ: ${t.message}", true) }
        }

        fun doReplace(code: String) {
            val ed = EditorAccess.find(a) ?: run { toast("ما كاين حتى ملف مفتوح"); return }
            val old = ed.allText()
            AlertDialog.Builder(a)
                .setTitle("استبدال الملف كامل؟")
                .setMessage("${old.lines().size} سطر ← ${code.lines().size} سطر\n(تقدر دير Undo فالمحرر)")
                .setPositiveButton("استبدل") { _, _ ->
                    try { ed.replaceAll(code); toast("تم التطبيق — يمكنك التراجع من المحرر") }
                    catch (t: Throwable) { toast("تعذّر التنفيذ: ${t.message}", true) }
                }
                .setNegativeButton("إلغاء", null)
                .show()
        }

        // ---- عناصر الرسائل
        fun codeView(s: Seg): View {
            val box = LinearLayout(a).apply {
                orientation = LinearLayout.VERTICAL
                background = outlined(p.codeBg, dp(a, 10).toFloat(), p.line, dp(a, 1))
                setPadding(dp(a, 12), dp(a, 8), dp(a, 12), dp(a, 10))
            }
            val bar = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            bar.addView(TextView(a).apply {
                text = s.lang.ifBlank { "code" }; setTextColor(Color.parseColor("#8A8A9A")); textSize = 11.5f
                typeface = Typeface.MONOSPACE; textDirection = View.TEXT_DIRECTION_LTR
            }, LinearLayout.LayoutParams(0, WRAP, 1f))
            fun mini(label: String, f: () -> Unit) {
                bar.addView(TextView(a).apply {
                    text = label; textSize = 11.5f; setTextColor(p.codeText); gravity = Gravity.CENTER
                    setPadding(dp(a, 12), dp(a, 6), dp(a, 12), dp(a, 6))
                    background = ripple(shape(Color.parseColor("#1E2530"), dp(a, 8).toFloat()), dp(a, 8).toFloat())
                    isClickable = true; isFocusable = true
                    setOnClickListener { f() }
                }, LinearLayout.LayoutParams(WRAP, WRAP).apply { marginStart = dp(a, 6) })
            }
            mini("نسخ") { copy(s.text) }
            mini("إدراج") { doInsert(s.text) }
            mini("استبدال") { doReplace(s.text) }

            val tv = TextView(a).apply {
                text = s.text; setTextColor(p.codeText); textSize = 12.5f; typeface = Typeface.MONOSPACE
                setTextIsSelectable(true); textDirection = View.TEXT_DIRECTION_LTR
                setHorizontallyScrolling(true)
                setPadding(0, dp(a, 8), 0, 0)
            }
            val hs = HorizontalScrollView(a).apply {
                addView(tv); isHorizontalScrollBarEnabled = false; layoutDirection = View.LAYOUT_DIRECTION_LTR
            }
            box.addView(bar)
            box.addView(hs)
            return box
        }

        /** كود طويل وصل للشات: ما كنعرضوهش، كنعرضو بطاقة صغيرة فيها أزرار (إدراج/استبدال/نسخ) فقط. */
        fun codeChip(s: Seg): View {
            val n = s.text.lines().size
            val box = LinearLayout(a).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                background = outlined(Color.TRANSPARENT, dp(a, 10).toFloat(), p.line, dp(a, 1))
                setPadding(dp(a, 12), dp(a, 8), dp(a, 8), dp(a, 8))
            }
            box.addView(TextView(a).apply {
                text = "‹/›  " + (s.lang.ifBlank { "كود" }) + " · " + n + " سطر"
                setTextColor(p.sub); textSize = 12.5f; setSingleLine()
                ellipsize = TextUtils.TruncateAt.END; textDirection = View.TEXT_DIRECTION_ANY_RTL
            }, LinearLayout.LayoutParams(0, WRAP, 1f))
            fun mini(label: String, f: () -> Unit) {
                box.addView(TextView(a).apply {
                    text = label; textSize = 12f; setTextColor(p.text); gravity = Gravity.CENTER
                    setPadding(dp(a, 12), dp(a, 6), dp(a, 12), dp(a, 6))
                    background = ripple(shape(p.surface, dp(a, 8).toFloat()), dp(a, 8).toFloat())
                    isClickable = true; isFocusable = true
                    setOnClickListener { f() }
                }, LinearLayout.LayoutParams(WRAP, WRAP).apply { marginStart = dp(a, 6) })
            }
            mini("إدراج") { doInsert(s.text) }
            mini("استبدال") { doReplace(s.text) }
            mini("نسخ") { copy(s.text) }
            return box
        }

        fun itemParams(@Suppress("UNUSED_PARAMETER") mine: Boolean) = LinearLayout.LayoutParams(MATCH, WRAP).apply {
            bottomMargin = dp(a, 10)
        }

        /** سجل الوكيل: كل أداة نفّذها (✓ نجحت / ✗ فشلت) بصفوف mono كثيفة. */
        fun activity(m: AiClient.Msg): View {
            val items = AiAgent.parseResults(m.content)
            val mono = ZelligeHome.loadMono(a)
            val col = LinearLayout(a).apply {
                orientation = LinearLayout.VERTICAL
                background = outlined(Color.TRANSPARENT, dp(a, 10).toFloat(), p.line, dp(a, 1))
                setPadding(dp(a, 12), dp(a, 6), dp(a, 12), dp(a, 6))
            }
            col.addView(TextView(a).apply {
                text = "AGENT LOG · ${items.size}"
                typeface = mono; textSize = 10.5f; letterSpacing = 0.12f; setTextColor(p.sub)
                textDirection = View.TEXT_DIRECTION_LTR; textAlignment = View.TEXT_ALIGNMENT_VIEW_START
                setPadding(0, dp(a, 4), 0, dp(a, 4))
            })
            items.forEach { (ok, label, detail) ->
                val (tool, target) = toolOf(label)
                val row = LinearLayout(a).apply {
                    orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                    layoutDirection = View.LAYOUT_DIRECTION_LTR
                    setPadding(0, dp(a, 5), 0, dp(a, 5))
                }
                row.addView(TextView(a).apply {
                    text = if (ok) "✓" else "✗"; typeface = mono; textSize = 12f
                    setTextColor(if (ok) p.okColor else p.danger)
                }, LinearLayout.LayoutParams(dp(a, 16), WRAP))
                if (tool.isNotEmpty()) {
                    row.addView(TextView(a).apply {
                        text = tool; typeface = mono; textSize = 11.5f
                        setTextColor(when (tool) { "write", "insert" -> p.okColor; "edit" -> p.accent; "delete" -> p.danger; else -> p.sub })
                    }, LinearLayout.LayoutParams(dp(a, 62), WRAP))
                }
                row.addView(TextView(a).apply {
                    text = target; typeface = mono; textSize = 11.5f; setTextColor(p.text)
                    setSingleLine(); ellipsize = TextUtils.TruncateAt.MIDDLE; textDirection = View.TEXT_DIRECTION_LTR
                }, LinearLayout.LayoutParams(0, WRAP, 1f))
                col.addView(row)
                if (!ok && detail.isNotBlank()) {
                    col.addView(TextView(a).apply {
                        text = detail.take(160); typeface = mono; textSize = 11f; setTextColor(p.danger)
                        textDirection = View.TEXT_DIRECTION_ANY_RTL
                        setPadding(dp(a, 16), 0, 0, dp(a, 4))
                    })
                }
            }
            col.layoutParams = itemParams(false)
            return col
        }

        fun bubble(m: AiClient.Msg): View? {
            if (AiAgent.isResults(m)) return if (AiAgent.parseResults(m.content).isEmpty()) null else activity(m)
            val mine = m.role == "user"
            val body = if (mine) m.content else AiAgent.strip(m.content)
            if (body.isBlank()) return null
            if (mine) {
                // طلب المستعمل: صندوق بحدّ رفيع و«›» عنبرية، مثل سطر الأوامر
                val row = LinearLayout(a).apply {
                    orientation = LinearLayout.HORIZONTAL
                    background = outlined(p.surface, dp(a, 10).toFloat(), p.line, dp(a, 1))
                    setPadding(dp(a, 12), dp(a, 10), dp(a, 12), dp(a, 10))
                }
                row.addView(TextView(a).apply {
                    text = "›"; typeface = ZelligeHome.loadMono(a); textSize = 15f; setTextColor(p.accent)
                    textDirection = View.TEXT_DIRECTION_LTR
                }, LinearLayout.LayoutParams(WRAP, WRAP).apply { marginEnd = dp(a, 10) })
                row.addView(TextView(a).apply {
                    text = body; setTextColor(p.text); textSize = 14f
                    setLineSpacing(0f, 1.2f)
                    setTextIsSelectable(true); textDirection = View.TEXT_DIRECTION_ANY_RTL
                }, LinearLayout.LayoutParams(0, WRAP, 1f))
                row.layoutParams = itemParams(true)
                return row
            }
            // جواب الوكيل: نص بلا فقاعة
            val col = LinearLayout(a).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(a, 2), dp(a, 2), dp(a, 2), dp(a, 2))
            }
            var first = true
            for (s in parse(body)) {
                val gap = if (first) 0 else dp(a, 6)
                first = false
                if (s.isCode) {
                    col.addView(if (s.text.lines().size >= 4) codeChip(s) else codeView(s), LinearLayout.LayoutParams(MATCH, WRAP).apply {
                        topMargin = maxOf(gap, dp(a, 4)); bottomMargin = dp(a, 4)
                    })
                } else {
                    col.addView(TextView(a).apply {
                        text = md(p, s.text); setTextColor(p.text); textSize = 14f
                        setLineSpacing(0f, 1.25f)
                        setTextIsSelectable(true); textDirection = View.TEXT_DIRECTION_ANY_RTL
                    }, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = gap })
                }
            }
            col.layoutParams = itemParams(false)
            return col
        }

        fun working(): View = LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = outlined(p.surface, dp(a, 10).toFloat(), p.line, dp(a, 1))
            setPadding(dp(a, 12), dp(a, 11), dp(a, 14), dp(a, 11))
            addView(ProgressBar(a).apply {
                isIndeterminate = true; indeterminateTintList = ColorStateList.valueOf(p.accent)
            }, LinearLayout.LayoutParams(dp(a, 16), dp(a, 16)))
            addView(TextView(a).apply {
                text = status.ifBlank { "جارٍ العمل…" }
                setTextColor(p.accent); textSize = 13f; setPadding(dp(a, 10), 0, 0, 0)
                setSingleLine(); ellipsize = TextUtils.TruncateAt.END
                textDirection = View.TEXT_DIRECTION_ANY_RTL
            }, LinearLayout.LayoutParams(0, WRAP, 1f))
            layoutParams = itemParams(false)
        }

        fun errorCard(e: String): View = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            background = shape(p.danger, dp(a, 10).toFloat())
            setPadding(dp(a, 14), dp(a, 10), dp(a, 14), dp(a, 12))
            addView(TextView(a).apply {
                text = "تعذّر إتمام الطلب"; setTextColor(p.onDanger); textSize = 13.5f; typeface = Typeface.DEFAULT_BOLD
            })
            addView(TextView(a).apply {
                text = e; setTextColor(p.onDanger); textSize = 12.5f; setTextIsSelectable(true)
                setPadding(0, dp(a, 4), 0, 0)
            })
            layoutParams = itemParams(false)
        }

        fun emptyState(): View {
            val col = LinearLayout(a).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(a, 4), dp(a, 28), dp(a, 4), dp(a, 8))
                layoutParams = LinearLayout.LayoutParams(MATCH, WRAP)
            }
            col.addView(FrameLayout(a).apply {
                background = outlined(p.surface, dp(a, 14).toFloat(), p.line, dp(a, 1))
                addView(ImageView(a).apply {
                    setImageDrawable(icon(a, "ic_ai_sparkle")); imageTintList = ColorStateList.valueOf(p.accent)
                }, FrameLayout.LayoutParams(dp(a, 30), dp(a, 30), Gravity.CENTER))
            }, LinearLayout.LayoutParams(dp(a, 64), dp(a, 64)))
            col.addView(TextView(a).apply {
                text = "وكيلك البرمجي جاهز"; setTextColor(p.text); textSize = 18f
                typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            }, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(a, 16) })
            col.addView(TextView(a).apply {
                text = "اكتب أمرا بسيطا وسأنفّذه مباشرة داخل التطبيق: أفتح الملف وأكتب فيه قدامك، وأنشئ المجلدات والشاشات والمشاريع."
                setTextColor(p.sub); textSize = 13.5f; gravity = Gravity.CENTER; setLineSpacing(0f, 1.25f)
            }, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(a, 6); bottomMargin = dp(a, 20) })
            listOf(
                "أنشئ مجلدا باسم login وضع فيه واجهة تسجيل دخول كاملة",
                "أنشئ مشروع أندرويد جديد باسم Notes",
                "أضف زر حفظ في الملف المفتوح"
            ).forEach { ex ->
                col.addView(TextView(a).apply {
                    text = ex; setTextColor(p.text); textSize = 13.5f
                    textDirection = View.TEXT_DIRECTION_ANY_RTL
                    background = ripple(outlined(Color.TRANSPARENT, dp(a, 10).toFloat(), p.line, dp(a, 1)), dp(a, 10).toFloat())
                    setPadding(dp(a, 16), dp(a, 12), dp(a, 16), dp(a, 12))
                    isClickable = true; isFocusable = true
                    setOnClickListener {
                        input.setText(ex); input.setSelection(input.text.length); input.requestFocus()
                    }
                }, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(a, 8) })
            }
            return col
        }

        fun nearBottom(): Boolean {
            val c = scroll.getChildAt(0) ?: return true
            return c.bottom - (scroll.scrollY + scroll.height) < dp(a, 96)
        }

        fun render() {
            // ما نسحبوش المستعمل لتحت إلا إلا كان قريب من آخر المحادثة (باش يقدر يقرا القديم وهو الوكيل خدّام)
            val stick = stickNext || nearBottom()
            stickNext = false
            list.removeAllViews()
            if (AiPlugin.history.isEmpty() && !busy) list.addView(emptyState())
            AiPlugin.history.forEach { m -> bubble(m)?.let { list.addView(it) } }
            if (busy) list.addView(working())
            lastError?.let { e -> list.addView(errorCard(e)) }
            if (stick) scroll.post { scroll.scrollTo(0, list.height) }
        }

        // ---- الإرسال / الإيقاف
        fun ask(prompt: String) {
            if (busy) return
            if (!prefs.ready()) { toast("ضع مفتاح API أولا", true); showSettings(a); return }
            stickNext = true
            startRun(a, prompt)
        }

        fun cancel() {
            reqId++; busy = false; status = ""
            val last = AiPlugin.history.lastOrNull()
            if (last != null && last.role == "user" && !AiAgent.isResults(last)) AiPlugin.history.removeAt(AiPlugin.history.lastIndex)
            AiPlugin.save(a)
            updateSend(); render()
            observer?.invoke()
        }

        // ---- الهيدر
        val header = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val titles = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        titles.addView(TextView(a).apply {
            text = "وكيل Zellige"; setTextColor(p.text); textSize = 16f; typeface = Typeface.DEFAULT_BOLD
        })
        val subtitle = TextView(a).apply {
            setTextColor(p.sub); textSize = 12f; setSingleLine(); ellipsize = TextUtils.TruncateAt.END
            textDirection = View.TEXT_DIRECTION_LTR
            setPadding(0, dp(a, 2), 0, dp(a, 2))
            isClickable = true; isFocusable = true
            setOnClickListener { showSettings(a) }
        }
        titles.addView(subtitle)
        val projLine = TextView(a).apply {
            setTextColor(p.accent); textSize = 12f; setSingleLine(); ellipsize = TextUtils.TruncateAt.MIDDLE
            textDirection = View.TEXT_DIRECTION_ANY_RTL
            setPadding(0, 0, 0, dp(a, 2))
            isClickable = true; isFocusable = true
            setOnClickListener { showProjects(a) }
        }
        titles.addView(projLine)
        fun updateSubtitle() {
            subtitle.text = prefs.providerLabel() + " · " + prefs.effectiveModel().ifBlank { "اختر موديل" } + "  ›"
            projLine.text = try { "📁 " + AiIde.activeRoot(a, EditorAccess.find(a)?.file()).name + "  ›" } catch (t: Throwable) { "" }
        }
        val avatar = FrameLayout(a).apply {
            background = outlined(p.surface, dp(a, 10).toFloat(), p.line, dp(a, 1))
            addView(ImageView(a).apply {
                setImageDrawable(icon(a, "ic_ai_sparkle")); imageTintList = ColorStateList.valueOf(p.accent)
            }, FrameLayout.LayoutParams(dp(a, 20), dp(a, 20), Gravity.CENTER))
        }
        val more = iconButton(a, "ic_ai_more", "المزيد", p.sub, Color.TRANSPARENT, 42) { }
        more.setOnClickListener { v ->
            val pm = PopupMenu(a, v)
            pm.menu.add(0, 1, 0, "الإعدادات")
            pm.menu.add(0, 2, 1, "محادثة جديدة")
            pm.menu.add(0, 3, 2, "تراجع عن آخر تنفيذ")
            pm.menu.add(0, 4, 3, "المشاريع")
            pm.setOnMenuItemClickListener { item ->
                when (item.itemId) {
                    1 -> showSettings(a)
                    2 -> { cancel(); AiPlugin.history.clear(); lastError = null; AiPlugin.save(a); render() }
                    3 -> toast(AiAgent.undoLast(a), true)
                    4 -> showProjects(a)
                }
                true
            }
            pm.show()
        }
        val close = iconButton(a, "ic_ai_close", "إغلاق", p.sub, Color.TRANSPARENT, 42) { dialog.dismiss() }
        header.addView(avatar, LinearLayout.LayoutParams(dp(a, 42), dp(a, 42)).apply { marginEnd = dp(a, 12) })
        header.addView(titles, LinearLayout.LayoutParams(0, WRAP, 1f))
        val folder = iconButton(a, "ic_ai_folder", "المشاريع", p.sub, Color.TRANSPARENT, 42) { showProjects(a) }
        header.addView(folder, LinearLayout.LayoutParams(dp(a, 42), dp(a, 42)))
        header.addView(more, LinearLayout.LayoutParams(dp(a, 42), dp(a, 42)))
        header.addView(close, LinearLayout.LayoutParams(dp(a, 42), dp(a, 42)))

        // ---- اقتراحات سريعة (Material Chips)
        val chipsRow = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL }
        fun chip(label: String, onClick: () -> Unit) {
            chipsRow.addView(Chip(a).apply {
                text = label; setTextColor(p.text); textSize = 12.5f; isCheckable = false
                chipBackgroundColor = ColorStateList.valueOf(p.surface)
                chipStrokeColor = ColorStateList.valueOf(p.line)
                chipStrokeWidth = dp(a, 1).toFloat()
                setOnClickListener { onClick() }
            }, LinearLayout.LayoutParams(WRAP, WRAP).apply { marginEnd = dp(a, 6) })
        }
        fun prefill(text: String) {
            input.setText(text); input.setSelection(input.text.length); input.requestFocus()
        }
        chip("مشروع جديد") { prefill("أنشئ مشروع أندرويد جديد باسم ") }
        chip("مجلد + واجهة") { prefill("أنشئ مجلدا باسم ") }
        chip("أصلح الملف") { ask("أصلح الأخطاء في الملف المفتوح وطبّق الإصلاح مباشرة.") }
        chip("اشرح الملف") { ask("اشرح لي هذا الملف باختصار.") }
        chip("حسّن الكود") { ask("حسّن جودة وقراءة الكود (التحديد إن وُجد، وإلا الملف) دون تغيير السلوك، وطبّق التعديل مباشرة.") }
        chip("اختبارات") { ask("اكتب اختبارات unit tests مناسبة للملف الحالي وأنشئها في مكانها الصحيح بالمشروع.") }
        chip("تعليقات") { ask("أضف توثيق KDoc/Javadoc واضحا للملف الحالي وطبّقه مباشرة.") }
        chip("حلّل خطأ من الحافظة") {
            val c = clip()
            if (c == null) toast("الحافظة فارغة — انسخ اللوغ أولا")
            else ask("حلّل هذا الخطأ/اللوغ، وقل لي السبب، ثم أصلحه في المشروع إن أمكن:\n```\n${c.take(6000)}\n```")
        }
        val chips = HorizontalScrollView(a).apply { addView(chipsRow); isHorizontalScrollBarEnabled = false }

        send.setOnClickListener {
            if (busy) { cancel(); return@setOnClickListener }
            val t = input.text.toString().trim()
            if (t.isNotEmpty()) { input.text.clear(); ask(t) }
        }
        val inputRow = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.BOTTOM }
        inputRow.addView(modeChip, LinearLayout.LayoutParams(WRAP, dp(a, 48)).apply { marginEnd = dp(a, 8) })
        inputRow.addView(input, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginEnd = dp(a, 8) })
        inputRow.addView(send, LinearLayout.LayoutParams(dp(a, 48), dp(a, 48)))

        // ---- التجميع
        val root = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(a, 16), dp(a, 10), dp(a, 16), dp(a, 12))
            background = sheetBackground(a, p)
        }
        root.addView(View(a).apply { background = shape(p.line, dp(a, 2).toFloat()) },
            LinearLayout.LayoutParams(dp(a, 36), dp(a, 4)).apply { gravity = Gravity.CENTER_HORIZONTAL; bottomMargin = dp(a, 10) })
        root.addView(header)
        root.addView(View(a).apply { setBackgroundColor(p.line) },
            LinearLayout.LayoutParams(MATCH, dp(a, 1)).apply { topMargin = dp(a, 10) })
        root.addView(scroll, LinearLayout.LayoutParams(MATCH, 0, 1f))
        root.addView(chips, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(a, 4); bottomMargin = dp(a, 10) })
        root.addView(inputRow)

        onChange = { updateSend(); updateSubtitle(); render() }
        sheet = dialog
        dialog.setOnDismissListener { onChange = null; if (sheet === dialog) sheet = null }
        updateSend(); updateSubtitle(); render()
        setupSheet(a, dialog, root, 56)
        val pp = pendingPrompt
        if (pp != null) {
            pendingPrompt = null
            if (pendingSend) ask(pp) else prefill(pp)
        }
        dialog.show()
    }

    // ------------------------------------------------------------ agent loop
    private fun startRun(a: Activity, prompt: String) {
        val prefs = AiPrefs(a)
        lastError = null
        val ed = EditorAccess.find(a)
        val root = AiIde.activeRoot(a, ed?.file())
        runCatching { root.mkdirs() }
        val ws = AiAgent.Workspace(root, AiIde.projectsDir(a).also { runCatching { it.mkdirs() } })
        val system = buildSystem(a, ed, ws)
        val first = buildPrompt(prompt, ed)
        val runStart = AiPlugin.history.size
        AiPlugin.history.add(AiClient.Msg("user", prompt))
        val my = ++reqId
        busy = true
        status = "يفكّر…"
        notifyChange()

        Thread {
            var err: String? = null
            val run = AiAgent.Run()
            run.alive = { my == reqId }
            var finalText = ""
            try {
                var step = 0
                var strikes = 0
                val extra = mutableListOf<AiClient.Msg>()   // رسائل مؤقتة (ما كتبانش ولا كتتحفظ)
                while (my == reqId) {
                    val snap = AiPlugin.history.toList()
                    val cut = runStart.coerceAtMost(snap.size)
                    val older = snap.subList(0, cut).takeLast(10).dropWhile { it.role != "user" }.map { AiAgent.compact(it) }
                    val cur = snap.subList(cut, snap.size).toMutableList()
                    if (cur.isNotEmpty()) cur[0] = AiClient.Msg("user", first)
                    status = if (step == 0) "يفكّر…" else "يراجع النتائج…"
                    notifyChange()
                    val reply = AiClient.complete(prefs, system, older + cur + extra)
                    if (my != reqId) break

                    val calls = AiAgent.parse(reply)
                    // النموذج كتب كودا طويلا فالشات بدل ما يطبّقو: نرجّعو ليه الطلب مرة/مرتين بلا ما يبان للمستعمل
                    if (calls.isEmpty() && strikes < 2 && AiAgent.hasCodeDump(reply)) {
                        strikes++
                        extra.clear()
                        extra.add(AiClient.Msg("assistant", reply))
                        extra.add(AiClient.Msg("user", CODE_IN_CHAT_FIX))
                        status = "يجهّز التطبيق على الملف…"
                        notifyChange()
                        continue
                    }
                    extra.clear()
                    AiPlugin.history.add(AiClient.Msg("assistant", reply))
                    notifyChange()
                    if (calls.isEmpty()) {
                        finalText = AiAgent.strip(reply).lineSequence().firstOrNull { it.isNotBlank() }.orEmpty().take(120)
                        break
                    }
                    step++
                    if (step > MAX_STEPS) {
                        AiPlugin.history.add(AiClient.Msg("user", "<tool_results>\n</tool_results>"))
                        AiPlugin.history.add(AiClient.Msg("assistant", "توقفت بعد $MAX_STEPS خطوة. اكتب «تابع» لإكمال العمل."))
                        break
                    }
                    status = AiAgent.describe(calls.first()) + (if (calls.size > 1) "  (+" + (calls.size - 1) + ")" else "")
                    notifyChange()
                    val results = calls.map { AiAgent.execute(a, run, ws, it, prefs.askBeforeEdit) }
                    runCatching { AiIde.sync(a, run) }
                    if (my != reqId) break
                    AiPlugin.history.add(AiClient.Msg("user", AiAgent.formatResults(results)))
                    notifyChange()
                }
            } catch (t: Throwable) {
                err = t.message ?: t.javaClass.simpleName
            }
            runCatching { AiIde.finish(a, run) }
            AiAgent.end(run)
            runCatching { AiLive.finish(a, run, err, finalText) }
            ui.post {
                if (my == reqId) {
                    busy = false
                    status = ""
                    if (err != null) {
                        val last = AiPlugin.history.lastOrNull()
                        if (AiPlugin.history.size == runStart + 1 && last != null && last.role == "user") {
                            AiPlugin.history.removeAt(AiPlugin.history.lastIndex)
                        }
                        lastError = err
                    }
                    AiPlugin.save(a)
                    onChange?.invoke()
                    observer?.invoke()
                }
            }
        }.start()
    }

    // -------------------------------------------------------------- projects
    /** شاشة المشاريع: كل المشاريع، المشروع النشط، فتح فـ IDE، مشروع جديد، تحديث الشجرة، تشخيص. */
    fun showProjects(a: Activity) {
        val p = pal(a)
        val dialog = BottomSheetDialog(a)

        fun toast(s: String, long: Boolean = false) =
            Toast.makeText(a, s, if (long) Toast.LENGTH_LONG else Toast.LENGTH_SHORT).show()

        fun activeDir(): File =
            try { AiIde.activeRoot(a, EditorAccess.find(a)?.file()) } catch (t: Throwable) { AiIde.projectsDir(a) }

        val list = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(a, 6), 0, dp(a, 6))
        }
        val scroll = NestedScrollView(a).apply {
            addView(list)
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            setOnTouchListener { v, ev ->
                if (ev.action == MotionEvent.ACTION_DOWN || ev.action == MotionEvent.ACTION_MOVE) {
                    v.parent?.requestDisallowInterceptTouchEvent(true)
                }
                false
            }
        }

        lateinit var render: () -> Unit

        fun openIn(dir: File) {
            val err = try { AiIde.openProject(a, dir) } catch (t: Throwable) { t.message ?: "خطأ" }
            if (err != null) toast(err, true) else dialog.dismiss()
        }

        fun row(dir: File, isActive: Boolean): View {
            val r = dp(a, 16).toFloat()
            val box = LinearLayout(a).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                background = ripple(outlined(if (isActive) p.accentBox else p.surface, r, p.line, dp(a, 1)), r)
                setPadding(dp(a, 14), dp(a, 12), dp(a, 14), dp(a, 12))
                isClickable = true; isFocusable = true
            }
            val col = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
            col.addView(TextView(a).apply {
                text = dir.name; textSize = 15f; typeface = Typeface.DEFAULT_BOLD
                setTextColor(if (isActive) p.onAccentBox else p.text)
                setSingleLine(); ellipsize = TextUtils.TruncateAt.END
                textDirection = View.TEXT_DIRECTION_ANY_RTL
            })
            val kind = if (AiIde.isGradleProject(dir)) "Gradle" else "مجلد"
            val ago = android.text.format.DateUtils.getRelativeTimeSpanString(dir.lastModified())
            col.addView(TextView(a).apply {
                text = kind + " · " + ago + (if (isActive) " · نشط" else "")
                setTextColor(if (isActive) p.onAccentBox else p.sub); textSize = 12f
            })
            box.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))
            box.setOnClickListener { openIn(dir) }
            box.setOnLongClickListener {
                val pm = PopupMenu(a, box)
                pm.menu.add(0, 1, 0, "فتح في IDE")
                pm.menu.add(0, 2, 1, "نسخ المسار")
                pm.menu.add(0, 3, 2, "حذف")
                pm.setOnMenuItemClickListener { item ->
                    when (item.itemId) {
                        1 -> openIn(dir)
                        2 -> try {
                            val cm = a.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            cm.setPrimaryClip(ClipData.newPlainText("path", dir.path)); toast("تم النسخ")
                        } catch (t: Throwable) { toast("تعذّر النسخ", true) }
                        3 -> {
                            if (AiIde.ideProjectDir()?.path == dir.path) toast("هذا المشروع مفتوح الآن فـ IDE", true)
                            else AlertDialog.Builder(a)
                                .setTitle("حذف المشروع؟")
                                .setMessage(dir.path)
                                .setPositiveButton("حذف") { _, _ ->
                                    val ok = dir.deleteRecursively()
                                    toast(if (ok) "تم الحذف" else "تعذّر الحذف", !ok)
                                    AiIde.refreshAll(a); render()
                                }
                                .setNegativeButton("إلغاء", null).show()
                        }
                    }
                    true
                }
                pm.show()
                true
            }
            return box
        }

        render = {
            list.removeAllViews()
            val act = activeDir()
            val projects = AiIde.findProjects(a)
            if (projects.isEmpty()) {
                list.addView(TextView(a).apply {
                    text = "لا توجد مشاريع بعد فـ\n" + AiIde.projectsDir(a).path + "\n\nاضغط «مشروع جديد» ودع الذكاء ينشئه."
                    setTextColor(p.sub); textSize = 13.5f; gravity = Gravity.CENTER
                    setPadding(dp(a, 16), dp(a, 36), dp(a, 16), dp(a, 36))
                })
            }
            projects.forEach { d ->
                list.addView(row(d, d.path == act.path),
                    LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(a, 8) })
            }
        }

        fun newProject() {
            val name = EditText(a).apply { hint = "اسم المشروع"; setSingleLine() }
            val desc = EditText(a).apply { hint = "فكرة المشروع (اختياري)"; minLines = 2 }
            val col = LinearLayout(a).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(a, 20), dp(a, 8), dp(a, 20), 0)
                addView(name); addView(desc)
            }
            AlertDialog.Builder(a).setTitle("مشروع جديد").setView(col)
                .setPositiveButton("أنشئ") { _, _ ->
                    val n = name.text.toString().trim().replace(Regex("[\\\\/:*?\"<>|]"), "_")
                    val prefs = AiPrefs(a)
                    when {
                        n.isEmpty() -> toast("اكتب اسما للمشروع")
                        busy -> toast("الذكاء مشغول بمهمة أخرى", true)
                        !prefs.ready() -> { toast("ضع مفتاح API أولا", true); showSettings(a) }
                        else -> {
                            val dir = File(AiIde.projectsDir(a), n)
                            val d = desc.text.toString().trim()
                            dialog.dismiss()
                            startRun(
                                a,
                                "أنشئ مشروع أندرويد جديد كامل وجاهز للبناء باسم \"$n\" داخل ${dir.path}" +
                                    (if (d.isNotEmpty()) "\nالفكرة: $d" else "") +
                                    "\nثم افتحه فـ IDE."
                            )
                            show(a)
                        }
                    }
                }
                .setNegativeButton("إلغاء", null).show()
        }

        val head = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val titles = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        titles.addView(TextView(a).apply {
            text = "المشاريع"; setTextColor(p.text); textSize = 17f; typeface = Typeface.DEFAULT_BOLD
        })
        titles.addView(TextView(a).apply {
            text = AiIde.projectsDir(a).path
            setTextColor(p.sub); textSize = 11.5f; setSingleLine(); ellipsize = TextUtils.TruncateAt.MIDDLE
            textDirection = View.TEXT_DIRECTION_LTR
        })
        head.addView(titles, LinearLayout.LayoutParams(0, WRAP, 1f))
        head.addView(iconButton(a, "ic_ai_close", "إغلاق", p.sub, Color.TRANSPARENT, 42) { dialog.dismiss() },
            LinearLayout.LayoutParams(dp(a, 42), dp(a, 42)))

        val actions = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(a, 10), 0, 0) }
        actions.addView(materialButton(a, p, "مشروع جديد", true) { newProject() },
            LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(a, 6) })
        val row2 = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL }
        row2.addView(materialButton(a, p, "تحديث الشجرة", false) {
            AiIde.refreshAll(a); toast("تم تحديث شجرة الملفات"); render()
        }, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginEnd = dp(a, 8) })
        row2.addView(materialButton(a, p, "تشخيص الربط", false) {
            AlertDialog.Builder(a).setTitle("تشخيص الربط مع IDE").setMessage(AiIde.report(a))
                .setPositiveButton("حسنا", null).show()
        }, LinearLayout.LayoutParams(0, WRAP, 1f))
        actions.addView(row2)

        val root = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(a, 16), dp(a, 10), dp(a, 16), dp(a, 12))
            background = sheetBackground(a, p)
        }
        root.addView(View(a).apply { background = shape(p.line, dp(a, 2).toFloat()) },
            LinearLayout.LayoutParams(dp(a, 36), dp(a, 4)).apply { gravity = Gravity.CENTER_HORIZONTAL; bottomMargin = dp(a, 8) })
        root.addView(head)
        root.addView(scroll, LinearLayout.LayoutParams(MATCH, 0, 1f).apply { topMargin = dp(a, 8) })
        root.addView(actions)

        render()
        setupSheet(a, dialog, root, 96)
        dialog.show()
    }

    // -------------------------------------------------------------- settings
    fun showSettings(a: Activity) {
        val prefs = AiPrefs(a)
        val p = pal(a)
        val dialog = BottomSheetDialog(a)

        fun toast(s: String, long: Boolean = false) =
            Toast.makeText(a, s, if (long) Toast.LENGTH_LONG else Toast.LENGTH_SHORT).show()

        fun section(t: String) = TextView(a).apply {
            text = t; setTextColor(p.sub); textSize = 12f; typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(a, 4), dp(a, 20), dp(a, 4), dp(a, 6))
        }
        fun note(t: String) = TextView(a).apply {
            text = t; setTextColor(p.sub); textSize = 11.5f; setLineSpacing(0f, 1.2f)
            setPadding(dp(a, 4), dp(a, 6), dp(a, 4), 0)
        }
        fun field(h: String, v: String, pass: Boolean = false, multi: Boolean = false, uri: Boolean = false) =
            EditText(a).apply {
                hint = h; setText(v); setTextColor(p.text); setHintTextColor(p.sub)
                textSize = 14f
                background = outlined(p.surface, dp(a, 14).toFloat(), p.line, dp(a, 1))
                setPadding(dp(a, 16), dp(a, 13), dp(a, 16), dp(a, 13))
                layoutDirection = View.LAYOUT_DIRECTION_LTR
                if (multi) {
                    minLines = 3
                    gravity = Gravity.TOP or Gravity.START
                    inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
                } else {
                    setSingleLine()
                    inputType = when {
                        pass -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                        uri -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
                        else -> InputType.TYPE_CLASS_TEXT
                    }
                }
            }

        val ids = AiProviders.ids()
        val labels = AiProviders.ALL.map { it.label }
        var cur = prefs.provider.let { if (ids.contains(it)) it else "openrouter" }

        val key = field("API Key", "", pass = true)
        val model = field("", "")
        val base = field("", "", uri = true)
        val providerNote = note("")

        // ---- حقول المزوّد المخصص (custom)
        val formats = listOf("openai", "anthropic", "gemini")
        val cName = field("اسم المزوّد (للعرض فقط)", prefs.customName)
        val cFormat = selector(
            a, p, "صيغة الـ API",
            listOf("OpenAI-compatible (الأشهر)", "Anthropic Messages", "Google Gemini"),
            formats.indexOf(prefs.customFormat)
        ) { }
        val cAuthHeader = field("Authorization", prefs.customAuthHeader)
        val cAuthPrefix = field("Bearer ", prefs.customAuthPrefix)
        val cHeaders = field("X-Header: value", prefs.customHeaders, multi = true)
        val cPath = field("/chat/completions", prefs.customChatPath)
        val custom = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            addView(section("اسم المزوّد")); addView(cName)
            addView(section("صيغة الـ API")); addView(cFormat.view)
            addView(section("Header ديال المفتاح (اختياري)")); addView(cAuthHeader)
            addView(note("فارغ = الافتراضي حسب الصيغة (Authorization مع Bearer، أو x-api-key فـ Anthropic)."))
            addView(section("بادئة المفتاح (اختياري)")); addView(cAuthPrefix)
            addView(section("Headers إضافية (سطر لكل header)")); addView(cHeaders)
            addView(section("مسار الدردشة (اختياري)")); addView(cPath)
            addView(note("فارغ = المسار الافتراضي حسب الصيغة. فـ Gemini تقدر تكتب {model} داخل المسار."))
        }
        val advanced = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            addView(section("العنوان (Base URL)")); addView(base)
            addView(custom)
        }
        val advToggle = TextView(a).apply {
            text = "خيارات متقدمة  ▾"; setTextColor(p.accent); textSize = 13f
            setPadding(dp(a, 4), dp(a, 20), dp(a, 4), dp(a, 4))
            isClickable = true; isFocusable = true
            setOnClickListener {
                val opening = advanced.visibility != View.VISIBLE
                advanced.visibility = if (opening) View.VISIBLE else View.GONE
                text = if (opening) "خيارات متقدمة  ▴" else "خيارات متقدمة  ▾"
            }
        }

        fun load(id: String) {
            val pr = AiProviders.get(id)
            key.setText(prefs.keyFor(id))
            model.setText(prefs.modelFor(id))
            base.setText(prefs.baseFor(id))
            val defBase = pr?.base.orEmpty()
            base.hint = if (defBase.isBlank()) "https://example.com/v1" else defBase
            val defModel = pr?.model.orEmpty()
            model.hint = if (defModel.isBlank()) "اكتب اسم الموديل أو اضغط «اختيار»" else defModel
            val isCustom = id == "custom"
            custom.visibility = if (isCustom) View.VISIBLE else View.GONE
            advToggle.visibility = if (isCustom) View.GONE else View.VISIBLE
            if (isCustom) {
                advanced.visibility = View.VISIBLE
            } else {
                advanced.visibility = View.GONE
                advToggle.text = "خيارات متقدمة  ▾"
            }
            providerNote.text = when {
                isCustom -> "مزوّد مخصص: أدخل Base URL (فالخيارات المتقدمة) + الصيغة + المفتاح + اسم الموديل. يدعم أي خدمة."
                pr != null && !pr.needsKey -> "مزوّد محلي: المفتاح اختياري. تأكد أن الخادم يشتغل (مثلا فـ Termux)."
                else -> "ما عليك إلا مفتاح API — العنوان جاهز. بعد إدخاله اضغط «اختيار» لتشوف كل موديلات المزوّد."
            }
        }
        fun store(id: String) {
            prefs.setKeyFor(id, key.text.toString().trim())
            prefs.setModelFor(id, model.text.toString().trim())
            prefs.setBaseFor(id, base.text.toString().trim())
        }

        val providerSel = selector(a, p, "المزوّد", labels, ids.indexOf(cur)) { idx ->
            store(cur)
            cur = ids[idx]
            load(cur)
        }

        // ---- المفتاح + إظهار/إخفاء
        var reveal = false
        val eye = TextView(a).apply {
            text = "إظهار"; setTextColor(p.accent); textSize = 13f; gravity = Gravity.CENTER
            setPadding(dp(a, 14), dp(a, 8), dp(a, 6), dp(a, 8))
            isClickable = true; isFocusable = true
            setOnClickListener {
                reveal = !reveal
                val pos = key.selectionStart.coerceAtLeast(0)
                key.inputType = InputType.TYPE_CLASS_TEXT or
                    (if (reveal) InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD else InputType.TYPE_TEXT_VARIATION_PASSWORD)
                key.setSelection(pos.coerceAtMost(key.text.length))
                text = if (reveal) "إخفاء" else "إظهار"
            }
        }
        val keyRow = LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            addView(key, LinearLayout.LayoutParams(0, WRAP, 1f))
            addView(eye, LinearLayout.LayoutParams(WRAP, WRAP))
        }

        // ---- الموديل + جلب اللائحة
        fun fetchModels() {
            store(cur)
            prefs.provider = cur
            val id = cur
            toast("⏳ جارٍ جلب الموديلات…")
            Thread {
                val res = runCatching { AiClient.listModels(prefs) }
                a.runOnUiThread {
                    val found = res.getOrNull()
                    val fallback = AiProviders.get(id)?.fallback.orEmpty()
                    when {
                        found != null && found.isNotEmpty() -> pickModel(a, p, found) { model.setText(it) }
                        fallback.isNotEmpty() -> pickModel(a, p, fallback) { model.setText(it) }
                        res.isFailure -> toast("تعذّر جلب الموديلات: " + (res.exceptionOrNull()?.message ?: ""), true)
                        else -> toast("ما لقيتش موديلات — اكتب الاسم يدويا", true)
                    }
                }
            }.start()
        }
        val pick = materialButton(a, p, "اختيار", false) { fetchModels() }
        val modelRow = LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            addView(model, LinearLayout.LayoutParams(0, WRAP, 1f))
            addView(pick, LinearLayout.LayoutParams(WRAP, WRAP).apply { marginStart = dp(a, 8) })
        }

        // ---- السلوك والمظهر
        val modes = listOf("تلقائي — ينفّذ كل شيء مباشرة", "اسأل قبل كل تعديل وحذف وأمر")
        val modeSel = selector(a, p, "وضع التنفيذ", modes, if (prefs.askBeforeEdit) 1 else 0) { }
        val liveSel = selector(a, p, "التطبيق المباشر", listOf("مفعّل — أشاهد الذكاء يكتب فالمحرر", "معطّل — يكتب على القرص بصمت"),
            if (prefs.liveApply) 0 else 1) { }
        val workspace = field("/storage/emulated/0/AndroidIDEProjects", prefs.workspace)
        val themeIds = AiPrefs.THEMES
        val themeSel = selector(a, p, "المظهر", listOf("تلقائي (حسب النظام)", "فاتح", "داكن"), themeIds.indexOf(prefs.theme)) { }
        val startSel = selector(a, p, "عند فتح التطبيق", listOf("أعد فتح آخر مشروع تلقائيا", "ابقَ فـ الشاشة الرئيسية"),
            if (prefs.autoOpenLast) 0 else 1) { }
        val newSel = selector(a, p, "المشاريع التي ينشئها الذكاء", listOf("افتحها فـ IDE تلقائيا", "لا تفتحها"),
            if (prefs.autoOpenNew) 0 else 1) { }

        fun save() {
            store(cur)
            prefs.provider = cur
            prefs.customName = cName.text.toString().trim()
            prefs.customFormat = formats[cFormat.index.coerceIn(0, formats.size - 1)]
            prefs.customAuthHeader = cAuthHeader.text.toString().trim()
            prefs.customAuthPrefix = cAuthPrefix.text.toString()
            prefs.customHeaders = cHeaders.text.toString().trim()
            prefs.customChatPath = cPath.text.toString().trim()
            prefs.askBeforeEdit = modeSel.index == 1
            prefs.liveApply = liveSel.index == 0
            prefs.theme = themeIds[themeSel.index.coerceIn(0, themeIds.size - 1)]
            prefs.workspace = workspace.text.toString().trim()
            prefs.autoOpenLast = startSel.index == 0
            prefs.autoOpenNew = newSel.index == 0
        }

        // ---- المحتوى
        val content = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(a, 20), 0, dp(a, 20), dp(a, 16))
            addView(section("المزوّد")); addView(providerSel.view); addView(providerNote)
            addView(section("مفتاح API")); addView(keyRow)
            addView(note("كيتخزّن محليا فجهازك فقط، ولكل مزوّد مفتاحو."))
            addView(section("الموديل")); addView(modelRow)
            addView(advToggle); addView(advanced)
            addView(section("وضع التنفيذ")); addView(modeSel.view)
            addView(note("فالوضع التلقائي كل شيء (كتابة، حذف، أوامر) كيتنفّذ بلا أسئلة، وتقدر ترجع بـ «تراجع عن آخر تنفيذ»."))
            addView(section("التطبيق المباشر")); addView(liveSel.view)
            addView(note("الذكاء يفتح الملف فالمحرر ويكتب فيه قدامك، ولا يعرض الكود فالشات."))
            addView(section("عند فتح التطبيق")); addView(startSel.view)
            addView(section("المشاريع الجديدة")); addView(newSel.view)
            addView(section("مجلد المشاريع (اختياري)")); addView(workspace)
            addView(note("فارغ = نفس مجلد مشاريع AndroidIDE، باش المشاريع الجديدة تبان فقائمة التطبيق. عمل الوكيل دائما داخل المشروع المفتوح."))
            addView(section("المظهر")); addView(themeSel.view)
        }
        val scroll = NestedScrollView(a).apply {
            addView(content)
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            isNestedScrollingEnabled = true
            setOnTouchListener { v, ev ->
                if (ev.action == MotionEvent.ACTION_DOWN || ev.action == MotionEvent.ACTION_MOVE) {
                    v.parent?.requestDisallowInterceptTouchEvent(true)
                }
                false
            }
        }

        // ---- الأزرار (ثابتة تحت، ما كتتحركش مع السكرول)
        val actions = LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(a, 20), dp(a, 12), dp(a, 20), dp(a, 16))
        }
        actions.addView(materialButton(a, p, "اختبار الاتصال", false) {
            save()
            toast("⏳ كنجرب الاتصال…")
            Thread {
                val msg = try { AiClient.ping(prefs); "الاتصال ناجح ✓" }
                catch (t: Throwable) { "فشل الاتصال: ${t.message ?: t.javaClass.simpleName}" }
                a.runOnUiThread { Toast.makeText(a, msg, Toast.LENGTH_LONG).show() }
            }.start()
        }, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginEnd = dp(a, 8) })
        actions.addView(materialButton(a, p, "حفظ", true) {
            save()
            toast("تم الحفظ")
            onChange?.invoke()
            dialog.dismiss()
        }, LinearLayout.LayoutParams(0, WRAP, 1f))

        // ---- الهيكل
        val head = LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(a, 20), dp(a, 4), dp(a, 8), 0)
            addView(TextView(a).apply {
                text = "إعدادات المساعد"; setTextColor(p.text); textSize = 18f; typeface = Typeface.DEFAULT_BOLD
            }, LinearLayout.LayoutParams(0, WRAP, 1f))
            addView(iconButton(a, "ic_ai_close", "إغلاق", p.sub, Color.TRANSPARENT, 42) { dialog.dismiss() },
                LinearLayout.LayoutParams(dp(a, 42), dp(a, 42)))
        }
        val root = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(a, 10), 0, 0)
            background = sheetBackground(a, p)
        }
        root.addView(View(a).apply { background = shape(p.line, dp(a, 2).toFloat()) },
            LinearLayout.LayoutParams(dp(a, 36), dp(a, 4)).apply { gravity = Gravity.CENTER_HORIZONTAL; bottomMargin = dp(a, 8) })
        root.addView(head)
        root.addView(scroll, LinearLayout.LayoutParams(MATCH, 0, 1f))
        root.addView(View(a).apply { setBackgroundColor(p.line) }, LinearLayout.LayoutParams(MATCH, dp(a, 1)))
        root.addView(actions)

        load(cur)
        setupSheet(a, dialog, root, 64)
        dialog.show()
    }

    // --------------------------------------------------------------- context
    private fun buildPrompt(p: String, ed: EditorAccess?): String = buildString {
        appendLine(p)
        if (ed != null) {
            ed.file()?.let {
                appendLine("\n## Current file (open in the editor): ${it.path}")
                appendLine("## Cursor: line ${ed.cursorLine() + 1}, column ${ed.cursorColumn() + 1} (1-based)")
            }
            ed.selection()?.let { appendLine("\n## Selected text:\n```\n${it.take(4000)}\n```") }
            val all = ed.allText()
            if (all.isNotBlank()) {
                appendLine("\n## Full current file:\n```\n${all.take(12000)}\n```")
                if (all.length > 12000) appendLine("(الملف طويل: تم اقتطاع الجزء الأخير — استعمل read_file لقراءته كاملا)")
            }
        }
    }

    private const val CODE_IN_CHAT_FIX = """STOP. You wrote code in the chat. The user NEVER wants code in the chat.
Apply it now with tools, with no code outside the tags:
- the open file is named in "Current file": use <tool name="edit_file"> for local changes, <tool name="insert"> to add code at the cursor, <tool name="write_file"> for a full rewrite;
- if no file is open, or the code belongs elsewhere, pick the right path inside the active project and use write_file (create folders with create_dir if needed).
Start with ONE short sentence in the user's language saying what you are applying, then the tool tags. Do not repeat the code in text."""

    private val AGENT_RULES = """
You are an autonomous coding AGENT embedded inside AndroidIDE (an Android IDE running on the phone).
The user gives short commands and you EXECUTE them with tools, directly inside the IDE the user is looking at:
the editor opens the file and the code is typed into it live, the file tree shows new folders and files.
Never just describe what to do when you can do it.
Reply in the same language the user writes in. Keep chat text very short.

## THE GOLDEN RULE: code goes into files, NEVER into the chat
- NEVER write code, snippets or file contents in your chat text, not even "just an example". Code exists ONLY inside write_file / edit_file / insert tags.
- When the user says "write code", "add ...", "fix ...", "continue", "make a button" and does not name a file, the target is the file open in the editor ("Current file", see the cursor line):
  use edit_file for local changes, insert (at the cursor or at a line) to add code, write_file to rewrite the whole file.
- If no file is open or the code needs a new file, choose the sensible path inside the active project, create folders with create_dir if needed, and use write_file.
- Before the tool tags, write ONE short sentence in the user's language saying what you are starting to apply and where
  (for example: "أبدأ بتطبيق زر الحفظ في MainActivity.kt…" / "Applying the save button to MainActivity.kt…"). Then the tags. After the work, ONE short sentence summary.
- If the user only wants an explanation, answer in 1-3 plain sentences without code blocks.

## Tools
Emit tool calls as tag blocks in your reply (several per reply are allowed; they run in order).
The results come back in the next message inside <tool_results>. Continue until the task is fully done,
then reply with a SHORT summary and NO tool tags.

<tool name="list_dir" path="dir"/>
<tool name="read_file" path="file"/>
<tool name="open_file" path="file" line="optional line number"/>
<tool name="write_file" path="file">
complete file content, raw (no code fence, no escaping)
</tool>
<tool name="edit_file" path="file">
<find>exact existing text (copy it verbatim, must be unique in the file)</find>
<replace>new text</replace>
</tool>
<tool name="insert" path="optional file (default: the file open in the editor)" at="cursor|start|end" line="optional: insert before this 1-based line">
code to insert, raw
</tool>
<tool name="create_dir" path="dir"/>
<tool name="move" path="from" to="to"/>
<tool name="delete" path="file-or-dir"/>
<tool name="open_project" path="project-dir"/>
<tool name="search" query="text" path="dir"/>
<tool name="run" dir="optional-dir" timeout="seconds, optional (default 120, max 1800)">
one shell command (same bash and environment as the IDE terminal: PATH, JAVA_HOME, ANDROID_HOME; runs in the project root; executes immediately)
</tool>

## Rules
- Paths are relative to the workspace root, or absolute anywhere inside shared storage (/storage/emulated/0/...).
- The workspace root is the project currently active in the IDE. Everything you write appears in the IDE file tree automatically. Work inside that project unless the user asks for another one.
- EXECUTE IMMEDIATELY. NEVER ask the user for permission or confirmation ("should I run/create/delete this?"): the command itself is the approval. Ask only when truly blocked.
- To create a NEW project: write it as <Projects folder>/<ProjectName>/... A project that contains settings.gradle(.kts) is opened in the IDE automatically when you finish; you may also call open_project explicitly (it opens after you finish, so use absolute paths for the rest of the work).
- After creating a new Gradle project, if another project in the Projects folder has gradlew and gradle/wrapper, copy them with run (cp -r ...; chmod +x gradlew) so the project can build.
- Use run for builds, git, unzip, chmod and similar; set timeout for long commands (builds).
- Always use double quotes for tag attributes, and write file content RAW inside the tag (never inside a ``` code fence).
- To create a NEW project, use absolute paths under the projects folder and write every file the project needs
  (settings.gradle.kts, build.gradle.kts, app/build.gradle.kts, gradle.properties, AndroidManifest.xml,
  MainActivity, layouts/values). If you could not add the Gradle wrapper, tell the user once that it must be added/synced by the IDE.
- Use edit_file for small changes in existing files, insert for pure additions, write_file for new files or full rewrites.
  Always write COMPLETE files: never placeholders such as "rest of the code unchanged".
- read_file before editing a file you have not seen. The currently open file is included in the first message.
- Do not invent APIs or files that are not in the project; verify with list_dir/search/read_file.
- NEVER claim that you created or changed anything unless a <tool_results> block confirmed it. Do the work with tools first.
- NEVER use the API's native function calling. Tools are ONLY the plain-text <tool .../> tags above.
- After write/edit, if something may break (imports, manifest entries, dependencies), fix it in the same run.
- If a tool fails, read the error, fix the cause and retry once with a corrected call. If it fails again, stop and tell the user why.

## Building things (IMPORTANT)
- When the user asks to create a folder, file, screen, UI or project: DO IT NOW with create_dir + write_file. Never answer with instructions only.
- "Create a folder X and put Y in it" means: create_dir X, then write_file X/<files>. Use the workspace root unless the user gives another path.
- For a screen/UI in an Android project: write the XML layout (res/layout), its Activity or Fragment, any strings/colors/styles it needs,
  and register a new Activity in AndroidManifest.xml with edit_file. If the project uses Jetpack Compose, write Composables instead.
- Make UIs look good: Material 3 components, 16dp paddings, clear hierarchy, labels/hints in the user's language, no placeholder text.
- Plain folders/files outside an Android project (HTML, scripts, notes) are fine too: just create exactly what was asked.
- Use run only when a shell command is really needed (for example chmod or a build); prefer the file tools for everything else.
- When finished, reply with a SHORT summary (1-3 lines) naming what was created, with paths. No code in the summary.
"""

    private fun buildSystem(a: Activity, ed: EditorAccess?, ws: AiAgent.Workspace): String = buildString {
        appendLine(AGENT_RULES.trim())
        appendLine("\n## Workspace root: ${ws.root.path}")
        appendLine("## Projects folder: ${ws.projects.path}")
        appendLine("## Active project (the one opened in the IDE): ${ws.root.path}")
        val known = runCatching { AiIde.findProjects(a).take(40) }.getOrDefault(emptyList())
        if (known.isNotEmpty()) appendLine("## Known projects (full paths): " + known.joinToString(", ") { it.path })
        appendLine("\n## Files in workspace:")
        val lines = mutableListOf<String>()
        tree(ws.root, ws.root, 0, lines)
        lines.forEach { appendLine("- $it") }
        if (lines.isEmpty()) appendLine("(empty)")
    }

    private fun projectRoot(f: File?): File? {
        val first = f?.parentFile
        var d = first
        while (d != null) {
            if (File(d, "settings.gradle").exists() || File(d, "settings.gradle.kts").exists()) return d
            d = d.parentFile
        }
        return first
    }

    private val skip = setOf("build", ".gradle", ".git", ".idea", ".cxx", ".kotlin", "node_modules")
    private val skipExt = setOf(
        "png", "jpg", "jpeg", "webp", "gif", "jar", "aar", "apk", "so", "zip",
        "ttf", "otf", "mp3", "mp4", "class", "dex", "keystore", "jks"
    )

    private fun tree(root: File, dir: File, depth: Int, out: MutableList<String>) {
        if (depth > 6 || out.size >= 100) return
        dir.listFiles()?.sortedBy { it.name }?.forEach { f ->
            if (out.size >= 100 || f.name in skip) return@forEach
            if (f.isDirectory) tree(root, f, depth + 1, out)
            else if (f.extension.lowercase() !in skipExt) out.add(f.relativeTo(root).path)
        }
    }
}
