package com.itsaky.androidide.ai

import android.app.Activity
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Collections
import java.util.WeakHashMap

/**
 * أدوات مشتركة لشاشات اتجاه Console (الترمنال C9 · المحرر C5 · درج الملفات C6 · الإعدادات C8):
 * ألوان التصميم كما هي (داكن) مع نسخة فاتحة، عناصر صغيرة، و reflection آمن.
 *
 * كل ما كنلمسو من شاشات AndroidIDE الأصلية (ترمنال، محرر، درج) كنوصلو ليه بالاسم عبر `resources.getIdentifier` وبالـ reflection،
 * باش ما يتكسر البناء إلا تبدّلات أسماء الكلاسات، وكلشي محاط بـ try/catch: إلا فشل شي حاجة كتبقى الشاشة الأصلية خدّامة.
 */
internal object Con {

    // ------------------------------------------------------------------ palette (C-direction tokens)
    class P(val dark: Boolean) {
        val page = if (dark) 0xFF0A0C10.toInt() else 0xFFF7F6F2.toInt()
        val bar = if (dark) 0xFF0D0F14.toInt() else 0xFFF0EFEA.toInt()
        val field = if (dark) 0xFF10131A.toInt() else 0xFFFFFFFF.toInt()
        val key = if (dark) 0xFF161A23.toInt() else 0xFFE9E8E3.toInt()
        val chip = if (dark) 0xFF1A1F29.toInt() else 0xFFE4E3DD.toInt()
        val chipHi = if (dark) 0xFF1E2530.toInt() else 0xFFDCDBD4.toInt()
        val line = if (dark) 0xFF1A1F29.toInt() else 0xFFE4E3DD.toInt()
        val border = if (dark) 0xFF242A36.toInt() else 0xFFD3D2CB.toInt()
        val guide = if (dark) 0xFF1F2530.toInt() else 0xFFE4E3DD.toInt()
        val text = if (dark) 0xFFD9DDE5.toInt() else 0xFF14171C.toInt()
        val text2 = if (dark) 0xFFC4CAD6.toInt() else 0xFF2A2E36.toInt()
        val dim = if (dark) 0xFFA5ADBB.toInt() else 0xFF4A5160.toInt()
        val muted = if (dark) 0xFF7B8494.toInt() else 0xFF6B7280.toInt()
        val faint = if (dark) 0xFF5C6472.toInt() else 0xFF8A8F9A.toInt()
        val amber = if (dark) 0xFFFFB454.toInt() else 0xFF9A5B00.toInt()
        val onAmber = if (dark) 0xFF1A1000.toInt() else 0xFFFFFFFF.toInt()
        val amberSoft = if (dark) 0xFF2A2113.toInt() else 0xFFFFE9C7.toInt()
        val green = if (dark) 0xFF7BD88F.toInt() else 0xFF1E7A3B.toInt()
        val red = if (dark) 0xFFFF7A7A.toInt() else 0xFFC62828.toInt()
        val onRed = if (dark) 0xFF2A0608.toInt() else 0xFFFFFFFF.toInt()
        val errBg = if (dark) 0xFF1A1315.toInt() else 0xFFFDECEA.toInt()
        val errLine = if (dark) 0xFF5A2E32.toInt() else 0xFFF1B7B2.toInt()
        val errText = if (dark) 0xFFFFC9C9.toInt() else 0xFF7A1F1F.toInt()
        val blue = if (dark) 0xFF7DCFFF.toInt() else 0xFF1F6FB2.toInt()
        val purple = if (dark) 0xFFC79BFF.toInt() else 0xFF7A4FC2.toInt()
        val orange = if (dark) 0xFFFF9E64.toInt() else 0xFFB5541C.toInt()
        val gold = if (dark) 0xFFD8B26A.toInt() else 0xFF8A6A12.toInt()
        val sel = if (dark) 0xFF161A23.toInt() else 0xFFECEBE5.toInt()
        val scrim = 0x9E030406.toInt()
    }

    private class PalEntry(val p: P, val night: Int)
    private val palettes = Collections.synchronizedMap(WeakHashMap<Activity, PalEntry>())

    /**
     * الألوان حسب ثيم التطبيق (خلفية الصفحة داكنة؟). مخبّأة لكل Activity ولا كتتحسب من جديد غير إلا تبدّل uiMode:
     * قبل كانت كتعمل getIdentifier + resolveAttribute فكل نداء، وكنعيطو عليها لكل صف فكل layout.
     */
    fun pal(a: Activity): P {
        val night = a.resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK
        val e = palettes[a]
        if (e != null && e.night == night) return e.p
        val bg = themeColor(a, listOf("colorSurface", "colorBackground"), Color.parseColor("#0A0C10"))
        val dark = (Color.red(bg) * 299 + Color.green(bg) * 587 + Color.blue(bg) * 114) / 1000 < 128
        val p = if (e != null && e.p.dark == dark) e.p else P(dark)
        palettes[a] = PalEntry(p, night)
        return p
    }

    fun themeColor(a: Context, names: List<String>, fb: Int): Int {
        for (n in names) {
            try {
                val id = a.resources.getIdentifier(n, "attr", a.packageName)
                if (id == 0) continue
                val tv = TypedValue()
                if (a.theme.resolveAttribute(id, tv, true) &&
                    tv.type >= TypedValue.TYPE_FIRST_COLOR_INT && tv.type <= TypedValue.TYPE_LAST_COLOR_INT
                ) return tv.data
            } catch (t: Throwable) { /* اسم آخر */ }
        }
        return fb
    }

    fun mono(a: Context): Typeface = try {
        Typeface.createFromAsset(a.assets, "fonts/jetbrains-mono.ttf")
    } catch (t: Throwable) { Typeface.MONOSPACE }

    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density).toInt()
    fun dpf(c: Context, v: Float): Float = v * c.resources.displayMetrics.density

    // ------------------------------------------------------------------ one-time marker (بدل setTag بمفتاح)
    private val marked = Collections.synchronizedMap(WeakHashMap<View, String>())

    /** true إلا هاد الـ view تعلّم بهاد العلامة من قبل؛ وإلا كيعلّمو. */
    fun seen(v: View, mark: String): Boolean {
        if (marked[v] == mark) return true
        marked[v] = mark
        return false
    }

    fun unmark(v: View) { marked.remove(v) }

    // ------------------------------------------------------------------ reflection
    private fun box(c: Class<*>): Class<*> = when (c) {
        java.lang.Integer.TYPE -> Integer::class.java
        java.lang.Boolean.TYPE -> java.lang.Boolean::class.java
        java.lang.Float.TYPE -> java.lang.Float::class.java
        java.lang.Long.TYPE -> java.lang.Long::class.java
        java.lang.Double.TYPE -> java.lang.Double::class.java
        else -> c
    }

    // ذاكرة مؤقتة للـ reflection: getMethods()/getDeclaredField كيكلفو، وكنعيّطو عليهم فكل tick
    private val methodCache = java.util.concurrent.ConcurrentHashMap<String, Array<java.lang.reflect.Method>>()
    private val fieldCache = java.util.concurrent.ConcurrentHashMap<String, java.lang.reflect.Field>()
    private val idCache = java.util.concurrent.ConcurrentHashMap<String, Int>()

    /** يستدعي ميثود عامة بالاسم وعدد الوسائط (null إلا فشل). */
    fun call(t: Any?, name: String, vararg args: Any?): Any? {
        if (t == null) return null
        return try {
            val cls = t.javaClass
            val ms = methodCache.getOrPut(cls.name + "#" + name + "#" + args.size) {
                cls.methods.filter { it.name == name && it.parameterTypes.size == args.size }.toTypedArray()
            }
            val m = ms.firstOrNull { m ->
                m.parameterTypes.indices.all { i ->
                    val x = args[i]
                    if (x == null) !m.parameterTypes[i].isPrimitive else box(m.parameterTypes[i]).isInstance(x)
                }
            } ?: return null
            m.isAccessible = true
            m.invoke(t, *args)
        } catch (e: Throwable) { null }
    }

    /** أول ميثود عامة بهاد الاسم وعدد الوسائط (من الكاش؛ getMethods() على CodeEditor كيرجّع مئات الـ Method وكيكلّف فكل نداء). */
    fun method(t: Any, name: String, argc: Int): java.lang.reflect.Method? {
        val cls = t.javaClass
        val ms = methodCache.getOrPut(cls.name + "#" + name + "#" + argc) {
            cls.methods.filter { it.name == name && it.parameterTypes.size == argc }.toTypedArray()
        }
        return ms.firstOrNull()
    }

    private fun fieldOf(t: Any, name: String): java.lang.reflect.Field? {
        var c: Class<*>? = t.javaClass
        while (c != null) {
            val key = c.name + "#" + name
            val hit = fieldCache[key]
            if (hit != null) return hit
            try {
                val f = c.getDeclaredField(name)
                f.isAccessible = true
                fieldCache[key] = f
                return f
            } catch (e: NoSuchFieldException) {
                c = c.superclass
            } catch (e: Throwable) { return null }
        }
        return null
    }

    /** قيمة حقل (عام أو خاص، في الكلاس أو آباءو). */
    fun field(t: Any?, name: String): Any? {
        if (t == null) return null
        return try { fieldOf(t, name)?.get(t) } catch (e: Throwable) { null }
    }

    /** يكتب حقل (خاص كذلك). true إلا نجح. */
    fun setField(t: Any?, name: String, value: Any?): Boolean {
        if (t == null) return false
        return try { val f = fieldOf(t, name) ?: return false; f.set(t, value); true } catch (e: Throwable) { false }
    }

    /** id بالاسم (محفوظ: getIdentifier كيمشي فالـ resources كل مرة). */
    fun id(c: Context, name: String): Int = idCache.getOrPut(name) { c.resources.getIdentifier(name, "id", c.packageName) }

    /** يبدّل text/visibility فقط إلا تغيّرو (setText كيطلب relayout حتى للقيمة نفسها). */
    fun setTextIfChanged(tv: TextView?, cs: CharSequence) {
        if (tv == null) return
        if (!TextUtils.equals(tv.text, cs)) tv.text = cs
    }

    fun setVisible(v: View?, mode: Int) { if (v != null && v.visibility != mode) v.visibility = mode }

    @Suppress("UNCHECKED_CAST")
    fun <T : View> find(a: Activity, name: String): T? {
        val i = id(a, name)
        return if (i == 0) null else a.findViewById<View>(i) as? T
    }

    @Suppress("UNCHECKED_CAST")
    fun <T : View> find(root: View, c: Context, name: String): T? {
        val i = id(c, name)
        return if (i == 0) null else root.findViewById<View>(i) as? T
    }

    /** أول view تحت root (بما فيه root) كيحقق الشرط. */
    fun firstOf(root: View, pred: (View) -> Boolean): View? {
        if (pred(root)) return root
        if (root is ViewGroup) for (i in 0 until root.childCount) firstOf(root.getChildAt(i), pred)?.let { return it }
        return null
    }

    fun allOf(root: View, pred: (View) -> Boolean, out: MutableList<View> = ArrayList()): MutableList<View> {
        if (pred(root)) out.add(root)
        if (root is ViewGroup) for (i in 0 until root.childCount) allOf(root.getChildAt(i), pred, out)
        return out
    }

    /** يجمّع النداءات المتتالية فنداء واحد بعد `ms` (بدل ما نخدمو فكل onGlobalLayout). */
    class Soon(private val h: android.os.Handler, private val ms: Long, private val f: () -> Unit) {
        private var pending = false
        private val r = Runnable { pending = false; try { f() } catch (t: Throwable) { } }
        fun poke() { if (!pending) { pending = true; h.postDelayed(r, ms) } }
        fun cancel() { pending = false; h.removeCallbacks(r) }
    }

    /** يعيّط `f` فور ما صف جديد يتزاد للـ RecyclerView (reflection + Proxy: بلا تبعية مباشرة على androidx). مرة وحدة لكل rv. */
    fun onChildAttached(rv: View, f: (View) -> Unit) {
        if (seen(rv, "child-hook")) return
        try {
            val ifc = Class.forName("androidx.recyclerview.widget.RecyclerView\$OnChildAttachStateChangeListener")
            val h = java.lang.reflect.Proxy.newProxyInstance(ifc.classLoader, arrayOf(ifc)) { _, m, args ->
                if (m.name == "onChildViewAttachedToWindow") (args?.getOrNull(0) as? View)?.let { try { f(it) } catch (t: Throwable) { } }
                null
            }
            call(rv, "addOnChildAttachStateChangeListener", h)
        } catch (t: Throwable) { }
    }

    fun isA(v: Any, simple: String): Boolean {
        var c: Class<*>? = v.javaClass
        while (c != null) {
            if (c.simpleName == simple) return true
            c = c.superclass
        }
        return false
    }

    // ------------------------------------------------------------------ drawables / views
    fun rounded(color: Int, r: Float, stroke: Int = 0, sw: Int = 0): GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius = r
        if (sw > 0) setStroke(sw, stroke)
    }

    fun ripple(content: Drawable?, r: Float, rip: Int = Color.argb(60, 150, 150, 160)): Drawable =
        RippleDrawable(ColorStateList.valueOf(rip), content, rounded(Color.WHITE, r))

    fun icon(a: Context, name: String, tint: Int? = null): Drawable? {
        for (pkg in listOf(a.packageName, "com.itsaky.androidide")) {
            val id = a.resources.getIdentifier(name, "drawable", pkg)
            if (id != 0) {
                val d = a.getDrawable(id)?.mutate() ?: continue
                if (tint != null) d.setTint(tint)
                return d
            }
        }
        return null
    }

    fun iconView(a: Context, name: String, tint: Int, sizeDp: Int): ImageView = ImageView(a).apply {
        setImageDrawable(icon(a, name))
        imageTintList = ColorStateList.valueOf(tint)
        scaleType = ImageView.ScaleType.FIT_CENTER
        layoutParams = LinearLayout.LayoutParams(dp(a, sizeDp), dp(a, sizeDp))
    }

    /** زر أيقونة مربع بزوايا r (تعبئة/حد اختياريان). */
    fun squareButton(
        a: Context, name: String, desc: String, tint: Int, fill: Int, strokeC: Int, w: Int, h: Int, r: Int, glyph: Int,
        onClick: (View) -> Unit
    ): ImageView = ImageView(a).apply {
        setImageDrawable(icon(a, name))
        imageTintList = ColorStateList.valueOf(tint)
        scaleType = ImageView.ScaleType.FIT_CENTER
        val pad = dp(a, ((minOf(w, h) - glyph) / 2).coerceAtLeast(0))
        setPadding(pad, pad, pad, pad)
        val base = if (Color.alpha(fill) == 0 && strokeC == 0) null
        else rounded(fill, dpf(a, r.toFloat()), strokeC, if (strokeC != 0) dp(a, 1).coerceAtLeast(1) else 0)
        background = ripple(base, dpf(a, r.toFloat()))
        contentDescription = desc
        isClickable = true; isFocusable = true
        setOnClickListener { onClick(it) }
        layoutParams = LinearLayout.LayoutParams(dp(a, w), dp(a, h))
    }

    fun text(
        a: Context, s: CharSequence, sizeSp: Float, color: Int, tf: Typeface? = null, bold: Boolean = false
    ): TextView = TextView(a).apply {
        text = s; textSize = sizeSp; setTextColor(color)
        if (tf != null) typeface = if (bold) Typeface.create(tf, Typeface.BOLD) else tf
        else if (bold) typeface = Typeface.DEFAULT_BOLD
        includeFontPadding = false
    }

    fun hairline(a: Context, color: Int, vertical: Boolean = false): View = View(a).apply {
        setBackgroundColor(color)
        layoutParams = if (vertical) LinearLayout.LayoutParams(dp(a, 1).coerceAtLeast(1), ViewGroup.LayoutParams.MATCH_PARENT)
        else LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(a, 1).coerceAtLeast(1))
    }

    fun dot(a: Context, color: Int, sizeDp: Int = 6): View = View(a).apply {
        background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(color) }
        layoutParams = LinearLayout.LayoutParams(dp(a, sizeDp), dp(a, sizeDp))
    }

    fun gravityCenterV() = Gravity.CENTER_VERTICAL
}
