package com.itsaky.androidide.ai

import android.app.Activity
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.InsetDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.StateListDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewTreeObserver
import android.widget.CompoundButton
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import java.util.WeakHashMap

/**
 * شاشة الإعدادات بتصميم C8: ترويسة بزر رجوع مربع وعنوان، عناوين أقسام mono بحروف كبيرة (AI · EDITOR · …)،
 * صفوف 46dp بخط سفلي رفيع بلا أيقونات، مفاتيح تبديل مربّعة 38×22 (عنبري = مفعّل)، وسهم › للصفوف اللي كتفتح شي حاجة،
 * وفالأخير سطر `zellige <version> · GPL-3.0 · حول ›` (كيفتح صفحة «حول Zellige»).
 *
 * كلشي وقت التشغيل على نفس الـ RecyclerView ديال androidx.preference (ما كنبدّلو لا adapter لا fragment): كنمرّو على الصفوف
 * الظاهرة عند كل layout ونطبّقو الأسلوب، فالتمرير وفتح الشاشات الفرعية كيبقاو خدّامين. إلا فشل شي حاجة كتبقى الواجهة الأصلية.
 */
object SettingsChrome {

    private val ui = Handler(Looper.getMainLooper())

    private class S(val a: Activity) {
        var tick: Runnable? = null
        var gl: ViewTreeObserver.OnGlobalLayoutListener? = null
        var obs: ViewTreeObserver? = null
        var soon: Con.Soon? = null
    }

    private var cur: S? = null

    /** خلفيات صفوفنا: PreferenceViewHolder.resetState() كيرجّع الخلفية ولون العنوان الأصليين مع كل bind، فكنعاودو نطبّقوهم. */
    private val bgs = WeakHashMap<View, Drawable>()

    fun install(a: Activity) {
        val s = cur?.takeIf { it.a === a } ?: S(a).also { cur = it }
        if (s.tick != null) return
        try { apply(s) } catch (t: Throwable) { }
        val r = object : Runnable {
            override fun run() {
                if (cur !== s || s.tick !== this) return
                try { apply(s) } catch (t: Throwable) { }
                ui.postDelayed(this, 1200)
            }
        }
        s.tick = r
        ui.postDelayed(r, 300)
        // كل layout كان كيدير مرور كامل على الشجرة؛ دابا كنجمّعوهم (40ms)، والصفوف الجديدة كتتنسّق فور ظهورها (onChildAttached)
        val soon = Con.Soon(ui, 40) { apply(s) }
        s.soon = soon
        try {
            val vto = a.window.decorView.viewTreeObserver
            val gl = ViewTreeObserver.OnGlobalLayoutListener { soon.poke() }
            vto.addOnGlobalLayoutListener(gl)
            s.gl = gl; s.obs = vto
        } catch (t: Throwable) { }
    }

    fun stop() {
        val s = cur ?: return
        s.tick?.let { ui.removeCallbacks(it) }
        s.tick = null
        s.soon?.cancel(); s.soon = null
        try { s.gl?.let { g -> s.obs?.takeIf { it.isAlive }?.removeOnGlobalLayoutListener(g) } } catch (t: Throwable) { }
        s.gl = null; s.obs = null
    }

    fun destroyed(a: Activity) { if (cur?.a === a) { stop(); cur = null } }

    // ------------------------------------------------------------------ pass
    private fun apply(s: S) {
        val a = s.a
        header(a)
        val box = Con.find<ViewGroup>(a, "fragmentContainer") ?: return
        footer(a, box)
        for (rv in Con.allOf(box, { it.javaClass.name.endsWith("RecyclerView") })) {
            val g = rv as? ViewGroup ?: continue
            if (!Con.seen(g, "sc-rv")) {
                g.setBackgroundColor(Con.pal(a).page)
                g.clipToPadding = false
            }
            Con.onChildAttached(g) { row(a, it) }
            for (i in 0 until g.childCount) row(a, g.getChildAt(i))
        }
    }

    // ------------------------------------------------------------------ header
    private fun header(a: Activity) {
        val tb = Con.find<ViewGroup>(a, "toolbar") ?: return
        val p = Con.pal(a)
        val bar = tb.parent as? ViewGroup
        if (!Con.seen(tb, "sc-head")) {
            bar?.setBackgroundColor(p.page)
            bar?.elevation = 0f
            bar?.stateListAnimator = null
            Con.call(bar, "setLiftOnScroll", false)
            Con.call(bar, "setStatusBarForeground", null)
            tb.setBackgroundColor(p.page)
            tb.layoutParams?.let { it.height = Con.dp(a, 52); tb.layoutParams = it }
            Con.call(tb, "setTitleMarginStart", Con.dp(a, 10))
            bar?.addView(Con.hairline(a, p.line))
        }
        for (v in Con.allOf(tb, { it is TextView })) {
            val t = v as TextView
            if (!Con.seen(t, "sc-title")) {
                t.textSize = 17f
                t.setTextColor(p.text)
                t.typeface = ZelligeHome.face(600)
            }
        }
        for (v in Con.allOf(tb, { it is ImageButton })) {
            val b = v as ImageButton
            if (Con.seen(b, "sc-nav")) continue
            b.imageTintList = ColorStateList.valueOf(p.dim)
            b.background = Con.ripple(Con.rounded(Color.TRANSPARENT, Con.dpf(a, 10f), p.border, Con.dp(a, 1).coerceAtLeast(1)), Con.dpf(a, 10f))
            val pad = Con.dp(a, 8)
            b.setPadding(pad, pad, pad, pad)
            b.layoutParams?.let { it.width = Con.dp(a, 36); it.height = Con.dp(a, 36); b.layoutParams = it }
        }
    }

    // ------------------------------------------------------------------ footer
    private fun footer(a: Activity, box: ViewGroup) {
        val parent = box.parent as? LinearLayout ?: return
        if (parent.findViewWithTag<View>("zl_settings_footer") != null) return
        val p = Con.pal(a)
        val ver = try { a.packageManager.getPackageInfo(a.packageName, 0).versionName } catch (t: Throwable) { null } ?: "1.0"
        val tv = Con.text(a, "zellige $ver · GPL-3.0 · حول ›", 11f, p.faint, Con.mono(a)).apply {
            tag = "zl_settings_footer"
            isClickable = true
            setOnClickListener { AboutChrome.show(a) }
            gravity = Gravity.CENTER
            textDirection = View.TEXT_DIRECTION_LTR
            setPadding(Con.dp(a, 16), Con.dp(a, 28), Con.dp(a, 16), Con.dp(a, 20))
        }
        parent.addView(tv, 1, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }

    // ------------------------------------------------------------------ rows
    private fun row(a: Activity, v: View) {
        val title = v.findViewById<TextView>(android.R.id.title) ?: return
        val frame = v.findViewById<ViewGroup>(android.R.id.widget_frame)
        val p = Con.pal(a)
        if (frame == null) category(a, p, v, title) else normal(a, p, v, title, frame)
    }

    private fun category(a: Activity, p: Con.P, v: View, title: TextView) {
        // الصف ممكن يتعاود يتربط (title/summary يتبدلو)؛ نعاودو نثبّتو الأيقونة فقط
        v.findViewById<View>(Con.id(a, "icon_frame"))?.visibility = View.GONE
        v.findViewById<View>(android.R.id.icon)?.visibility = View.GONE
        if (title.currentTextColor != p.muted) title.setTextColor(p.muted)
        if (Con.seen(v, "sc-cat")) return
        title.textSize = 11f
        title.typeface = Con.mono(a)
        title.letterSpacing = 0.12f
        title.isAllCaps = true
        title.textDirection = View.TEXT_DIRECTION_LTR
        title.textAlignment = View.TEXT_ALIGNMENT_VIEW_START
        title.setPadding(0, 0, 0, 0)
        (title.parent as? View)?.setPadding(0, 0, 0, 0)
        v.setPaddingRelative(Con.dp(a, 16), Con.dp(a, 14), Con.dp(a, 16), Con.dp(a, 6))
        v.minimumHeight = Con.dp(a, 28)
        v.findViewById<TextView>(android.R.id.summary)?.apply { textSize = 11f; setTextColor(p.faint) }
        v.setBackgroundColor(Color.TRANSPARENT)
    }

    private fun normal(a: Activity, p: Con.P, v: View, title: TextView, frame: ViewGroup) {
        // تُعاد قراءتها مع كل bind: التطبيق يرجّع الأيقونة ويبدّل ظهور الملخّص
        v.findViewById<View>(Con.id(a, "icon_frame"))?.visibility = View.GONE
        v.findViewById<View>(android.R.id.icon)?.visibility = View.GONE
        bgs[v]?.let { if (v.background !== it) v.background = it }
        if (title.currentTextColor != p.text) title.setTextColor(p.text)
        if (Con.seen(v, "sc-row")) return
        v.setPaddingRelative(Con.dp(a, 16), Con.dp(a, 6), Con.dp(a, 16), Con.dp(a, 6))
        v.minimumHeight = Con.dp(a, 46)
        Con.ripple(line(p.line, bottom = true), 0f).also { bgs[v] = it; v.background = it }
        title.textSize = 14f
        v.findViewById<TextView>(android.R.id.summary)?.apply {
            textSize = 11.5f; setTextColor(p.faint)
            (layoutParams as? ViewGroup.MarginLayoutParams)?.let { it.topMargin = Con.dp(a, 2); layoutParams = it }
        }
        val w = frame.getChildAt(0)
        when {
            w is CompoundButton && w.javaClass.simpleName.contains("Switch", true) -> switchStyle(a, p, w)
            w is CompoundButton -> {
                Con.call(w, "setButtonTintList", ColorStateList.valueOf(p.amber))
            }
            w == null && v.isClickable -> {
                // صف كيفتح شي حاجة: سهم › (كيتبدّل حسب اتجاه الواجهة)
                val rtl = a.resources.configuration.layoutDirection == View.LAYOUT_DIRECTION_RTL
                frame.addView(Con.iconView(a, if (rtl) "zl_ic_chevron_left" else "zl_ic_chevron_right", p.faint, 15),
                    FrameLayout.LayoutParams(Con.dp(a, 15), Con.dp(a, 15), Gravity.CENTER))
                frame.visibility = View.VISIBLE
            }
        }
    }

    /** خط سفلي 1px (وعلوي اختياري) فوق خلفية شفافة. */
    private fun line(color: Int, bottom: Boolean, top: Boolean = false): Drawable {
        val layers = ArrayList<Drawable>()
        layers.add(ColorDrawable(Color.TRANSPARENT))
        if (bottom) layers.add(ColorDrawable(color))
        if (top) layers.add(ColorDrawable(color))
        val ld = LayerDrawable(layers.toTypedArray())
        var i = 1
        if (bottom) { ld.setLayerGravity(i, Gravity.BOTTOM); ld.setLayerHeight(i, 1); i++ }
        if (top) { ld.setLayerGravity(i, Gravity.TOP); ld.setLayerHeight(i, 1) }
        return ld
    }

    /** مفتاح 38×22 بزوايا 7dp؛ المقبض 16×16 بزوايا 5dp: عنبري/داكن عند التفعيل، رمادي عند الإطفاء. */
    private fun switchStyle(a: Activity, p: Con.P, sw: CompoundButton) {
        fun dp(v: Int) = Con.dp(a, v)
        fun track(c: Int) = GradientDrawable().apply { setColor(c); cornerRadius = Con.dpf(a, 7f); setSize(dp(38), dp(22)) }
        fun thumb(c: Int): Drawable {
            val g = GradientDrawable().apply { setColor(c); cornerRadius = Con.dpf(a, 5f); setSize(dp(16), dp(16)) }
            return InsetDrawable(g, (dp(3) / 2).coerceAtLeast(1), dp(3), (dp(3) / 2).coerceAtLeast(1), dp(3))
        }
        val tr = StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_checked), track(p.amber))
            addState(intArrayOf(), track(p.chipHi))
        }
        val th = StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_checked), thumb(p.onAmber))
            addState(intArrayOf(), thumb(p.faint))
        }
        Con.call(sw, "setUseMaterialThemeColors", false)
        Con.call(sw, "setThumbTintList", null)
        Con.call(sw, "setTrackTintList", null)
        Con.call(sw, "setThumbIconDrawable", null)
        Con.call(sw, "setTrackDecorationDrawable", null)
        Con.call(sw, "setThumbDrawable", th)
        Con.call(sw, "setTrackDrawable", tr)
        Con.call(sw, "setSwitchMinWidth", dp(38))
        Con.call(sw, "setShowText", false)
    }
}
