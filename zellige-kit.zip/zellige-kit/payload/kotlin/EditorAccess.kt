package com.itsaky.androidide.ai

import android.app.Activity
import android.view.View
import android.view.ViewGroup
import java.io.File

/**
 * وصول للمحرر (Sora CodeEditor / IDEEditor) عبر reflection،
 * باش الكود يبقى خدّام حتى لو تبدلات أسماء الحقول فـ EditorActivity.
 */
class EditorAccess private constructor(private val v: View) {

    private fun invoke(t: Any, name: String, vararg args: Any?): Any? {
        val m = t.javaClass.methods.firstOrNull { it.name == name && it.parameterTypes.size == args.size }
            ?: throw NoSuchMethodException("${t.javaClass.name}.$name/${args.size}")
        return m.invoke(t, *args)
    }

    private fun call(t: Any?, name: String, vararg args: Any?): Any? =
        if (t == null) null else try { invoke(t, name, *args) } catch (e: Throwable) { null }

    private fun i(o: Any?): Int = (o as? Number)?.toInt() ?: 0

    private val text: Any? get() = call(v, "getText")
    private val cursor: Any? get() = call(v, "getCursor")

    fun allText(): String = text?.toString().orEmpty()

    fun file(): File? = call(v, "getFile") as? File

    fun selection(): String? {
        val c = cursor ?: return null
        if (call(c, "isSelected") != true) return null
        val s = allText()
        val l = i(call(c, "getLeft"))
        val r = i(call(c, "getRight"))
        return if (l in 0 until r && r <= s.length) s.substring(l, r) else null
    }

    /** يدرج الكود فموضع المؤشر (أو يستبدل التحديد). */
    fun replaceSelection(code: String) {
        val c = cursor ?: throw IllegalStateException("ما لقيتش المؤشر")
        val t = text ?: throw IllegalStateException("ما لقيتش النص")
        invoke(
            t, "replace",
            i(call(c, "getLeftLine")), i(call(c, "getLeftColumn")),
            i(call(c, "getRightLine")), i(call(c, "getRightColumn")),
            code
        )
    }

    // ---- primitives used by the live "typing" apply (AiLive)
    fun lineCount(): Int = i(call(text, "getLineCount"))

    /** سطر/عمود المؤشر (يبدآن من 0). */
    fun cursorLine(): Int = i(call(cursor, "getLeftLine"))
    fun cursorColumn(): Int = i(call(cursor, "getLeftColumn"))

    /** موضع المؤشر كفهرس داخل النص (نفس ترقيم allText بعد توحيد نهايات الأسطر). */
    fun cursorIndex(): Int {
        val all = allText().replace("\r\n", "\n")
        val line = cursorLine()
        var idx = 0
        var l = 0
        while (l < line) {
            val nl = all.indexOf('\n', idx)
            if (nl < 0) return all.length
            idx = nl + 1
            l++
        }
        return (idx + cursorColumn()).coerceIn(0, all.length)
    }

    /** يحط المؤشر ويظهره فالشاشة. */
    fun moveCursor(line: Int, col: Int) {
        call(v, "setSelection", line, col)
        call(v, "ensureSelectionVisible")
    }

    /** يحدد مجالا (للتمييز البصري قبل الاستبدال). */
    fun selectRange(l1: Int, c1: Int, l2: Int, c2: Int) {
        call(v, "setSelectionRegion", l1, c1, l2, c2)
        call(v, "ensureSelectionVisible")
    }

    /** يستبدل مجالا بنص (أو يدرج إذا كان المجال فارغا). */
    fun replaceRange(l1: Int, c1: Int, l2: Int, c2: Int, code: String) {
        val t = text ?: throw IllegalStateException("ما لقيتش النص")
        invoke(t, "replace", l1, c1, l2, c2, code)
    }

    /** يستبدل محتوى الملف كامل (كيمكن التراجع بـ undo ديال المحرر). */
    fun replaceAll(code: String) {
        val t = text ?: throw IllegalStateException("ما لقيتش النص")
        val last = i(invoke(t, "getLineCount")) - 1
        val col = i(invoke(t, "getColumnCount", last))
        invoke(t, "replace", 0, 0, last, col, code)
    }

    companion object {
        fun find(a: Activity): EditorAccess? {
            val root = a.window?.decorView ?: return null
            var found: View? = null
            fun walk(x: View) {
                if (found != null) return
                if (isEditor(x) && x.isShown) { found = x; return }
                if (x is ViewGroup) for (k in 0 until x.childCount) walk(x.getChildAt(k))
            }
            walk(root)
            return found?.let { EditorAccess(it) }
        }

        private fun isEditor(x: View): Boolean {
            var c: Class<*>? = x.javaClass
            while (c != null) {
                if (c.name == "io.github.rosemoe.sora.widget.CodeEditor") return true
                c = c.superclass
            }
            return false
        }
    }
}
