package com.itsaky.androidide.ai

import android.app.Activity
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import java.io.File
import java.lang.ref.WeakReference

/**
 * «التطبيق المباشر»: لمّا الذكاء يكتب كود، كيفتح الملف فالمحرر وكيكتب فيه قدام المستعمل (سطر بسطر)،
 * والشات ما كيعرض كود. التنقل (فتح الملف، فتح شجرة الملفات) والكتابة كلها داخل واجهة التطبيق نفسها.
 *
 * كل شيء عبر reflection ومحمي بـ try/catch: إلا تعذّر أي شيء كنرجعو للكتابة المباشرة على القرص
 * (نفس النتيجة، بلا أنيميشن)، يعني ما كيتكسر لا البناء ولا التطبيق.
 */
object AiLive {

    private val ui = Handler(Looper.getMainLooper())
    @Volatile private var lastTreeFlash = 0L

    fun isEditor(a: Activity) = a.javaClass.simpleName.contains("Editor")

    fun enabled(a: Activity): Boolean = isEditor(a) && AiPrefs(a).liveApply

    private fun norm(s: String) = s.replace("\r\n", "\n")

    private fun sameFile(ed: EditorAccess, f: File): Boolean =
        try { ed.file()?.canonicalFile == f.canonicalFile } catch (t: Throwable) { false }

    // ------------------------------------------------------------------ entering live mode
    /** أول عملية مباشرة فالمهمة: كنسدّو نافذة الشات ونعرضو الـ HUD باش المستعمل يشوف المحرر. */
    fun begin(a: Activity, run: AiAgent.Run) {
        if (run.live) return
        run.live = true
        a.runOnUiThread {
            AiChat.dismissSheet()
            AiHud.show(a)
        }
    }

    // ------------------------------------------------------------------ navigation
    /** يفتح الملف فـ تبويب جديد (أو يمرّ لتبويبو) ويرجع المحرر بعد ما يبان. من أي thread (ماشي الـ UI). */
    fun open(a: Activity, run: AiAgent.Run, f: File, line: Int? = null): EditorAccess? {
        if (!enabled(a)) return null
        begin(a, run)
        val opened = AiAgent.onUi(a) { openFile(a, f) }
        if (!opened) return null
        val ed = waitEditor(a, f, run) ?: return null
        if (line != null && line > 0) {
            AiAgent.onUi(a) {
                val l = (line - 1).coerceIn(0, (ed.lineCount() - 1).coerceAtLeast(0))
                ed.moveCursor(l, 0)
            }
        }
        return ed
    }

    private fun openFile(a: Activity, f: File): Boolean {
        return try {
            val m = a.javaClass.methods.firstOrNull {
                it.name == "openFile" && it.parameterTypes.size == 2 && it.parameterTypes[0] == File::class.java
            } ?: return false
            m.invoke(a, f, null)
            true
        } catch (t: Throwable) { false }
    }

    private fun waitEditor(a: Activity, f: File, run: AiAgent.Run): EditorAccess? {
        repeat(50) {
            if (!run.alive()) return null
            val ed = AiAgent.onUi(a) { EditorAccess.find(a)?.takeIf { sameFile(it, f) } }
            if (ed != null) return ed
            Thread.sleep(60)
        }
        return null
    }

    /** ينتظر حتى المحرر يحمّل محتوى الملف (التحميل async). */
    private fun waitText(a: Activity, ed: EditorAccess, expected: String, run: AiAgent.Run): Boolean {
        val want = norm(expected)
        repeat(45) {
            if (!run.alive()) return false
            val now = AiAgent.onUi(a) { norm(ed.allText()) }
            if (now == want) return true
            Thread.sleep(60)
        }
        return false
    }

    /** يفتح الدرج الجانبي (شجرة الملفات) لحظة قصيرة باش المستعمل يشوف المجلد/الملف الجديد. */
    fun showTree(a: Activity, run: AiAgent.Run) {
        if (!enabled(a)) return
        begin(a, run)
        val now = System.currentTimeMillis()
        if (now - lastTreeFlash < 4000) return
        lastTreeFlash = now
        AiIde.refreshAll(a)
        a.runOnUiThread {
            val dl = findDrawer(a.window?.decorView) ?: return@runOnUiThread
            ui.postDelayed({ drawer(dl, true) }, 450)
            ui.postDelayed({ drawer(dl, false) }, 2000)
        }
        try { Thread.sleep(1500) } catch (t: InterruptedException) { }
    }

    private const val GRAVITY_START = 8388611

    private fun drawer(dl: View, open: Boolean) {
        try {
            val m = dl.javaClass.getMethod(if (open) "openDrawer" else "closeDrawer", Int::class.javaPrimitiveType)
            m.invoke(dl, GRAVITY_START)
        } catch (t: Throwable) { /* بلا درج: ما كاين مشكل */ }
    }

    private fun findDrawer(x: View?): View? {
        if (x == null) return null
        var c: Class<*>? = x.javaClass
        while (c != null) {
            if (c.name == "androidx.drawerlayout.widget.DrawerLayout") return x
            c = c.superclass
        }
        if (x is ViewGroup) for (k in 0 until x.childCount) findDrawer(x.getChildAt(k))?.let { return it }
        return null
    }

    // ------------------------------------------------------------------ live apply
    /**
     * يطبّق newText على الملف فالمحرر مباشرة ثم يكتبو على القرص.
     * يرجع false إلا ما أمكنش (ماشي فشاشة المحرر، الميزة مطفية، أو تعذّر الربط) والمستدعي يكتب عادي.
     * كيشتغل من thread الوكيل (ماشي الـ UI).
     */
    fun apply(a: Activity, run: AiAgent.Run, f: File, old: String?, newText: String): Boolean {
        if (!enabled(a)) return false
        return try {
            val existed = f.exists()
            if (!existed) {
                f.parentFile?.mkdirs()
                f.writeText("")
                showTree(a, run)
            }
            val ed = open(a, run, f) ?: return false
            val base = old ?: ""
            if (!waitText(a, ed, base, run)) {
                // المحرر ما طابقش المتوقع: نبدّلو المحتوى كامل مرة وحدة
                AiAgent.onUi(a) { ed.replaceAll(newText) }
            } else {
                AiDiff.animate(EditorSink(a, ed, run), norm(base), norm(newText))
                AiAgent.onUi(a) { if (norm(ed.allText()) != norm(newText)) ed.replaceAll(newText) }
            }
            f.writeText(newText)
            true
        } catch (t: Throwable) { false }
    }

    /** يحوّل عمليات الأنيميشن إلى استدعاءات حقيقية على المحرر (كلها على الـ UI thread). */
    private class EditorSink(private val a: Activity, private val ed: EditorAccess, private val run: AiAgent.Run) : EditSink {
        override fun select(l1: Int, c1: Int, l2: Int, c2: Int) { AiAgent.onUi(a) { ed.selectRange(l1, c1, l2, c2) } }
        override fun replace(l1: Int, c1: Int, l2: Int, c2: Int, text: String) { AiAgent.onUi(a) { ed.replaceRange(l1, c1, l2, c2, text) } }
        override fun move(line: Int, col: Int) { AiAgent.onUi(a) { ed.moveCursor(line, col) } }
        override fun pause(ms: Long) { if (ms > 0) Thread.sleep(ms) }
        override fun alive(): Boolean = run.alive()
    }

    // ------------------------------------------------------------------ end of run
    fun finish(a: Activity, run: AiAgent.Run, error: String?, summary: String) {
        if (!run.live) return
        a.runOnUiThread { AiHud.finish(a, error, summary) }
    }
}

/** شريط عائم صغير فوق المحرر: كيقول شنو كيتطبّق دابا، مع زر إيقاف، وفالأخير «تراجع» و«الشات». */
object AiHud {

    private var ref: WeakReference<Activity>? = null
    private var view: LinearLayout? = null
    private var label: TextView? = null
    private var spin: ProgressBar? = null
    private var tick: ImageView? = null
    private var stop: View? = null
    private var buttons: LinearLayout? = null
    private var finished = false
    private val ui = Handler(Looper.getMainLooper())
    private var hideTask: Runnable? = null

    private fun lp(a: Activity) = FrameLayout.LayoutParams(
        ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
        Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
    ).apply {
        bottomMargin = AiChat.dp(a, 118)
        marginStart = AiChat.dp(a, 12)
        marginEnd = AiChat.dp(a, 12)
    }

    /** من الـ UI thread. */
    fun show(a: Activity) {
        hideTask?.let { ui.removeCallbacks(it) }
        finished = false
        ref = WeakReference(a)
        val content = a.findViewById<ViewGroup>(android.R.id.content) ?: return
        val existing = content.findViewWithTag<View>("ai_hud")
        if (existing != null && existing === view) {
            apply(a, false, null)
            return
        }
        (existing?.parent as? ViewGroup)?.removeView(existing)
        try {
            val p = AiChat.pal(a)
            val box = LinearLayout(a).apply {
                tag = "ai_hud"
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = AiChat.outlined(p.bg, AiChat.dp(a, 12).toFloat(), p.accent, AiChat.dp(a, 1))
                elevation = AiChat.dp(a, 12).toFloat()
                setPadding(AiChat.dp(a, 14), AiChat.dp(a, 8), AiChat.dp(a, 8), AiChat.dp(a, 8))
            }
            val sp = ProgressBar(a).apply {
                isIndeterminate = true
                indeterminateTintList = ColorStateList.valueOf(p.accent)
            }
            val tk = ImageView(a).apply {
                setImageDrawable(AiChat.icon(a, "ic_ai_sparkle"))
                imageTintList = ColorStateList.valueOf(p.okColor)
                visibility = View.GONE
            }
            val tv = TextView(a).apply {
                setTextColor(p.text); textSize = 12.5f; typeface = ZelligeHome.loadMono(a)
                setSingleLine(); ellipsize = TextUtils.TruncateAt.END
                textDirection = View.TEXT_DIRECTION_ANY_RTL
                maxWidth = (a.resources.displayMetrics.widthPixels * 0.62f).toInt()
            }
            val st = AiChat.iconButton(a, "ic_ai_stop", "إيقاف", p.sub, Color.TRANSPARENT, 38) { AiChat.stop(a) }
            val btns = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; visibility = View.GONE }
            fun pill(t: String, accent: Boolean, f: () -> Unit): TextView = TextView(a).apply {
                text = t; textSize = 12.5f; gravity = Gravity.CENTER
                setTextColor(if (accent) p.onAccent else p.text)
                setPadding(AiChat.dp(a, 12), AiChat.dp(a, 6), AiChat.dp(a, 12), AiChat.dp(a, 6))
                background = AiChat.ripple(AiChat.shape(if (accent) p.accent else p.surface, AiChat.dp(a, 8).toFloat()), AiChat.dp(a, 8).toFloat())
                isClickable = true; isFocusable = true
                setOnClickListener { f() }
            }
            btns.addView(pill("تراجع", false) {
                android.widget.Toast.makeText(a, AiAgent.undoLast(a), android.widget.Toast.LENGTH_LONG).show()
                hide(a)
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginStart = AiChat.dp(a, 8) })
            btns.addView(pill("الشات", true) { hide(a); AiChat.show(a) },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginStart = AiChat.dp(a, 6) })
            box.addView(sp, LinearLayout.LayoutParams(AiChat.dp(a, 18), AiChat.dp(a, 18)).apply { marginEnd = AiChat.dp(a, 10) })
            box.addView(tk, LinearLayout.LayoutParams(AiChat.dp(a, 20), AiChat.dp(a, 20)).apply { marginEnd = AiChat.dp(a, 10) })
            box.addView(tv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            box.addView(btns)
            box.addView(st, LinearLayout.LayoutParams(AiChat.dp(a, 38), AiChat.dp(a, 38)).apply { marginStart = AiChat.dp(a, 4) })
            box.alpha = 0f
            box.translationY = AiChat.dp(a, 24).toFloat()
            content.addView(box, lp(a))
            box.animate().alpha(1f).translationY(0f).setDuration(200).start()
            view = box; label = tv; spin = sp; tick = tk; stop = st; buttons = btns
            apply(a, false, null)
        } catch (t: Throwable) { /* الـ HUD اختياري */ }
    }

    private fun apply(a: Activity, done: Boolean, text: String?) {
        val shown = text ?: AiChat.statusText().ifBlank { "يطبّق التعديلات…" }
        val pre = "AI ▸ "
        val sb = android.text.SpannableStringBuilder(pre).append(shown)
        sb.setSpan(android.text.style.ForegroundColorSpan(AiChat.pal(a).accent), 0, pre.length - 1, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        label?.text = sb
        spin?.visibility = if (done) View.GONE else View.VISIBLE
        tick?.visibility = if (done) View.VISIBLE else View.GONE
        stop?.visibility = if (done) View.GONE else View.VISIBLE
        buttons?.visibility = if (done) View.VISIBLE else View.GONE
    }

    /** كتتنادى كل ما تتبدّل حالة الوكيل (من الـ UI thread). */
    fun refresh() {
        val a = ref?.get() ?: return
        if (view == null || finished) return
        if (!AiChat.isBusy()) return
        apply(a, false, null)
    }

    fun finish(a: Activity, error: String?, summary: String) {
        if (view == null) return
        finished = true
        val ok = error == null
        val text = if (ok) summary.ifBlank { "تم التطبيق" } else "توقّف: " + error.orEmpty().take(80)
        apply(a, true, text)
        if (!ok) tick?.imageTintList = ColorStateList.valueOf(AiChat.pal(a).danger)
        hideTask?.let { ui.removeCallbacks(it) }
        val t = Runnable { hide(a) }
        hideTask = t
        ui.postDelayed(t, 10_000)
    }

    fun hide(a: Activity) {
        hideTask?.let { ui.removeCallbacks(it) }
        val v = view ?: return
        view = null; label = null; spin = null; tick = null; stop = null; buttons = null
        v.animate().alpha(0f).translationY(AiChat.dp(a, 24).toFloat()).setDuration(180).withEndAction {
            (v.parent as? ViewGroup)?.removeView(v)
        }.start()
    }
}
