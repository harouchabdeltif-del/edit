package com.itsaky.androidide.ai

/** عمليات المحرر التي يحتاجها الأنيميشن (التنفيذ الحقيقي فـ AiLive، والاختبار بنسخة وهمية). */
interface EditSink {
    fun select(l1: Int, c1: Int, l2: Int, c2: Int)
    fun replace(l1: Int, c1: Int, l2: Int, c2: Int, text: String)
    fun move(line: Int, col: Int)
    fun pause(ms: Long)
    fun alive(): Boolean
}

/**
 * منطق «الكتابة المباشرة»: يحسب المجال اللي تبدّل بين النص القديم والجديد (بداية ونهاية مشتركتين على حدود الأسطر)،
 * يبيّن المجال القديم، يمسحو، ثم يكتب الجديد على دفعات من الأسطر. بلا أي اعتماد على Android (قابل للاختبار على JVM).
 */
object AiDiff {

    /** (سطر، عمود) لفهرس داخل نص موحّد بـ \n. */
    fun lineCol(text: String, idx: Int): Pair<Int, Int> {
        var line = 0
        var last = -1
        var i = text.indexOf('\n')
        while (i in 0 until idx) { line++; last = i; i = text.indexOf('\n', i + 1) }
        return line to (idx - (last + 1))
    }

    /** المجال المتغيّر: [start, oldEnd) في القديم يتبدّل بـ [start, newEnd) من الجديد. */
    data class Region(val start: Int, val oldEnd: Int, val newEnd: Int)

    fun region(old: String, new: String): Region {
        val max = minOf(old.length, new.length)
        var p = 0
        while (p < max && old[p] == new[p]) p++
        p = old.lastIndexOf('\n', p - 1) + 1
        var s = 0
        while (s < old.length - p && s < new.length - p && old[old.length - 1 - s] == new[new.length - 1 - s]) s++
        while (s > 0 && old.length - s - 1 >= 0 && old[old.length - s - 1] != '\n') s--
        return Region(p, old.length - s, new.length - s)
    }

    /** old و new لازم يكونو موحّدين بـ \n. */
    fun animate(sink: EditSink, old: String, new: String) {
        if (old == new) return
        val r = region(old, new)
        val oldMid = old.substring(r.start, r.oldEnd)
        val newMid = new.substring(r.start, r.newEnd)
        val (l0, c0) = lineCol(old, r.start)

        if (oldMid.isNotEmpty()) {
            val (l1, c1) = lineCol(old, r.oldEnd)
            sink.select(l0, c0, l1, c1)                       // نبيّنو شنو غادي يتبدّل
            sink.pause(if (sink.alive()) 380 else 0)
            sink.replace(l0, c0, l1, c1, "")
        } else {
            sink.move(l0, c0)
            sink.pause(if (sink.alive()) 160 else 0)
        }
        if (newMid.isEmpty()) return

        // المدة الكلية 0.4–2.8 ثانية مهما كان الحجم
        val lines = newMid.split('\n')
        val duration = (400 + lines.size * 16).coerceAtMost(2800)
        val frames = (duration / 45).coerceIn(1, 90)
        val per = ((lines.size + frames - 1) / frames).coerceAtLeast(1)
        var line = l0
        var col = c0
        var i = 0
        while (i < lines.size) {
            val last = (i + per).coerceAtMost(lines.size)
            val hasMore = last < lines.size
            val rest = if (sink.alive()) null else lines.subList(i, lines.size).joinToString("\n")  // المستعمل وقّف: نكمّلو دفعة وحدة
            val text = rest ?: (lines.subList(i, last).joinToString("\n") + (if (hasMore) "\n" else ""))
            sink.replace(line, col, line, col, text)
            val nl = text.count { it == '\n' }
            if (nl == 0) col += text.length else { line += nl; col = text.length - text.lastIndexOf('\n') - 1 }
            sink.move(line, col)
            if (rest != null) return
            i = last
            if (i < lines.size) sink.pause((duration / frames).toLong())
        }
        sink.pause(120)
    }
}
