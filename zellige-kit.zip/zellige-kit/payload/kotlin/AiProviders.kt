package com.itsaky.androidide.ai

/**
 * سجل المزوّدين. لكل مزوّد: صيغة الـ API + العنوان الجاهز، والمستعمل يدخل المفتاح فقط.
 * أي مزوّد غير موجود هنا يمكن إضافته عبر "custom" (عنوان + صيغة + headers).
 */
object AiProviders {

    /** format = openai (متوافق مع OpenAI) | anthropic | gemini */
    class Provider(
        val id: String,
        val label: String,
        val format: String,
        val base: String,
        val model: String = "",
        val needsKey: Boolean = true,
        /** لائحة احتياطية لما ما يكونش عند المزوّد endpoint لجلب الموديلات. */
        val fallback: List<String> = emptyList()
    )

    val ALL: List<Provider> = listOf(
        Provider("openrouter", "OpenRouter (مئات الموديلات)", "openai", "https://openrouter.ai/api/v1", "openrouter/auto"),
        Provider("openai", "OpenAI (GPT)", "openai", "https://api.openai.com/v1", "gpt-4o-mini"),
        Provider("claude", "Anthropic (Claude)", "anthropic", "https://api.anthropic.com", "claude-sonnet-5-5"),
        Provider("gemini", "Google (Gemini)", "gemini", "https://generativelanguage.googleapis.com", "gemini-2.5-pro"),
        Provider("deepseek", "DeepSeek", "openai", "https://api.deepseek.com/v1", "deepseek-chat"),
        Provider("groq", "Groq", "openai", "https://api.groq.com/openai/v1", "llama-3.3-70b-versatile"),
        Provider("xai", "xAI (Grok)", "openai", "https://api.x.ai/v1"),
        Provider("mistral", "Mistral", "openai", "https://api.mistral.ai/v1", "mistral-large-latest"),
        Provider("together", "Together AI", "openai", "https://api.together.xyz/v1"),
        Provider("fireworks", "Fireworks AI", "openai", "https://api.fireworks.ai/inference/v1"),
        Provider("deepinfra", "DeepInfra", "openai", "https://api.deepinfra.com/v1/openai"),
        Provider("hyperbolic", "Hyperbolic", "openai", "https://api.hyperbolic.xyz/v1"),
        Provider("cerebras", "Cerebras", "openai", "https://api.cerebras.ai/v1"),
        Provider("sambanova", "SambaNova", "openai", "https://api.sambanova.ai/v1"),
        Provider("nvidia", "NVIDIA NIM", "openai", "https://integrate.api.nvidia.com/v1"),
        Provider("huggingface", "Hugging Face", "openai", "https://router.huggingface.co/v1"),
        Provider("moonshot", "Moonshot (Kimi)", "openai", "https://api.moonshot.ai/v1"),
        Provider("zai", "Z.AI (GLM)", "openai", "https://api.z.ai/api/paas/v4"),
        Provider("qwen", "Alibaba Qwen (DashScope)", "openai", "https://dashscope-intl.aliyuncs.com/compatible-mode/v1"),
        Provider("siliconflow", "SiliconFlow", "openai", "https://api.siliconflow.com/v1"),
        Provider("cohere", "Cohere", "openai", "https://api.cohere.ai/compatibility/v1"),
        Provider(
            "perplexity", "Perplexity", "openai", "https://api.perplexity.ai", "sonar",
            fallback = listOf("sonar", "sonar-pro", "sonar-reasoning", "sonar-reasoning-pro", "sonar-deep-research")
        ),
        Provider("ollama", "Ollama (محلي — بلا مفتاح)", "openai", "http://127.0.0.1:11434/v1", needsKey = false),
        Provider("lmstudio", "LM Studio (محلي — بلا مفتاح)", "openai", "http://127.0.0.1:1234/v1", needsKey = false),
        Provider("custom", "Custom — أي مزوّد آخر", "openai", "", needsKey = false)
    )

    fun get(id: String): Provider? = ALL.firstOrNull { it.id == id }

    fun ids(): List<String> = ALL.map { it.id }
}
