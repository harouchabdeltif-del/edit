package com.itsaky.androidide.ai

import android.content.Context

/**
 * الإعدادات. المفتاح والموديل والعنوان كيتخزنوا لكل مزوّد على حدة،
 * وبالتالي تبديل المزوّد ما كيضيّع حتى مفتاح.
 */
class AiPrefs(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("ai_assistant", Context.MODE_PRIVATE)

    init { migrate() }

    /** ترحيل الإعدادات القديمة (مفتاح واحد) إلى النظام الجديد (مفتاح لكل مزوّد). */
    private fun migrate() {
        if (sp.getBoolean("migrated_v2", false)) return
        val e = sp.edit()
        if (sp.contains("api_key")) {
            val pr = sp.getString("provider", "openrouter") ?: "openrouter"
            e.putString("key_$pr", sp.getString("api_key", "") ?: "")
            e.putString("model_$pr", sp.getString("model", "") ?: "")
            e.putString("base_$pr", sp.getString("base_url", "") ?: "")
        }
        e.putBoolean("migrated_v2", true).apply()
    }

    private fun str(k: String): String = sp.getString(k, "") ?: ""
    private fun put(k: String, v: String) { sp.edit().putString(k, v).apply() }

    var provider: String
        get() = sp.getString("provider", "openrouter") ?: "openrouter"
        set(v) { put("provider", v) }

    // ---- قيم خاصة بكل مزوّد
    fun keyFor(id: String): String = str("key_$id")
    fun setKeyFor(id: String, v: String) = put("key_$id", v)
    fun modelFor(id: String): String = str("model_$id")
    fun setModelFor(id: String, v: String) = put("model_$id", v)
    fun baseFor(id: String): String = str("base_$id")
    fun setBaseFor(id: String, v: String) = put("base_$id", v)

    // ---- قيم المزوّد الحالي
    var model: String
        get() = modelFor(provider)
        set(v) { setModelFor(provider, v) }

    var apiKey: String
        get() = keyFor(provider)
        set(v) { setKeyFor(provider, v) }

    var baseUrl: String
        get() = baseFor(provider)
        set(v) { setBaseFor(provider, v) }

    // ---- إعدادات المزوّد المخصص (custom)
    var customName: String
        get() = str("custom_name")
        set(v) { put("custom_name", v) }

    /** openai | anthropic | gemini */
    var customFormat: String
        get() = str("custom_format").ifBlank { "openai" }
        set(v) { put("custom_format", v) }

    /** اسم الـ header ديال المفتاح (فارغ = الافتراضي حسب الصيغة). */
    var customAuthHeader: String
        get() = str("custom_auth_header")
        set(v) { put("custom_auth_header", v) }

    var customAuthPrefix: String
        get() = str("custom_auth_prefix")
        set(v) { put("custom_auth_prefix", v) }

    /** headers إضافية: سطر لكل header بالشكل  Name: value */
    var customHeaders: String
        get() = str("custom_headers")
        set(v) { put("custom_headers", v) }

    /** مسار الدردشة (فارغ = الافتراضي حسب الصيغة). يقبل {model} فالـ gemini. */
    var customChatPath: String
        get() = str("custom_chat_path")
        set(v) { put("custom_chat_path", v) }

    /** auto | light | dark */
    var theme: String
        get() = sp.getString("theme", "auto") ?: "auto"
        set(v) { put("theme", v) }

    /** سجل المحادثة (JSON) باش يبقى حتى بعد إغلاق التطبيق. */
    var history: String
        get() = str("history")
        set(v) { put("history", v) }

    /** false (الافتراضي) = ينفّذ مباشرة بلا أسئلة. true = يطلب تأكيدا قبل كل كتابة/حذف/تنفيذ أمر. */
    var askBeforeEdit: Boolean
        get() = sp.getBoolean("ask_before_edit", false)
        set(v) { sp.edit().putBoolean("ask_before_edit", v).apply() }

    /** التطبيق المباشر: الذكاء يفتح الملف فالمحرر ويكتب فيه قدام المستعمل (الافتراضي مفعّل). */
    var liveApply: Boolean
        get() = sp.getBoolean("live_apply", true)
        set(v) { sp.edit().putBoolean("live_apply", v).apply() }

    /** ترتيب المشاريع فالشاشة الرئيسية: recent | name */
    var homeSort: String
        get() = sp.getString("home_sort", "recent") ?: "recent"
        set(v) { put("home_sort", v) }

    /** المشاريع المثبّتة فالشاشة الرئيسية (مسارات، كل مسار فسطر). */
    var pinned: String
        get() = str("pinned_projects")
        set(v) { put("pinned_projects", v) }

    /** مجلد المشاريع (فارغ = نفس مجلد AndroidIDEProjects ديال IDE). المشاريع الجديدة كتتخلق فيه. */
    var workspace: String
        get() = str("workspace")
        set(v) { put("workspace", v) }

    /** المشروع النشط للوكيل (كيتحفظ باش يبقى حتى بعد إغلاق التطبيق). */
    var activeProject: String
        get() = str("active_project")
        set(v) { put("active_project", v) }

    /** آخر مشروع تفتح فـ IDE. */
    var lastOpened: String
        get() = str("last_opened")
        set(v) { put("last_opened", v) }

    /** عند تشغيل التطبيق: رجوع تلقائي لآخر مشروع. */
    var autoOpenLast: Boolean
        get() = sp.getBoolean("auto_open_last", true)
        set(v) { sp.edit().putBoolean("auto_open_last", v).apply() }

    /** فتح المشاريع التي ينشئها الذكاء داخل IDE تلقائيا. */
    var autoOpenNew: Boolean
        get() = sp.getBoolean("auto_open_new", true)
        set(v) { sp.edit().putBoolean("auto_open_new", v).apply() }

    /** حارس ضد حلقة انهيار عند الفتح التلقائي (commit متزامن باش يتحفظ قبل أي انهيار). */
    var autoOpenPending: Boolean
        get() = sp.getBoolean("auto_open_pending", false)
        set(v) { sp.edit().putBoolean("auto_open_pending", v).commit() }

    fun needsKey(): Boolean = AiProviders.get(provider)?.needsKey ?: true

    fun ready(): Boolean = apiKey.isNotBlank() || !needsKey()

    fun effectiveModel(): String = model.ifBlank { AiProviders.get(provider)?.model.orEmpty() }

    fun providerLabel(): String =
        if (provider == "custom") customName.ifBlank { "Custom" }
        else AiProviders.get(provider)?.label?.substringBefore(" (")?.substringBefore(" —") ?: provider

    companion object {
        val THEMES = listOf("auto", "light", "dark")
    }
}
