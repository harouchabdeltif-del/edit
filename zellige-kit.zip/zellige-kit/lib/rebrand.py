"""Stage 2 - rebrand: app name, launcher icon, splash, in-app logo, colour theme (see theme.py).

What changes:
  * the visible name "AndroidIDE" inside <string> texts of every locale
    (never in licence comments, URLs or identifiers)
  * TermuxConstants.TERMUX_APP_NAME (display name used in crash/info screens)
  * launcher icons (legacy, round, adaptive, themed), splash icon,
    notification glyph, in-app logo, Play Store icon

What deliberately does NOT change: the applicationId / package name.
The terminal, JDK and Gradle toolchain live under
/data/data/<applicationId>/files/usr and come from prebuilt packages that
hard-code that path (see README), so a different id would break them.
"""
import re

from . import theme
from .core import KIT, Fail, NAME_OK, read, res_roots, say, walk

BRAND_RES = KIT / "brand" / "res"
OLD_NAME = "AndroidIDE"

# "AndroidIDE" as a word: not part of a URL path, a dotted id, an @mention or AndroidIDEOfficial
NAME_RE = re.compile(r"(?<![\w/.\-@])AndroidIDE(?!\w)")
COMMENT_RE = re.compile(r"(<!--.*?-->)", re.S)
STRING_FILES = re.compile(r"^(strings|termux_app_strings|termux_shared_strings)\.xml$")


def xml_escape(name):
    return (name.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            .replace("'", "\\'").replace('"', '\\"').replace("@", "\\@"))


def run(ws, app, name):
    if not NAME_OK.match(name):
        raise Fail(f"الاسم «{name}» ما صالحش (حروف/أرقام/فراغ/نقطة/شرطة، حتى 32 حرف)")
    if not BRAND_RES.is_dir():
        raise Fail(f"brand/res ناقص ({BRAND_RES})")
    roots = res_roots(ws.root)
    if not roots:
        raise Fail("ما لقيتش مجلد res فيه أيقونة التطبيق (mipmap-anydpi-v26/ic_launcher.xml)")
    names = rename_strings(ws, roots + [app / "src" / "main" / "res"], name)
    rename_constant(ws, name)
    icons(ws, roots)
    playstore(ws, app)
    theme.run(ws, app)
    ws.set_applied(rebrand="1", name=name)
    say(f"✅ الاسم: {OLD_NAME} → {name}  ({names} نص)")


# ------------------------------------------------------------------ names
def rename_strings(ws, roots, name):
    safe = xml_escape(name)
    total = 0
    seen = set()
    for res in roots:
        if res in seen or not res.is_dir():
            continue
        seen.add(res)
        for values in sorted(res.glob("values*")):
            for f in sorted(values.glob("*.xml")):
                if not STRING_FILES.match(f.name):
                    continue
                text = read(f)
                if OLD_NAME not in text:
                    continue
                parts = COMMENT_RE.split(text)  # odd indexes are comments: leave them alone
                n = 0
                for i in range(0, len(parts), 2):
                    parts[i], k = NAME_RE.subn(safe, parts[i])
                    n += k
                if n:
                    ws.write(f, "".join(parts))
                    total += n
    return total


CONST_RE = re.compile(r'(TERMUX_APP_NAME\s*=\s*")AndroidIDE(")')


def rename_constant(ws, name):
    hits = 0
    for d, files in walk(ws.root):
        if "TermuxConstants.java" in files:
            f = d / "TermuxConstants.java"
            text = read(f)
            new, n = CONST_RE.subn(lambda m: m.group(1) + name.replace('"', "") + m.group(2), text)
            if n:
                ws.write(f, new)
                hits += n
    if hits:
        say("✅ TermuxConstants.TERMUX_APP_NAME")


# ------------------------------------------------------------------ icons
def icons(ws, roots):
    n = 0
    for res in roots:
        for src in sorted(BRAND_RES.rglob("*")):
            if not src.is_file():
                continue
            rel = src.relative_to(BRAND_RES)
            dst = res / rel
            # a same-named .webp/.png twin would be a duplicate resource
            for ext in (".webp", ".png", ".jpg"):
                twin = dst.with_suffix(ext)
                if twin != dst and twin.exists() and dst.suffix in (".png", ".webp", ".jpg"):
                    ws.delete(twin)
            ws.copy(src, dst)
            n += 1
    say(f"✅ {n} ملف أيقونة/شعار  (launcher، splash، notification، logo)")


def playstore(ws, app):
    src = KIT / "brand" / "playstore.png"
    dst = app / "src" / "main" / "ic_launcher-playstore.png"
    if src.is_file() and dst.exists():
        ws.copy(src, dst)
