"""Stage 2 - rebrand: app name, launcher icon, splash, in-app logo, colour theme (see theme.py).

What changes:
  * the visible name "AndroidIDE" inside <string> texts of every locale
    (never in licence comments, URLs or identifiers)
  * TermuxConstants.TERMUX_APP_NAME (display name used in crash/info screens)
  * user-visible string literals in a few Kotlin/Java files (build messages, crash screen,
    new-project templates, layout-preview defaults) - see LITERAL_FILES
  * the projects folder name AndroidIDEProjects -> ZelligeProjects (the app moves the old folder once)
  * launcher icons (legacy, round, adaptive, themed), splash icon,
    notification glyph, in-app logo, Play Store icon

What deliberately does NOT change: the applicationId / package name.
The terminal, JDK and Gradle toolchain live under
/data/data/<applicationId>/files/usr and come from prebuilt packages that
hard-code that path (see README), so a different id would break them.
"""
import re

from . import theme
from .core import KIT, NOT_APP_PARTS, Fail, NAME_OK, read, res_roots, say, walk

BRAND_RES = KIT / "brand" / "res"
OLD_NAME = "AndroidIDE"

# "AndroidIDE" as a word: not part of a URL path, a dotted id, an @mention or AndroidIDEOfficial
NAME_RE = re.compile(r"(?<![\w/.\-@])AndroidIDE(?!\w)")
COMMENT_RE = re.compile(r"(<!--.*?-->)", re.S)
STRING_FILES = re.compile(r"^(strings|termux_app_strings|termux_shared_strings)\.xml$")


def xml_escape(name):
    return (name.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            .replace("'", "\\'").replace('"', '\\"').replace("@", "\\@"))


def run(ws, app, name):
    if not NAME_OK.match(name):
        raise Fail(f"الاسم «{name}» ما صالحش (حروف/أرقام/فراغ/نقطة/شرطة، حتى 32 حرف)")
    if not BRAND_RES.is_dir():
        raise Fail(f"brand/res ناقص ({BRAND_RES})")
    roots = res_roots(ws.root)
    if not roots:
        raise Fail("ما لقيتش مجلد res فيه أيقونة التطبيق (mipmap-anydpi-v26/ic_launcher.xml)")
    names = rename_strings(ws, roots + [app / "src" / "main" / "res"] + module_res(ws.root), name)
    rename_constant(ws, name)
    lits = rename_literals(ws, name)
    projects_folder(ws)
    icons(ws, roots)
    playstore(ws, app)
    theme.run(ws, app)
    ws.set_applied(rebrand="1", name=name)
    say(f"✅ الاسم: {OLD_NAME} → {name}  ({names} نص، {lits} نص فالكود)")


# ------------------------------------------------------------------ names
def rename_strings(ws, roots, name):
    safe = xml_escape(name)
    total = 0
    seen = set()
    for res in roots:
        if res in seen or not res.is_dir():
            continue
        seen.add(res)
        for values in sorted(res.glob("values*")):
            for f in sorted(values.glob("*.xml")):
                if not STRING_FILES.match(f.name):
                    continue
                text = read(f)
                if OLD_NAME not in text:
                    continue
                parts = COMMENT_RE.split(text)  # odd indexes are comments: leave them alone
                n = 0
                for i in range(0, len(parts), 2):
                    parts[i], k = NAME_RE.subn(safe, parts[i])
                    n += k
                if n:
                    ws.write(f, "".join(parts))
                    total += n
    return total


CONST_RE = re.compile(r'(TERMUX_APP_NAME\s*=\s*")AndroidIDE(")')


def rename_constant(ws, name):
    hits = 0
    for d, files in walk(ws.root):
        if "TermuxConstants.java" in files:
            f = d / "TermuxConstants.java"
            text = read(f)
            new, n = CONST_RE.subn(lambda m: m.group(1) + name.replace('"', "") + m.group(2), text)
            if n:
                ws.write(f, new)
                hits += n
    if hits:
        say("✅ TermuxConstants.TERMUX_APP_NAME")


def module_res(root):
    """Every module's src/main/res (libraries too: logsender, termux…), never tests/samples."""
    out = []
    for d, _ in walk(root):
        if d.name == "res" and d.parent.name == "main" and d.parent.parent.name == "src":
            if NOT_APP_PARTS & set(d.relative_to(root).parts):
                continue
            out.append(d)
    return out


# Kotlin/Java files whose *string literals* are shown to the user. Only literals are touched,
# and NAME_RE never matches inside URLs, package names or AndroidIDEOfficial.
LITERAL_FILES = (
    "core/app/src/main/java/com/itsaky/androidide/fragments/CrashReportFragment.kt",
    "core/app/src/main/java/com/itsaky/androidide/actions/filetree/CopyPathAction.kt",
    "tooling/impl/src/main/java/com/itsaky/androidide/tooling/impl/sync/AbstractModelBuilder.kt",
    "utilities/templates-impl/src/main/java/com/itsaky/androidide/templates/impl/navDrawerActivity/navDrawerActivityTemplate.kt",
    "utilities/xml-inflater/src/main/java/com/itsaky/androidide/inflater/internal/utils/basicParseUtils.kt",
    "utilities/xml-inflater/src/main/java/com/itsaky/androidide/inflater/internal/adapters/TextViewAdapter.kt",
    "logging/logsender/src/main/java/com/itsaky/androidide/logsender/LogSenderService.java",
    "termux/shared/src/main/java/com/termux/shared/termux/TermuxUtils.java",
)
LITERAL_RE = re.compile(r'"(?:[^"\\\n]|\\.)*"')
EXTRA_LITERALS = {'"contact@androidide.com"': '"contact@example.com"'}


def rename_literals(ws, name):
    safe = name.replace("\\", "").replace('"', "")
    total = 0
    for rel in LITERAL_FILES:
        f = ws.root / rel
        if not f.is_file():
            continue
        text = read(f)
        count = [0]

        def lit(m):
            s = m.group(0)
            if s in EXTRA_LITERALS:
                count[0] += 1
                return EXTRA_LITERALS[s]
            new, k = NAME_RE.subn(safe, s)
            count[0] += k
            return new

        new = LITERAL_RE.sub(lit, text)
        if count[0]:
            ws.write(f, new)
            total += count[0]
    return total


PROJECTS_RE = re.compile(r'(PROJECTS_FOLDER\s*=\s*")AndroidIDEProjects(")')


def projects_folder(ws):
    for d, files in walk(ws.root):
        if "Environment.java" in files and d.name == "utils":
            f = d / "Environment.java"
            text = read(f)
            new, n = PROJECTS_RE.subn(r"\g<1>ZelligeProjects\g<2>", text)
            if n:
                ws.write(f, new)
                say("✅ مجلد المشاريع: AndroidIDEProjects → ZelligeProjects")


# ------------------------------------------------------------------ icons
def icons(ws, roots):
    n = 0
    for res in roots:
        for src in sorted(BRAND_RES.rglob("*")):
            if not src.is_file():
                continue
            rel = src.relative_to(BRAND_RES)
            dst = res / rel
            # a same-named .webp/.png twin would be a duplicate resource
            for ext in (".webp", ".png", ".jpg"):
                twin = dst.with_suffix(ext)
                if twin != dst and twin.exists() and dst.suffix in (".png", ".webp", ".jpg"):
                    ws.delete(twin)
            ws.copy(src, dst)
            n += 1
    say(f"✅ {n} ملف أيقونة/شعار  (launcher، splash، notification، logo)")


def playstore(ws, app):
    src = KIT / "brand" / "playstore.png"
    dst = app / "src" / "main" / "ic_launcher-playstore.png"
    if src.is_file() and dst.exists():
        ws.copy(src, dst)
