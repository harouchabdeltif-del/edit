"""Stage 2b - theme: Zellige "Console" palette, tighter shapes, system font.

AndroidIDE applies "Blue Wave" by default (IDETheme.DEFAULT), whose colours are plain
<color name="_blue_wave_{light,dark}_*"> resources.  Re-colouring those resources restyles the whole
app (editor chrome, dialogs, sheets, buttons, preferences) without touching any Kotlin.

Everything goes through Workspace, so `undo` restores the originals byte for byte.
Console direction: near-black surfaces (#0A0C10), hairline borders, one amber accent (#FFB454) used for the
AI and for primary actions, green for success, red for errors.  A paper-light variant is provided for the
light theme (the design mock-ups are dark only).
"""
import re

from .core import read, say, walk

# role -> hex (RGB). Names are the suffix after "_blue_wave_<mode>_".
PALETTE = {
    "light": {
        "colorPrimary": "9A5B00", "colorPrimaryContainer": "FFE2B8", "colorPrimaryDark": "9A5B00",
        "colorPrimaryInverse": "FFB454", "colorOnPrimary": "FFFFFF", "colorOnPrimaryContainer": "2D1A00",
        "colorSecondary": "4A5160", "colorSecondaryContainer": "E6E8EE", "colorOnSecondary": "FFFFFF",
        "colorOnSecondaryContainer": "161A23",
        "colorTertiary": "1E7A3B", "colorTertiaryContainer": "C5F0D1", "colorOnTertiary": "FFFFFF",
        "colorOnTertiaryContainer": "002110",
        "colorError": "C62828", "colorErrorContainer": "FFDAD6", "colorOnError": "FFFFFF",
        "colorOnErrorContainer": "410002",
        "colorBackground": "F7F6F2", "colorOnBackground": "14171C",
        "colorSurface": "F7F6F2", "colorSurfaceInverse": "2A2E36", "colorSurfaceVariant": "E9E8E3",
        "colorOnSurface": "14171C", "colorOnSurfaceInverse": "F1F2F5", "colorOnSurfaceVariant": "4A5160",
        "colorOutline": "8A8F9A",
    },
    "dark": {
        "colorPrimary": "FFB454", "colorPrimaryContainer": "3A290C", "colorPrimaryDark": "FFB454",
        "colorPrimaryInverse": "8A5A00", "colorOnPrimary": "1A1000", "colorOnPrimaryContainer": "FFD9A0",
        "colorSecondary": "C4CAD6", "colorSecondaryContainer": "1E2530", "colorOnSecondary": "10131A",
        "colorOnSecondaryContainer": "D9DDE5",
        "colorTertiary": "7BD88F", "colorTertiaryContainer": "17301F", "colorOnTertiary": "0A2412",
        "colorOnTertiaryContainer": "B6F0C4",
        "colorError": "FF7A7A", "colorErrorContainer": "4A1A1D", "colorOnError": "2A0608",
        "colorOnErrorContainer": "FFC9C9",
        "colorBackground": "0A0C10", "colorOnBackground": "D9DDE5",
        "colorSurface": "0A0C10", "colorSurfaceInverse": "D9DDE5", "colorSurfaceVariant": "161A23",
        "colorOnSurface": "D9DDE5", "colorOnSurfaceInverse": "0A0C10", "colorOnSurfaceVariant": "A5ADBB",
        "colorOutline": "4A5160",
    },
}

COLOR_RE = re.compile(r'(<color\s+name="_blue_wave_(light|dark)_(\w+)">)#[0-9a-fA-F]{8}(</color>)')
SPLASH_RE = re.compile(r'(<color\s+name="splash_bg">)[^<]*(</color>)')
SPLASH = {"day": "#F7F6F2", "night": "#0A0C10"}

SHAPES_FILE = "zellige_theme.xml"
SHAPES_XML = """<?xml version="1.0" encoding="utf-8"?>
<resources>
    <!-- Zellige Console: tight components (cards, text fields, chips) -->
    <style name="Zl.ShapeAppearance.Small" parent="">
        <item name="cornerFamily">rounded</item>
        <item name="cornerSize">8dp</item>
    </style>
    <style name="Zl.ShapeAppearance.Medium" parent="">
        <item name="cornerFamily">rounded</item>
        <item name="cornerSize">12dp</item>
    </style>
</resources>
"""
SHAPE_MARK = "Zl.ShapeAppearance.Medium"
ANCHOR = re.compile(r'(<item\s+name="colorSuccess">[^<]*</item>)')
FONT_RE = re.compile(r'(<item\s+name="(?:android:)?fontFamily">)@font/josefin_sans(</item>)')
SHEET_RE = re.compile(r'(<style\s+name="AppTheme\.ShapeOverlay\.Large"[^>]*>.*?</style>)', re.S)


def run(ws, app):
    files = {"colors": 0, "styles": 0, "splash": 0, "dimens": 0}
    for d, names in walk(ws.root):
        if d.name == "values" and "theme_blue_wave.xml" in names:
            files["colors"] += recolor(ws, d / "theme_blue_wave.xml")
            files["styles"] += restyle(ws, d)
        if d.name == "values" and "dimens.xml" in names:
            files["dimens"] += square(ws, d / "dimens.xml")
        if d.name in ("values", "values-night") and "colors.xml" in names:
            files["splash"] += splash(ws, d / "colors.xml", night=d.name == "values-night")
    if not files["colors"]:
        say("⚠️  ما لقيتش theme_blue_wave.xml: الثيم ما تبدّلش (الاسم والأيقونة كيخدمو عادي)")
        return
    ws.set_applied(theme="1")
    say(f"✅ الثيم: Console ({files['colors']} لون: أسود + عنبري) + أشكال 8/12dp + خط النظام")


def recolor(ws, f):
    text = read(f)
    n = 0

    def sub(m):
        nonlocal n
        hexv = PALETTE[m.group(2)].get(m.group(3))
        if hexv is None:
            return m.group(0)
        n += 1
        return f"{m.group(1)}#ff{hexv.lower()}{m.group(4)}"

    new = COLOR_RE.sub(sub, text)
    if new != text:
        ws.write(f, new)
    return n


def restyle(ws, values_dir):
    f = values_dir / "styles.xml"
    if not f.is_file():
        return 0
    text = read(f)
    nl = "\r\n" if "\r\n" in text else "\n"
    new = FONT_RE.sub(r"\1sans-serif\2", text)
    new = SHEET_RE.sub(lambda m: re.sub(r'(cornerSize(?:TopRight|TopLeft)">)16dp', r"\g<1>12dp", m.group(1)), new)
    if SHAPE_MARK not in new:
        m = ANCHOR.search(new)
        if m:
            add = (nl + '    <item name="shapeAppearanceSmallComponent">@style/Zl.ShapeAppearance.Small</item>'
                   + nl + '    <item name="shapeAppearanceMediumComponent">@style/Zl.ShapeAppearance.Medium</item>')
            new = new[:m.end()] + add + new[m.end():]
            ws.write(values_dir / SHAPES_FILE, SHAPES_XML if nl == "\n" else SHAPES_XML.replace("\n", nl))
    if new != text:
        ws.write(f, new)
        return 1
    return 0


CORNERS_RE = re.compile(r'(<dimen\s+name="editor_container_corners">)28dp(</dimen>)')


def square(ws, f):
    """Design C: the editor surface is flush with the screen (no 28dp rounded card)."""
    text = read(f)
    new = CORNERS_RE.sub(r"\g<1>0dp\g<2>", text)
    if new != text:
        ws.write(f, new)
        return 1
    return 0


def splash(ws, f, night):
    text = read(f)
    new = SPLASH_RE.sub(lambda m: m.group(1) + SPLASH["night" if night else "day"] + m.group(2), text)
    if new != text:
        ws.write(f, new)
        return 1
    return 0
