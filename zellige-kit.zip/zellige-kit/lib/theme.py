"""Stage 2b - theme: Zellige palette, rounder shapes, system font.

AndroidIDE applies "Blue Wave" by default (IDETheme.DEFAULT), whose colours are plain
<color name="_blue_wave_{light,dark}_*"> resources.  Re-colouring those resources restyles the whole
app (editor chrome, dialogs, sheets, buttons, preferences) without touching any Kotlin.

Everything goes through Workspace, so `undo` restores the originals byte for byte.
The palette below is a Majorelle-blue / saffron "zellige" scheme; the dark variant uses the same deep
navy surfaces as the reference design (#0F131C background, raised cards ~#1C1E2A).
"""
import re

from .core import read, say, walk

# role -> hex (RGB). Names are the suffix after "_blue_wave_<mode>_".
PALETTE = {
    "light": {
        "colorPrimary": "3550C8", "colorPrimaryContainer": "DCE1FF", "colorPrimaryDark": "3550C8",
        "colorPrimaryInverse": "B8C4FF", "colorOnPrimary": "FFFFFF", "colorOnPrimaryContainer": "00164F",
        "colorSecondary": "5A5E7A", "colorSecondaryContainer": "DFE1FA", "colorOnSecondary": "FFFFFF",
        "colorOnSecondaryContainer": "171B33",
        "colorTertiary": "7B5800", "colorTertiaryContainer": "FFDFA0", "colorOnTertiary": "FFFFFF",
        "colorOnTertiaryContainer": "261900",
        "colorError": "BA1A1A", "colorErrorContainer": "FFDAD6", "colorOnError": "FFFFFF",
        "colorOnErrorContainer": "410002",
        "colorBackground": "F9F9FF", "colorOnBackground": "191B24",
        "colorSurface": "F9F9FF", "colorSurfaceInverse": "2E313B", "colorSurfaceVariant": "E1E2EE",
        "colorOnSurface": "191B24", "colorOnSurfaceInverse": "F0F0FB", "colorOnSurfaceVariant": "444653",
        "colorOutline": "747685",
    },
    "dark": {
        "colorPrimary": "B8C4FF", "colorPrimaryContainer": "1B3FA3", "colorPrimaryDark": "B8C4FF",
        "colorPrimaryInverse": "3A52C9", "colorOnPrimary": "0B1F6E", "colorOnPrimaryContainer": "DCE1FF",
        "colorSecondary": "C3C7DE", "colorSecondaryContainer": "3F4565", "colorOnSecondary": "2C3045",
        "colorOnSecondaryContainer": "DDE1FB",
        "colorTertiary": "F1C873", "colorTertiaryContainer": "5B4300", "colorOnTertiary": "3E2D00",
        "colorOnTertiaryContainer": "FFDFA0",
        "colorError": "FFB4AB", "colorErrorContainer": "93000A", "colorOnError": "690005",
        "colorOnErrorContainer": "FFDAD6",
        "colorBackground": "0F131C", "colorOnBackground": "E1E2EC",
        "colorSurface": "0F131C", "colorSurfaceInverse": "E1E2EC", "colorSurfaceVariant": "262A38",
        "colorOnSurface": "E1E2EC", "colorOnSurfaceInverse": "2E313B", "colorOnSurfaceVariant": "C4C7D6",
        "colorOutline": "8E92A3",
    },
}

COLOR_RE = re.compile(r'(<color\s+name="_blue_wave_(light|dark)_(\w+)">)#[0-9a-fA-F]{8}(</color>)')
SPLASH_RE = re.compile(r'(<color\s+name="splash_bg">)[^<]*(</color>)')
SPLASH = {"day": "#F6F7FF", "night": "#0F131C"}

SHAPES_FILE = "zellige_theme.xml"
SHAPES_XML = """<?xml version="1.0" encoding="utf-8"?>
<resources>
    <!-- Zellige: rounder components (cards, text fields, chips) -->
    <style name="Zl.ShapeAppearance.Small" parent="">
        <item name="cornerFamily">rounded</item>
        <item name="cornerSize">14dp</item>
    </style>
    <style name="Zl.ShapeAppearance.Medium" parent="">
        <item name="cornerFamily">rounded</item>
        <item name="cornerSize">22dp</item>
    </style>
</resources>
"""
SHAPE_MARK = "Zl.ShapeAppearance.Medium"
ANCHOR = re.compile(r'(<item\s+name="colorSuccess">[^<]*</item>)')
FONT_RE = re.compile(r'(<item\s+name="(?:android:)?fontFamily">)@font/josefin_sans(</item>)')
SHEET_RE = re.compile(r'(<style\s+name="AppTheme\.ShapeOverlay\.Large"[^>]*>.*?</style>)', re.S)


def run(ws, app):
    files = {"colors": 0, "styles": 0, "splash": 0}
    for d, names in walk(ws.root):
        if d.name == "values" and "theme_blue_wave.xml" in names:
            files["colors"] += recolor(ws, d / "theme_blue_wave.xml")
            files["styles"] += restyle(ws, d)
        if d.name in ("values", "values-night") and "colors.xml" in names:
            files["splash"] += splash(ws, d / "colors.xml", night=d.name == "values-night")
    if not files["colors"]:
        say("⚠️  ما لقيتش theme_blue_wave.xml: الثيم ما تبدّلش (الاسم والأيقونة كيخدمو عادي)")
        return
    ws.set_applied(theme="1")
    say(f"✅ الثيم: ألوان Zellige ({files['colors']} لون) + أشكال أنعم + خط النظام")


def recolor(ws, f):
    text = read(f)
    n = 0

    def sub(m):
        nonlocal n
        hexv = PALETTE[m.group(2)].get(m.group(3))
        if hexv is None:
            return m.group(0)
        n += 1
        return f"{m.group(1)}#ff{hexv.lower()}{m.group(4)}"

    new = COLOR_RE.sub(sub, text)
    if new != text:
        ws.write(f, new)
    return n


def restyle(ws, values_dir):
    f = values_dir / "styles.xml"
    if not f.is_file():
        return 0
    text = read(f)
    nl = "\r\n" if "\r\n" in text else "\n"
    new = FONT_RE.sub(r"\1sans-serif\2", text)
    new = SHEET_RE.sub(lambda m: re.sub(r'(cornerSize(?:TopRight|TopLeft)">)16dp', r"\g<1>28dp", m.group(1)), new)
    if SHAPE_MARK not in new:
        m = ANCHOR.search(new)
        if m:
            add = (nl + '    <item name="shapeAppearanceSmallComponent">@style/Zl.ShapeAppearance.Small</item>'
                   + nl + '    <item name="shapeAppearanceMediumComponent">@style/Zl.ShapeAppearance.Medium</item>')
            new = new[:m.end()] + add + new[m.end():]
            ws.write(values_dir / SHAPES_FILE, SHAPES_XML if nl == "\n" else SHAPES_XML.replace("\n", nl))
    if new != text:
        ws.write(f, new)
        return 1
    return 0


def splash(ws, f, night):
    text = read(f)
    new = SPLASH_RE.sub(lambda m: m.group(1) + SPLASH["night" if night else "day"] + m.group(2), text)
    if new != text:
        ws.write(f, new)
        return 1
    return 0
