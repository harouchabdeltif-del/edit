"""Shared plumbing: locating the app module and reversible file changes.

Every file the kit touches goes through `Workspace`:
  * an existing file is copied once into  <root>/.zellige/backup/<relpath>
    before its first modification;
  * a file/dir the kit creates is listed in <root>/.zellige/created.txt.
`undo` replays both, so the tree returns to exactly what it was.
"""
import os
import re
import shutil
from pathlib import Path

KIT = Path(__file__).resolve().parent.parent
STATE_DIR = ".zellige"
SKIP_DIRS = {"build", ".git", ".gradle", ".idea", ".kotlin", ".cxx", "node_modules", STATE_DIR}
# directories that look like Android modules but are not the real app
NOT_APP_PARTS = {"assets", "testing", "test", "androidTest", "sample", "samples", "templates"}


def read(p):
    """Read text without newline translation (keeps CRLF files byte-exact)."""
    return Path(p).read_bytes().decode("utf-8", errors="surrogateescape")


class Fail(Exception):
    """A problem the user can act on (printed without a traceback)."""


def say(msg=""):
    print(msg, flush=True)


def walk(root, skip=SKIP_DIRS):
    """os.walk that never descends into build/VCS directories."""
    for dirpath, dirs, files in os.walk(root):
        dirs[:] = [d for d in dirs if d not in skip]
        yield Path(dirpath), files


def find_app(root):
    """Return the application module dir (the one with <application> in its manifest)."""
    for cand in (root / "app", root / "core" / "app"):
        if (cand / "src" / "main" / "AndroidManifest.xml").is_file():
            return cand
    found = []
    for d, files in walk(root):
        if len(d.relative_to(root).parts) > 6:
            continue
        if d.name == "main" and d.parent.name == "src" and "AndroidManifest.xml" in files:
            if NOT_APP_PARTS & set(d.relative_to(root).parts):
                continue
            try:
                if "<application" in (d / "AndroidManifest.xml").read_text(errors="ignore"):
                    found.append(d.parent.parent)
            except OSError:
                pass
    if not found:
        raise Fail(f"ما لقيتش موديول التطبيق فـ: {root}\n"
                   f"   (خاصو يكون فيه src/main/AndroidManifest.xml فيه <application>)")
    found.sort(key=lambda p: (p.name != "app", len(p.parts)))
    return found[0]


def res_roots(root):
    """Resource dirs that hold the real launcher icon (adaptive icon xml)."""
    out = []
    for d, _ in walk(root):
        if d.name == "res" and d.parent.name == "main" and d.parent.parent.name == "src":
            rel = d.relative_to(root).parts
            if NOT_APP_PARTS & set(rel):
                continue
            if (d / "mipmap-anydpi-v26" / "ic_launcher.xml").is_file():
                out.append(d)
    return out


class Workspace:
    def __init__(self, root):
        self.root = Path(root).resolve()
        self.dir = self.root / STATE_DIR
        self.bak = self.dir / "backup"
        self.created_file = self.dir / "created.txt"
        self.applied_file = self.dir / "applied.txt"
        self._created = None

    # ---------------------------------------------------------------- state
    def rel(self, p):
        return Path(p).resolve().relative_to(self.root).as_posix()

    def created(self):
        if self._created is None:
            self._created = []
            if self.created_file.is_file():
                self._created = [l for l in self.created_file.read_text().splitlines() if l]
        return self._created

    def mark_created(self, p):
        rel = self.rel(p)
        if rel in self.created():
            return
        self.created().append(rel)
        self.dir.mkdir(parents=True, exist_ok=True)
        self.created_file.write_text("\n".join(self._created) + "\n")

    def applied(self):
        if not self.applied_file.is_file():
            return {}
        out = {}
        for line in self.applied_file.read_text().splitlines():
            if "=" in line:
                k, v = line.split("=", 1)
                out[k] = v
        return out

    def set_applied(self, **kv):
        cur = self.applied()
        cur.update({k: str(v) for k, v in kv.items()})
        self.dir.mkdir(parents=True, exist_ok=True)
        self.applied_file.write_text("".join(f"{k}={v}\n" for k, v in cur.items()))

    # ---------------------------------------------------------------- changes
    def _guard(self, p):
        """Snapshot an existing file once, before its first change."""
        rel = self.rel(p)
        if any(rel == c or rel.startswith(c + "/") for c in self.created()):
            return  # our own file (or inside our own dir): no original to protect
        dst = self.bak / rel
        if dst.exists():
            return
        legacy = p.with_name(p.name + ".ai-bak")  # backup left by the old inject-ai.sh
        dst.parent.mkdir(parents=True, exist_ok=True)
        if legacy.exists():
            shutil.move(str(legacy), str(dst))
        elif p.exists():
            shutil.copy2(p, dst)

    def write(self, p, data):
        p = Path(p)
        if p.exists():
            self._guard(p)
        else:
            top = p  # record the highest missing ancestor so undo leaves no empty dirs
            while not top.parent.exists():
                top = top.parent
            self.mark_created(top)
            p.parent.mkdir(parents=True, exist_ok=True)
        if not isinstance(data, bytes):
            data = data.encode("utf-8", errors="surrogateescape")
        p.write_bytes(data)

    def copy(self, src, dst):
        self.write(dst, Path(src).read_bytes())

    def delete(self, p):
        """Remove an existing file (it is restored by undo)."""
        p = Path(p)
        if p.exists():
            self._guard(p)
            p.unlink()

    def new_dir(self, p):
        p = Path(p)
        if not p.exists():
            self.mark_created(p)
            p.mkdir(parents=True)

    def adopt_legacy(self, app):
        """Take ownership of files created by the old inject-ai.sh so undo can remove them."""
        if self.dir.exists():
            return
        main = app / "src" / "main"
        found = []
        ai = main / "java" / "com" / "itsaky" / "androidide" / "ai"
        if ai.is_dir():
            found.append(ai)
        found += sorted((main / "res" / "drawable").glob("ic_ai_*.xml"))
        keep = main / "res" / "raw" / "ai_keep.xml"
        if keep.is_file():
            found.append(keep)
        lc = app / "src" / "debug" / "res" / "values" / "leakcanary_config.xml"
        if lc.is_file() and "leak_canary_add_launcher_icon" in read(lc):
            found.append(lc)
        for f in found:
            self.mark_created(f)

    def _prune_empty(self, d):
        """Drop directories our files left empty (never the project root itself)."""
        while d != self.root and d.is_dir() and not any(d.iterdir()):
            d.rmdir()
            d = d.parent

    # ---------------------------------------------------------------- undo
    def undo(self):
        restored = removed = 0
        if self.bak.is_dir():
            for f in sorted(self.bak.rglob("*")):
                if f.is_file():
                    target = self.root / f.relative_to(self.bak)
                    target.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(f, target)
                    restored += 1
        for rel in sorted(self.created(), key=len, reverse=True):
            p = self.root / rel
            if p.is_dir() and not p.is_symlink():
                shutil.rmtree(p, ignore_errors=True)
                removed += 1
            elif p.exists():
                p.unlink()
                removed += 1
            self._prune_empty(p.parent)
        # leftovers from the old script that never reached our state dir
        for d, files in walk(self.root):
            for name in files:
                if name.endswith(".ai-bak"):
                    orig = d / name[: -len(".ai-bak")]
                    shutil.move(str(d / name), str(orig))
                    restored += 1
        shutil.rmtree(self.dir, ignore_errors=True)
        self._created = None
        return restored, removed


NAME_OK = re.compile(r"^[\w][\w .\-]{0,31}$")
