"""Command line: zellige.sh [ROOT] [all|inject|rebrand|undo|status] [--name NAME]"""
import argparse
import sys
from pathlib import Path

from . import inject, rebrand
from .core import Fail, Workspace, find_app, say

APPID_MSG = """\
⛔ تغيير الـ package name (applicationId) ما كيدعمهش هاد الـ kit، وهادا هو السبب:
   الترمنال و JDK و Gradle ديال AndroidIDE كيتخزنو فـ /data/data/<applicationId>/files/usr
   والحزم الجاهزة (bootstrap) مبنية بهاد المسار القديم com.itsaky.androidide بالضبط.
   إلا بدّلتي الـ id غادي يبقى التطبيق كيفتح، ولكن bash و apt و java ما غاديش يخدمو.
   (المسار مكتوب فـ TermuxConstants، والحزم كتنزل من terminal-packages جاهزة.)
   الاسم والأيقونة كيتبدلو بلا مشكل. شوف README → «لماذا بقى الـ package name؟»"""


def build_parser():
    ap = argparse.ArgumentParser(
        prog="zellige.sh",
        description="يحقن المساعد الذكي فـ AndroidIDE ويبدّل الاسم والأيقونة (كلشي كيتراجع بـ undo).")
    ap.add_argument("root", nargs="?", default=".", help="مجلد مصدر AndroidIDE")
    ap.add_argument("action", nargs="?", default="all",
                    choices=["all", "inject", "rebrand", "undo", "status"],
                    help="all (الافتراضي) = inject + rebrand")
    ap.add_argument("--name", default="Zellige", help="الاسم الجديد للتطبيق (الافتراضي Zellige)")
    ap.add_argument("--appid", help=argparse.SUPPRESS)
    return ap


def status(ws, app):
    ap = ws.applied()
    say(f"📁 الموديول : {ws.rel(app)}")
    say(f"🤖 المساعد  : {'مركّب' if ap.get('inject') else 'غير مركّب'}")
    say(f"🎨 الهوية   : {('مبدّلة → ' + ap.get('name', '?')) if ap.get('rebrand') else 'الأصلية'}")
    say(f"🗂️  ملفات مضافة: {len(ws.created())}   نسخ احتياطية: "
        f"{sum(1 for f in ws.bak.rglob('*') if f.is_file()) if ws.bak.is_dir() else 0}")


def main(argv=None):
    args = build_parser().parse_args(argv)
    if args.appid:
        say(APPID_MSG)
        return 2
    root = Path(args.root).expanduser()
    if not root.is_dir():
        raise Fail(f"المجلد غير موجود: {root}")
    ws = Workspace(root)
    app = find_app(ws.root)
    say(f"📁 موديول التطبيق: {app}")

    if args.action != "status":
        ws.adopt_legacy(app)

    if args.action == "undo":
        restored, removed = ws.undo()
        say(f"✅ تم التراجع  (رجّعت {restored} ملف، حيّدت {removed} مضاف)")
        return 0
    if args.action == "status":
        status(ws, app)
        return 0

    if args.action in ("all", "inject"):
        inject.run(ws, app)
    if args.action in ("all", "rebrand"):
        rebrand.run(ws, app, args.name)

    rel = ws.rel(app)
    gradle_path = ":" + rel.replace("/", ":") if rel != "." else ""
    say("")
    say("✅ تمّ. دابا بني التطبيق:")
    say(f"   cd {ws.root} && ./gradlew {gradle_path}:assembleDebug")
    say(f"   (للتراجع: bash zellige.sh {ws.root} undo)")
    return 0


def entry():
    try:
        sys.exit(main())
    except Fail as e:
        say(f"❌ {e}")
        sys.exit(1)
