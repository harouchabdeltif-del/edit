"""Stage 1 - inject the AI agent into the app module.

  1. copy the Kotlin sources (package com.itsaky.androidide.ai)
  2. copy the small vector icons the chat window uses
  3. call AiPlugin.install(this) from Application.onCreate()
  4. make sure the INTERNET permission exists
  5. hide LeakCanary's second "Leaks" launcher icon
"""
import re

from .core import KIT, Fail, read, say, walk

HOOK_MARK = "com.itsaky.androidide.ai.AiPlugin"
AI_PKG_PATH = "com/itsaky/androidide/ai"


def run(ws, app):
    install_sources(ws, app)
    install_resources(ws, app)
    hook_application(ws, app)
    ensure_internet(ws, app)
    hide_leakcanary(ws, app)
    ws.set_applied(inject="1")


# ------------------------------------------------------------------ 1 + 2
def install_sources(ws, app):
    src = KIT / "payload" / "kotlin"
    files = sorted(src.glob("*.kt"))
    if not files:
        raise Fail(f"payload/kotlin فارغ ({src})")
    dst = app / "src" / "main" / "java" / AI_PKG_PATH
    ws.new_dir(dst)
    for f in files:
        ws.copy(f, dst / f.name)
    say(f"✅ {len(files)} ملفات Kotlin  →  {ws.rel(dst)}")


def install_resources(ws, app):
    res = app / "src" / "main" / "res"
    n = 0
    for sub in ("drawable", "raw"):
        for f in sorted((KIT / "payload" / "res" / sub).glob("*")):
            ws.copy(f, res / sub / f.name)
            n += 1
    say(f"✅ {n} موارد (أيقونات الشات + ai_keep.xml)")


# ------------------------------------------------------------------ 3
APP_CLASS = re.compile(r":\s*\w*Application\w*\s*\(\)|extends\s+\w*Application\b")
ON_CREATE = re.compile(r"(override\s+fun\s+onCreate\s*\(\s*\)\s*\{|void\s+onCreate\s*\(\s*\)\s*\{)")
SUPER_CALL = re.compile(r"super\.onCreate\(\)[ \t]*;?")


def hook_application(ws, app):
    cands = []
    for d, files in walk(app / "src"):
        parts = set(d.relative_to(app / "src").parts)
        if parts & {"test", "androidTest", "ai"}:
            continue
        for name in files:
            if not name.endswith((".kt", ".java")):
                continue
            p = d / name
            text = read(p)
            if APP_CLASS.search(text) and "onCreate" in text:
                cands.append((p, text))
    cands.sort(key=lambda c: (0 if "IDEApplication" in c[0].name else 1, str(c[0])))
    if not cands:
        say("⚠️  ما لقيتش كلاس Application. زيد هاد السطر يدويا فـ Application.onCreate():")
        say("    com.itsaky.androidide.ai.AiPlugin.install(this)")
        return
    p, text = cands[0]
    if HOOK_MARK in text:
        say(f"ℹ️  {p.name} فيه الربط من قبل")
        return
    m = ON_CREATE.search(text)
    if not m:
        say(f"⚠️  ما لقيتش onCreate() فـ {ws.rel(p)}. زيد السطر يدويا.")
        return
    sup = SUPER_CALL.search(text, m.end())
    pos = sup.end() if sup else m.end()
    if p.suffix == ".kt":
        snippet = "\n        runCatching { com.itsaky.androidide.ai.AiPlugin.install(this) }"
    else:
        snippet = "\n        try { com.itsaky.androidide.ai.AiPlugin.install(this); } catch (Throwable ignored) {}"
    if "\r\n" in text:
        snippet = snippet.replace("\n", "\r\n")
    ws.write(p, text[:pos] + snippet + text[pos:])
    say(f"✅ ربطت المساعد فـ {ws.rel(p)}")


# ------------------------------------------------------------------ 4
def ensure_internet(ws, app):
    mf = app / "src" / "main" / "AndroidManifest.xml"
    text = read(mf)
    if "android.permission.INTERNET" in text:
        say("ℹ️  صلاحية INTERNET موجودة")
        return
    nl = "\r\n" if "\r\n" in text else "\n"
    text = re.sub(r"(<manifest[^>]*>)",
                  lambda m: m.group(1) + nl + '    <uses-permission android:name="android.permission.INTERNET"/>',
                  text, count=1)
    ws.write(mf, text)
    say("✅ زدت صلاحية INTERNET")


# ------------------------------------------------------------------ 5
LC_CODE = re.compile(r"import\s+(?:com\.squareup\.)?leakcanary|\bLeakCanary\.")
LC_LINE = re.compile(r"leakcanary", re.I)


def hide_leakcanary(ws, app):
    """Debug builds bundle LeakCanary, which adds a second "Leaks" icon to the launcher."""
    build_files = []
    for d, files in walk(ws.root):
        for name in files:
            if name.endswith((".kts", ".gradle", ".toml")):
                p = d / name
                try:
                    if LC_LINE.search(read(p)):
                        build_files.append(p)
                except OSError:
                    pass
    if not build_files:
        say("ℹ️  LeakCanary ما كاينش فالبناء")
        return
    code_uses = []
    for d, files in walk(ws.root):
        for name in files:
            if name.endswith((".kt", ".java")):
                p = d / name
                try:
                    if LC_CODE.search(read(p)):
                        code_uses.append(p)
                except OSError:
                    pass
    if not code_uses:
        for p in build_files:
            lines = read(p).splitlines(keepends=True)
            ws.write(p, "".join(l for l in lines if not LC_LINE.search(l)))
            say(f"🗑️  حيّدت LeakCanary من {ws.rel(p)}")
        return
    say("⚠️  LeakCanary مستعمل فالكود، غنخبّي الأيقونة فقط:")
    for p in code_uses:
        say("    " + ws.rel(p))
    cfg = app / "src" / "debug" / "res" / "values" / "leakcanary_config.xml"
    ws.write(cfg, '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n'
                  '    <bool name="leak_canary_add_launcher_icon">false</bool>\n</resources>\n')
