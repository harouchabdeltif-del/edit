#!/usr/bin/env bash
# Builds dist/zellige-all-in-one.sh (one self-extracting file) and dist/zellige-kit.zip
set -euo pipefail
KIT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OUT="$KIT/dist"; rm -rf "$OUT"; mkdir -p "$OUT"
find "$KIT" -name __pycache__ -type d -prune -exec rm -rf {} +

# one-file installer: shell header + base64(tar.gz of the kit)
{
cat <<'HEADER'
#!/usr/bin/env bash
# Zellige — all-in-one. نفس استعمال zellige.sh:
#   bash zellige-all-in-one.sh /path/to/AndroidIDE [all|inject|rebrand|undo|status] [--name NAME]
set -euo pipefail
command -v base64 >/dev/null 2>&1 || { echo "❌ خاصك base64"; exit 1; }
TMP="$(mktemp -d "${TMPDIR:-/tmp}/zellige.XXXXXX")"
trap 'rm -rf "$TMP"' EXIT
sed '1,/^__ZELLIGE_PAYLOAD__$/d' "$0" | base64 -d | tar xz -C "$TMP"
bash "$TMP/zellige-kit/zellige.sh" "$@"
exit $?
__ZELLIGE_PAYLOAD__
HEADER
tar -C "$(dirname "$KIT")" -czf - \
  --exclude="zellige-kit/dist" --exclude="zellige-kit/brand/preview.png" --exclude="__pycache__" \
  "$(basename "$KIT")" | base64 -w0
echo
} > "$OUT/zellige-all-in-one.sh"
chmod +x "$OUT/zellige-all-in-one.sh"

# organised kit
( cd "$(dirname "$KIT")" && zip -qr "$OUT/zellige-kit.zip" "$(basename "$KIT")" \
    -x "*/dist/*" "*/__pycache__/*" "*/brand/preview.png" )

ls -la "$OUT"
