#!/usr/bin/env python3
"""Zellige brand generator (dev-time only; needs Pillow).

Draws an eight-point zellige star on majorelle blue and writes every launcher
asset AndroidIDE uses into brand/res/, laid out exactly like a real `res/` dir
so rebrand.py can copy the tree over the app's resources.

The results are committed in brand/res, so the phone never needs Pillow.
"""
import math
import pathlib

from PIL import Image, ImageDraw

BG, GOLD, WHITE = "#22379A", "#F4B63E", "#FFFFFF"
HERE = pathlib.Path(__file__).parent
OUT = HERE / "res"

# (color, outer radius) on a 108 viewport centred at (54, 54): outermost first.
LAYERS = [(WHITE, 30.0), (BG, 24.0), (GOLD, 16.5), (BG, 9.0), (WHITE, 3.6)]
C = 54.0


def star(cx, cy, r):
    """Eight-point star = an axis-aligned square plus a 45-degree square."""
    s = r / math.sqrt(2)
    return [
        [(cx - s, cy - s), (cx + s, cy - s), (cx + s, cy + s), (cx - s, cy + s)],
        [(cx, cy - r), (cx + r, cy), (cx, cy + r), (cx - r, cy)],
    ]


def path(polys):
    return " ".join("M" + " L".join(f"{x:.2f},{y:.2f}" for x, y in p) + " Z" for p in polys)


def write(rel, text):
    p = OUT / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text)


HDR = '<?xml version="1.0" encoding="utf-8"?>\n'


def vector(size_dp, viewport, body):
    return (
        HDR
        + '<vector xmlns:android="http://schemas.android.com/apk/res/android"\n'
        + f'    android:width="{size_dp}dp" android:height="{size_dp}dp"\n'
        + f'    android:viewportWidth="{viewport}" android:viewportHeight="{viewport}">\n'
        + body
        + "</vector>\n"
    )


def colored_paths(outer_color):
    out = ""
    for i, (col, r) in enumerate(LAYERS):
        col = outer_color if i == 0 else col
        out += f'    <path android:fillColor="{col}" android:pathData="{path(star(C, C, r))}"/>\n'
    return out


def mono_path(cx, radii, fill="#FFFFFFFF"):
    d = " ".join(path(star(cx, cx, r)) for r in radii)
    return f'    <path android:fillColor="{fill}" android:fillType="evenOdd" android:pathData="{d}"/>\n'


# ---------------------------------------------------------------- XML resources
write("values/ic_launcher_background.xml",
      HDR + f'<resources>\n    <color name="ic_launcher_background">{BG}</color>\n</resources>\n')

# adaptive icon, with a real silhouette for Android 13+ themed icons
write("mipmap-anydpi-v26/ic_launcher.xml",
      HDR + '<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">\n'
      '    <background android:drawable="@color/ic_launcher_background"/>\n'
      '    <foreground android:drawable="@mipmap/ic_launcher_foreground"/>\n'
      '    <monochrome android:drawable="@drawable/ic_launcher_monochrome"/>\n'
      '</adaptive-icon>\n')
write("drawable/ic_launcher_monochrome.xml",
      vector(108, 108, mono_path(C, [30.0, 24.0, 16.5, 9.0, 3.6])))

# in-app logo (tinted by the theme in places, so single colour)
write("drawable/ic_launcher_fg_vector.xml",
      vector(24, 24, mono_path(12.0, [10.5, 8.4, 5.7, 3.2, 1.3])))

# splash icon: light variant must stay visible on a white splash
write("drawable/ic_launcher_animated.xml", vector(108, 108, colored_paths(BG)))
write("drawable/ic_launcher_animated_dark.xml", vector(108, 108, colored_paths(WHITE)))


# ---------------------------------------------------------------- PNGs
def draw_star(d, scale, ox, oy, layers=LAYERS):
    for col, r in layers:
        for poly in star(C, C, r):
            d.polygon([((x - C) * scale + ox, (y - C) * scale + oy) for x, y in poly], fill=col)


def render_foreground(px):
    k = 4
    S = px * k
    im = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    draw_star(ImageDraw.Draw(im), S / 108.0, S / 2, S / 2)
    return im.resize((px, px), Image.LANCZOS)


def render_legacy(px, shape):
    k = 4
    S = px * k
    im = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    if shape == "round":
        d.ellipse([0, 0, S - 1, S - 1], fill=BG)
    elif shape == "square":
        d.rounded_rectangle([0, 0, S - 1, S - 1], radius=int(S * 0.22), fill=BG)
    else:  # full bleed (store icon)
        d.rectangle([0, 0, S - 1, S - 1], fill=BG)
    draw_star(d, S / 108.0 * 1.22, S / 2, S / 2)
    return im.resize((px, px), Image.LANCZOS)


def render_silhouette(px):
    """White-on-transparent notification glyph with the ring cut-outs."""
    k = 8
    S = px * k
    mask = Image.new("L", (S, S), 0)
    d = ImageDraw.Draw(mask)
    scale = S / 24.0
    for fill, r in [(255, 10.5), (0, 8.4), (255, 5.7), (0, 3.2), (255, 1.3)]:
        for poly in star(12.0, 12.0, r):
            d.polygon([(x * scale, y * scale) for x, y in poly], fill=fill)
    mask = mask.resize((px, px), Image.LANCZOS)
    im = Image.new("RGBA", (px, px), (255, 255, 255, 0))
    im.putalpha(mask)
    return im


def save(im, rel):
    p = OUT / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    im.save(p, optimize=True)


for dens, legacy, fg, notif in [
    ("mdpi", 48, 108, 24), ("hdpi", 72, 162, 36), ("xhdpi", 96, 216, 48),
    ("xxhdpi", 144, 324, 72), ("xxxhdpi", 192, 432, 96),
]:
    save(render_legacy(legacy, "square"), f"mipmap-{dens}/ic_launcher.png")
    save(render_legacy(legacy, "round"), f"mipmap-{dens}/ic_launcher_round.png")
    save(render_foreground(fg), f"mipmap-{dens}/ic_launcher_foreground.png")
    save(render_silhouette(notif), f"drawable-{dens}/ic_launcher_notification.png")

save(render_legacy(512, "full"), "../playstore.png")

# dev preview (not shipped to the app)
sheet = Image.new("RGBA", (1100, 560), "#101218")
big = render_legacy(512, "square")
sheet.paste(big, (24, 24), big)
for px, pos in [(192, (580, 24)), (96, (580, 250)), (48, (710, 250))]:
    r = render_legacy(px, "round")
    sheet.paste(r, pos, r)
sheet.save(HERE / "preview.png")
print("brand assets written to", OUT)
