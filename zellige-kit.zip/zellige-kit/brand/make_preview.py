#!/usr/bin/env python3
"""Design mock-up of the Zellige home (HTML/CSS -> PNG with Chromium). Dev tool; not a real screenshot.
   python3 brand/make_preview.py  -> brand/home-preview.png"""
from pathlib import Path
from playwright.sync_api import sync_playwright

KIT = Path(__file__).resolve().parent.parent
ICON = {
 "sparkle": "M12,2l2.4,6.6L21,11l-6.6,2.4L12,20l-2.4,-6.6L3,11l6.6,-2.4zM19,16l0.9,2.1L22,19l-2.1,0.9L19,22l-0.9,-2.1L16,19l2.1,-0.9z",
 "star": "M12,1 L14.1,6.1 L19.1,4.9 L17.9,9.9 L23,12 L17.9,14.1 L19.1,19.1 L14.1,17.9 L12,23 L9.9,17.9 L4.9,19.1 L6.1,14.1 L1,12 L6.1,9.9 L4.9,4.9 L9.9,6.1z",
 "search": "M15.5,14h-0.79l-0.28,-0.27C15.41,12.59 16,11.11 16,9.5 16,5.91 13.09,3 9.5,3S3,5.91 3,9.5 5.91,16 9.5,16c1.61,0 3.09,-0.59 4.23,-1.57l0.27,0.28v0.79l5,4.99L20.49,19l-4.99,-5zM9.5,14C7.01,14 5,11.99 5,9.5S7.01,5 9.5,5 14,7.01 14,9.5 11.99,14 9.5,14z",
 "history": "M13,3c-4.97,0 -9,4.03 -9,9L1,12l3.89,3.89 0.07,0.14L9,12L6,12c0,-3.87 3.13,-7 7,-7s7,3.13 7,7 -3.13,7 -7,7c-1.93,0 -3.68,-0.79 -4.94,-2.06l-1.42,1.42C8.27,19.99 10.51,21 13,21c4.97,0 9,-4.03 9,-9s-4.03,-9 -9,-9zM12,8v5l4.28,2.54 0.72,-1.21 -3.5,-2.08L13.5,8L12,8z",
 "down": "M16.59,8.59L12,13.17L7.41,8.59L6,10l6,6l6,-6z",
 "right": "M10,6L8.59,7.41L13.17,12l-4.58,4.59L10,18l6,-6z",
 "add": "M19,13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z",
 "sort": "M3,18h6v-2H3v2zM3,6v2h18V6H3zM3,13h12v-2H3v2z",
 "projects": "M4,14h4v-4H4v4zM4,19h4v-4H4v4zM4,9h4V5H4v4zM9,14h12v-4H9v4zM9,19h12v-4H9v4zM9,5v4h12V5H9z",
 "tools": "M22.7,19l-9.1,-9.1c0.9,-2.3 0.4,-5 -1.5,-6.9 -2,-2 -5,-2.4 -7.4,-1.3L9,6 6,9 1.6,4.7C0.4,7.1 0.9,10.1 2.9,12.1c1.9,1.9 4.6,2.4 6.9,1.5l9.1,9.1c0.4,0.4 1,0.4 1.4,0l2.3,-2.3c0.5,-0.4 0.5,-1.1 0.1,-1.4z",
 "bolt": "M11,21h-1l1,-7H7.5c-0.88,0 -0.33,-0.75 -0.31,-0.78C8.48,10.94 10.42,7.54 13.01,3h1l-1,7h3.51c0.4,0 0.62,0.19 0.4,0.66C12.97,17.55 11,21 11,21z",
 "open": "M12,4l-1.41,1.41L16.17,11H4v2h12.17l-5.58,5.59L12,20l8,-8z",
 "copy": "M16,1H4c-1.1,0 -2,0.9 -2,2v14h2V3h12V1zM19,5H8c-1.1,0 -2,0.9 -2,2v14c0,1.1 0.9,2 2,2h11c1.1,0 2,-0.9 2,-2V7c0,-1.1 -0.9,-2 -2,-2zM19,21H8V7h11v14z",
 "delete": "M6,19c0,1.1 0.9,2 2,2h8c1.1,0 2,-0.9 2,-2V7H6v12zM19,4h-3.5l-1,-1h-5l-1,1H5v2h14V4z",
 "terminal": "M20,4H4C2.9,4 2,4.9 2,6v12c0,1.1 0.9,2 2,2h16c1.1,0 2,-0.9 2,-2V6C22,4.9 21.1,4 20,4zM20,18H4V8h16V18zM6.5,16.5L5.1,15.1 7.2,13 5.1,10.9 6.5,9.5 10,13zM11,15h6v1.5h-6z",
 "folder": "M20,6h-8l-2,-2H4C2.9,4 2.01,4.9 2.01,6L2,18c0,1.1 0.9,2 2,2h16c1.1,0 2,-0.9 2,-2V8C22,6.9 21.1,6 20,6zM20,18H4V6h5.17l2,2H20V18z",
 "git": "M14,4l2.29,2.29 -2.88,2.88 1.42,1.42 2.88,-2.88L20,10V4zM10,4H4v6l2.29,-2.29 4.71,4.7V20h2v-8.41l-5.29,-5.3z",
 "docs": "M14,2H6c-1.1,0 -1.99,0.9 -1.99,2L4,20c0,1.1 0.89,2 1.99,2H18c1.1,0 2,-0.9 2,-2V8l-6,-6zM16,18H8v-2h8v2zM16,14H8v-2h8v2zM13,9V3.5L18.5,9H13z",
 "info": "M12,2C6.48,2 2,6.48 2,12s4.48,10 10,10 10,-4.48 10,-10S17.52,2 12,2zM13,17h-2v-6h2v6zM13,9h-2V7h2v2z",
 "bug": "M20,8h-2.81c-0.45,-0.78 -1.07,-1.45 -1.82,-1.96L17,4.41 15.59,3l-2.17,2.17C12.96,5.06 12.49,5 12,5c-0.49,0 -0.96,0.06 -1.41,0.17L8.41,3 7,4.41l1.62,1.63C7.88,6.55 7.26,7.22 6.81,8H4v2h2.09c-0.05,0.33 -0.09,0.66 -0.09,1v1H4v2h2v1c0,0.34 0.04,0.67 0.09,1H4v2h2.81c1.04,1.79 2.97,3 5.19,3s4.15,-1.21 5.19,-3H20v-2h-2.09c0.05,-0.33 0.09,-0.66 0.09,-1v-1h2v-2h-2v-1c0,-0.34 -0.04,-0.67 -0.09,-1H20V8zM14,16h-4v-2h4v2zM14,12h-4v-2h4v2z",
 "palette": "M12,3c-4.97,0 -9,4.03 -9,9s4.03,9 9,9c0.83,0 1.5,-0.67 1.5,-1.5 0,-0.39 -0.15,-0.74 -0.39,-1.01 -0.23,-0.26 -0.38,-0.61 -0.38,-0.99 0,-0.83 0.67,-1.5 1.5,-1.5H16c2.76,0 5,-2.24 5,-5 0,-4.42 -4.03,-8 -9,-8z",
 "settings": "M12,8a4,4 0 1,0 0.01,0zM19.4,13a7.5,7.5 0 0,0 0,-2l2,-1.6 -2,-3.4 -2.4,1a7.6,7.6 0 0,0 -1.7,-1L15,3h-4l-0.3,3a7.6,7.6 0 0,0 -1.7,1l-2.4,-1 -2,3.4 2,1.6a7.5,7.5 0 0,0 0,2l-2,1.6 2,3.4 2.4,-1a7.6,7.6 0 0,0 1.7,1l0.3,3h4l0.3,-3a7.6,7.6 0 0,0 1.7,-1l2.4,1 2,-3.4z",
}
def svg(name, size, color):
    return f'<svg width="{size}" height="{size}" viewBox="0 0 24 24" style="flex:none"><path d="{ICON[name]}" fill="{color}"/></svg>'

DARK = dict(page="#0F131C", card="#1C212E", tile="#0B0E15", line="#252A38", text="#E1E2EC", sub="#C4C7D6", accent="#B8C4FF",
            onAccent="#0B1F6E", box="#1B3FA3", onBox="#DCE1FF", secBox="#3F4565", onSecBox="#DDE1FB", nav="#1B2130", err="#FFB4AB",
            aiCard="#1B2A5E")
LIGHT = dict(page="#F9F9FF", card="#FFFFFF", tile="#EEF0FB", line="#E3E5F2", text="#191B24", sub="#444653", accent="#3550C8",
             onAccent="#FFFFFF", box="#DCE1FF", onBox="#00164F", secBox="#DFE1FA", onSecBox="#171B33", nav="#FFFFFF", err="#BA1A1A",
             aiCard="#E3E8FF")
AV = ["#4C5FD5", "#1FA6A0", "#D99A1E", "#D2603F", "#8A5BD6", "#3FA66B"]

def scoped(css, scope):
    import re
    out = []
    for m in re.finditer(r"([^{}]+)\{([^{}]*)\}", css):
        sel, body = m.group(1).strip(), m.group(2)
        sel = f".ph.{scope}" if sel == ".ph" else f".{scope} {sel}"
        out.append(f"{sel}{{{body}}}")
    return "\n".join(out)


def phone(c, page):
    css = f"""
    .ph{{width:412px;height:892px;background:{c['page']};color:{c['text']};position:relative;border-radius:34px;overflow:hidden;font-family:'DejaVu Sans',sans-serif;box-shadow:0 8px 30px rgba(0,0,0,.35)}}
    .st{{height:34px}}
    .col{{padding:10px 16px 0}}
    .pill{{height:56px;border-radius:28px;background:{c['card']};display:flex;align-items:center;padding:0 8px 0 16px;gap:12px;color:{c['sub']};font-size:15px}}
    .card{{background:{c['card']};border-radius:24px;display:flex;align-items:center;padding:14px 16px 14px 14px;gap:14px;margin-top:12px}}
    .tile{{width:60px;height:60px;border-radius:18px;background:{c['tile']};display:flex;align-items:center;justify-content:center;flex:none}}
    .t1{{font-size:17px;font-weight:700}} .t2{{font-size:13px;color:{c['sub']};margin-top:2px;line-height:1.35}}
    .h{{display:flex;align-items:center;margin:22px 0 12px;gap:10px}} .h b{{font-size:30px}}
    .cnt{{background:{c['secBox']};color:{c['onSecBox']};font-size:12px;font-weight:700;border-radius:12px;padding:2px 10px}}
    .sort{{margin-left:auto;display:flex;align-items:center;gap:6px;border:1px solid {c['line']};background:{c['card']};border-radius:20px;padding:8px 14px 8px 12px;font-size:13px;font-weight:700}}
    .proj{{background:{c['card']};border-radius:24px;margin-bottom:12px;overflow:hidden}}
    .ph1{{display:flex;align-items:center;padding:14px 6px 14px 14px;gap:14px}}
    .av{{width:64px;height:64px;border-radius:18px;display:flex;align-items:center;justify-content:center;color:#fff;font-size:28px;font-weight:700;flex:none}}
    .pn{{font-size:17.5px;font-weight:700}} .ps{{font-size:13px;color:{c['sub']};margin-top:2px}}
    .det{{padding:0 16px 16px}} .det hr{{border:0;border-top:1px solid {c['line']};margin:0 0 12px}}
    .acts{{display:flex;gap:6px;margin-top:12px}} .act{{flex:1;height:42px;border-radius:20px;background:{c['tile']};display:flex;align-items:center;justify-content:center;gap:6px;font-size:13px;font-weight:700}}
    .fabs{{position:absolute;right:16px;bottom:112px;display:flex;flex-direction:column;align-items:flex-end;gap:12px}}
    .mini{{width:52px;height:52px;border-radius:26px;background:{c['secBox']};display:flex;align-items:center;justify-content:center;box-shadow:0 3px 8px rgba(0,0,0,.35)}}
    .ext{{height:60px;border-radius:20px;background:{c['box']};color:{c['onBox']};display:flex;align-items:center;gap:10px;padding:0 24px 0 20px;font-size:16px;font-weight:700;box-shadow:0 5px 14px rgba(0,0,0,.4)}}
    .nav{{position:absolute;left:0;right:0;bottom:0;height:86px;background:{c['nav']};border-top:1px solid {c['line']};display:flex;padding:10px 8px 0}}
    .ni{{flex:1;display:flex;flex-direction:column;align-items:center;font-size:12.5px;color:{c['sub']}}}
    .ind{{width:64px;height:32px;border-radius:16px;display:flex;align-items:center;justify-content:center;margin-bottom:4px}}
    .sec{{font-size:13px;font-weight:700;color:{c['sub']};padding:20px 4px 8px}}
    .grid{{display:grid;grid-template-columns:1fr 1fr;gap:10px}}
    .gc{{background:{c['card']};border-radius:22px;padding:16px}} .gc .tile{{width:44px;height:44px;border-radius:14px;background:{c['tile']}}}
    .gt{{font-size:15.5px;font-weight:700;margin-top:12px}} .gh{{font-size:12.5px;color:{c['sub']};margin-top:2px}}
    .hero{{background:{c['aiCard']};border-radius:28px;padding:20px}}
    .btn{{flex:1;height:44px;border-radius:22px;display:flex;align-items:center;justify-content:center;font-size:14px;font-weight:700}}
    """
    return css

def nav(c, sel):
    items = [("projects","المشاريع"),("sparkle","الذكاء"),("tools","الأدوات")]
    out = ""
    for i,(ic,lb) in enumerate(items):
        on = i==sel
        out += f'<div class="ni"><div class="ind" style="background:{c["secBox"] if on else "transparent"}">{svg(ic,24,c["onSecBox"] if on else c["sub"])}</div><span style="color:{c["text"] if on else c["sub"]};font-weight:{700 if on else 400}">{lb}</span></div>'
    return f'<div class="nav">{out}</div>'

def proj(c, name, l2, appid, k, open_=False, icon=None):
    col = AV[k % 6]
    det = ""
    if open_:
        det = f'''<div class="det"><hr><div style="font-size:12.5px;color:{c['sub']};direction:ltr;text-align:left">/storage/emulated/0/AndroidIDEProjects/{name.replace(' ','')}</div>
        <div style="font-size:12.5px;color:{c['sub']};margin-top:4px">مشروع Gradle · آخر تعديل منذ ساعتين</div>
        <div class="acts"><div class="act" style="background:{c['box']};color:{c['onBox']}">{svg('open',18,c['onBox'])}فتح</div><div class="act">{svg('sparkle',18,c['text'])}الذكاء</div><div class="act">{svg('copy',18,c['text'])}نسخ</div><div class="act" style="color:{c['err']}">{svg('delete',18,c['err'])}حذف</div></div></div>'''
    return f'''<div class="proj"><div class="ph1"><div class="av" style="background:linear-gradient(135deg,{col},#10131f 160%)">{name[0].upper()}</div>
      <div style="flex:1;min-width:0"><div class="pn">{name}</div><div class="ps">{l2}</div><div class="ps" style="direction:ltr;text-align:left;margin-top:1px">{appid}</div></div>
      <div style="width:44px;display:flex;justify-content:center;transform:rotate({180 if open_ else 0}deg)">{svg('down',24,c['sub'])}</div></div>{det}</div>'''

def S(c):
    return "dk" if c is DARK else "lt"


def page_projects(c):
    return f'''<div class="ph {S(c)}"><style>{scoped(phone(c,0), S(c))}</style><div class="st"></div><div class="col">
    <div class="pill">{svg('star',26,c['accent'])}<span style="flex:1">ابحث في المشاريع…</span>{svg('search',24,c['sub'])}</div>
    <div class="card"><div class="tile">{svg('history',28,c['accent'])}</div><div style="flex:1"><div class="t1">تابع من حيث توقّفت</div><div class="t2">Vance ai · منذ ساعتين</div></div>{svg('right',24,c['sub'])}</div>
    <div class="card" style="background:{c['aiCard']};padding:12px 16px 12px 14px;margin-top:10px"><div class="tile" style="width:48px;height:48px;border-radius:16px;background:{c['box']}">{svg('sparkle',24,c['onBox'])}</div><div style="flex:1"><div class="t1" style="font-size:16px">اطلب من الذكاء</div><div class="t2" style="font-size:12.5px">قل ما تريد وسيُنفَّذ مباشرة داخل مشروعك، مثلا «أنشئ تطبيق ملاحظات»</div></div>{svg('right',22,c['sub'])}</div>
    <div class="h"><b>المشاريع</b><span class="cnt">3</span><div class="sort">{svg('sort',18,c['accent'])}الأحدث</div></div>
    {proj(c,'Vance ai','NewProject · v1.0 (1)','com.my.newproject',0,True)}
    {proj(c,'Notes Pro','v2.3 (14)','com.zellige.notes',1)}
    {proj(c,'مشروعي','v1.0 (1)','com.example.myapp',4)}
    </div><div class="fabs"><div class="mini">{svg('sparkle',24,c['onSecBox'])}</div><div class="ext">{svg('add',24,c['onBox'])}مشروع جديد</div></div>{nav(c,0)}</div>'''

def page_ai(c):
    def g(ic,t,h): return f'<div class="gc"><div class="tile">{svg(ic,22,c["accent"])}</div><div class="gt">{t}</div><div class="gh">{h}</div></div>'
    return f'''<div class="ph {S(c)}"><style>{scoped(phone(c,0), S(c))}</style><div class="st"></div><div class="col" style="padding-top:18px">
    <div style="font-size:30px;font-weight:700">الذكاء</div><div style="font-size:14px;color:{c['sub']};margin:4px 0 16px">وكيل برمجي ينفّذ داخل التطبيق: يفتح الملفات ويكتب فيها قدامك</div>
    <div class="hero"><div style="display:flex;align-items:center;gap:14px"><div class="tile" style="width:64px;height:64px;border-radius:20px;background:{c['box']}">{svg('sparkle',34,c['onBox'])}</div><div><div style="font-size:20px;font-weight:700">وكيل Zellige</div><div style="font-size:13px;color:{c['sub']};direction:ltr">OpenRouter · anthropic/claude-sonnet</div></div></div>
    <div style="display:flex;gap:8px;margin-top:16px"><div class="btn" style="background:{c['accent']};color:{c['onAccent']}">فتح الشات</div><div class="btn" style="background:{c['tile']}">الإعدادات</div></div></div>
    <div class="sec">ابدأ بسرعة</div><div class="grid">{g('add','تطبيق جديد','مشروع كامل من فكرة واحدة')}{g('projects','شاشة جديدة','واجهة + Activity مسجّلة')}{g('bug','أصلح الأخطاء','يفحص ويطبّق الإصلاح')}{g('info','اشرح المشروع','ملخص سريع للهيكل')}{g('palette','حسّن الواجهة','Material 3 أجمل')}{g('bolt','اختبارات','unit tests جاهزة')}</div>
    </div>{nav(c,1)}</div>'''

def page_tools(c):
    def g(ic,t,h): return f'<div class="gc"><div class="tile">{svg(ic,22,c["accent"])}</div><div class="gt">{t}</div><div class="gh">{h}</div></div>'
    return f'''<div class="ph {S(c)}"><style>{scoped(phone(c,0), S(c))}</style><div class="st"></div><div class="col" style="padding-top:18px">
    <div style="font-size:30px;font-weight:700">الأدوات</div><div style="font-size:14px;color:{c['sub']};margin:4px 0 16px">كل ما تحتاجه خارج المحرر</div>
    <div class="grid">{g('terminal','الترمنال','bash و Gradle و Git')}{g('folder','فتح مجلد','افتح مشروعا من التخزين')}{g('git','استنساخ Git','من رابط مستودع')}{g('settings','الإعدادات','المظهر والمحرر والبناء')}{g('docs','الوثائق','دليل الاستعمال')}{g('sparkle','إعدادات الذكاء','المزوّد والمفتاح والموديل')}</div>
    <div style="font-size:12.5px;color:{c['sub']};text-align:center;padding:24px 8px 0">Zellige مبني على AndroidIDE (ترخيص GPL-3.0). الشيفرة المصدرية متاحة لكل من يحصل على نسخة من التطبيق.</div>
    </div>{nav(c,2)}</div>'''

def main():
    html = '<html><body style="margin:0;background:#2a2d36;padding:28px;display:flex;gap:28px;flex-wrap:nowrap;width:max-content">'
    html += page_projects(DARK) + page_ai(DARK) + page_tools(DARK) + page_projects(LIGHT) + '</body></html>'
    out = KIT / "brand" / "home-preview.html"; out.write_text(html, encoding="utf-8")
    with sync_playwright() as p:
        b = p.chromium.launch(); pg = b.new_page(viewport={"width": 1900, "height": 960}, device_scale_factor=1)
        pg.goto(out.as_uri()); pg.screenshot(path=str(KIT / "brand" / "home-preview.png"), full_page=True); b.close()
    out.unlink()
    print("ok")

if __name__ == "__main__":
    main()
