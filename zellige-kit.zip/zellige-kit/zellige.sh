#!/usr/bin/env bash
# zellige.sh — حقن المساعد الذكي + تغيير الهوية (الاسم والأيقونة) فـ AndroidIDE
#
#   bash zellige.sh /path/to/AndroidIDE              # الكل: المساعد + الهوية
#   bash zellige.sh /path/to/AndroidIDE inject       # المساعد فقط
#   bash zellige.sh /path/to/AndroidIDE rebrand      # الاسم والأيقونة فقط
#   bash zellige.sh /path/to/AndroidIDE undo         # رجوع كامل للأصل
#   bash zellige.sh /path/to/AndroidIDE status
#   اختياري:  --name "اسم آخر"
set -euo pipefail
KIT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
command -v python3 >/dev/null 2>&1 || { echo "❌ خاصك python3  (فـ Termux: pkg install python)"; exit 1; }
exec python3 -c "import sys; sys.path.insert(0, sys.argv.pop(1)); from lib.cli import entry; entry()" "$KIT" "$@"
