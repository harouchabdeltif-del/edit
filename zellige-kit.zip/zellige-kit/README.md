# Zellige kit — AndroidIDE بذكاء اصطناعي مدمج + واجهة جديدة

يحقن وكيل الذكاء الاصطناعي داخل مصدر AndroidIDE، ويبدّل الاسم والأيقونة والثيم والشاشة الرئيسية إلى **Zellige** (زليج: النجمة الثمانية فـ الفسيفساء المغربية).
كل شي كيتراجع بأمر واحد.

## الاستعمال (Termux)

```bash
# الملف الواحد (الأسهل): فيه كلشي مدمج
bash zellige-all-in-one.sh /storage/emulated/0/Documents/Android_Projects/AndroidIDE

# أو الـ kit المنظّم
bash zellige.sh  /path/to/AndroidIDE              # المساعد + الهوية + الثيم + الشاشة الرئيسية
bash zellige.sh  /path/to/AndroidIDE inject       # المساعد فقط
bash zellige.sh  /path/to/AndroidIDE rebrand      # الاسم والأيقونة والثيم فقط
bash zellige.sh  /path/to/AndroidIDE status
bash zellige.sh  /path/to/AndroidIDE undo         # رجوع كامل للأصل (بايت ببايت)
bash zellige.sh  /path/to/AndroidIDE --name "اسم آخر"
```

بعدها: `cd /path/to/AndroidIDE && ./gradlew :core:app:assembleDebug`
أو دفع التعديلات لـ GitHub وبناء الـ APK بـ `ci/build.yml` (توقيع ثابت باش التحديثات تتركّب فوق بعضها).

يحتاج `python3` فقط (`pkg install python`). السكريبت ما كيعدّل المصدر إلا داخل المشروع، وكيحفظ نسخة من كل ملف قبل تعديله فـ `.zellige/backup/` (ماشي بجنب الملفات، باش ما يتلخبطش aapt2).
إلا كنتي دايز بالسكريبت القديم `inject-ai.sh` فالمشروع، هاد الـ kit كيتبنّاه ويقدر يتراجع عليه.

## الجديد فهاد النسخة

### 1) الذكاء كيكتب مباشرة فالمحرر (ماشي فالشات)
- فين قلتي ليه «كتب كود / أنشئ ملف / عدّل»، الوكيل كيقول بلي بدا التطبيق، وكيدير الخطوات **قدامك فالواجهة**:
  يفتح مجلد المشروع فشجرة الملفات، ينشئ المجلدات والملفات، يفتح الملف فالمحرر، ويكتب فيه حرف حرف (مع تحديد المنطقة المتبدلة) بلا ما يرميه فالمحادثة.
- فوق الشاشة كاينة شريحة صغيرة (HUD) كتبيّن شنو كيدير دابا، وفيها زر **تراجع** للتعديل الأخير وزر إيقاف.
- ضمانة: فالأخير كيتحقق بلي النص فالمحرر = النص النهائي = اللي كاين فالقرص، حتى إلا تقطعات الأنيميشن.
- إلا الموديل رمى كود فالرد بدل ما يطبّقو، التطبيق كيرفض ويرجّعو يطبّق بالأدوات (`CODE_IN_CHAT_FIX`)، والكود اللي كيبقى فالشات كيتبدّل بشريحة (chip) كتفتح الملف.
- أدوات جديدة: `open_file`, `insert` (إدراج فسطر معيّن)، وكل الأدوات القديمة (`list_dir`, `read_file`, `write_file`, `edit_file`, `create_dir`, `move`, `delete`, `open_project`, `search`, `run`).
- الوكيل كيشوف الملف المفتوح ومكان المؤشر.
- من الإعدادات (فالمحادثة: زر ⋮ ← الإعدادات ← «التطبيق المباشر»): تفعيل/تعطيل. إلا عطلتو، كيكتب على القرص بصمت.

### 2) واجهة جديدة (مستوحاة من الصورة اللي صيفطتي)
- **الثيم**: ألوان Majorelle الزرقاء + الذهبي، خلفية داكنة `#0F131C`، أشكال أنعم (بطاقات 22dp، حقول 14dp، sheets 28dp)، وخط النظام بدل Josefin Sans. كلشي كيتبدل من الموارد (ألوان `theme_blue_wave.xml` وstyles)، بلا كود.
- **الشاشة الرئيسية** (`ZelligeHome`): بحث على شكل حبة، بطاقة «تابع العمل»، بطاقة الذكاء، **مشاريعك كبطاقات** (أيقونة، اسم، إصدار، package، سهم التوسيع)، ترتيب A–Z/الأحدث، زر كبير **«+ مشروع جديد»**، وتنقّل سفلي (المشاريع / الذكاء / الأدوات).
- كتتركّب **فوق** الشاشة الأصلية (ما كنبدلوش `MainFragment` ولا `fragment_main.xml`). الأزرار الأصلية (إنشاء، فتح مجلد، Git، ترمنال، إعدادات) كتخدم من نفس الـ adapter الأصلي. إلا فشل أي شيء، كتبقى الشاشة الأصلية كما هي.
- 27 أيقونة vector (`zl_ic_*.xml`) مولّدة بـ `brand/make_ui_icons.py`.
- النصوص ديال الواجهة الجديدة **بالعربية فقط** دابا.

### 3) الهوية
- الاسم `AndroidIDE → Zellige` داخل نصوص `<string>` لكل اللغات و `TermuxConstants.TERMUX_APP_NAME`. ما كيلمس: روابط GitHub، مسارات `/data/data/...`، أسماء الـ styles، تعليقات الرخصة.
- أيقونة launcher (عادية + دائرية + adaptive + themed)، splash، أيقونة الإشعار، شعار الشاشة الرئيسية، أيقونة Play Store.

## الهيكل

```
zellige.sh              نقطة الدخول (bash رفيعة)
lib/
  cli.py                الأوامر والرسائل
  core.py               إيجاد الموديول، النسخ الاحتياطية، التراجع
  inject.py             المرحلة 1: المساعد
  rebrand.py            المرحلة 2: الاسم والأيقونة
  theme.py              المرحلة 2b: الألوان والأشكال والخط
payload/
  kotlin/               11 ملف Kotlin (package com.itsaky.androidide.ai)
    AiAgent / AiChat / AiClient / AiProviders / AiPrefs / AiPlugin   الوكيل والمحادثة
    AiIde / EditorAccess                                              الربط مع AndroidIDE (reflection)
    AiLive / AiDiff                                                   التطبيق المباشر فالمحرر
    ZelligeHome                                                       الشاشة الرئيسية
  res/                  أيقونات الواجهة (zl_ic_*) + ai_keep.xml
brand/                  أيقونات Zellige الجاهزة + سكريبتات التوليد + المعاينات
ci/build.yml            workflow ديال GitHub Actions
tests/
  smoke.sh              اختبار على مصدر AndroidIDE حقيقي
  typecheck.sh          فحص الأنواع ضد android.jar حقيقي
  jvm/                  اختبار عشوائي (fuzz) لمنطق الكتابة المباشرة
build-single.sh         يبني الملف الواحد + zip
```

## لماذا بقى الـ package name ؟

طلبتي تبديله، ودرست المصدر وما بدّلتوش، لهاد الأسباب (كلها مأخوذة من الكود):

1. `TermuxConstants.TERMUX_PACKAGE_NAME = "com.itsaky.androidide"` — منها كيتحسب `/data/data/<id>/files/usr`، مسار الترمنال و JDK و Gradle.
2. الحزم (bootstrap) كتتنزل جاهزة من `AndroidIDEOfficial/terminal-packages` (`TerminalBootstrapPackagesPlugin`)، مبنية بهاد المسار بالضبط، و`TermuxInstaller` ما كيعاود كتابة المسارات.
3. إلا بدّلتي الـ id، التطبيق كيفتح ولكن `bash` و `apt` و `java` ما كيخدمو، يعني ما غادي تقدر تبني حتى مشروع.
4. حتى لو بدّلتي المسار: المانيفست فيه `com.itsaky.androidide.documents` و `com.itsaky.androidide.permission.BIND_LOG_SERVICE` ثابتين، وغادي يعطيو `INSTALL_FAILED_CONFLICTING_PROVIDER` مع التطبيق الأصلي.

**النتيجة:** نفس الـ id، يعني ما تقدرش تخلي الاثنين مثبتين مع بعض. الطريقة:
1. خدم نسخة احتياطية ديال مشاريعك (المجلد `AndroidIDEProjects` فالتخزين المشترك كيبقى، ولكن احتياطا).
2. حيّد AndroidIDE الأصلي، ثبّت Zellige. الـ SDK و JDK و Gradle غادي يتنزلو من جديد فـ onboarding.
3. من هنا ورا: تبني Zellige بـ Zellige (نفس التوقيع، يتحدّث فوق نفسو).

إلا بغيتي فعلا id مختلف، خاصو بناء bootstrap جديد بالمسار الجديد (مشروع كبير بوحدو). `--appid` كيعطيك هاد الشرح.

## شنو تختبر وشنو لا

تم (على نسخة حقيقية من المصدر، commit `77ee1a3`):
- ✔ `tests/smoke.sh`: تركيب، إعادة التشغيل بلا تغيير (idempotent)، التراجع مطابق بايت ببايت، تبنّي شجرة معدّلة بالسكريبت القديم، وما تلمسش `MainFragment` ولا الروابط ولا الرخص ولا الـ package.
- ✔ `tests/typecheck.sh`: مترجم Kotlin 2.0 ضد `android.jar` الحقيقي (API 34) — ما كاين لا خطأ نوع ولا تعريف مكرر.
- ✔ `tests/jvm/run.sh`: 4000 تعديل عشوائي على منطق الكتابة المباشرة (`AiDiff`) كيعطيو دايما النص النهائي الصحيح.
- ✔ كل ملفات XML المعدّلة أو الجديدة well-formed، وكل أسماء الـ reflection (`IProjectManager`، `FileTreeFragment`، `EditorActivityKt`، `IEditor.getFile`…) تأكدت بالاسم فالمصدر.

ما تمش (خاصك تعرف هادشي):
- ✘ **ما تبنى حتى بـ Gradle/aapt2** (الشبكة ديالي ما كتوصلش لـ Google Maven)، وما تجرّب على هاتف. أول `assembleDebug` هو الاختبار الحقيقي.
- ✘ كلاسات AndroidX/Material فالفحص هي **stubs** كتبتها أنا، يعني الفحص ديالها صحيح بقدر ما هي دقيقة. فرق صغير فتوقيع دالة ممكن يبان غير فالبناء الحقيقي.
- ✘ الشاشة الرئيسية كتعتمد على ids `main` / `appbar` / `actions` ديال AndroidIDE. إلا تبدلو فنسخة أخرى، كترجع الشاشة الأصلية تلقائيا (ما كتكراشيش).
- ✘ `brand/home-preview.png` **مجرد تصميم تقريبي**، ماشي لقطة شاشة حقيقية؛ الشكل الحقيقي ممكن يختلف شوية.
- إلا طلع خطأ فالبناء، صيفط ليا اللوغ كامل (ماشي آخر سطور).

## الرخصة

AndroidIDE تحت GPL-3.0. الـ kit ما كيلمس رؤوس حقوق النشر. إلا وزّعتي APK معدّل، خاصك تعطي المصدر المعدّل بنفس الرخصة وتحافظ على الإشارة للمشروع الأصلي.
