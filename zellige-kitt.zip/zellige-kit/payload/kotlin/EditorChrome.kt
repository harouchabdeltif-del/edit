package com.itsaky.androidide.ai

import android.app.Activity
import android.content.Context
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.TextUtils
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import java.io.File

/**
 * شريط الذكاء داخل المحرر (اتجاه Console): سطر رفيع تحت تبويبات الملفات فيه نجمة الذكاء وخانة «اطلب تعديلا على هذا الملف…»
 * ومن جهة أخرى موضع المؤشر ولغة الملف (17:35 · Kotlin).
 *
 * Enter ← الطلب كيتنفّذ بلا ما يتفتح الشات الكبير: كتطلع لوحة صغيرة تحت الشريط (نفس الـ AppBarLayout، يعني المحرر
 * كينزل شويا بلا ما يتغطّى الكود) فيها شنو كيدير الوكيل (✓ write …)، ومن بعد ما يسالي كترجع وحدها لشريط صغير.
 * النجمة كتفتح الشات الكامل.
 *
 * كيتزاد جوا AppBarLayout الأصلي (آخر ولد) باش المحرر ينزل تحتو تلقائيا بلا ما نلمس أي layout.
 * إلا فشل أي شيء، AiPlugin كيرجع للزر العائم القديم.
 */
object EditorChrome {

    private const val TAG = "ai_bar"
    private const val HOLD_OK_MS = 9_000L
    private const val HOLD_ERR_MS = 20_000L
    private val ui = Handler(Looper.getMainLooper())

    private class Parts(
        val a: Activity,
        val p: AiChat.Pal,
        val mono: android.graphics.Typeface,
        val box: LinearLayout,
        val input: EditText,
        val readout: TextView,
        val panel: LinearLayout,
        val head: TextView,
        val spin: ProgressBar,
        val mark: TextView,
        val stopBtn: View,
        val req: TextView,
        val rows: LinearLayout,
        val answer: TextView,
        val actions: LinearLayout,
        val undoPill: View
    )

    private var cur: Parts? = null
    private var tick: Runnable? = null
    private var collapseTask: Runnable? = null

    /** اللوحة مفتوحة (المستعمل شاف/كيشوف نتيجة المهمة الحالية)؟ */
    private var panelOpen = false
    /** رسالة المستعمل ديال المهمة اللي كتعرضها اللوحة (باش ما نخلطوهاش مع مهام قديمة). */
    private var runMsg: AiClient.Msg? = null
    private var reqText: String? = null

    private val MUTATING = setOf("write", "edit", "insert", "delete", "move", "mkdir")

    // ------------------------------------------------------------------ install / lifecycle
    /** من الـ UI thread. يرجع true إلا الشريط موجود فالشاشة. */
    fun install(a: Activity): Boolean {
        return try {
            val id = a.resources.getIdentifier("editor_appBarLayout", "id", a.packageName)
            if (id == 0) return false
            val appbar = a.findViewById<ViewGroup>(id) ?: return false
            val existing = appbar.findViewWithTag<View>(TAG)
            var c = cur
            if (existing == null || c == null || c.box !== existing || c.a !== a) {
                if (existing != null) appbar.removeView(existing)
                c = build(a)
                appbar.addView(c.box, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
                cur = c
            }
            start(a)
            true
        } catch (t: Throwable) { false }
    }

    /** كيتنادى مللي المحرر كيتوقف (pause): كنوقفو الـ poll والمراقب (المهمة كتكمل، وكيتعاود الربط فـ resume). */
    fun stop() {
        tick?.let { ui.removeCallbacks(it) }
        tick = null
        cancelCollapse()
        AiChat.observer = null
    }

    fun destroyed(a: Activity) {
        if (cur?.a === a) { cur = null; panelOpen = false; runMsg = null; reqText = null }
    }

    // ------------------------------------------------------------------ the panel API (also used by AiHud)
    /** AiHud.show كيتنادى من التطبيق المباشر: فالمحرر كنعرضو اللوحة الصغيرة بدل الشريط العائم. */
    fun showPanel(a: Activity): Boolean {
        val c = cur ?: return false
        if (c.a !== a || c.box.parent == null) return false
        val m = lastUserMsg()
        if (m !== runMsg) { runMsg = m; reqText = null }
        panelOpen = true
        cancelCollapse()
        render()
        return true
    }

    fun closePanel() {
        panelOpen = false
        cancelCollapse()
        render()
    }

    private fun lastUserMsg(): AiClient.Msg? =
        AiPlugin.history.lastOrNull { it.role == "user" && !AiAgent.isResults(it) }

    // ------------------------------------------------------------------ build
    private fun build(a: Activity): Parts {
        val p = AiChat.pal(a)
        val mono = ZelligeHome.loadMono(a)
        val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
        val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
        fun dp(v: Int) = AiChat.dp(a, v)

        val box = LinearLayout(a).apply {
            tag = TAG
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(p.surface)
        }

        // ---------------- السطر الصغير: ✦ [ اطلب تعديلا… ]  17:35 · Kotlin
        val row = LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), 0, dp(12), 0)
        }
        val star = ImageView(a).apply {
            setImageDrawable(AiChat.icon(a, "ic_ai_sparkle"))
            imageTintList = ColorStateList.valueOf(p.accent)
            contentDescription = "فتح الشات"
            isClickable = true; isFocusable = true
            setOnClickListener {
                panelOpen = false
                render()
                AiChat.open(a, null, false)
            }
        }
        row.addView(star, LinearLayout.LayoutParams(dp(18), dp(18)))

        val input = EditText(a).apply {
            hint = HINT
            setHintTextColor(p.sub); setTextColor(p.text); textSize = 12.5f
            background = null
            setSingleLine()
            inputType = InputType.TYPE_CLASS_TEXT
            imeOptions = EditorInfo.IME_ACTION_SEND
            textDirection = View.TEXT_DIRECTION_ANY_RTL
            setPadding(dp(10), 0, dp(8), 0)
        }
        row.addView(input, LinearLayout.LayoutParams(0, dp(40), 1f))

        val readout = TextView(a).apply {
            typeface = mono; textSize = 10.5f; setTextColor(p.sub)
            textDirection = View.TEXT_DIRECTION_LTR
            setSingleLine()
            text = "—"
        }
        row.addView(readout, LinearLayout.LayoutParams(WRAP, WRAP))
        box.addView(row, LinearLayout.LayoutParams(MATCH, WRAP))

        // ---------------- اللوحة الصغيرة (مخبّية حتى يبدا طلب)
        val panel = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(p.bg)
            setPadding(dp(12), dp(4), dp(12), dp(6))
            visibility = View.GONE
        }
        panel.addView(View(a).apply { setBackgroundColor(p.line) }, LinearLayout.LayoutParams(MATCH, dp(1)).apply {
            marginStart = -dp(12); marginEnd = -dp(12); bottomMargin = dp(2)
        })

        val headRow = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val spin = ProgressBar(a).apply {
            isIndeterminate = true; indeterminateTintList = ColorStateList.valueOf(p.accent)
        }
        val mark = TextView(a).apply {
            typeface = mono; textSize = 13f; gravity = Gravity.CENTER; text = "✓"; setTextColor(p.okColor)
            visibility = View.GONE
        }
        headRow.addView(spin, LinearLayout.LayoutParams(dp(14), dp(14)).apply { marginEnd = dp(8) })
        headRow.addView(mark, LinearLayout.LayoutParams(dp(14), WRAP).apply { marginEnd = dp(8) })
        val head = TextView(a).apply {
            typeface = mono; textSize = 12f; setTextColor(p.text)
            setSingleLine(); ellipsize = TextUtils.TruncateAt.END
            textDirection = View.TEXT_DIRECTION_ANY_RTL
        }
        headRow.addView(head, LinearLayout.LayoutParams(0, WRAP, 1f))
        val stopBtn = AiChat.iconButton(a, "ic_ai_stop", "إيقاف", p.sub, Color.TRANSPARENT, 34) { onStop(a) }
        headRow.addView(stopBtn, LinearLayout.LayoutParams(dp(34), dp(34)))
        val collapse = AiChat.iconButton(a, "ic_ai_chevron", "طيّ", p.sub, Color.TRANSPARENT, 34) { closePanel() }
        collapse.rotation = 180f        // السهم لفوق: يرجع للشريط
        headRow.addView(collapse, LinearLayout.LayoutParams(dp(34), dp(34)))
        panel.addView(headRow, LinearLayout.LayoutParams(MATCH, WRAP))

        val req = TextView(a).apply {
            typeface = mono; textSize = 11.5f; setTextColor(p.sub)
            setSingleLine(); ellipsize = TextUtils.TruncateAt.END
            textDirection = View.TEXT_DIRECTION_ANY_RTL
        }
        panel.addView(req, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(1) })

        val rows = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        panel.addView(rows, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(4) })

        val answer = TextView(a).apply {
            textSize = 12.5f; setTextColor(p.text); setLineSpacing(0f, 1.15f)
            maxLines = 3; ellipsize = TextUtils.TruncateAt.END
            textDirection = View.TEXT_DIRECTION_ANY_RTL
            visibility = View.GONE
        }
        panel.addView(answer, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(4) })

        fun pill(label: String, accent: Boolean, f: () -> Unit): TextView = TextView(a).apply {
            text = label; textSize = 12f; gravity = Gravity.CENTER
            setTextColor(if (accent) p.onAccent else p.text)
            setPadding(dp(12), dp(6), dp(12), dp(6))
            background = AiChat.ripple(
                if (accent) AiChat.shape(p.accent, dp(8).toFloat()) else AiChat.outlined(Color.TRANSPARENT, dp(8).toFloat(), p.line, dp(1)),
                dp(8).toFloat()
            )
            isClickable = true; isFocusable = true
            setOnClickListener { f() }
        }
        val actions = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; visibility = View.GONE }
        val undoPill = pill("تراجع", false) {
            Toast.makeText(a, AiAgent.undoLast(a), Toast.LENGTH_LONG).show()
            closePanel()
        }
        actions.addView(undoPill, LinearLayout.LayoutParams(WRAP, WRAP).apply { marginEnd = dp(8) })
        actions.addView(pill("الشات", true) { closePanel(); AiChat.open(a, null, false) }, LinearLayout.LayoutParams(WRAP, WRAP))
        panel.addView(actions, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(6); bottomMargin = dp(2) })
        box.addView(panel, LinearLayout.LayoutParams(MATCH, WRAP))

        box.addView(View(a).apply { setBackgroundColor(p.line) }, LinearLayout.LayoutParams(MATCH, dp(1)))

        val c = Parts(a, p, mono, box, input, readout, panel, head, spin, mark, stopBtn, req, rows, answer, actions, undoPill)
        input.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) { submit(c); true } else false
        }
        return c
    }

    private const val HINT = "اطلب تعديلا على هذا الملف…"

    // ------------------------------------------------------------------ actions
    private fun submit(c: Parts) {
        val a = c.a
        val t = c.input.text.toString().trim()
        try {
            (a.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(c.input.windowToken, 0)
        } catch (e: Throwable) { }
        c.input.clearFocus()
        if (t.isEmpty()) { AiChat.open(a, null, false); return }
        if (AiChat.isBusy()) {
            Toast.makeText(a, "الوكيل مازال خدّام، سنّى شويا أو أوقفو", Toast.LENGTH_SHORT).show()
            return
        }
        // اللوحة مفتوحة قبل البداية، باش أول تحديث يلقاها
        panelOpen = true
        reqText = t
        cancelCollapse()
        if (AiChat.runDetached(a, t)) {
            c.input.text.clear()
            runMsg = lastUserMsg()
            render()
        } else {
            panelOpen = false
            render()
        }
    }

    private fun onStop(a: Activity) {
        AiChat.stop(a)
        closePanel()
        Toast.makeText(a, "تم الإيقاف", Toast.LENGTH_SHORT).show()
    }

    // ------------------------------------------------------------------ render
    private class Snap(val request: String, val rows: List<Triple<Boolean, String, String>>, val answer: String)

    /** الحالة ديال المهمة الحالية من السجل: طلبها، سجل الأدوات، وآخر جواب. */
    private fun snapshot(): Snap {
        val h = AiPlugin.history.toList()
        val m = runMsg
        val i = if (m == null) -1 else h.indexOfFirst { it === m }
        val request = reqText ?: m?.content.orEmpty()
        if (i < 0) return Snap(request, emptyList(), "")
        val rows = mutableListOf<Triple<Boolean, String, String>>()
        var answer = ""
        for (k in i + 1 until h.size) {
            val x = h[k]
            if (AiAgent.isResults(x)) rows.addAll(AiAgent.parseResults(x.content))
            else if (x.role == "assistant") answer = AiAgent.strip(x.content)
        }
        return Snap(request, rows, answer)
    }

    private fun prefixed(c: Parts, text: String): CharSequence {
        val pre = "AI ▸ "
        val sb = SpannableStringBuilder(pre).append(text)
        sb.setSpan(ForegroundColorSpan(c.p.accent), 0, pre.length - 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        return sb
    }

    private fun render() {
        val c = cur ?: return
        val a = c.a
        val busy = AiChat.isBusy()
        if (busy) cancelCollapse()
        updateBar(c, busy)

        val panel = c.panel
        if (!panelOpen) {
            if (panel.visibility == View.VISIBLE) {
                panel.animate().cancel()
                panel.animate().alpha(0f).setDuration(140).withEndAction {
                    if (!panelOpen) panel.visibility = View.GONE
                }.start()
            }
            return
        }
        if (panel.visibility != View.VISIBLE || panel.alpha < 1f) {
            val wasHidden = panel.visibility != View.VISIBLE
            panel.animate().cancel()
            if (wasHidden) panel.alpha = 0f
            panel.visibility = View.VISIBLE
            panel.animate().alpha(1f).setDuration(160).start()
        }

        val p = c.p
        val err = AiChat.errorText()
        val failed = !busy && err != null
        val s = snapshot()

        // ---- السطر الأول: الحالة
        c.spin.visibility = if (busy) View.VISIBLE else View.GONE
        c.mark.visibility = if (busy) View.GONE else View.VISIBLE
        c.mark.text = if (failed) "✗" else "✓"
        c.mark.setTextColor(if (failed) p.danger else p.okColor)
        c.stopBtn.visibility = if (busy) View.VISIBLE else View.GONE
        val okN = s.rows.count { it.first }
        val badN = s.rows.size - okN
        c.head.text = prefixed(
            c,
            when {
                busy -> AiChat.statusText().ifBlank { "يخدم…" }
                failed -> "توقّف"
                s.rows.isEmpty() -> "جاوب"
                badN > 0 -> "تم · $okN نجحت · $badN فشلت"
                else -> "تم · $okN عملية"
            }
        )

        // ---- طلبك
        val reqS = SpannableStringBuilder("› ").append(s.request.replace('\n', ' '))
        reqS.setSpan(ForegroundColorSpan(p.accent), 0, 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        c.req.text = reqS
        c.req.visibility = if (s.request.isBlank()) View.GONE else View.VISIBLE

        // ---- سجل الأدوات (آخر 3؛ 2 فالعرضي)
        val max = if (a.resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) 2 else 3
        c.rows.removeAllViews()
        val shown = s.rows.takeLast(max)
        if (s.rows.size > shown.size) c.rows.addView(moreRow(c, s.rows.size - shown.size))
        shown.forEach { (ok, label, detail) -> c.rows.addView(logRow(c, ok, label, detail)) }
        c.rows.visibility = if (shown.isEmpty()) View.GONE else View.VISIBLE

        // ---- الجواب / الخطأ (غير بعد ما يسالي)
        val text = when {
            busy -> ""
            failed -> err.orEmpty().take(240)
            else -> s.answer.lineSequence().map { it.trim() }.filter { it.isNotEmpty() }.take(3).joinToString("\n").take(260)
        }
        c.answer.text = text
        c.answer.setTextColor(if (failed) p.danger else p.text)
        c.answer.visibility = if (text.isBlank()) View.GONE else View.VISIBLE

        // ---- الأزرار (تراجع كاين غير إلا الوكيل بدّل شي حاجة)
        c.actions.visibility = if (busy) View.GONE else View.VISIBLE
        val changed = s.rows.any { it.first && AiChat.toolOf(it.second).first in MUTATING }
        c.undoPill.visibility = if (changed) View.VISIBLE else View.GONE

        // ---- من بعد ما يسالي: ترجع وحدها للشريط الصغير
        if (!busy && collapseTask == null) scheduleCollapse(if (failed) HOLD_ERR_MS else HOLD_OK_MS)
    }

    private fun moreRow(c: Parts, n: Int): View = TextView(c.a).apply {
        text = "… +$n"; typeface = c.mono; textSize = 10.5f; setTextColor(c.p.sub)
        textDirection = View.TEXT_DIRECTION_LTR; textAlignment = View.TEXT_ALIGNMENT_VIEW_START
        setPadding(0, 0, 0, AiChat.dp(c.a, 2))
    }

    private fun logRow(c: Parts, ok: Boolean, label: String, detail: String): View {
        val a = c.a
        val p = c.p
        fun dp(v: Int) = AiChat.dp(a, v)
        val (tool, target) = AiChat.toolOf(label)
        val col = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        val row = LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            setPadding(0, dp(2), 0, dp(2))
        }
        row.addView(TextView(a).apply {
            text = if (ok) "✓" else "✗"; typeface = c.mono; textSize = 11.5f
            setTextColor(if (ok) p.okColor else p.danger)
        }, LinearLayout.LayoutParams(dp(15), ViewGroup.LayoutParams.WRAP_CONTENT))
        if (tool.isNotEmpty()) {
            row.addView(TextView(a).apply {
                text = tool; typeface = c.mono; textSize = 11f
                setTextColor(when (tool) { "write", "insert" -> p.okColor; "edit" -> p.accent; "delete" -> p.danger; else -> p.sub })
            }, LinearLayout.LayoutParams(dp(58), ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        row.addView(TextView(a).apply {
            text = target; typeface = c.mono; textSize = 11f; setTextColor(p.text)
            setSingleLine(); ellipsize = TextUtils.TruncateAt.MIDDLE
            textDirection = View.TEXT_DIRECTION_LTR
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        col.addView(row)
        if (!ok && detail.isNotBlank()) {
            col.addView(TextView(a).apply {
                text = detail.take(120); typeface = c.mono; textSize = 10.5f; setTextColor(p.danger)
                setSingleLine(); ellipsize = TextUtils.TruncateAt.END
                textDirection = View.TEXT_DIRECTION_ANY_RTL
                setPadding(dp(15), 0, 0, dp(2))
            })
        }
        return col
    }

    // ------------------------------------------------------------------ auto-collapse
    private fun scheduleCollapse(ms: Long) {
        cancelCollapse()
        val r = Runnable { collapseTask = null; if (!AiChat.isBusy()) closePanel() }
        collapseTask = r
        ui.postDelayed(r, ms)
    }

    private fun cancelCollapse() {
        collapseTask?.let { ui.removeCallbacks(it) }
        collapseTask = null
    }

    // ------------------------------------------------------------------ bar readout: cursor / language / busy
    private fun start(a: Activity) {
        tick?.let { ui.removeCallbacks(it) }
        AiChat.observer = { render() }
        val r = object : Runnable {
            override fun run() {
                val c = cur
                if (c == null || c.a !== a) return
                try { updateBar(c, AiChat.isBusy()) } catch (t: Throwable) { /* اختياري */ }
                ui.postDelayed(this, 800)
            }
        }
        tick = r
        ui.post(r)
        render()
    }

    private fun updateBar(c: Parts, busy: Boolean) {
        val tv = c.readout
        if (busy && !panelOpen) {
            // اللوحة مطويّة والوكيل خدّام: مؤشر صغير فالشريط
            tv.setTextColor(c.p.accent)
            tv.text = "● " + AiChat.statusText().ifBlank { "يخدم…" }.take(22)
        } else {
            tv.setTextColor(c.p.sub)
            val ed = EditorAccess.find(c.a)
            val f = ed?.file()
            tv.text = if (ed == null || f == null) "—" else "${ed.cursorLine() + 1}:${ed.cursorColumn() + 1} · ${lang(f)}"
        }
        val hint = if (busy) "الوكيل خدّام…" else HINT
        if (c.input.hint?.toString() != hint) c.input.hint = hint
    }

    private fun lang(f: File): String = when (val e = f.extension.lowercase()) {
        "kt" -> "Kotlin"
        "java" -> "Java"
        "xml" -> "XML"
        "kts" -> "Gradle KTS"
        "gradle" -> "Gradle"
        "json" -> "JSON"
        "md" -> "Markdown"
        "txt" -> "Text"
        "" -> f.name
        else -> e.uppercase()
    }
}
