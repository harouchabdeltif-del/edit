# زليج (Zellige)

تطبيق أندرويد مستقل: **كتكتب أمر، والذكاء الاصطناعي كيبني ليك المشروع كملفات** ـ ماشي ورقة كود فالشات. فالمحادثة كتشوف غير كلمات صغيرة وبطاقات خفيفة بأسماء الملفات (`write app/src/main/.../MainActivity.kt`)، والكود كيتكتب مباشرة فالمجلد.
ما فيه حتى شي علاقة بـ AndroidIDE: كود جديد بحزمة `com.zellige.app`، بدون Gradle داخل الهاتف ولا مترجم ولا محرر ثقيل.

## شنو كيدير

- **الشات**: كتقول «ابني ليا تطبيق ملاحظات»، الوكيل كيخطّط، كيخلق المجلدات والملفات، كيعدّل، وكيصلّح. كيحتفظ بملاحظات قصيرة على المشروع (`remember`) وكيكمّل من فين وقف مع كل مشروع.
- **أدوات الوكيل** (كلها داخل مجلد المشروع فقط): `tree` · `list_dir` · `outline` · `read_file` · `search` · `find_files` · `write_file` · `edit_file` · `create_dir` · `move` · `delete` · `remember` · `github_issues` · `github_issue`. أي مسار برا المجلد (`..`، مسارات مطلقة، روابط رمزية، مجلد `.zellige` الداخلي) كيترفض.
- **اكتشف**: بحث فمشاريع GitHub **العامة** ← «افتح فزليج» كينزّلها كـ zip (بحدّ للحجم وحماية من zip-slip) وتولي مشروع عادي كيخدم عليه الوكيل؛ و`github_issues` كيخليو يقرا issues ديال المشروع الأصلي ويشتغل عليها.
- **مشاريعي**: قائمة المشاريع، فتح، إعادة تسمية، **تصدير ZIP لمجلد Downloads**، مسح المحادثة، حذف.
- **مزوّدين**: OpenRouter، OpenAI، Anthropic، Gemini، DeepSeek، Groq، xAI، Mistral، Together، Fireworks… + مزوّد مخصص (عنوان + صيغة). كتحط المفتاح ديالك فقط؛ الموديلات كتتجلب من المزوّد.
- ما كاين حتى كود كيطلع فالمحادثة: إلا الموديل رمى كود فالرد، التطبيق كيرفضو وكيرجّعو يطبّق بالأدوات (`write_file`).

المشاريع كتتخزن فـ `filesDir/projects` (مجلد التطبيق الخاص). باش تخرجهم: **مشاريعي ← ⋮ ← تصدير ZIP**.

## كيفاش تبني APK (GitHub Actions)

1. حط محتوى هاد المجلد فريبو GitHub جديد.
2. انسخ `ci/build.yml` إلى `.github/workflows/build.yml`.
3. Actions ← **Build Zellige app** ← Run workflow. فالأخير كتلقى `zellige-debug-apk` فـ Artifacts.
4. (اختياري) توقيع ثابت باش التحديثات تتثبّت فوق بعضها: حط keystore بصيغة base64 فـ Secret `ZELLIGE_KEYSTORE_B64` وكلمة السر فـ `ZELLIGE_KS_PASS`.

كيستعمل JDK 17 وGradle 8.9 (ما فيه gradle-wrapper). محلّيا: `gradle :app:assembleDebug`.

### بدّل معرّف التطبيق

```
bash tools/rename-package.sh com.mycompany.zellige
```
كيبدّل الحزمة فالكود والاختبارات و`applicationId`/`namespace`. (معرّف جديد = تطبيق جديد فنظر أندرويد.)

## الإعداد داخل التطبيق

1. ⚙ الإعدادات ← اختار المزوّد وحط مفتاح API.
2. (اختياري) GitHub token لرفع حدّ البحث من 60 لـ 5000 طلب فالساعة. توكن بلا صلاحيات كافي لقراءة المشاريع العامة.

## الهيكل

```
app/src/main/java/com/zellige/app/
  agent/    Agent (الحلقة) · Tools (الأدوات) · Workspace (المجلدات + sandbox)
  ai/       AiClient (openai / anthropic / gemini) · AiProviders · AiPrefs
  github/   GitHubApi (REST بلا مكتبات) · ZipUtil (zip آمن)
  ui/       MainActivity · ChatPage · DiscoverPage · ProjectsPage · SettingsSheet  (Views بالكود، RTL، بلا AndroidX)
tests/      jvm/ (اختبارات منطق) · typecheck.sh
ci/         build.yml        tools/  rename-package.sh
```

## شنو تختبر وشنو لا (للأمانة)

تم:
- ✔ `tests/jvm/run.sh`: **277 فحص** على JVM: parser الأدوات، الـ sandbox (مسارات خبيثة، `..`، روابط)، zip وحماية zip-slip والحدود، عميل GitHub وعميل الذكاء ضد **سيرفرات وهمية محلية** (200/401/403/429/أخطاء)، وحلقة الوكيل كاملة (عدد الخطوات، رفض الكود فالشات، تزامن).
- ✔ `tests/typecheck.sh`: كل الكود كيتترجم ضد `android.jar` الحقيقي (API 34).
- ✔ `tools/rename-package.sh` مجرّب على نسخة (الاختبارات ماشية بعد التبديل).
- ✔ ما فالمشروع حتى أثر لـ AndroidIDE/Termux (فحص `grep`).

ما تمش:
- ✘ **ما تبنى بـ Gradle/aapt2 ولا تجرّب على هاتف.** أول بناء على GitHub Actions هو الاختبار الحقيقي؛ إلا طلع خطأ صيفط ليا اللوغ كامل.
- ✘ الشكل ما تشافش على شاشة حقيقية (Views بالكود): الأبعاد والـ insets ممكن تحتاج تعديل.
- ✘ اتصال الشبكة (OpenRouter/OpenAI/…) تجرّب ضد سيرفرات وهمية فقط، ماشي ضد المزوّدين الحقيقيين.
- محدودية: التطبيق **كيكتب الملفات ما كيبنيهاش**. باش تبني المشروع اللي خلق الوكيل، صدّرو ZIP وارفعو لـ GitHub وبنيه بـ Actions (ولا فتحو فبيئة بناء أخرى).
- الواجهة بالعربية فقط دابا.

## الرخصة

كود زليج ديالك. المشاريع اللي كتنزّل من GitHub كتبقى بالرخصة ديال أصحابها ـ شوف `LICENSE` فكل مشروع قبل ما توزّعو.
