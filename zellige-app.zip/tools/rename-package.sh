#!/usr/bin/env bash
# يبدّل معرّف التطبيق (package / applicationId) من com.zellige.app إلى معرّف ديالك، فكل المشروع (كود، gradle، اختبارات).
#   bash tools/rename-package.sh com.mycompany.zellige
# خاصو يكون: حروف صغيرة/أرقام/_ مفصولة بنقط، جزءان على الأقل، وكل جزء كيبدا بحرف.
set -euo pipefail
NEW="${1:?usage: rename-package.sh com.your.app}"
OLD="com.zellige.app"
[[ "$NEW" =~ ^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$ ]] || { echo "❌ معرّف غير صالح: $NEW"; exit 1; }
[ "$NEW" = "$OLD" ] && { echo "نفس المعرّف، ما كاين ما نبدّل"; exit 0; }
cd "$(dirname "${BASH_SOURCE[0]}")/.."
SRC_ROOT="app/src/main/java"
[ -d "$SRC_ROOT/${OLD//.//}" ] || { echo "❌ ما لقيتش $SRC_ROOT/${OLD//.//} (واش سبق ودّرتي rename؟)"; exit 1; }
[ -e "$SRC_ROOT/${NEW//.//}" ] && { echo "❌ $SRC_ROOT/${NEW//.//} كاين من قبل"; exit 1; }

OLD_PATH="${OLD//.//}"; NEW_PATH="${NEW//.//}"
# 1) نص الملفات (بلا .git و build)
grep -rlI --exclude-dir=.git --exclude-dir=build --exclude-dir=.gradle -e "$OLD" -e "$OLD_PATH" . | while read -r f; do
  sed -i -e "s#$OLD_PATH#$NEW_PATH#g" -e "s#${OLD//./\\.}#$NEW#g" "$f"
done
# 2) نقل مجلد الكود
mkdir -p "$SRC_ROOT/$(dirname "$NEW_PATH")"
mv "$SRC_ROOT/$OLD_PATH" "$SRC_ROOT/$NEW_PATH"
# تنظيف المجلدات الفارغة القديمة (com/zellige)
find "$SRC_ROOT" -type d -empty -delete 2>/dev/null || true
echo "✅ $OLD → $NEW"
echo "   ملاحظة: تغيير الـ applicationId كيخلي Android يعتبرو تطبيق مختلف (ما غاديش يتحدّث فوق النسخة القديمة)."
