#!/usr/bin/env bash
# JVM tests of the app logic (no Android needed): tools, sandbox, zip, GitHub + AI clients against local fake servers, agent loop.
#   KOTLINC=/path/kotlinc bash tests/jvm/run.sh
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP="$(cd "$HERE/../.." && pwd)"
KC="${KOTLINC:-kotlinc}"
KBIN="$(dirname "$(command -v "$KC")")"
T="$(mktemp -d)"; trap 'rm -rf "$T"' EXIT
SRC="$APP/app/src/main/java/com/zellige/app"

mkdir -p "$T/stubs"
javac -nowarn -d "$T/stubs" "$HERE"/stubs/android/content/*.java 2>&1 | grep -v '^Note:' || true

"$KC" -jvm-target 17 -cp "$T/stubs" -d "$T/out" \
  "$HERE/shim/org/json/Json.kt" \
  "$SRC/agent/Agent.kt" "$SRC/agent/Tools.kt" "$SRC/agent/Workspace.kt" \
  "$SRC/ai/AiClient.kt" "$SRC/ai/AiPrefs.kt" "$SRC/ai/AiProviders.kt" \
  "$SRC/github/GitHubApi.kt" "$SRC/github/ZipUtil.kt" \
  "$HERE/AppTest.kt" 2>&1 | grep -v '^Picked up\|warning:' || true

java -cp "$T/out:$T/stubs:$KBIN/../lib/kotlin-stdlib.jar" AppTestKt
