package android.content;
import java.util.HashMap;
import java.util.Map;
/** Minimal JVM stand-in for android.content.Context: in-memory SharedPreferences. */
public class Context {
    public static final int MODE_PRIVATE = 0;
    private final Map<String, Map<String, String>> stores = new HashMap<>();
    public Context getApplicationContext() { return this; }
    public SharedPreferences getSharedPreferences(String name, int mode) {
        final Map<String, String> m = stores.computeIfAbsent(name, k -> new HashMap<>());
        return new SharedPreferences() {
            public String getString(String key, String def) { return m.containsKey(key) ? m.get(key) : def; }
            public Editor edit() {
                return new Editor() {
                    public Editor putString(String key, String value) { m.put(key, value); return this; }
                    public void apply() {}
                };
            }
        };
    }
}
