import com.sun.net.httpserver.HttpExchange
import com.sun.net.httpserver.HttpServer
import com.zellige.app.agent.Agent
import com.zellige.app.agent.ProjectInfo
import com.zellige.app.agent.Sandbox
import com.zellige.app.agent.Tools
import com.zellige.app.agent.Workspace
import com.zellige.app.ai.AiClient
import com.zellige.app.ai.AiPrefs
import com.zellige.app.github.GitHubApi
import com.zellige.app.github.ZipUtil
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.InetSocketAddress
import java.nio.file.Files
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlin.system.exitProcess

// ------------------------------------------------------------------ tiny test kit
var passed = 0
var failed = 0

fun check(name: String, cond: Boolean, extra: () -> String = { "" }) {
    if (cond) passed++ else { failed++; println("  ✗ $name ${extra()}") }
}

fun section(t: String) = println("• $t")

fun tmp(): File = Files.createTempDirectory("zl-test").toFile()

fun threw(f: () -> Unit): Throwable? = try { f(); null } catch (t: Throwable) { t }

fun zipOf(vararg entries: Pair<String, String>): ByteArray {
    val bo = ByteArrayOutputStream()
    ZipOutputStream(bo).use { z ->
        for ((n, c) in entries) {
            z.putNextEntry(ZipEntry(n))
            z.write(c.toByteArray())
            z.closeEntry()
        }
    }
    return bo.toByteArray()
}

fun call(name: String, vararg a: Pair<String, String>, body: String = "") =
    Tools.Call(name, a.toMap() + ("name" to name), body)

// ------------------------------------------------------------------ fake servers
class FakeProvider {
    val replies = java.util.concurrent.LinkedBlockingDeque<String>()
    val seen = java.util.Collections.synchronizedList(ArrayList<JSONObject>())
    val headers = java.util.Collections.synchronizedList(ArrayList<Map<String, String>>())
    @Volatile var failWith = 0
    val server: HttpServer = HttpServer.create(InetSocketAddress("127.0.0.1", 0), 0)
    val base get() = "http://127.0.0.1:${server.address.port}"

    private fun send(ex: HttpExchange, code: Int, body: String, ct: String = "application/json") {
        val b = body.toByteArray()
        ex.responseHeaders.add("Content-Type", ct)
        ex.sendResponseHeaders(code, b.size.toLong())
        ex.responseBody.use { it.write(b) }
    }

    init {
        server.createContext("/") { ex ->
            val body = String(ex.requestBody.readBytes())
            val path = ex.requestURI.path
            if (ex.requestMethod == "POST") {
                seen.add(JSONObject(body))
                headers.add(ex.requestHeaders.entries.associate { it.key.lowercase() to it.value.joinToString(",") })
            }
            if (failWith != 0) { send(ex, failWith, """{"error":{"message":"nope"}}"""); return@createContext }
            val reply = replies.pollFirst() ?: "(no scripted reply)"
            when {
                path.endsWith("/chat/completions") ->
                    send(ex, 200, JSONObject().put("choices", JSONArray().put(JSONObject().put("message", JSONObject().put("role", "assistant").put("content", reply)))).toString())
                path.endsWith("/messages") ->
                    send(ex, 200, JSONObject().put("content", JSONArray().put(JSONObject().put("type", "text").put("text", reply))).toString())
                path.endsWith(":generateContent") ->
                    send(ex, 200, JSONObject().put("candidates", JSONArray().put(JSONObject().put("content", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", reply)))))).toString())
                path.endsWith("/models") ->
                    send(ex, 200, """{"data":[{"id":"zeta-1"},{"id":"alpha-2"}]}""")
                else -> send(ex, 404, "{}")
            }
        }
        server.start()
    }
    fun stop() = server.stop(0)
}

class FakeGitHub {
    val server: HttpServer = HttpServer.create(InetSocketAddress("127.0.0.1", 0), 0)
    val base get() = "http://127.0.0.1:${server.address.port}"
    val auth = java.util.Collections.synchronizedList(ArrayList<String>())
    val queries = java.util.Collections.synchronizedList(ArrayList<String>())
    var zip: ByteArray = zipOf("o-r-abc123/README.md" to "# hello\n", "o-r-abc123/src/Main.kt" to "fun main() {}\n")

    private fun send(ex: HttpExchange, code: Int, body: ByteArray, ct: String = "application/json", extra: Map<String, String> = emptyMap()) {
        ex.responseHeaders.add("Content-Type", ct)
        extra.forEach { (k, v) -> ex.responseHeaders.add(k, v) }
        ex.sendResponseHeaders(code, if (body.isEmpty()) -1 else body.size.toLong())
        if (body.isNotEmpty()) ex.responseBody.use { it.write(body) } else ex.responseBody.close()
    }

    private val repo = """{"full_name":"o/r","description":"demo repo","stargazers_count":1234,"language":"Kotlin",
        "license":{"spdx_id":"MIT","name":"MIT License"},"size":900,"html_url":"https://github.com/o/r","default_branch":"main",
        "open_issues_count":3,"topics":["android","demo"]}"""

    init {
        server.createContext("/") { ex ->
            ex.requestHeaders.getFirst("Authorization")?.let { auth.add(it) }
            val path = ex.requestURI.path
            val q = ex.requestURI.rawQuery.orEmpty()
            queries.add(java.net.URLDecoder.decode(q, "UTF-8"))
            fun s(code: Int, text: String) = send(ex, code, text.toByteArray())
            when {
                path == "/search/repositories" -> s(200, """{"items":[$repo,{"full_name":"x/y","description":null,"stargazers_count":5,"language":null,"license":null,"size":10,"html_url":"u","default_branch":"main","open_issues_count":0}]}""")
                path == "/repos/o/r" -> s(200, repo)
                path == "/repos/limit/x" -> send(ex, 403, """{"message":"rate limited"}""".toByteArray(), extra = mapOf("X-RateLimit-Remaining" to "0", "X-RateLimit-Reset" to ((System.currentTimeMillis() / 1000) + 600).toString()))
                path == "/repos/o/r/issues" -> s(200, """[{"number":7,"title":"Crash on start","body":"stack…","user":{"login":"bob"},"labels":[{"name":"bug"}],"comments":1,"html_url":"u"},
                    {"number":8,"title":"A PR","pull_request":{},"user":{"login":"x"},"labels":[],"comments":0,"html_url":"u"}]""")
                path == "/repos/o/r/issues/7" -> s(200, """{"number":7,"title":"Crash on start","body":"stack…","user":{"login":"bob"},"labels":[{"name":"bug"}],"comments":1,"html_url":"u"}""")
                path == "/repos/o/r/issues/7/comments" -> s(200, """[{"user":{"login":"amy"},"body":"same here"}]""")
                path == "/repos/o/r/zipball" -> send(ex, 302, ByteArray(0), extra = mapOf("Location" to "/codeload/o-r.zip"))
                path == "/codeload/o-r.zip" -> send(ex, 200, zip, "application/zip")
                else -> s(404, """{"message":"Not Found"}""")
            }
        }
        server.start()
    }
    fun stop() = server.stop(0)
}

// ------------------------------------------------------------------ helpers for the agent
class Run(val agent: Agent) {
    val events = java.util.Collections.synchronizedList(ArrayList<Agent.Event>())
    private var latch = CountDownLatch(1)
    var finish: Agent.Event.Finish? = null

    init {
        agent.listener = { e ->
            events.add(e)
            if (e is Agent.Event.Finish) { finish = e; latch.countDown() }
        }
    }

    fun go(prompt: String, timeoutSec: Long = 20): Agent.Event.Finish {
        latch = CountDownLatch(1)
        finish = null
        events.clear()
        check("send accepted", agent.send(prompt))
        check("finished in time", latch.await(timeoutSec, TimeUnit.SECONDS))
        return finish ?: Agent.Event.Finish("timeout", false, emptyList(), "")
    }
}

fun alternates(views: List<List<AiClient.Msg>>, label: String) {
    views.forEachIndexed { n, v ->
        check("$label: request #$n starts with user", v.firstOrNull()?.role == "user")
        for (i in 1 until v.size) check("$label: request #$n alternates at $i", v[i].role != v[i - 1].role) { "(${v[i - 1].role}->${v[i].role})" }
    }
}

fun w(path: String, body: String) = "<tool name=\"write_file\" path=\"$path\">\n$body\n</tool>"

fun main() {
    // ============================================================ Sandbox & Workspace
    section("Workspace / Sandbox")
    val wsDir = tmp()
    val ws = Workspace(wsDir)
    val p1 = ws.create("Login App")
    val p2 = ws.create("Login App")
    check("unique names", p1.name == "Login App" && p2.name == "Login App-2", { "${p1.name} ${p2.name}" })
    check("sanitize path chars", ws.sanitize("a/b\\c:d*e?") == "a-b-c-d-e", { ws.sanitize("a/b\\c:d*e?") })
    check("find refuses traversal", ws.find("../x") == null)
    check("find ok", ws.find("Login App") != null)
    ProjectInfo.writeMeta(p1, JSONObject().put("repo", "Owner/Repo"))
    check("findByRepo case-insensitive", ws.findByRepo("owner/repo")?.name == p1.name)
    check("repo() from meta", ProjectInfo.repo(p1) == "Owner/Repo")

    val sb = Sandbox(p1)
    check("resolve inside", sb.resolve("a/b.txt").path == File(sb.root, "a/b.txt").path)
    check("resolve '.' = root", sb.resolve(".") == sb.root && sb.resolve("") == sb.root)
    check("dotdot escape blocked", threw { sb.resolve("../x") } is SecurityException)
    check("deep dotdot escape blocked", threw { sb.resolve("a/../../x") } is SecurityException)
    check("abs path stays inside root", sb.resolve("/etc/passwd").path.startsWith(sb.root.path))
    check(".zellige blocked", threw { sb.resolve(".zellige/chat.json") } is SecurityException)
    check("./.zellige blocked", threw { sb.resolve("./.zellige") } is SecurityException)
    check("a/../.zellige blocked", threw { sb.resolve("a/../.zellige/x") } is SecurityException)
    val outside = tmp()
    File(outside, "secret.txt").writeText("s")
    Files.createSymbolicLink(File(sb.root, "link").toPath(), outside.toPath())
    check("symlink escape blocked", threw { sb.resolve("link/secret.txt") } is SecurityException)
    check("rel()", sb.rel(File(sb.root, "x/y.kt")) == "x/y.kt" && sb.rel(sb.root) == ".")

    ProjectInfo.appendNote(p1, "first\nline")
    ProjectInfo.appendNote(p1, "second")
    check("notes appended", ProjectInfo.notes(p1).contains("- first line") && ProjectInfo.notes(p1).contains("- second"))
    repeat(60) { ProjectInfo.appendNote(p1, "x".repeat(300) + it) }
    check("notes capped", ProjectInfo.notes(p1).length <= 6100 && ProjectInfo.notes(p1).contains("x59"))
    ProjectInfo.saveChat(p1, listOf(AiClient.Msg("user", "مرحبا"), AiClient.Msg("assistant", "أهلا \"x\"\n")))
    check("chat roundtrip unicode", ProjectInfo.loadChat(p1).map { it.content } == listOf("مرحبا", "أهلا \"x\"\n"))
    check("delete only inside workspace", ws.delete(p2) && !p2.exists() && !ws.delete(outside))

    // ============================================================ Tools: parsing
    section("Tools parsing")
    val reply = """
        سأبدأ الآن.
        <tool name="write_file" path="a/B.kt">
        fun x() = 1
        </tool>
        <tool name='read_file' path="a/B.kt" start="1" end="3"/>
        <tool name="remember">use kotlin</tool>
        تم.
    """.trimIndent()
    val calls = Tools.parse(reply)
    check("parse count", calls.size == 3, { "${calls.size}" })
    check("parse write_file body trimmed", calls[0].name == "write_file" && calls[0].body == "fun x() = 1" && calls[0].path == "a/B.kt", { calls[0].toString() })
    check("parse single-quoted + self-closing", calls[1].name == "read_file" && calls[1].attrs["start"] == "1")
    check("parse remember body", calls[2].body == "use kotlin")
    check("clean removes tags", !Tools.clean(reply).contains("<tool") && Tools.clean(reply).contains("سأبدأ") && Tools.clean(reply).contains("تم."))
    val dump = "Here you go:\n```kotlin\nfun a() {\n  println(1)\n  println(2)\n}\n```\ndone"
    check("hasCodeDump long fence", Tools.hasCodeDump(dump))
    check("hasCodeDump ignores short", !Tools.hasCodeDump("use `x` or\n```\nls\n```"))
    check("hasCodeDump ignores code inside tools", !Tools.hasCodeDump(w("a.kt", "```kotlin\na\nb\nc\nd\n```")))
    check("clean strips all fences", !Tools.clean(dump).contains("```") && !Tools.clean(dump).contains("println") && Tools.clean(dump).contains("done"))
    check("clean strips unclosed fence", !Tools.clean("hi\n```kotlin\nfun a() {").contains("fun a"))
    check("countTags detects cut-off", Tools.countTags("<tool name=\"write_file\" path=\"a\">partial") == 1 && Tools.parse("<tool name=\"write_file\" path=\"a\">partial").isEmpty())
    val big = AiClient.Msg("assistant", w("a/Big.kt", "x".repeat(2000)))
    check("compact omits big bodies", Tools.compact(big).content.contains("[content omitted]") && Tools.compact(big).content.length < 200)
    val small = AiClient.Msg("assistant", w("a/S.kt", "x"))
    check("compact keeps small", Tools.compact(small) == small)
    check("kindOf", Tools.kindOf("write_file") == "write" && Tools.kindOf("outline") == "read" && Tools.kindOf("github_issue") == "github")

    // ============================================================ Tools: execution
    section("Tools execution")
    val proj = tmp()
    val undo = Tools.Undo()
    val box = Tools.Box(Sandbox(proj), undo, null, null)
    fun run(c: Tools.Call) = box.execute(c)

    var r = run(call("write_file", "path" to "app/src/Main.kt", body = "package app\n\nclass Main {\n  fun hi() = \"hello\"\n}\n"))
    check("write_file ok", r.ok && File(proj, "app/src/Main.kt").readText().contains("class Main"), { r.text })
    check("write_file created nested dir tracked", undo.dirs.isNotEmpty())
    r = run(call("write_file", "path" to "notes.md", body = "```md\n# T\n```"))
    check("write_file unfences", File(proj, "notes.md").readText() == "# T", { File(proj, "notes.md").readText() })
    r = run(call("read_file", "path" to "app/src/Main.kt", "numbered" to "true", "start" to "3", "end" to "4"))
    check("read_file numbered range", r.ok && r.text.contains("3\tclass Main {") && r.text.contains("4\t  fun hi()") && r.text.startsWith("[3-4"), { r.text })
    r = run(call("read_file", "path" to "nope.txt"))
    check("read_file missing -> ok=false", !r.ok)
    r = run(call("edit_file", "path" to "app/src/Main.kt", body = "<find>\"hello\"</find><replace>\"salam\"</replace>"))
    check("edit_file ok", r.ok && File(proj, "app/src/Main.kt").readText().contains("salam"), { r.text })
    r = run(call("edit_file", "path" to "app/src/Main.kt", body = "<find>nothing here</find><replace>x</replace>"))
    check("edit_file not found -> error", !r.ok && r.text.contains("غير موجود"), { r.text })
    File(proj, "dup.txt").writeText("a a")
    r = run(call("edit_file", "path" to "dup.txt", body = "<find>a</find><replace>b</replace>"))
    check("edit_file non-unique -> error, file untouched", !r.ok && File(proj, "dup.txt").readText() == "a a", { r.text })
    r = run(call("edit_file", "path" to "dup.txt", body = "<find>a a</find><replace>c</replace><find>c</find><replace>d</replace>"))
    check("edit_file multi sequential", r.ok && File(proj, "dup.txt").readText() == "d", { r.text })
    check("edit_file records 'edit' (not new) for existing file", undo.changes["dup.txt"] == "edit" && undo.changes["notes.md"] == "new", { undo.changes.toString() })

    r = run(call("search", "path" to ".", "query" to "salam"))
    check("search plain", r.ok && r.text.contains("app/src/Main.kt:4"), { r.text })
    r = run(call("search", "path" to ".", "query" to "fu?n\\s+hi", "regex" to "true", "context" to "1"))
    check("search regex + context", r.ok && r.text.contains("3| class Main"), { r.text })
    r = run(call("search", "path" to ".", "query" to "class", "glob" to "*.md"))
    check("search glob filters", r.text.contains("ما لقيت"), { r.text })
    r = run(call("find_files", "path" to ".", "pattern" to "*.kt"))
    check("find_files", r.ok && r.text.trim() == "app/src/Main.kt", { r.text })
    r = run(call("tree", "path" to "."))
    check("tree", r.ok && r.text.contains("app/") && r.text.contains("Main.kt"), { r.text })
    r = run(call("outline", "path" to "."))
    check("outline lists declarations", r.ok && r.text.contains("class Main") && r.text.contains("fun hi"), { r.text })
    r = run(call("list_dir", "path" to "app"))
    check("list_dir", r.ok && r.text.contains("src/"), { r.text })
    r = run(call("create_dir", "path" to "res/values"))
    check("create_dir", r.ok && File(proj, "res/values").isDirectory)
    r = run(call("move", "path" to "dup.txt", "to" to "res/values/dup.txt"))
    check("move", r.ok && !File(proj, "dup.txt").exists() && File(proj, "res/values/dup.txt").readText() == "d", { r.text })
    r = run(call("move", "path" to "notes.md", "to" to "res/values/dup.txt"))
    check("move refuses existing target", !r.ok)
    r = run(call("remember", body = "uses gradle 8.7"))
    check("remember", r.ok && ProjectInfo.notes(proj).contains("gradle 8.7"))
    r = run(call("remember"))
    check("remember needs text", !r.ok)

    // sandbox through tools
    r = run(call("read_file", "path" to "../../etc/passwd"))
    check("tool refuses escape", !r.ok && r.text.contains("خارج"), { r.text })
    r = run(call("write_file", "path" to ".zellige/chat.json", body = "x"))
    check("tool refuses .zellige", !r.ok)
    r = run(call("delete", "path" to "."))
    check("cannot delete root", !r.ok && proj.exists())
    r = run(call("bogus"))
    check("unknown tool", !r.ok)

    // delete + undo (state before the "run" must come back)
    File(proj, "keep/sub").mkdirs()
    File(proj, "keep/a.txt").writeText("A"); File(proj, "keep/sub/b.txt").writeText("B"); File(proj, "edit.txt").writeText("old")
    val u3 = Tools.Undo()
    val box3 = Tools.Box(Sandbox(proj), u3, null, null)
    r = box3.execute(call("delete", "path" to "keep"))
    check("delete dir", r.ok && !File(proj, "keep").exists())
    check("delete dir recorded", u3.changes["keep/"] == "delete", { u3.changes.toString() })
    box3.execute(call("edit_file", "path" to "edit.txt", body = "<find>old</find><replace>new</replace>"))
    box3.execute(call("write_file", "path" to "fresh/dir/new.txt", body = "n"))
    check("changes tracked", u3.changes["edit.txt"] == "edit" && u3.changes["fresh/dir/new.txt"] == "new", { u3.changes.toString() })
    val restored = u3.restore()
    check("undo restores deleted files with original content", File(proj, "keep/a.txt").readText() == "A" && File(proj, "keep/sub/b.txt").readText() == "B", { "restored=$restored" })
    check("undo restores edited file", File(proj, "edit.txt").readText() == "old")
    check("undo removes created file and its new dirs", !File(proj, "fresh").exists(), { File(proj, "fresh").list()?.toList().toString() })

    val u2 = Tools.Undo()
    u2.mark("x.kt", "new"); u2.mark("x.kt", "edit")
    check("mark new+edit stays new", u2.changes["x.kt"] == "new")
    u2.mark("x.kt", "delete")
    check("mark new+delete vanishes", !u2.changes.containsKey("x.kt"))

    // ============================================================ Zip
    section("ZipUtil")
    val z = tmp()
    val n = ZipUtil.extract(ByteArrayInputStream(zipOf("top-abc/a.txt" to "A", "top-abc/d/b.txt" to "B")), z, true, 1_000_000, 100)
    check("extract strips first component", n == 2 && File(z, "a.txt").readText() == "A" && File(z, "d/b.txt").readText() == "B")
    val z2 = tmp()
    val evil = threw { ZipUtil.extract(ByteArrayInputStream(zipOf("top/../../evil.txt" to "x")), z2, true, 1000, 10) }
    check("zip-slip blocked", evil is SecurityException, { evil.toString() })
    check("zip-slip left nothing outside", !File(z2.parentFile, "evil.txt").exists())
    val evil2 = threw { ZipUtil.extract(ByteArrayInputStream(zipOf("../evil2.txt" to "x")), tmp(), false, 1000, 10) }
    check("zip-slip (no strip) blocked", evil2 is SecurityException)
    check("max bytes enforced", threw { ZipUtil.extract(ByteArrayInputStream(zipOf("t/a" to "x".repeat(500))), tmp(), true, 100, 10) } is IllegalStateException)
    check("max files enforced", threw { ZipUtil.extract(ByteArrayInputStream(zipOf("t/a" to "1", "t/b" to "2", "t/c" to "3")), tmp(), true, 1000, 2) } is IllegalStateException)
    val src = tmp()
    File(src, "keep.txt").writeText("k"); File(src, "sub").mkdirs(); File(src, "sub/x.kt").writeText("x")
    File(src, ".zellige").mkdirs(); File(src, ".zellige/chat.json").writeText("secret")
    File(src, "build").mkdirs(); File(src, "build/out.bin").writeText("junk")
    val bo = ByteArrayOutputStream()
    val zn = ZipUtil.zipDir(src, bo)
    val names = java.util.zip.ZipInputStream(ByteArrayInputStream(bo.toByteArray())).let { zi -> generateSequence { zi.nextEntry }.map { it.name }.toList() }
    check("zipDir skips .zellige and build", zn == 2 && names.sorted() == listOf("keep.txt", "sub/x.kt"), { names.toString() })

    // ============================================================ GitHub client vs fake server
    section("GitHubApi (fake server)")
    val fg = FakeGitHub()
    val gh = GitHubApi({ "tok123" }, fg.base)
    val found = gh.search("todo app archived:false", 2, 15)
    check("search parses repos", found.size == 2 && found[0].full == "o/r" && found[0].stars == 1234 && found[0].license == "MIT" && found[0].topics == listOf("android", "demo"))
    check("search handles null fields", found[1].description == "" && found[1].language == "" && found[1].license == "")
    check("search query + paging sent", fg.queries.last().contains("q=todo app archived:false") && fg.queries.last().contains("page=2"), { fg.queries.last() })
    check("token sent as Bearer", fg.auth.last() == "Bearer tok123")
    check("repo()", gh.repo("o/r").branch == "main")
    val iss = gh.issues("o/r")
    check("issues excludes PRs", iss.size == 1 && iss[0].number == 7 && iss[0].labels == listOf("bug"), { iss.toString() })
    val (issue, comments) = gh.issueWithComments("o/r", 7)
    check("issue + comments", issue.title == "Crash on start" && comments == listOf("amy: same here"), { comments.toString() })
    val rl = threw { gh.repo("limit/x") }
    check("rate limit message", rl is GitHubApi.GhException && rl.message!!.contains("حدّ") && rl.message!!.contains("دقيقة"), { rl?.message ?: "" })
    val nf = threw { gh.repo("no/pe") }
    check("404 message", nf is GitHubApi.GhException && nf.message!!.contains("غير موجود"))
    val dl = tmp()
    val files = gh.download("o/r", dl) { _, _ -> }
    check("download follows redirect + strips top dir", files == 2 && File(dl, "README.md").exists() && File(dl, "src/Main.kt").exists(), { dl.list()?.toList().toString() })
    // tools using github
    val ghBox = Tools.Box(Sandbox(proj), Tools.Undo(), gh, "o/r")
    check("tool github_issues", ghBox.execute(call("github_issues")).text.contains("#7 Crash on start"))
    check("tool github_issue", ghBox.execute(call("github_issue", "number" to "7")).text.contains("amy"))
    check("tool github_issue w/o repo -> error", !Tools.Box(Sandbox(proj), Tools.Undo(), gh, null).execute(call("github_issues")).ok)

    // ============================================================ AiClient vs fake provider
    section("AiClient (fake provider)")
    val fp = FakeProvider()
    val ctx = android.content.Context()
    val prefs = AiPrefs(ctx)
    check("prefs default provider", prefs.provider == "deepseek" && !prefs.ready())
    prefs.apiKey = "sk-test"
    check("prefs ready + model default", prefs.ready() && prefs.effectiveModel() == "deepseek-v4-flash")
    prefs.provider = "custom"; prefs.baseUrl = fp.base + "/v1"; prefs.model = "m1"; prefs.apiKey = "k-custom"
    check("per-provider key isolation", prefs.keyFor("deepseek") == "sk-test" && prefs.apiKey == "k-custom")
    fp.replies.add("pong")
    check("openai format", AiClient.ping(prefs) == "pong")
    check("openai auth header", fp.headers.last()["authorization"] == "Bearer k-custom", { fp.headers.last().toString() })
    check("openai body has system+user", fp.seen.last().getJSONArray("messages").getJSONObject(0).getString("role") == "system")
    prefs.customFormat = "anthropic"; fp.replies.add("A-pong")
    check("anthropic format", AiClient.complete(prefs, "s", listOf(AiClient.Msg("user", "hi"))) == "A-pong")
    check("anthropic headers", fp.headers.last()["x-api-key"] == "k-custom" && fp.headers.last()["anthropic-version"] != null, { fp.headers.last().toString() })
    prefs.customFormat = "gemini"; prefs.customChatPath = "/v1beta/models/{model}:generateContent"; fp.replies.add("G-pong")
    check("gemini format", AiClient.complete(prefs, "s", listOf(AiClient.Msg("user", "hi"))) == "G-pong")
    prefs.customFormat = "openai"; prefs.customChatPath = ""
    check("listModels sorted", AiClient.listModels(prefs) == listOf("alpha-2", "zeta-1"))
    fp.failWith = 401
    val e401 = threw { AiClient.complete(prefs, "s", listOf(AiClient.Msg("user", "x"))) }
    check("401 -> ApiException(401) without retry storm", e401 is AiClient.ApiException && e401.code == 401, { e401.toString() })
    fp.failWith = 0

    // ============================================================ Agent (scripted model)
    section("Agent: create project")
    val scriptDir = tmp()
    val ws2 = Workspace(scriptDir)
    val views = java.util.Collections.synchronizedList(ArrayList<List<AiClient.Msg>>())
    val script = java.util.concurrent.LinkedBlockingDeque<String>()
    val systems = java.util.Collections.synchronizedList(ArrayList<String>())
    val hook = java.util.concurrent.atomic.AtomicReference<(() -> Unit)?>(null)
    val agent = Agent({ sys, msgs ->
        systems.add(sys); views.add(msgs.toList())
        hook.get()?.invoke()
        script.pollFirst() ?: "لا شيء"
    }, gh)
    val login = ws2.create("login-app")
    agent.open(login)
    val rn = Run(agent)

    script.add("غادي ننشئ المشروع.\n" +
        w("settings.gradle.kts", "rootProject.name = \"Login\"\ninclude(\":app\")") + "\n" +
        w("app/src/main/java/com/example/LoginActivity.kt", "package com.example\n\nclass LoginActivity\n") + "\n" +
        "<tool name=\"remember\">single module app</tool>")
    script.add("<tool name=\"read_file\" path=\"app/src/main/java/com/example/LoginActivity.kt\"/>\n<tool name=\"search\" path=\".\" query=\"LoginActivity\"/>")
    script.add("أنشأت شاشة تسجيل الدخول في app/src/main/java/com/example/LoginActivity.kt وملف settings.gradle.kts.")
    val fin = rn.go("اصنع لي تطبيق تسجيل دخول")
    check("run ok", fin.error == null && !fin.stopped, { fin.error ?: "" })
    check("files created", File(login, "settings.gradle.kts").exists() && File(login, "app/src/main/java/com/example/LoginActivity.kt").exists())
    check("finish lists new files", fin.changes.contains("settings.gradle.kts" to "new") && fin.changes.contains("app/src/main/java/com/example/LoginActivity.kt" to "new"), { fin.changes.toString() })
    check("finish summary is the last plain sentence", fin.summary.contains("LoginActivity.kt") && !fin.summary.contains("<tool"))
    val steps = rn.events.filterIsInstance<Agent.Event.Step>()
    val dones = rn.events.filterIsInstance<Agent.Event.Done>()
    check("events: step+done pairs", steps.size == 5 && dones.size == 5 && dones.all { it.ok }, { "${steps.size}/${dones.size}" })
    check("events: Note for narration", rn.events.any { it is Agent.Event.Note && it.text.contains("غادي ننشئ") })
    check("events: Finish is last", rn.events.last() is Agent.Event.Finish)
    check("notes stored", ProjectInfo.notes(login).contains("single module"))
    check("system prompt: rules + empty project", systems[0].contains("NEVER write code") && systems[0].contains("EMPTY"))
    check("system prompt has no old-product names", !systems[0].lowercase().contains("androidide") && !systems[0].lowercase().contains("itsaky"))
    check("tool results fed back", views[1].last().content.startsWith("<tool_results>") && views[1].last().content.contains("LoginActivity.kt"))
    val hist = agent.history()
    check("history: user + one assistant sentence", hist.size == 2 && hist[0].fromUser && !hist[1].fromUser, { hist.toString() })
    check("history: assistant carries only written paths", hist[1].paths == listOf("settings.gradle.kts", "app/src/main/java/com/example/LoginActivity.kt"), { hist[1].paths.toString() })
    check("history shows no code", hist.none { it.text.contains("class LoginActivity\n") || it.text.contains("```") })
    check("persisted chat file", ProjectInfo.chatFile(login).exists())
    check("no dangling busy", !agent.busy())
    check("undo available", agent.canUndo())
    alternates(views.toList(), "create")

    // reopen -> history restored
    val agentB = Agent({ _, _ -> "x" }, gh)
    agentB.open(login)
    check("history restored after reopen", agentB.history().map { it.text } == hist.map { it.text })

    section("Agent: undo")
    val nUndo = agent.undoLast()
    check("undo removes created files", nUndo == 2 && !File(login, "settings.gradle.kts").exists() && !File(login, "app").exists(), { "n=$nUndo app=${File(login, "app").exists()}" })
    check("undo consumed", !agent.canUndo())
    script.add("تمام.")
    views.clear(); systems.clear()
    rn.go("ابدأ من جديد")
    check("undo note reaches next run's system prompt", systems[0].contains("pressed Undo"), { systems.firstOrNull()?.takeLast(300) ?: "" })

    section("Agent: code dump -> forced to use tools")
    views.clear()
    script.add("هاك الكود:\n```kotlin\nfun a() {\n  println(1)\n  println(2)\n}\n```")
    script.add(w("Hello.kt", "fun main() = println(\"hi\")"))
    script.add("أنشأت Hello.kt.")
    val f2 = rn.go("اكتب برنامج hello")
    check("code dump retried", f2.error == null && File(login, "Hello.kt").exists(), { f2.error ?: "" })
    check("fix instruction was sent", views.any { v -> v.any { Tools.isResults(it) && it.content.contains("You wrote code in the chat") } })
    check("history hides the dump", agent.history().none { it.text.contains("println(1)") || it.text.contains("هاك الكود") })
    check("final summary has no code", !f2.summary.contains("```"))
    alternates(views.toList(), "dump")

    section("Agent: failing edit then recovery")
    views.clear(); systems.clear()
    script.add("<tool name=\"edit_file\" path=\"Hello.kt\"><find>println(\"nope\")</find><replace>x</replace></tool>")
    script.add("<tool name=\"edit_file\" path=\"Hello.kt\"><find>\"hi\"</find><replace>\"salam\"</replace></tool>")
    script.add("بدّلت الرسالة فـ Hello.kt.")
    val f3 = rn.go("بدل الرسالة")
    check("next run's system prompt shows the existing tree", systems[0].contains("Hello.kt") && !systems[0].contains("EMPTY"), { systems[0].takeLast(200) })
    check("recovered", f3.error == null && File(login, "Hello.kt").readText().contains("salam"))
    check("failure surfaced as Done(ok=false) event", rn.events.filterIsInstance<Agent.Event.Done>().first().let { !it.ok })
    check("model saw the failure", views[1].last().content.contains("ok=\"false\""))

    section("Agent: cut-off tag")
    views.clear()
    script.add("<tool name=\"write_file\" path=\"Big.kt\">\nclass Big {")   // مقطوع
    script.add(w("Big.kt", "class Big"))
    script.add("كتبت Big.kt.")
    val f4 = rn.go("اكتب ملف كبير")
    check("cut-off handled", f4.error == null && File(login, "Big.kt").readText() == "class Big", { f4.error ?: "" })
    check("model told it was cut", views[1].last().content.contains("CUT OFF"))
    check("cut-off tag not executed", rn.events.filterIsInstance<Agent.Event.Step>().size == 1)

    section("Agent: stop")
    views.clear()
    hook.set { Thread.sleep(150) }
    script.add(w("S1.kt", "1"))
    script.add(w("S2.kt", "2"))
    script.add("done")
    val latch = CountDownLatch(1)
    Thread { Thread.sleep(80); agent.stop(); latch.countDown() }.start()
    val f5 = rn.go("اعمل ملفات")
    hook.set(null)
    latch.await()
    check("stopped flag", f5.stopped && f5.error == null, { "stopped=${f5.stopped} err=${f5.error}" })
    check("stop kept consistent history (next run alternates)", true)
    script.clear()
    script.add("تمام بعد الإيقاف.")
    views.clear()
    val f5b = rn.go("كمّل")
    check("run after stop works", f5b.error == null && f5b.summary.contains("تمام"), { f5b.error ?: "" })
    alternates(views.toList(), "after-stop")

    section("Agent: provider errors")
    views.clear()
    val agentE = Agent({ _, _ -> throw AiClient.ApiException(401, "HTTP 401: bad key") }, gh)
    val projE = ws2.create("err-proj")
    agentE.open(projE)
    val rnE = Run(agentE)
    val fe = rnE.go("hello")
    check("error text is friendly", fe.error != null && fe.error!!.contains("المفتاح"), { fe.error ?: "" })
    check("failed prompt removed from history", agentE.history().isEmpty())
    check("busy cleared after error", !agentE.busy())
    val agentN = Agent({ _, _ -> throw java.net.UnknownHostException("x") }, gh)
    agentN.open(ws2.create("net-proj"))
    check("offline text", Run(agentN).go("hi").error!!.contains("إنترنت"))
    val agentBlank = Agent({ _, _ -> "   " }, gh)
    agentBlank.open(ws2.create("blank-proj"))
    check("blank replies end with error, not a hang", Run(agentBlank).go("hi").error != null)

    section("Agent: step budget")
    val budgetViews = java.util.Collections.synchronizedList(ArrayList<List<AiClient.Msg>>())
    val agentL = Agent({ _, msgs ->
        budgetViews.add(msgs.toList())
        (1..16).joinToString("\n") { "<tool name=\"list_dir\" path=\".\"/>" }
    }, gh)
    agentL.open(ws2.create("loop-proj"))
    val fl = Run(agentL).go("ما تتوقف")
    check("budget stops the loop", fl.error == null && fl.summary.contains("كمّل"), { fl.summary })
    check("budget: bounded rounds", budgetViews.size in 5..7, { "${budgetViews.size}" })
    alternates(budgetViews.toList(), "budget")

    section("Agent: concurrency guards")
    val agentC = Agent({ _, _ -> Thread.sleep(300); "ok" }, gh)
    agentC.open(ws2.create("busy-proj"))
    val rnC = Run(agentC)
    check("send accepted", agentC.send("a"))
    check("second send refused while busy", !agentC.send("b"))
    check("open refused while busy", !agentC.open(null))
    agentC.stop()
    Thread.sleep(500)
    check("idle again", !agentC.busy())

    section("Agent: full stack through AiClient + HTTP")
    prefs.provider = "custom"; prefs.customFormat = "openai"; prefs.baseUrl = fp.base + "/v1"; prefs.model = "m1"; prefs.apiKey = "k"
    val agentH = Agent({ sys, msgs -> AiClient.complete(prefs, sys, msgs) }, gh)
    val projH = ws2.create("http-proj")
    agentH.open(projH)
    val rnH = Run(agentH)
    fp.seen.clear()
    fp.replies.add(w("index.html", "<h1>Salam</h1>") + "\n" + w("style.css", "h1{color:#fb4}"))
    fp.replies.add("صاوبت صفحة index.html بتنسيق فـ style.css.")
    val fh = rnH.go("صاوب ليا صفحة ويب بسيطة")
    check("http run ok", fh.error == null && File(projH, "index.html").readText().contains("Salam"), { fh.error ?: "" })
    check("http: 2 requests (tools round + final)", fp.seen.size == 2, { "${fp.seen.size}" })
    val msgsSent = fp.seen[1].getJSONArray("messages")
    check("http: second request carries assistant + tool_results", msgsSent.length() == 4 && msgsSent.getJSONObject(3).getString("content").startsWith("<tool_results>"), { "${msgsSent.length()}" })

    // ============================================================ no leftovers of the other product
    fp.stop(); fg.stop()
    println("\n$passed passed, $failed failed")
    exitProcess(if (failed == 0) 0 else 1)
}
