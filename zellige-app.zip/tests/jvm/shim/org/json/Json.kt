package org.json

/**
 * Small org.json work-alike for JVM tests only (the real one ships with Android).
 * Mirrors the behaviours the app relies on: optString -> "null" for JSON null, put(k, null) removes, NULL sentinel.
 */
class JSONException(message: String?) : Exception(message)

private object NullValue {
    override fun equals(other: Any?) = other == null || other === this
    override fun hashCode() = 0
    override fun toString() = "null"
}

private fun quote(s: String): String = buildString {
    append('"')
    for (c in s) when (c) {
        '"' -> append("\\\""); '\\' -> append("\\\\"); '\n' -> append("\\n"); '\r' -> append("\\r"); '\t' -> append("\\t")
        else -> if (c < ' ') append(String.format("\\u%04x", c.code)) else append(c)
    }
    append('"')
}

private fun write(v: Any?, indent: Int, level: Int, sb: StringBuilder) {
    when (v) {
        null, NullValue -> sb.append("null")
        is JSONObject -> v.write(indent, level, sb)
        is JSONArray -> v.write(indent, level, sb)
        is String -> sb.append(quote(v))
        else -> sb.append(v.toString())
    }
}

class JSONObject() {
    private val map = LinkedHashMap<String, Any?>()

    constructor(src: String) : this() {
        val p = Parser(src)
        val v = p.value()
        p.end()
        if (v !is JSONObject) throw JSONException("Value is not a JSONObject")
        map.putAll(v.map)
    }

    fun put(k: String, v: Any?): JSONObject { if (v == null) map.remove(k) else map[k] = v; return this }
    fun has(k: String) = map.containsKey(k)
    fun length() = map.size
    fun keys(): Iterator<String> = map.keys.toList().iterator()
    fun opt(k: String): Any? = map[k]

    fun optString(k: String): String = optString(k, "")
    fun optString(k: String, d: String): String {
        val v = map[k] ?: return d
        return v.toString()
    }
    fun optInt(k: String, d: Int = 0): Int = when (val v = map[k]) { is Number -> v.toInt(); is String -> v.toIntOrNull() ?: d; else -> d }
    fun optLong(k: String, d: Long = 0): Long = when (val v = map[k]) { is Number -> v.toLong(); is String -> v.toLongOrNull() ?: d; else -> d }
    fun optBoolean(k: String, d: Boolean = false): Boolean = when (val v = map[k]) { is Boolean -> v; is String -> v.toBooleanStrictOrNull() ?: d; else -> d }
    fun optJSONObject(k: String): JSONObject? = map[k] as? JSONObject
    fun optJSONArray(k: String): JSONArray? = map[k] as? JSONArray

    fun getString(k: String): String = (map[k] ?: throw JSONException("No value for $k")).toString()
    fun getInt(k: String): Int = optInt(k, Int.MIN_VALUE).also { if (!map.containsKey(k)) throw JSONException("No value for $k") }
    fun getJSONObject(k: String): JSONObject = map[k] as? JSONObject ?: throw JSONException("No JSONObject for $k")
    fun getJSONArray(k: String): JSONArray = map[k] as? JSONArray ?: throw JSONException("No JSONArray for $k")

    internal fun write(indent: Int, level: Int, sb: StringBuilder) {
        if (map.isEmpty()) { sb.append("{}"); return }
        sb.append('{')
        var first = true
        for ((k, v) in map) {
            if (!first) sb.append(',')
            first = false
            if (indent > 0) sb.append('\n').append(" ".repeat(indent * (level + 1)))
            sb.append(quote(k)).append(if (indent > 0) ": " else ":")
            write(v, indent, level + 1, sb)
        }
        if (indent > 0) sb.append('\n').append(" ".repeat(indent * level))
        sb.append('}')
    }

    override fun toString(): String = StringBuilder().also { write(0, 0, it) }.toString()
    fun toString(indent: Int): String = StringBuilder().also { write(indent, 0, it) }.toString()

    companion object {
        @JvmField val NULL: Any = NullValue
    }
}

class JSONArray() {
    private val list = ArrayList<Any?>()

    constructor(src: String) : this() {
        val p = Parser(src)
        val v = p.value()
        p.end()
        if (v !is JSONArray) throw JSONException("Value is not a JSONArray")
        list.addAll(v.list)
    }

    fun put(v: Any?): JSONArray { list.add(v ?: NullValue); return this }
    fun length() = list.size
    fun opt(i: Int): Any? = list.getOrNull(i)
    fun optString(i: Int): String = list.getOrNull(i)?.toString() ?: ""
    fun optInt(i: Int): Int = (list.getOrNull(i) as? Number)?.toInt() ?: 0
    fun optJSONObject(i: Int): JSONObject? = list.getOrNull(i) as? JSONObject
    fun optJSONArray(i: Int): JSONArray? = list.getOrNull(i) as? JSONArray
    fun getString(i: Int): String = (list.getOrNull(i) ?: throw JSONException("No value at $i")).toString()
    fun getJSONObject(i: Int): JSONObject = list.getOrNull(i) as? JSONObject ?: throw JSONException("No JSONObject at $i")

    internal fun write(indent: Int, level: Int, sb: StringBuilder) {
        if (list.isEmpty()) { sb.append("[]"); return }
        sb.append('[')
        list.forEachIndexed { i, v ->
            if (i > 0) sb.append(',')
            if (indent > 0) sb.append('\n').append(" ".repeat(indent * (level + 1)))
            write(v, indent, level + 1, sb)
        }
        if (indent > 0) sb.append('\n').append(" ".repeat(indent * level))
        sb.append(']')
    }

    override fun toString(): String = StringBuilder().also { write(0, 0, it) }.toString()
}

internal class Parser(private val s: String) {
    private var i = 0

    private fun ws() { while (i < s.length && s[i].isWhitespace()) i++ }

    fun end() { ws(); if (i != s.length) throw JSONException("Unexpected trailing data at $i") }

    fun value(): Any? {
        ws()
        if (i >= s.length) throw JSONException("Unexpected end")
        return when (val c = s[i]) {
            '{' -> obj()
            '[' -> arr()
            '"' -> str()
            else -> {
                if (s.startsWith("true", i)) { i += 4; true }
                else if (s.startsWith("false", i)) { i += 5; false }
                else if (s.startsWith("null", i)) { i += 4; NullValue }
                else if (c == '-' || c.isDigit()) num()
                else throw JSONException("Unexpected '$c' at $i")
            }
        }
    }

    private fun obj(): JSONObject {
        val o = JSONObject()
        i++
        ws()
        if (s.getOrNull(i) == '}') { i++; return o }
        while (true) {
            ws()
            if (s.getOrNull(i) != '"') throw JSONException("Expected key at $i")
            val k = str()
            ws()
            if (s.getOrNull(i) != ':') throw JSONException("Expected ':' at $i")
            i++
            o.put(k, value())
            ws()
            when (s.getOrNull(i)) {
                ',' -> i++
                '}' -> { i++; return o }
                else -> throw JSONException("Expected ',' or '}' at $i")
            }
        }
    }

    private fun arr(): JSONArray {
        val a = JSONArray()
        i++
        ws()
        if (s.getOrNull(i) == ']') { i++; return a }
        while (true) {
            a.put(value())
            ws()
            when (s.getOrNull(i)) {
                ',' -> i++
                ']' -> { i++; return a }
                else -> throw JSONException("Expected ',' or ']' at $i")
            }
        }
    }

    private fun str(): String {
        val sb = StringBuilder()
        i++
        while (true) {
            if (i >= s.length) throw JSONException("Unterminated string")
            val c = s[i++]
            when (c) {
                '"' -> return sb.toString()
                '\\' -> {
                    when (val e = s[i++]) {
                        'n' -> sb.append('\n'); 't' -> sb.append('\t'); 'r' -> sb.append('\r'); 'b' -> sb.append('\b'); 'f' -> sb.append('\u000c')
                        'u' -> { sb.append(s.substring(i, i + 4).toInt(16).toChar()); i += 4 }
                        else -> sb.append(e)
                    }
                }
                else -> sb.append(c)
            }
        }
    }

    private fun num(): Any {
        val st = i
        if (s[i] == '-') i++
        while (i < s.length && (s[i].isDigit() || s[i] in ".eE+-")) i++
        val t = s.substring(st, i)
        return t.toIntOrNull() ?: t.toLongOrNull() ?: t.toDouble()
    }
}
