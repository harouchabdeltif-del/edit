#!/usr/bin/env bash
# Type-check all Kotlin sources against a real android.jar (the app uses framework classes only, no AndroidX).
# R is generated from res/drawable + res/values by a tiny script (aapt2 is not needed for the check).
#   ANDROID_JAR=/path/android-34/android.jar KOTLINC=/path/kotlinc bash tests/typecheck.sh
set -euo pipefail
APP="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
AJ="${ANDROID_JAR:?set ANDROID_JAR to an android-XX/android.jar}"
KC="${KOTLINC:-kotlinc}"
T="$(mktemp -d)"; trap 'rm -rf "$T"' EXIT
mkdir -p "$T/gen/com/zellige/app"
python3 - "$APP/app/src/main/res" "$T/gen/com/zellige/app/R.java" <<'PY'
import os, re, sys
res, out = sys.argv[1], sys.argv[2]
groups = {}
for d in sorted(os.listdir(res)):
    kind = d.split('-')[0]
    full = os.path.join(res, d)
    if not os.path.isdir(full): continue
    for f in sorted(os.listdir(full)):
        name = os.path.splitext(f)[0]
        if kind == 'values':
            txt = open(os.path.join(full, f), encoding='utf-8').read()
            for t, n in re.findall(r'<(string|color|style|dimen)\s+name="([^"]+)"', txt):
                groups.setdefault(t, set()).add(n.replace('.', '_'))
        else:
            groups.setdefault(kind, set()).add(name)
lines = ['package com.zellige.app;', 'public final class R {']
i = 0x7f010000
for g, names in sorted(groups.items()):
    lines.append('  public static final class %s {' % g)
    for n in sorted(names):
        i += 1
        lines.append('    public static final int %s = 0x%08x;' % (n, i))
    lines.append('  }')
lines.append('}')
open(out, 'w').write('\n'.join(lines))
PY
find "$APP/app/src/main/java" -name '*.kt' > "$T/files.txt"
echo "$T/gen/com/zellige/app/R.java" >> "$T/files.txt"
"$KC" -jvm-target 17 -Xjsr305=ignore -cp "$AJ" -d "$T/out" @"$T/files.txt" 2>&1 | grep -v '^Picked up' | tee "$T/log.txt" || true
if grep -q 'error:' "$T/log.txt"; then echo "❌ type errors"; exit 1; fi
echo "✔ Kotlin sources type-check against android.jar"
