plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.zellige.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.zellige.app"      // بدّلو لمعرّف ديالك قبل Google Play (انظر tools/rename-package.sh)
        minSdk = 29
        targetSdk = 34
        versionCode = 1
        versionName = "0.1.0"
    }

    // توقيع ثابت: إلا كان keystore فجذر المشروع (zellige.keystore) كنستعملوه للـ debug والـ release
    // باش التحديثات تتثبّت فوق بعضها. لرفع Google Play استعمل upload key ديالك (انظر README).
    val ks = rootProject.file("zellige.keystore")
    signingConfigs {
        if (ks.exists()) {
            create("zellige") {
                storeFile = ks
                storePassword = System.getenv("ZELLIGE_KS_PASS") ?: "android"
                keyAlias = System.getenv("ZELLIGE_KS_ALIAS") ?: "zellige"
                keyPassword = System.getenv("ZELLIGE_KS_PASS") ?: "android"
            }
        }
    }

    buildTypes {
        debug {
            if (ks.exists()) signingConfig = signingConfigs.getByName("zellige")
        }
        release {
            isMinifyEnabled = false
            if (ks.exists()) signingConfig = signingConfigs.getByName("zellige")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
