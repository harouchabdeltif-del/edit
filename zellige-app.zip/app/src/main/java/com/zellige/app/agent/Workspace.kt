package com.zellige.app.agent

import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** مجلد المشاريع: كل مشروع هو مجلد داخله. */
class Workspace(val dir: File) {

    init { dir.mkdirs() }

    fun projects(): List<File> =
        (dir.listFiles { f -> f.isDirectory && !f.name.startsWith(".") } ?: emptyArray())
            .sortedByDescending { lastActivity(it) }

    fun lastActivity(p: File): Long =
        ProjectInfo.chatFile(p).takeIf { it.exists() }?.lastModified() ?: p.lastModified()

    fun sanitize(name: String): String =
        name.trim()
            .replace(Regex("[\\\\/:*?\"<>|\\u0000-\\u001f]"), "-")
            .replace(Regex("\\s+"), " ")
            .trim('.', ' ', '-')
            .take(60)

    fun uniqueName(base: String): String {
        val b = sanitize(base).ifEmpty { "project" }
        if (!File(dir, b).exists()) return b
        var i = 2
        while (File(dir, "$b-$i").exists()) i++
        return "$b-$i"
    }

    fun create(name: String): File = File(dir, uniqueName(name)).also { it.mkdirs() }

    fun find(name: String): File? {
        if (name.isBlank()) return null
        val f = File(dir, name)
        return if (f.isDirectory && f.canonicalFile.parentFile == dir.canonicalFile) f else null
    }

    /** مشروع محلي سبق وتحمّل من نفس مستودع GitHub (إن وُجد). */
    fun findByRepo(full: String): File? = projects().firstOrNull { ProjectInfo.repo(it).equals(full, ignoreCase = true) }

    fun delete(p: File): Boolean = p.canonicalFile.parentFile == dir.canonicalFile && p.deleteRecursively()
}

/** مسار مقيّد داخل مجلد مشروع واحد: أي محاولة للخروج منه (.. أو symlink) كترفض. */
class Sandbox(root: File) {
    val root: File = root.canonicalFile
    private val data: File = File(this.root, ProjectInfo.DATA_DIR)

    fun resolve(p: String): File {
        val t = p.trim().replace('\\', '/').removePrefix("./").trimStart('/').ifEmpty { "." }
        val f = File(root, t).canonicalFile
        val inside = f == root || f.path.startsWith(root.path + File.separator)
        if (!inside) throw SecurityException("المسار خارج المشروع: $p")
        if (f == data || f.path.startsWith(data.path + File.separator)) throw SecurityException("المجلد ${ProjectInfo.DATA_DIR} محجوز للتطبيق")
        return f
    }

    fun rel(f: File): String = if (f == root) "." else f.path.removePrefix(root.path + File.separator)
}

/** بيانات المشروع الخاصة بالتطبيق (.zellige): المصدر، ملاحظات الوكيل، سجل المحادثة. */
object ProjectInfo {
    const val DATA_DIR = ".zellige"

    fun dataDir(root: File) = File(root, DATA_DIR)
    fun metaFile(root: File) = File(dataDir(root), "project.json")
    fun notesFile(root: File) = File(dataDir(root), "notes.md")
    fun chatFile(root: File) = File(dataDir(root), "chat.json")

    fun meta(root: File): JSONObject? = try { JSONObject(metaFile(root).readText()) } catch (t: Throwable) { null }

    fun writeMeta(root: File, o: JSONObject) {
        dataDir(root).mkdirs()
        metaFile(root).writeText(o.toString(2))
    }

    /** owner/repo إلا كان المشروع جاي من GitHub. */
    fun repo(root: File): String? = meta(root)?.optString("repo")?.takeIf { it.isNotBlank() }

    fun notes(root: File): String = try { notesFile(root).readText() } catch (t: Throwable) { "" }

    /** كنزيدو سطرا لذاكرة المشروع وكنحافظو على آخر ~6000 حرف. */
    fun appendNote(root: File, line: String) {
        dataDir(root).mkdirs()
        val clean = line.trim().lineSequence().joinToString(" ").take(600)
        if (clean.isEmpty()) return
        var all = notes(root).trimEnd() + (if (notes(root).isBlank()) "" else "\n") + "- " + clean
        if (all.length > 6000) all = all.takeLast(6000).substringAfter('\n', all.takeLast(6000))
        notesFile(root).writeText(all + "\n")
    }

    fun saveChat(root: File, msgs: List<com.zellige.app.ai.AiClient.Msg>) {
        try {
            dataDir(root).mkdirs()
            val arr = JSONArray()
            msgs.forEach { arr.put(JSONObject().put("role", it.role).put("content", it.content)) }
            chatFile(root).writeText(arr.toString())
        } catch (t: Throwable) { /* الحفظ اختياري */ }
    }

    fun loadChat(root: File): List<com.zellige.app.ai.AiClient.Msg> = try {
        val arr = JSONArray(chatFile(root).readText())
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            com.zellige.app.ai.AiClient.Msg(o.getString("role"), o.getString("content"))
        }
    } catch (t: Throwable) { emptyList() }
}
