package com.zellige.app

import android.app.Application
import com.zellige.app.agent.Agent
import com.zellige.app.agent.AppPrefs
import com.zellige.app.agent.Workspace
import com.zellige.app.ai.AiClient
import com.zellige.app.ai.AiPrefs
import com.zellige.app.github.GitHubApi
import java.io.File

/** كيجمع الخدمات المشتركة. الوكيل كيعيش هنا باش يكمل خدمتو حتى إلا تبدلات الشاشة. */
class ZelligeApp : Application() {

    lateinit var workspace: Workspace
        private set
    lateinit var appPrefs: AppPrefs
        private set
    lateinit var aiPrefs: AiPrefs
        private set
    lateinit var gh: GitHubApi
        private set
    lateinit var agent: Agent
        private set

    override fun onCreate() {
        super.onCreate()
        workspace = Workspace(File(filesDir, "projects"))
        appPrefs = AppPrefs(this)
        aiPrefs = AiPrefs(this)
        gh = GitHubApi(token = { appPrefs.githubToken })
        agent = Agent({ system, msgs -> AiClient.complete(aiPrefs, system, msgs) }, gh)
        workspace.find(appPrefs.activeProject)?.let { agent.open(it) }
    }
}
