package com.zellige.app.ai

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * عميل HTTP بسيط بلا أي مكتبة خارجية.
 * 3 صيغ: openai (يغطي OpenRouter/OpenAI/Groq/DeepSeek/... وأي خدمة متوافقة) + anthropic + gemini.
 * كذلك كيجلب لائحة الموديلات ديال أي مزوّد بالمفتاح فقط.
 */
object AiClient {

    data class Msg(val role: String, val content: String) // role = "user" | "assistant"

    class ApiException(val code: Int, message: String) : RuntimeException(message)

    private const val NO_NATIVE =
        "\n\nIMPORTANT: Do NOT use native function/tool calling of the API (no browser, no functions, no python). " +
        "Tools exist ONLY as plain-text <tool .../> tags written inside your normal reply."

    /** وجهة الطلب بعد حلّ المزوّد والإعدادات. */
    private class Endpoint(val format: String, val base: String, val chatPath: String, val headers: Map<String, String>)

    private fun endpoint(p: AiPrefs): Endpoint {
        val prov = AiProviders.get(p.provider)
        val custom = p.provider == "custom"
        val format = if (custom) p.customFormat else (prov?.format ?: "openai")
        val base = p.baseUrl.ifBlank { prov?.base.orEmpty() }.trim().trimEnd('/')
        if (base.isBlank()) throw IllegalStateException("خاصك تدخل Base URL فالإعدادات")

        val h = LinkedHashMap<String, String>()
        val key = p.apiKey
        val defHeader = when (format) {
            "anthropic" -> "x-api-key"
            "gemini" -> "x-goog-api-key"
            else -> "Authorization"
        }
        val defPrefix = if (format == "openai") "Bearer " else ""
        val own = custom && p.customAuthHeader.isNotBlank()
        val header = if (own) p.customAuthHeader.trim() else defHeader
        var prefix = if (own) p.customAuthPrefix else defPrefix
        if (prefix.isNotEmpty() && prefix.last().isLetterOrDigit()) prefix += " "
        if (key.isNotBlank()) h[header] = prefix + key
        if (format == "anthropic" && !h.containsKey("anthropic-version")) h["anthropic-version"] = "2023-06-01"
        if (custom) {
            p.customHeaders.lines().forEach { l ->
                val i = l.indexOf(':')
                if (i > 0) {
                    val k = l.substring(0, i).trim()
                    val v = l.substring(i + 1).trim()
                    if (k.isNotEmpty()) h[k] = v
                }
            }
        }
        val path = if (custom && p.customChatPath.isNotBlank()) "/" + p.customChatPath.trim().trimStart('/') else ""
        return Endpoint(format, base, path, h)
    }

    private fun geminiRoot(e: Endpoint): String =
        if (e.base.endsWith("/v1beta") || e.base.endsWith("/v1")) e.base else e.base + "/v1beta"

    private fun chatUrl(e: Endpoint, model: String): String {
        if (e.chatPath.isNotEmpty()) return e.base + e.chatPath.replace("{model}", model.removePrefix("models/"))
        return when (e.format) {
            "anthropic" -> if (e.base.endsWith("/v1")) e.base + "/messages" else e.base + "/v1/messages"
            "gemini" -> geminiRoot(e) + "/models/" + model.removePrefix("models/") + ":generateContent"
            else -> e.base + "/chat/completions"
        }
    }

    /** كيعاود الطلب حتى 3 مرات فحالة 429 أو أخطاء السيرفر (5xx). */
    fun complete(p: AiPrefs, system: String, msgs: List<Msg>): String {
        require(p.ready()) { "ضع مفتاح API من الإعدادات" }
        val model = p.effectiveModel()
        require(model.isNotBlank()) { "اختر الموديل من الإعدادات (زر «اختيار»)" }
        val e = endpoint(p)
        var last: ApiException? = null
        var sys = system
        for (attempt in 0 until 3) {
            try {
                return when (e.format) {
                    "anthropic" -> claude(e, model, sys, msgs)
                    "gemini" -> gemini(e, model, sys, msgs)
                    else -> openAi(e, model, sys, msgs)
                }
            } catch (ex: ApiException) {
                // بعض النماذج (مثل gpt-oss) تحاول استدعاء أداة أصلية فيرفضها المزوّد: نعيد الطلب بتذكير صريح
                val nativeTool = ex.code == 400 && (ex.message ?: "").contains("tool", ignoreCase = true)
                if (!nativeTool && ex.code != 429 && ex.code < 500) throw ex
                if (nativeTool) sys = system + NO_NATIVE
                last = ex
                if (attempt < 2) Thread.sleep(if (nativeTool) 400L else 1500L * (attempt + 1))
            }
        }
        throw last ?: IllegalStateException("فشل الطلب")
    }

    /** اختبار سريع للاتصال والمفتاح. */
    fun ping(p: AiPrefs): String =
        complete(p, "Reply with the single word OK.", listOf(Msg("user", "ping"))).trim().take(40)

    // ------------------------------------------------------------------ chat formats
    private fun textOf(v: Any?): String = when (v) {
        is String -> v
        is JSONArray -> buildString {
            for (i in 0 until v.length()) {
                val o = v.optJSONObject(i)
                if (o != null) append(o.optString("text")) else append(v.optString(i))
            }
        }
        else -> ""
    }

    private fun failIfError(res: JSONObject) {
        when (val err = res.opt("error")) {
            is JSONObject -> throw RuntimeException(err.optString("message", "API error"))
            is String -> if (err.isNotBlank()) throw RuntimeException(err)
            else -> {}
        }
    }

    private fun openAi(e: Endpoint, model: String, system: String, msgs: List<Msg>): String {
        val arr = JSONArray()
        arr.put(JSONObject().put("role", "system").put("content", system))
        msgs.forEach { arr.put(JSONObject().put("role", it.role).put("content", it.content)) }
        val body = JSONObject().put("model", model).put("messages", arr)
        val res = JSONObject(http("POST", chatUrl(e, model), e.headers, body))
        failIfError(res)
        val choices = res.optJSONArray("choices")
            ?: throw RuntimeException("رد غير متوقع من المزوّد: " + res.toString().take(200))
        val msg = choices.optJSONObject(0)?.optJSONObject("message")
            ?: throw RuntimeException("رد فارغ من المزوّد: " + res.toString().take(200))
        return textOf(msg.opt("content"))
    }

    private fun claude(e: Endpoint, model: String, system: String, msgs: List<Msg>): String {
        val arr = JSONArray()
        msgs.forEach { arr.put(JSONObject().put("role", it.role).put("content", it.content)) }
        val body = JSONObject()
            .put("model", model)
            .put("max_tokens", 16000)
            .put("system", system)
            .put("messages", arr)
        val res = JSONObject(http("POST", chatUrl(e, model), e.headers, body))
        failIfError(res)
        val blocks = res.optJSONArray("content") ?: throw RuntimeException("رد غير متوقع: " + res.toString().take(200))
        return buildString {
            for (i in 0 until blocks.length()) {
                val b = blocks.getJSONObject(i)
                if (b.optString("type") == "text") append(b.optString("text"))
            }
        }
    }

    private fun gemini(e: Endpoint, model: String, system: String, msgs: List<Msg>): String {
        val contents = JSONArray()
        msgs.forEach {
            contents.put(
                JSONObject()
                    .put("role", if (it.role == "assistant") "model" else "user")
                    .put("parts", JSONArray().put(JSONObject().put("text", it.content)))
            )
        }
        val body = JSONObject()
            .put("contents", contents)
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
        val res = JSONObject(http("POST", chatUrl(e, model), e.headers, body))
        failIfError(res)
        val parts = res.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
            ?: throw RuntimeException("رد فارغ (ربما حجبه فلتر الأمان): " + res.toString().take(200))
        return buildString { for (i in 0 until parts.length()) append(parts.getJSONObject(i).optString("text")) }
    }

    // ------------------------------------------------------------------ models list
    private fun collectIds(arr: JSONArray?, out: MutableCollection<String>) {
        if (arr == null) return
        for (i in 0 until arr.length()) {
            val o = arr.opt(i)
            when (o) {
                is JSONObject -> out.add(o.optString("id").ifBlank { o.optString("name") })
                is String -> out.add(o)
            }
        }
    }

    /** يجلب كل موديلات المزوّد الحالي بالمفتاح المدخل (OpenAI-compatible / Anthropic / Gemini). */
    fun listModels(p: AiPrefs): List<String> {
        require(p.ready()) { "أدخل مفتاح API أولا" }
        val e = endpoint(p)
        val out = LinkedHashSet<String>()
        when (e.format) {
            "anthropic" -> {
                val root = if (e.base.endsWith("/v1")) e.base else e.base + "/v1"
                val res = JSONObject(http("GET", "$root/models?limit=1000", e.headers, null))
                collectIds(res.optJSONArray("data"), out)
            }
            "gemini" -> {
                var token: String? = null
                var pages = 0
                do {
                    val url = geminiRoot(e) + "/models?pageSize=1000" +
                        (token?.let { "&pageToken=" + URLEncoder.encode(it, "UTF-8") } ?: "")
                    val res = JSONObject(http("GET", url, e.headers, null))
                    val arr = res.optJSONArray("models")
                    if (arr != null) {
                        for (i in 0 until arr.length()) {
                            val o = arr.getJSONObject(i)
                            val methods = o.optJSONArray("supportedGenerationMethods")
                            var ok = methods == null
                            if (methods != null) {
                                for (j in 0 until methods.length()) if (methods.optString(j) == "generateContent") ok = true
                            }
                            if (ok) out.add(o.optString("name").removePrefix("models/"))
                        }
                    }
                    token = res.optString("nextPageToken").ifBlank { null }
                    pages++
                } while (token != null && pages < 5)
            }
            else -> {
                val raw = http("GET", e.base + "/models", e.headers, null).trim()
                if (raw.startsWith("[")) {
                    collectIds(JSONArray(raw), out)
                } else {
                    val o = JSONObject(raw)
                    collectIds(o.optJSONArray("data") ?: o.optJSONArray("models"), out)
                }
            }
        }
        return out.filter { it.isNotBlank() }.sortedBy { it.lowercase() }
    }

    // ------------------------------------------------------------------ http
    /** يستخرج رسالة الخطأ الحقيقية من رد الـ API بدل ما نعرض JSON خام. */
    private fun errorMessage(raw: String): String {
        val parsed = try {
            val e = JSONObject(raw).opt("error")
            when (e) {
                is JSONObject -> e.optString("message")
                is String -> e
                else -> ""
            }
        } catch (t: Throwable) { "" }
        return parsed.ifBlank { raw.take(300) }
    }

    private fun http(method: String, url: String, headers: Map<String, String>, body: JSONObject?): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = method
            c.connectTimeout = 20_000
            c.readTimeout = if (body != null) 300_000 else 30_000
            c.setRequestProperty("Accept", "application/json")
            headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
            if (body != null) {
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (code !in 200..299) throw ApiException(code, "HTTP $code: ${errorMessage(text)}")
            return text
        } finally {
            c.disconnect()
        }
    }
}
