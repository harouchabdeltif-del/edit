package com.zellige.app.github

import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * GitHub REST بلا أي مكتبة: بحث فالمستودعات العامة، قراءة issues، وتحميل المشروع كـ zip.
 * التوكن اختياري (للقراءة فقط يكفي توكن بلا صلاحيات): كيرفع الحدود من 60 لـ 5000 طلب فالساعة.
 */
class GitHubApi(private val token: () -> String, private val api: String = API) {

    class GhException(message: String) : RuntimeException(message)

    data class Repo(
        val full: String,
        val description: String,
        val stars: Int,
        val language: String,
        val license: String,
        val sizeKb: Int,
        val url: String,
        val branch: String,
        val openIssues: Int,
        val topics: List<String>
    ) {
        val owner: String get() = full.substringBefore('/')
        val name: String get() = full.substringAfter('/')
    }

    data class Issue(
        val number: Int,
        val title: String,
        val body: String,
        val author: String,
        val labels: List<String>,
        val comments: Int,
        val url: String
    )

    // ------------------------------------------------------------------ queries
    fun search(query: String, page: Int = 1, perPage: Int = 20): List<Repo> {
        val url = "$api/search/repositories?q=" + enc(query) + "&sort=stars&order=desc&per_page=$perPage&page=$page"
        return repos(JSONObject(get(url)).optJSONArray("items"))
    }

    fun repo(full: String): Repo = parseRepo(JSONObject(get("$api/repos/$full")))

    fun issues(full: String, limit: Int = 15): List<Issue> {
        val arr = JSONArray(get("$api/repos/$full/issues?state=open&per_page=${limit.coerceIn(1, 50)}"))
        val out = ArrayList<Issue>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (o.has("pull_request")) continue            // الـ PR كتجي مع issues فـ API
            out.add(parseIssue(o))
        }
        return out
    }

    /** issue واحد مع أول تعليقات (باش الوكيل يفهم السياق). */
    fun issueWithComments(full: String, number: Int, maxComments: Int = 6): Pair<Issue, List<String>> {
        val issue = parseIssue(JSONObject(get("$api/repos/$full/issues/$number")))
        val comments = ArrayList<String>()
        if (issue.comments > 0) {
            val arr = JSONArray(get("$api/repos/$full/issues/$number/comments?per_page=$maxComments"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                comments.add(str(o.optJSONObject("user"), "login") + ": " + str(o, "body").take(1500))
            }
        }
        return issue to comments
    }

    // ------------------------------------------------------------------ download
    /**
     * يحمّل آخر نسخة من الفرع الافتراضي كـ zip ويفكّها فـ dest (بلا المجلد الأول داخل الـ zip).
     * يرجع عدد الملفات. كيرمي GhException إلا كان المشروع كبير بزاف أو فيه ملفات مشبوهة.
     */
    fun download(full: String, dest: File, maxBytes: Long = ZipUtil.DEFAULT_MAX_BYTES, onProgress: (Int, Long) -> Unit): Int {
        val c = open("$api/repos/$full/zipball")
        try {
            val code = c.responseCode
            if (code !in 200..299) throw GhException(errorFor(c, code))
            return c.inputStream.use { ZipUtil.extract(it, dest, true, maxBytes, ZipUtil.DEFAULT_MAX_FILES, onProgress) }
        } finally {
            c.disconnect()
        }
    }

    // ------------------------------------------------------------------ http
    private fun open(url: String): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "GET"
        c.connectTimeout = 20_000
        c.readTimeout = 60_000
        c.setRequestProperty("Accept", "application/vnd.github+json")
        c.setRequestProperty("User-Agent", "Zellige-App")
        c.setRequestProperty("X-GitHub-Api-Version", "2022-11-28")
        val t = token().trim()
        if (t.isNotEmpty()) c.setRequestProperty("Authorization", "Bearer $t")
        return c
    }

    private fun get(url: String): String {
        val c = open(url)
        try {
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (code !in 200..299) throw GhException(errorFor(c, code, text))
            return text
        } finally {
            c.disconnect()
        }
    }

    private fun errorFor(c: HttpURLConnection, code: Int, body: String = ""): String {
        val remaining = c.getHeaderField("X-RateLimit-Remaining")
        if ((code == 403 || code == 429) && remaining == "0") {
            val reset = c.getHeaderField("X-RateLimit-Reset")?.toLongOrNull()
            val mins = reset?.let { ((it * 1000 - System.currentTimeMillis()) / 60000).coerceAtLeast(1) }
            return "وصلت حدّ طلبات GitHub" + (mins?.let { " (يتجدّد بعد ~$it دقيقة)" } ?: "") +
                ". أضف توكن GitHub فالإعدادات باش يرتفع الحدّ."
        }
        if (code == 404) return "غير موجود على GitHub (أو خاص)"
        val msg = try { JSONObject(body).optString("message") } catch (t: Throwable) { "" }
        return "GitHub HTTP $code" + (if (msg.isNotBlank()) ": $msg" else "")
    }

    // ------------------------------------------------------------------ parsing
    private fun str(o: JSONObject?, k: String): String {
        val v = o?.opt(k)
        return if (v == null || v == JSONObject.NULL) "" else v.toString()
    }

    private fun repos(arr: JSONArray?): List<Repo> {
        if (arr == null) return emptyList()
        return (0 until arr.length()).map { parseRepo(arr.getJSONObject(it)) }
    }

    private fun parseRepo(o: JSONObject): Repo {
        val lic = o.optJSONObject("license")
        val topics = o.optJSONArray("topics")
        return Repo(
            full = str(o, "full_name"),
            description = str(o, "description"),
            stars = o.optInt("stargazers_count"),
            language = str(o, "language"),
            license = str(lic, "spdx_id").ifBlank { str(lic, "name") },
            sizeKb = o.optInt("size"),
            url = str(o, "html_url"),
            branch = str(o, "default_branch"),
            openIssues = o.optInt("open_issues_count"),
            topics = if (topics == null) emptyList() else (0 until topics.length()).map { topics.optString(it) }
        )
    }

    private fun parseIssue(o: JSONObject): Issue {
        val labels = o.optJSONArray("labels")
        return Issue(
            number = o.optInt("number"),
            title = str(o, "title"),
            body = str(o, "body"),
            author = str(o.optJSONObject("user"), "login"),
            labels = if (labels == null) emptyList() else (0 until labels.length()).map { str(labels.optJSONObject(it), "name") },
            comments = o.optInt("comments"),
            url = str(o, "html_url")
        )
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    companion object {
        const val API = "https://api.github.com"
    }
}
