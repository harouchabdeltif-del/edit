package com.zellige.app.agent

import com.zellige.app.ai.AiClient
import com.zellige.app.github.GitHubApi
import java.io.File

/**
 * لغة الأدوات: النموذج كيكتب وسوم <tool .../> فـ ردّو والتطبيق كينفّذها داخل مجلد المشروع فقط.
 * (ماشي function calling ديال الـ API: كيخدم مع أي نموذج ومع أي مزوّد.)
 */
object Tools {

    data class Call(val name: String, val attrs: Map<String, String>, val body: String) {
        val path: String get() = attrs["path"].orEmpty()
    }

    data class StepResult(val call: Call, val ok: Boolean, val text: String)

    private val toolRe = Regex("<tool\\s+([^>]*?)\\s*(?:/>|>([\\s\\S]*?)</tool>)")
    private val attrRe = Regex("(\\w+)\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)')")
    private val editRe = Regex("<find>([\\s\\S]*?)</find>\\s*<replace>([\\s\\S]*?)</replace>")
    private val fencedRe = Regex("```[A-Za-z0-9_+#.-]*[ \\t]*\\r?\\n([\\s\\S]*?)```")
    private val anyFenceRe = Regex("```[\\s\\S]*?(?:```|$)")
    private val resultRe = Regex("<result ok=\"(true|false)\" label=\"([^\"]*)\">")

    val MUTATING = setOf("write_file", "edit_file", "create_dir", "delete", "move")

    fun trimNl(s: String) =
        s.removePrefix("\r\n").removePrefix("\n").removeSuffix("\r\n").removeSuffix("\n")

    fun parse(reply: String): List<Call> = toolRe.findAll(reply).map { m ->
        val attrs = attrRe.findAll(m.groupValues[1]).associate {
            it.groupValues[1] to (it.groups[2]?.value ?: it.groups[3]?.value ?: "")
        }
        Call(attrs["name"].orEmpty(), attrs, trimNl(m.groupValues[2]))
    }.toList()

    /** عدد بدايات وسوم الأدوات فالرد (كيفضح الوسم المقطوع إلا كان أكبر من عدد اللي تحلّلو). */
    fun countTags(reply: String): Int = Regex("<tool\\s").findAll(reply).count()

    /** نص الرد بلا وسوم الأدوات. */
    fun strip(reply: String): String = toolRe.replace(reply, "").trim()

    /** النص اللي كيبان للمستعمل: بلا وسوم أدوات وبلا أي كود (حتى إلا النموذج كتبو غلطة). */
    fun clean(reply: String): String =
        anyFenceRe.replace(strip(reply), "").replace(Regex("\\n{3,}"), "\n\n").trim()

    /** كود طويل (4 أسطر فأكثر) كتبو النموذج فـ الشات بدل ما يطبّقو بالأدوات. */
    fun hasCodeDump(reply: String): Boolean =
        fencedRe.findAll(strip(reply)).any { it.groupValues[1].trim().lines().size >= 4 }

    fun isResults(m: AiClient.Msg) = m.role == "user" && m.content.startsWith("<tool_results>")

    /** يقصّ محتوى الملفات الكبيرة فالرسائل القديمة باش السياق ما يتضخمش. */
    fun compact(m: AiClient.Msg): AiClient.Msg {
        if (m.role == "assistant" && m.content.contains("<tool")) {
            val c = toolRe.replace(m.content) { r ->
                val body = r.groupValues[2]
                if (body.length > 300) "<tool " + r.groupValues[1] + ">\n[content omitted]\n</tool>" else r.value
            }
            return AiClient.Msg(m.role, c)
        }
        if (isResults(m) && m.content.length > 3000) return AiClient.Msg(m.role, m.content.take(3000) + "\n[…]\n</tool_results>")
        return m
    }

    /** نوع الخطوة للواجهة: write | edit | delete | move | dir | read | search | memo | github */
    fun kindOf(name: String): String = when (name) {
        "write_file" -> "write"
        "edit_file" -> "edit"
        "delete" -> "delete"
        "move" -> "move"
        "create_dir" -> "dir"
        "read_file", "list_dir", "tree", "outline" -> "read"
        "search", "find_files" -> "search"
        "remember" -> "memo"
        "github_issues", "github_issue" -> "github"
        else -> "other"
    }

    fun describe(c: Call): String {
        val p = c.path.ifBlank { "." }
        return when (c.name) {
            "write_file" -> "كتابة $p"
            "edit_file" -> "تعديل $p"
            "read_file" -> "قراءة $p"
            "list_dir" -> "عرض $p"
            "tree" -> "شجرة $p"
            "outline" -> "فهرسة $p"
            "create_dir" -> "إنشاء مجلد $p"
            "delete" -> "حذف $p"
            "move" -> "نقل $p"
            "search" -> "بحث «${c.attrs["query"].orEmpty().take(30)}»"
            "find_files" -> "بحث عن ملفات «${c.attrs["pattern"].orEmpty().take(30)}»"
            "remember" -> "ملاحظة للمشروع"
            "github_issues" -> "قراءة issues"
            "github_issue" -> "قراءة issue #${c.attrs["number"].orEmpty()}"
            else -> c.name
        }
    }

    fun formatResults(rs: List<StepResult>): String = buildString {
        appendLine("<tool_results>")
        rs.forEach { r ->
            appendLine("<result ok=\"${r.ok}\" label=\"${describe(r.call).replace('"', '\'')}\">")
            appendLine(r.text)
            appendLine("</result>")
        }
        append("</tool_results>")
    }

    // ------------------------------------------------------------------ files helpers
    private val SKIP_DIRS = setOf("build", ".gradle", ".git", ".idea", ".cxx", ".kotlin", "node_modules", "__pycache__", ProjectInfo.DATA_DIR)
    private val BIN_EXT = setOf(
        "png", "jpg", "jpeg", "webp", "gif", "ico", "jar", "aar", "apk", "aab", "so", "zip", "gz", "7z", "rar",
        "ttf", "otf", "woff", "woff2", "mp3", "mp4", "ogg", "wav", "class", "dex", "keystore", "jks", "pdf"
    )

    /** نص الملف، أو null إلا كان ثنائي/كبير/غير موجود. */
    fun readText(f: File): String? {
        if (!f.isFile || f.length() > 2_000_000) return null
        if (f.extension.lowercase() in BIN_EXT) return null
        val bytes = f.readBytes()
        val head = minOf(bytes.size, 4096)
        for (i in 0 until head) if (bytes[i].toInt() == 0) return null
        return String(bytes, Charsets.UTF_8)
    }

    fun globToRegex(g: String): Regex {
        val b = StringBuilder()
        var i = 0
        while (i < g.length) {
            val ch = g[i]
            when {
                ch == '*' && i + 1 < g.length && g[i + 1] == '*' -> { b.append(".*"); i++ }
                ch == '*' -> b.append("[^/]*")
                ch == '?' -> b.append("[^/]")
                else -> b.append(Regex.escape(ch.toString()))
            }
            i++
        }
        return Regex(b.toString(), RegexOption.IGNORE_CASE)
    }

    /** شجرة نصية (مجلدات أولا). كتتوقف عند max سطر. */
    fun treeText(root: File, depth: Int, max: Int): String {
        val out = StringBuilder()
        var lines = 0
        var cut = false
        fun walk(d: File, level: Int) {
            if (cut) return
            val kids = d.listFiles()?.filter { !(it.isDirectory && it.name in SKIP_DIRS) }
                ?.sortedWith(compareBy({ !it.isDirectory }, { it.name.lowercase() })) ?: return
            for (k in kids) {
                if (lines >= max) { cut = true; return }
                out.append("  ".repeat(level)).append(k.name).append(if (k.isDirectory) "/" else "").append('\n')
                lines++
                if (k.isDirectory && level + 1 < depth) walk(k, level + 1)
            }
        }
        walk(root, 0)
        if (cut) out.append("… (فيه المزيد، استعمل list_dir على مجلد معيّن)\n")
        return out.toString().trimEnd()
    }

    fun walkFiles(root: File, visit: (File) -> Boolean) {
        fun go(d: File): Boolean {
            val kids = d.listFiles()?.sortedBy { it.name.lowercase() } ?: return true
            for (k in kids) {
                if (k.isDirectory) {
                    if (k.name in SKIP_DIRS) continue
                    if (!go(k)) return false
                } else if (!visit(k)) return false
            }
            return true
        }
        if (root.isFile) visit(root) else go(root)
    }

    private val CODE_EXT = setOf(
        "kt", "java", "kts", "py", "js", "ts", "tsx", "jsx", "dart", "go", "rs", "c", "h", "cpp", "hpp", "cs", "swift",
        "rb", "php", "gradle", "sh", "html", "css", "xml", "json", "yml", "yaml", "toml", "md"
    )
    private val DECL_RE = Regex(
        "^\\s*(?:(?:public|private|protected|internal|open|abstract|data|sealed|static|final|override|suspend|export|default|async|pub|const)\\s+)*" +
            "(?:class|interface|object|enum|fun|def|function|struct|trait|impl|type|func|fn|void|val|var)\\b"
    )

    private fun cap(s: String, n: Int = 14000) = if (s.length > n) s.take(n) + "\n…[تم الاقتطاع]" else s
    fun capText(s: String) = cap(s)

    // ------------------------------------------------------------------ undo
    class Undo {
        val files = LinkedHashMap<File, String?>()     // الحالة الأصلية: null = ما كانش موجود
        val dirs = LinkedHashSet<File>()               // مجلدات تخلقت
        /** مسار نسبي ← نوع التغيير: new | edit | delete | dir | move (للواجهة). */
        val changes = LinkedHashMap<String, String>()

        fun mark(path: String, kind: String) {
            val old = changes[path]
            when {
                old == "new" && kind == "edit" -> {}                 // جديد وبقى جديد
                old == "new" && kind == "delete" -> changes.remove(path)   // تخلق وتحذف فنفس الجولة
                else -> changes[path] = kind
            }
        }

        fun isEmpty() = files.isEmpty() && dirs.isEmpty() && changes.isEmpty()

        fun remember(f: File) { if (!files.containsKey(f)) files[f] = readText(f) }

        /** يرجّع الملفات للحالة الأصلية. يرجع عدد الملفات المعدّلة. */
        fun restore(): Int {
            var n = 0
            for ((f, old) in files.entries.reversed()) {
                try {
                    if (old == null) { if (f.delete()) n++ }
                    else { f.parentFile?.mkdirs(); f.writeText(old); n++ }
                } catch (t: Throwable) { /* نكمّل الباقي */ }
            }
            // الأعمق أولا: الأبناء قبل الآباء
            for (d in dirs.sortedByDescending { it.path.length }) {
                if (d.isDirectory && d.list()?.isEmpty() == true) d.delete()
            }
            return n
        }
    }

    // ------------------------------------------------------------------ executor
    class Box(
        private val sb: Sandbox,
        private val undo: Undo,
        private val gh: GitHubApi?,
        private val repo: String?
    ) {
        fun execute(c: Call): StepResult =
            try {
                StepResult(c, true, cap(dispatch(c)))
            } catch (t: Throwable) {
                StepResult(c, false, t.message ?: t.javaClass.simpleName)
            }

        private fun topMissing(f: File): File? {
            var cur: File? = f
            var top: File? = null
            while (cur != null && !cur.exists() && cur != sb.root) { top = cur; cur = cur.parentFile }
            return top
        }

        private fun mkdirsTracked(d: File) {
            val missing = ArrayList<File>()
            var cur: File? = d
            while (cur != null && !cur.exists() && cur != sb.root) { missing.add(cur); cur = cur.parentFile }
            d.mkdirs()
            undo.dirs.addAll(missing)
        }

        private fun unfence(s: String): String {
            val t = trimNl(s)
            val m = fencedRe.matchEntire(t.trim())
            return m?.groupValues?.get(1)?.let { trimNl(it) } ?: t
        }

        private fun dispatch(c: Call): String = when (c.name) {

            "tree" -> {
                val d = sb.resolve(c.path)
                require(d.isDirectory) { "ليس مجلدا: ${c.path}" }
                val depth = (c.attrs["depth"]?.toIntOrNull() ?: 3).coerceIn(1, 6)
                treeText(d, depth, 400).ifBlank { "(فارغ)" }
            }

            "list_dir" -> {
                val d = sb.resolve(c.path)
                require(d.isDirectory) { "ليس مجلدا: ${c.path}" }
                val items = d.listFiles()?.filter { it.name != ProjectInfo.DATA_DIR }
                    ?.sortedWith(compareBy({ !it.isDirectory }, { it.name.lowercase() })) ?: emptyList()
                if (items.isEmpty()) "(فارغ)"
                else items.take(400).joinToString("\n") { if (it.isDirectory) it.name + "/" else it.name + "  (" + it.length() + " B)" }
            }

            "read_file" -> {
                val f = sb.resolve(c.path)
                require(f.isFile) { "الملف غير موجود: ${c.path}" }
                val text = readText(f) ?: throw IllegalArgumentException("ملف ثنائي أو كبير: ${c.path}")
                val lines = text.replace("\r\n", "\n").split("\n")
                val start = (c.attrs["start"]?.toIntOrNull() ?: 1).coerceAtLeast(1)
                val end = (c.attrs["end"]?.toIntOrNull() ?: lines.size).coerceAtMost(lines.size)
                require(start <= lines.size) { "الملف فيه ${lines.size} سطر فقط" }
                val slice = lines.subList(start - 1, maxOf(start, end)).joinToString("\n")
                val numbered = c.attrs["numbered"] == "true"
                val body = if (numbered)
                    lines.subList(start - 1, maxOf(start, end)).mapIndexed { i, l -> "${start + i}\t$l" }.joinToString("\n")
                else slice
                (if (start != 1 || end != lines.size) "[$start-$end من ${lines.size} سطر]\n" else "") + body
            }

            "write_file" -> {
                val f = sb.resolve(c.path)
                require(c.path.isNotBlank()) { "write_file يحتاج path" }
                require(!f.isDirectory) { "هذا مجلد وليس ملفا: ${c.path}" }
                val content = unfence(c.body)
                val existed = f.exists()
                undo.remember(f)
                f.parentFile?.let { mkdirsTracked(it) }
                f.writeText(content)
                undo.mark(sb.rel(f), if (existed) "edit" else "new")
                (if (existed) "تم تحديث " else "تم إنشاء ") + sb.rel(f) + " (" + content.lines().size + " سطر)"
            }

            "edit_file" -> {
                val f = sb.resolve(c.path)
                val orig = readText(f) ?: throw IllegalArgumentException("الملف غير موجود: ${c.path}")
                val edits = editRe.findAll(c.body).toList()
                require(edits.isNotEmpty()) { "edit_file يحتاج <find> و <replace>" }
                var text = orig
                for ((i, m) in edits.withIndex()) {
                    val find = trimNl(m.groupValues[1])
                    val rep = trimNl(m.groupValues[2])
                    require(find.isNotEmpty()) { "تعديل رقم ${i + 1}: <find> فارغ" }
                    val first = text.indexOf(find)
                    require(first >= 0) { "تعديل رقم ${i + 1}: النص غير موجود بالضبط فالملف. اقرأ الملف من جديد وانسخ النص حرفيا" }
                    require(text.indexOf(find, first + 1) < 0) { "تعديل رقم ${i + 1}: النص يتكرر أكثر من مرة. زد سياقا أكثر" }
                    text = text.substring(0, first) + rep + text.substring(first + find.length)
                }
                undo.remember(f)
                f.writeText(text)
                undo.mark(sb.rel(f), "edit")
                "تم تعديل " + sb.rel(f) + " (" + edits.size + " تعديل)"
            }

            "create_dir" -> {
                val d = sb.resolve(c.path)
                require(c.path.isNotBlank()) { "create_dir يحتاج path" }
                require(!d.isFile) { "هذا ملف وليس مجلدا: ${c.path}" }
                if (!d.exists()) { mkdirsTracked(d); undo.mark(sb.rel(d) + "/", "dir") }
                "المجلد جاهز: " + sb.rel(d)
            }

            "delete" -> {
                val f = sb.resolve(c.path)
                require(f != sb.root) { "ما يمكنش حذف جذر المشروع" }
                require(f.exists()) { "غير موجود: ${c.path}" }
                val wasDir = f.isDirectory
                if (wasDir) {
                    // حذف مجلد ما كيتراجعش عنو: كنحفظو نصوص الملفات الصغيرة باش التراجع يرجّعها
                    var saved = 0
                    walkFiles(f) { k -> if (saved < 300) { undo.remember(k); saved++ }; true }
                    f.deleteRecursively()
                } else {
                    undo.remember(f)
                    f.delete()
                }
                undo.mark(sb.rel(f) + (if (wasDir) "/" else ""), "delete")
                "تم حذف " + sb.rel(f)
            }

            "move" -> {
                val from = sb.resolve(c.path)
                val to = sb.resolve(c.attrs["to"].orEmpty())
                require(from.exists()) { "غير موجود: ${c.path}" }
                require(!to.exists()) { "الوجهة موجودة: ${c.attrs["to"]}" }
                require(from != sb.root) { "ما يمكنش نقل جذر المشروع" }
                if (from.isFile) undo.remember(from)
                undo.remember(to)
                to.parentFile?.let { mkdirsTracked(it) }
                if (!from.renameTo(to)) throw IllegalStateException("فشل النقل")
                undo.mark(sb.rel(from) + " ← " + sb.rel(to), "move")
                "تم نقل " + sb.rel(from) + " ← " + sb.rel(to)
            }

            "search" -> {
                val q = c.attrs["query"].orEmpty()
                require(q.isNotEmpty()) { "search يحتاج query" }
                val dir = sb.resolve(c.path)
                val re = if (c.attrs["regex"] == "true") Regex(q, RegexOption.IGNORE_CASE) else null
                val glob = c.attrs["glob"]?.takeIf { it.isNotBlank() }?.let { globToRegex(it) }
                val ctx = (c.attrs["context"]?.toIntOrNull() ?: 0).coerceIn(0, 3)
                val out = ArrayList<String>()
                walkFiles(dir) { f ->
                    val rel = sb.rel(f)
                    if (glob != null && !glob.matches(if (glob.pattern.contains("/")) rel else f.name)) return@walkFiles true
                    if (f.length() > 512_000) return@walkFiles true
                    val text = readText(f) ?: return@walkFiles true
                    val lines = text.replace("\r\n", "\n").split("\n")
                    for ((i, l) in lines.withIndex()) {
                        val hit = re?.containsMatchIn(l) ?: l.contains(q, ignoreCase = true)
                        if (!hit) continue
                        if (ctx == 0) out.add("$rel:${i + 1}: ${l.trim().take(200)}")
                        else {
                            out.add("$rel:${i + 1}:")
                            for (k in maxOf(0, i - ctx)..minOf(lines.size - 1, i + ctx)) out.add("  ${k + 1}| ${lines[k].take(200)}")
                        }
                        if (out.size >= 120) return@walkFiles false
                    }
                    true
                }
                if (out.isEmpty()) "(ما لقيت شي)" else out.joinToString("\n")
            }

            "find_files" -> {
                val pat = c.attrs["pattern"].orEmpty()
                require(pat.isNotEmpty()) { "find_files يحتاج pattern" }
                val re = globToRegex(pat)
                val dir = sb.resolve(c.path)
                val out = ArrayList<String>()
                walkFiles(dir) { f ->
                    val rel = sb.rel(f)
                    if (re.matches(if (pat.contains("/")) rel else f.name)) out.add(rel)
                    out.size < 200
                }
                if (out.isEmpty()) "(ما لقيت شي)" else out.joinToString("\n")
            }

            "outline" -> {
                val dir = sb.resolve(c.path)
                require(dir.exists()) { "غير موجود: ${c.path}" }
                val glob = c.attrs["glob"]?.takeIf { it.isNotBlank() }?.let { globToRegex(it) }
                val out = StringBuilder()
                var files = 0
                walkFiles(dir) { f ->
                    if (glob != null && !glob.matches(f.name)) return@walkFiles true
                    if (f.extension.lowercase() !in CODE_EXT || f.length() > 400_000) return@walkFiles true
                    val text = readText(f) ?: return@walkFiles true
                    val hits = ArrayList<String>()
                    text.replace("\r\n", "\n").split("\n").forEachIndexed { i, l ->
                        if (hits.size < 14 && DECL_RE.containsMatchIn(l)) hits.add("  ${i + 1}: ${l.trim().take(110)}")
                    }
                    out.append(sb.rel(f)).append(" (").append(f.length()).append(" B)\n")
                    hits.forEach { out.append(it).append('\n') }
                    ++files < 70
                }
                if (out.isEmpty()) "(ما لقيت ملفات كود)" else out.toString().trimEnd()
            }

            "remember" -> {
                require(c.body.isNotBlank()) { "remember يحتاج نصا داخل الوسم" }
                ProjectInfo.appendNote(sb.root, c.body)
                "تم حفظ الملاحظة فذاكرة المشروع"
            }

            "github_issues" -> {
                val api = gh ?: throw IllegalStateException("GitHub غير متوفر")
                val r = repo ?: throw IllegalStateException("هذا المشروع ماشي من GitHub")
                val list = api.issues(r, (c.attrs["limit"]?.toIntOrNull() ?: 15))
                if (list.isEmpty()) "(ما كاين حتى issue مفتوح)"
                else list.joinToString("\n") { "#${it.number} ${it.title}" + (if (it.labels.isNotEmpty()) "  [" + it.labels.joinToString(", ") + "]" else "") }
            }

            "github_issue" -> {
                val api = gh ?: throw IllegalStateException("GitHub غير متوفر")
                val r = repo ?: throw IllegalStateException("هذا المشروع ماشي من GitHub")
                val n = c.attrs["number"]?.toIntOrNull() ?: throw IllegalArgumentException("github_issue يحتاج number")
                val (issue, comments) = api.issueWithComments(r, n)
                buildString {
                    appendLine("#${issue.number} ${issue.title}  (by ${issue.author})")
                    if (issue.labels.isNotEmpty()) appendLine("labels: " + issue.labels.joinToString(", "))
                    appendLine()
                    appendLine(issue.body.take(6000))
                    comments.forEachIndexed { i, t -> appendLine("\n--- comment ${i + 1} ---\n" + t) }
                }
            }

            else -> throw IllegalArgumentException("أداة غير معروفة: ${c.name}")
        }
    }
}
