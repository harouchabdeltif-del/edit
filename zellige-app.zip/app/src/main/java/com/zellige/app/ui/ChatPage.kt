package com.zellige.app.ui

import android.content.Context
import android.content.res.ColorStateList
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import com.zellige.app.R
import com.zellige.app.ZelligeApp
import com.zellige.app.agent.Agent
import com.zellige.app.agent.ProjectInfo

/**
 * صفحة الشات: المستعمل كيكتب الفكرة، والوكيل كيخدم. فالشات ما كاين كود أبدا:
 * فقاعة المستعمل + جملة قصيرة من الوكيل مع المسارات اللي لمسها،
 * ونافذة صغيرة كتبين مباشرة شنو كيدير (ملف جديد، تعديل، حذف…) بالمسار فقط.
 */
class ChatPage(private val ctx: Context, private val app: ZelligeApp, private val host: Host) : Page {

    private val h = Handler(Looper.getMainLooper())
    private val agent get() = app.agent

    private val column = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
    override val view: View = column

    private val scroll = ScrollView(ctx)
    private val list = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(ctx.dp(14), ctx.dp(10), ctx.dp(14), ctx.dp(10))
    }

    // ---- النافذة الصغيرة
    private val card = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        background = ctx.rounded(C.SURFACE, 18, C.LINE)
        setPadding(ctx.dp(14), ctx.dp(12), ctx.dp(14), ctx.dp(12))
        visibility = View.GONE
    }
    private val cardSpin = ProgressBar(ctx, null, android.R.attr.progressBarStyleSmall).apply {
        indeterminateTintList = ColorStateList.valueOf(C.AMBER)
    }
    private val cardCheck = ImageView(ctx).apply { setImageResource(R.drawable.ic_check) }
    private val cardTitle = ctx.label("", 15f, C.TEXT, bold = true)
    private val cardNow = ctx.label("", 13f, C.AMBER)
    private val cardNote = ctx.label("", 13f, C.TEXT)
    private val cardCounts = ctx.label("", 12f, C.DIM)
    private val cardRows = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
    private val cardRowsScroll = MaxHeightScroll(ctx, ctx.dp(170))
    private val cardFoot = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }

    // ---- الإدخال
    private val input = ctx.field("كتب شنو بغيتي نبني أو نبدّل…", multiline = true)
    private val sendBtn = ImageView(ctx)

    private var cardHidden = false
    private var lastPrompt = ""
    private val autoHide = Runnable { cardHidden = true; renderCard() }

    init {
        column.layoutDirection = View.LAYOUT_DIRECTION_RTL

        scroll.addView(list, android.widget.FrameLayout.LayoutParams(MATCH, WRAP))
        column.addView(scroll, lp(MATCH, 0, 1f))

        // البطاقة
        val head = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(cardSpin, LinearLayout.LayoutParams(ctx.dp(18), ctx.dp(18)).also { it.marginEnd = ctx.dp(10) })
        cardCheck.setColorFilter(C.GREEN)
        head.addView(cardCheck, LinearLayout.LayoutParams(ctx.dp(20), ctx.dp(20)).also { it.marginEnd = ctx.dp(8) })
        head.addView(cardTitle, lp(0, WRAP, 1f))
        head.addView(ctx.icon(R.drawable.ic_close, C.DIM, 18, 6) { cardHidden = true; h.removeCallbacks(autoHide); renderCard() })
        card.addView(head, lp())
        card.addView(cardNow, lp().margins(0, 8, 0, 0, ctx))
        card.addView(cardNote, lp().margins(0, 6, 0, 0, ctx))
        cardRowsScroll.addView(cardRows, android.widget.FrameLayout.LayoutParams(MATCH, WRAP))
        card.addView(cardRowsScroll, lp().margins(0, 8, 0, 0, ctx))
        card.addView(cardCounts, lp().margins(0, 8, 0, 0, ctx))
        card.addView(cardFoot, lp().margins(0, 10, 0, 0, ctx))
        column.addView(card, lp().margins(10, 4, 10, 6, ctx))

        // شريط الإدخال
        val bar = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.BOTTOM
            setBackgroundColor(C.BG)
            setPadding(ctx.dp(10), ctx.dp(8), ctx.dp(10), ctx.dp(10))
        }
        bar.addView(input, lp(0, WRAP, 1f).margins(0, 0, 8, 0, ctx))
        sendBtn.apply {
            val p = ctx.dp(11)
            setPadding(p, p, p, p)
            scaleType = ImageView.ScaleType.FIT_CENTER
            isClickable = true
            setOnClickListener { if (agent.busy()) agent.stop() else submit() }
        }
        bar.addView(sendBtn, LinearLayout.LayoutParams(ctx.dp(48), ctx.dp(48)))
        column.addView(bar, lp())
        setBusyUi(agent.busy())
        renderHistory()
        renderCard()
    }

    // ------------------------------------------------------------------ lifecycle
    fun attach() {
        agent.listener = { e -> h.post { handle(e) } }
    }

    fun detach() {
        agent.listener = null
        h.removeCallbacks(autoHide)
    }

    override fun onShow() {
        reload()
    }

    /** يعيد رسم الشات (بعد فتح مشروع آخر، مثلا). */
    fun reload() {
        setBusyUi(agent.busy())
        renderHistory()
        renderCard()
    }

    /** يكتب الطلب ويبعثو (مثلا من اكتشاف: خدمة على issue). */
    fun sendPrompt(text: String) {
        input.setText(text)
        submit()
    }

    // ------------------------------------------------------------------ events
    private fun handle(e: Agent.Event) {
        when (e) {
            is Agent.Event.Step -> { cardHidden = false; h.removeCallbacks(autoHide) }
            is Agent.Event.Finish -> {
                renderHistory()
                setBusyUi(false)
                if (e.error != null || e.stopped) {
                    val kept = agent.history().any { it.fromUser && it.text == lastPrompt }
                    if (!kept && lastPrompt.isNotEmpty() && input.text.isNullOrBlank()) input.setText(lastPrompt)
                }
                if (e.error == null && !e.stopped) {
                    h.removeCallbacks(autoHide)
                    h.postDelayed(autoHide, 25_000)
                }
            }
            else -> {}
        }
        renderCard()
        host.refreshHeader()
    }

    // ------------------------------------------------------------------ sending
    private fun submit() {
        val text = input.text.toString().trim()
        if (text.isEmpty() || agent.busy()) return
        if (!app.aiPrefs.ready()) {
            ctx.toast("حط مفتاح API الأول من الإعدادات")
            host.openSettings()
            return
        }
        if (agent.root() == null) {
            val dir = app.workspace.create(titleFrom(text))
            agent.open(dir)
            app.appPrefs.activeProject = dir.name
        }
        lastPrompt = text
        input.setText("")
        input.hideKeyboard()
        cardHidden = false
        h.removeCallbacks(autoHide)
        if (agent.send(text)) {
            renderHistory()
            setBusyUi(true)
            renderCard()
            host.refreshHeader()
        }
    }

    private fun titleFrom(text: String): String {
        val words = text.replace(Regex("[\\p{Punct}،؟!]"), " ").trim().split(Regex("\\s+")).filter { it.isNotBlank() }
        return words.take(4).joinToString("-").take(28).ifBlank { "مشروع" }
    }

    private fun setBusyUi(busy: Boolean) {
        if (busy) {
            sendBtn.setImageResource(R.drawable.ic_stop)
            sendBtn.setColorFilter(C.TEXT)
            sendBtn.background = ctx.circle(0xFF8E3B3B.toInt())
        } else {
            sendBtn.setImageResource(R.drawable.ic_send)
            sendBtn.setColorFilter(C.ON_AMBER)
            sendBtn.background = ctx.circle(C.AMBER)
        }
    }

    // ------------------------------------------------------------------ history
    private fun scrollEnd() { scroll.post { scroll.fullScroll(View.FOCUS_DOWN) } }

    private fun renderHistory() {
        list.removeAllViews()
        val turns = agent.history()
        if (turns.isEmpty()) {
            list.addView(emptyState(), lp())
            return
        }
        val lastAssistant = turns.indexOfLast { !it.fromUser }
        turns.forEachIndexed { i, t -> list.addView(bubble(t, i == lastAssistant), lp().margins(0, 5, 0, 5, ctx)) }
        scrollEnd()
    }

    private fun bubble(t: Agent.Turn, isLast: Boolean): View {
        val box = FractionBox(ctx, 0.9f).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(ctx.dp(14), ctx.dp(10), ctx.dp(14), ctx.dp(10))
        }
        val tv = ctx.label(t.text, 15f, if (t.fromUser) C.ON_AMBER else C.TEXT)
        tv.setTextIsSelectable(true)
        tv.setLineSpacing(0f, 1.15f)
        box.addView(tv, lp())
        if (t.fromUser) {
            box.background = ctx.rounded(C.AMBER, 18)
        } else {
            box.background = ctx.rounded(C.SURFACE, 18, C.LINE)
            if (t.paths.isNotEmpty()) {
                box.addView(ctx.spacer(8))
                t.paths.take(8).forEach { p ->
                    box.addView(ctx.label("▸ $p", 12f, C.DIM, mono = true).also { it.ellipsize1() }, lp())
                }
                if (t.paths.size > 8) box.addView(ctx.label("+ ${t.paths.size - 8} أخرى", 12f, C.DIM))
            }
            if (isLast && t.paths.isNotEmpty() && agent.canUndo()) {
                box.addView(ctx.spacer(6))
                box.addView(ctx.label("↩ تراجع عن هاد التعديلات", 13f, C.AMBER, bold = true).apply {
                    setPadding(0, ctx.dp(6), 0, ctx.dp(2))
                    isClickable = true
                    setOnClickListener { undo() }
                }, lp())
            }
        }
        val wrap = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        wrap.addView(box, LinearLayout.LayoutParams(WRAP, WRAP).also { it.gravity = Gravity.START })
        return wrap
    }

    private fun undo() {
        if (!agent.canUndo()) return
        val n = agent.undoLast()
        ctx.toast(if (n > 0) "رجّعت $n ملف لحالتو الأولى" else "ما كاين والو نرجّع")
        renderHistory()
        renderCard()
    }

    private fun emptyState(): View {
        val hasProject = agent.root() != null
        val repo = agent.root()?.let { ProjectInfo.repo(it) }
        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(ctx.dp(6), ctx.dp(30), ctx.dp(6), ctx.dp(10))
        }
        col.addView(ImageView(ctx).apply {
            setImageResource(R.drawable.ic_sparkle)
            setColorFilter(C.AMBER)
        }, LinearLayout.LayoutParams(ctx.dp(46), ctx.dp(46)))
        col.addView(ctx.label(if (hasProject) agent.root()!!.name else "شنو بغيتي نبني؟", 22f, C.TEXT, bold = true).apply {
            gravity = Gravity.CENTER
        }, lp().margins(0, 14, 0, 0, ctx))
        col.addView(ctx.label(
            if (hasProject) "المشروع جاهز. قول ليا شنو نعمل فيه."
            else "كتب الفكرة بكلماتك. الوكيل كيصاوب المشروع كامل فملفات، وأنت كتشوف غير شنو دار وفين.",
            14f, C.DIM
        ).apply { gravity = Gravity.CENTER }, lp().margins(12, 8, 12, 18, ctx))

        if (!app.aiPrefs.ready()) {
            col.addView(ctx.button("حط مفتاح الذكاء الاصطناعي أولا", FILLED) { host.openSettings() }, lp().margins(0, 0, 0, 14, ctx))
        }

        val ideas = when {
            !hasProject -> listOf(
                "تطبيق تسجيل دخول وإنشاء حساب بتصميم أنيق",
                "تطبيق لتتبع المصاريف اليومية مع إحصائيات",
                "قائمة مهام مع تذكيرات",
                "تطبيق ملاحظات كيخزن محليا",
                "صفحة ويب لمطعم بقائمة الطعام"
            )
            repo != null -> listOf(
                "اشرح ليا كيفاش كيخدم هاد المشروع",
                "قرا الـ issues المفتوحة واقترح عليا أسهل وحدة نبدا بيها",
                "لقا الأخطاء المحتملة فالكود"
            )
            else -> listOf(
                "اشرح ليا شنو كاين فهاد المشروع",
                "زيد ميزة جديدة: ",
                "لقا الأخطاء المحتملة فالكود"
            )
        }
        ideas.forEach { idea ->
            col.addView(TextView(ctx).apply {
                text = idea
                setTextColor(C.TEXT)
                textSize = 14f
                setPadding(ctx.dp(16), ctx.dp(13), ctx.dp(16), ctx.dp(13))
                background = ctx.ripple(C.SURFACE, 14, C.LINE)
                isClickable = true
                setOnClickListener { input.setText(idea); input.setSelection(input.text.length); input.showKeyboard() }
            }, lp().margins(0, 4, 0, 4, ctx))
        }
        return col
    }

    // ------------------------------------------------------------------ the small popup
    private fun renderCard() {
        val ev = agent.liveEvents()
        val fin = ev.lastOrNull { it is Agent.Event.Finish } as? Agent.Event.Finish
        val busy = fin == null && agent.busy()
        if (cardHidden || (fin == null && !busy)) { card.visibility = View.GONE; return }
        card.visibility = View.VISIBLE

        // العنوان والأيقونة
        cardSpin.visibility = if (busy) View.VISIBLE else View.GONE
        cardCheck.visibility = if (fin != null && fin.error == null && !fin.stopped) View.VISIBLE else View.GONE
        val steps = ev.filterIsInstance<Agent.Event.Done>()
        val title: String
        var titleColor = C.TEXT
        when {
            busy -> title = if (steps.isEmpty()) "الوكيل كيفكر…" else "الوكيل كيخدم…"
            fin!!.error != null -> { title = "وقع مشكل"; titleColor = C.RED }
            fin.stopped -> title = "تم الإيقاف"
            else -> title = "سالى"
        }
        cardTitle.text = title
        cardTitle.setTextColor(titleColor)

        // الخطوة الحالية
        val lastStepIdx = ev.indexOfLast { it is Agent.Event.Step }
        val lastDoneIdx = ev.indexOfLast { it is Agent.Event.Done }
        if (busy && lastStepIdx > lastDoneIdx) {
            val s = ev[lastStepIdx] as Agent.Event.Step
            cardNow.text = stepText(s.label, s.path)
            cardNow.visibility = View.VISIBLE
        } else {
            cardNow.visibility = View.GONE
        }

        // الجملة: ملاحظة الوكيل أثناء الخدمة، وخلاصتو أو الخطأ فالأخير
        val note = when {
            busy -> (ev.lastOrNull { it is Agent.Event.Note } as? Agent.Event.Note)?.text.orEmpty()
            fin!!.error != null -> fin.error
            else -> fin.summary
        }.orEmpty()
        cardNote.text = note
        cardNote.setTextColor(if (fin?.error != null) C.RED else C.TEXT)
        cardNote.visibility = if (note.isBlank()) View.GONE else View.VISIBLE

        // الصفوف: الملفات اللي تبدّلات (المسار فقط)
        cardRows.removeAllViews()
        if (fin != null) {
            fin.changes.forEach { (p, k) -> cardRows.addView(row(kindBadge(k), p, badgeColor(k))) }
        } else {
            steps.filter { it.kind in CHANGING || !it.ok }.forEach {
                cardRows.addView(row(if (!it.ok) "فشل" else doneBadge(it), it.path, if (!it.ok) C.RED else C.GREEN))
            }
        }
        cardRowsScroll.visibility = if (cardRows.childCount == 0) View.GONE else View.VISIBLE
        if (busy) cardRowsScroll.post { cardRowsScroll.fullScroll(View.FOCUS_DOWN) }

        // العدادات
        val reads = steps.count { it.kind == "read" && it.ok }
        val searches = steps.count { it.kind == "search" && it.ok }
        val gits = steps.count { it.kind == "github" && it.ok }
        val parts = ArrayList<String>()
        if (reads > 0) parts.add("قريت $reads")
        if (searches > 0) parts.add("بحثت $searches")
        if (gits > 0) parts.add("GitHub $gits")
        cardCounts.text = parts.joinToString(" · ")
        cardCounts.visibility = if (parts.isEmpty()) View.GONE else View.VISIBLE

        // الأزرار
        cardFoot.removeAllViews()
        if (busy) {
            cardFoot.addView(ctx.button("إيقاف", DANGER) { agent.stop() }, lp(0, WRAP, 1f))
        } else {
            if (agent.canUndo() && fin != null && fin.changes.isNotEmpty()) {
                cardFoot.addView(ctx.button("تراجع", TONAL) { undo() }, lp(0, WRAP, 1f).margins(0, 0, 6, 0, ctx))
            }
            cardFoot.addView(ctx.button("تمام", FILLED) {
                cardHidden = true
                h.removeCallbacks(autoHide)
                renderCard()
            }, lp(0, WRAP, 1f))
        }
    }

    private fun stepText(label: String, path: String): String {
        val verb = label.substringBefore(' ')
        return if (path.isBlank() || !label.contains(' ')) label else "$verb  ⁦$path⁩"
    }

    private fun row(badge: String, path: String, color: Int): View {
        val r = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        r.setPadding(0, ctx.dp(3), 0, ctx.dp(3))
        r.addView(ctx.label(badge, 11f, color, bold = true).apply {
            minWidth = ctx.dp(44)
            gravity = Gravity.CENTER
            background = ctx.rounded(C.SURFACE2, 8)
            setPadding(ctx.dp(8), ctx.dp(2), ctx.dp(8), ctx.dp(2))
        }, LinearLayout.LayoutParams(WRAP, WRAP).also { it.marginEnd = ctx.dp(10) })
        r.addView(ctx.label(path, 12f, C.TEXT, mono = true).also { it.ellipsize1() }, lp(0, WRAP, 1f))
        return r
    }

    private fun doneBadge(d: Agent.Event.Done): String = when (d.kind) {
        "write" -> if (d.detail.startsWith("تم إنشاء")) "جديد" else "تحديث"
        "edit" -> "تعديل"
        "delete" -> "حذف"
        "move" -> "نقل"
        "dir" -> "مجلد"
        else -> ""
    }

    private fun kindBadge(k: String): String = when (k) {
        "new" -> "جديد"
        "edit" -> "تعديل"
        "delete" -> "حذف"
        "move" -> "نقل"
        "dir" -> "مجلد"
        else -> k
    }

    private fun badgeColor(k: String): Int = when (k) {
        "new", "dir" -> C.GREEN
        "delete" -> C.RED
        "move" -> C.BLUE
        else -> C.AMBER
    }

    private companion object {
        val CHANGING = setOf("write", "edit", "delete", "move", "dir")
    }
}
