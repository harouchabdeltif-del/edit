package com.zellige.app.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.zellige.app.ZelligeApp
import com.zellige.app.agent.ProjectInfo
import com.zellige.app.github.GitHubApi
import com.zellige.app.github.ZipUtil
import org.json.JSONObject
import java.io.File

/**
 * اكتشف: بحث فمشاريع GitHub العامة. كتختار مشروع، كيتحمّل للتطبيق، وكتخدم عليه بالوكيل
 * (أو على issue معين). الرخصة ديال كل مشروع كتبان قبل ما تبدا.
 */
class DiscoverPage(private val ctx: Context, private val app: ZelligeApp, private val host: Host) : Page {

    private class Filter(val label: String, val q: String)

    private val filters = listOf(
        Filter("أندرويد", "topic:android"),
        Filter("Kotlin", "language:Kotlin"),
        Filter("Python", "language:Python"),
        Filter("JavaScript", "language:JavaScript"),
        Filter("Flutter", "topic:flutter"),
        Filter("فيها issues للمبتدئين", "good-first-issues:>0"),
        Filter("صغير", "size:<5000")
    )

    private val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
    override val view: View = col

    private val input = ctx.field("ابحث (todo app kotlin) أو الصق رابط GitHub…").apply {
        imeOptions = EditorInfo.IME_ACTION_SEARCH
        maxLines = 1
        setSingleLine(true)
    }
    private val chipsRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
    private val results = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
    private val status = ctx.label("", 13f, C.DIM).apply { gravity = Gravity.CENTER }
    private val moreBtn = ctx.button("المزيد", TONAL) { page++; search(false) }

    private val selected = LinkedHashSet<Int>()
    private val downloading = HashSet<String>()
    private var page = 1
    private var token = 0
    private var started = false
    private var alive = true

    init {
        col.layoutDirection = View.LAYOUT_DIRECTION_RTL
        col.setPadding(ctx.dp(14), ctx.dp(10), ctx.dp(14), 0)

        val searchRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        searchRow.addView(input, lp(0, WRAP, 1f))
        searchRow.addView(ctx.icon(com.zellige.app.R.drawable.ic_search, C.ON_AMBER, 22, 10) { search(true) }.apply {
            background = ctx.circle(C.AMBER)
        }, LinearLayout.LayoutParams(ctx.dp(46), ctx.dp(46)).also { it.marginStart = ctx.dp(8) })
        col.addView(searchRow, lp())
        input.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_SEARCH) { input.hideKeyboard(); search(true); true } else false
        }

        val chipScroll = HorizontalScrollView(ctx).apply { isHorizontalScrollBarEnabled = false }
        chipScroll.addView(chipsRow)
        col.addView(chipScroll, lp().margins(0, 10, 0, 6, ctx))
        renderChips()

        val body = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        body.addView(status, lp().margins(0, 8, 0, 8, ctx))
        body.addView(results, lp())
        moreBtn.visibility = View.GONE
        body.addView(moreBtn, lp().margins(0, 8, 0, 20, ctx))
        val scroll = ScrollView(ctx)
        scroll.addView(body, android.widget.FrameLayout.LayoutParams(MATCH, WRAP))
        col.addView(scroll, lp(MATCH, 0, 1f))
    }

    override fun onShow() {
        if (!started) { started = true; search(true) }
    }

    fun destroy() { alive = false }

    // ------------------------------------------------------------------ search
    private fun renderChips() {
        chipsRow.removeAllViews()
        filters.forEachIndexed { i, f ->
            chipsRow.addView(ctx.chip(f.label, i in selected) {
                if (!selected.add(i)) selected.remove(i)
                renderChips()
                search(true)
            }, lp(WRAP, WRAP).margins(0, 0, 8, 0, ctx))
        }
    }

    private fun buildQuery(text: String): String {
        val parts = ArrayList<String>()
        if (text.isNotEmpty()) parts.add(text)
        selected.forEach { parts.add(filters[it].q) }
        parts.add("archived:false")
        parts.add("fork:false")
        if (selected.none { filters[it].q.startsWith("size:") }) parts.add("size:<$MAX_KB")
        if (text.isEmpty() && selected.none { filters[it].q.startsWith("good-first") }) parts.add("stars:>200")
        return parts.joinToString(" ")
    }

    private val directRe = Regex("^(?:https?://)?(?:www\\.)?github\\.com/([A-Za-z0-9_.-]+)/([A-Za-z0-9_.-]+?)(?:\\.git)?(?:[/#?].*)?$")
    private val shortRe = Regex("^([A-Za-z0-9_.-]+)/([A-Za-z0-9_.-]+)$")

    private fun directRef(text: String): String? {
        directRe.find(text)?.let { return it.groupValues[1] + "/" + it.groupValues[2] }
        shortRe.find(text)?.let { return it.groupValues[1] + "/" + it.groupValues[2] }
        return null
    }

    private fun search(reset: Boolean) {
        if (reset) {
            page = 1
            results.removeAllViews()
            moreBtn.visibility = View.GONE
        }
        val my = ++token
        val text = input.text.toString().trim()
        status.setTextColor(C.DIM)
        status.text = "كنقلب…"
        status.visibility = View.VISIBLE
        val direct = if (reset) directRef(text) else null
        val pg = page
        bg({
            var found: List<GitHubApi.Repo>? = null
            if (direct != null) {
                found = try { listOf(app.gh.repo(direct)) } catch (t: GitHubApi.GhException) { null }
            }
            found ?: app.gh.search(buildQuery(text), pg, PER)
        }) { list, err ->
            if (!alive || my != token) return@bg
            if (err != null || list == null) {
                status.setTextColor(C.RED)
                status.text = err?.message ?: "وقع مشكل"
                return@bg
            }
            if (list.isEmpty() && results.childCount == 0) {
                status.text = "ما لقيت حتى مشروع. جرّب كلمات أخرى أو شيّل بعض الفلاتر."
            } else {
                status.visibility = View.GONE
            }
            list.forEach { results.addView(repoCard(it), lp().margins(0, 5, 0, 5, ctx)) }
            moreBtn.visibility = if (list.size >= PER && direct == null) View.VISIBLE else View.GONE
        }
    }

    // ------------------------------------------------------------------ cards
    private fun badges(r: GitHubApi.Repo): String {
        val parts = ArrayList<String>()
        parts.add("★ " + humanCount(r.stars))
        if (r.language.isNotBlank()) parts.add(r.language)
        if (r.license.isNotBlank() && r.license != "NOASSERTION") parts.add(r.license)
        parts.add(humanSize(r.sizeKb))
        return parts.joinToString("  ·  ")
    }

    private fun repoCard(r: GitHubApi.Repo): View {
        val c = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            background = ctx.ripple(C.SURFACE, 16, C.LINE)
            setPadding(ctx.dp(14), ctx.dp(12), ctx.dp(14), ctx.dp(12))
            isClickable = true
            setOnClickListener { openRepo(r) }
        }
        c.addView(ctx.label(r.full, 14f, C.AMBER, bold = true, mono = true).also { it.ellipsize1() }, lp())
        if (r.description.isNotBlank()) {
            c.addView(ctx.label(r.description, 13f, C.TEXT).apply {
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
            }, lp().margins(0, 5, 0, 0, ctx))
        }
        c.addView(ctx.label(badges(r), 12f, C.DIM).apply { textDirection = View.TEXT_DIRECTION_LTR; textAlignment = View.TEXT_ALIGNMENT_VIEW_START },
            lp().margins(0, 8, 0, 0, ctx))
        if (app.workspace.findByRepo(r.full) != null) {
            c.addView(ctx.label("✓ محمّل عندك", 12f, C.GREEN, bold = true), lp().margins(0, 6, 0, 0, ctx))
        }
        return c
    }

    // ------------------------------------------------------------------ repo sheet
    private fun licenseNote(r: GitHubApi.Repo): Pair<String, Int> =
        if (r.license.isBlank() || r.license == "NOASSERTION")
            "ما كاينة رخصة واضحة: الكود ديال صاحبو. خدم عليه للتعلم، وما تنشرش تعديلات بلا إذنو." to C.RED
        else
            "الرخصة: ${r.license}. احترم شروطها إلا نشرتي التعديلات." to C.DIM

    private fun openRepo(r: GitHubApi.Repo) {
        val s = Sheet(ctx, r.full, monoTitle = true)
        if (r.description.isNotBlank()) s.add(ctx.label(r.description, 14f, C.TEXT))
        s.add(ctx.label(badges(r) + "  ·  " + r.openIssues + " issues", 12f, C.DIM).apply {
            textDirection = View.TEXT_DIRECTION_LTR
            textAlignment = View.TEXT_ALIGNMENT_VIEW_START
        }, 8)
        val (note, noteColor) = licenseNote(r)
        s.add(ctx.label(note, 12f, noteColor), 8)

        val status = ctx.label("", 13f, C.DIM).apply { visibility = View.GONE }
        s.add(status, 10)

        val local = app.workspace.findByRepo(r.full)
        val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        val issuesBox = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        lateinit var open: TextView
        open = ctx.button(if (local != null) "افتح (محمّل)" else "افتح للعمل", FILLED) {
            ensureLocal(r, status, s) { dir -> s.dismiss(); host.openProject(dir) }
        }
        row.addView(open, lp(0, WRAP, 1f).margins(0, 0, 6, 0, ctx))
        row.addView(ctx.button("Issues", TONAL) { loadIssues(r, s, status, issuesBox) }, lp(0, WRAP, 1f).margins(3, 0, 3, 0, ctx))
        row.addView(ctx.button("GitHub ↗", TONAL) {
            try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(r.url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            catch (t: Throwable) { ctx.toast("ما لقيت متصفح") }
        }, lp(0, WRAP, 1f).margins(6, 0, 0, 0, ctx))
        s.add(row, 14)
        s.add(issuesBox, 10)
        s.show()
    }

    /** يحمّل المشروع إلا ما كانش محمّل، ثم يعطي المجلد. */
    private fun ensureLocal(r: GitHubApi.Repo, status: TextView, sheet: Sheet, done: (File) -> Unit) {
        app.workspace.findByRepo(r.full)?.let { done(it); return }
        if (r.sizeKb > MAX_KB) {
            status.visibility = View.VISIBLE
            status.setTextColor(C.RED)
            status.text = "المشروع كبير بزاف (${humanSize(r.sizeKb)}). الحد الأقصى ${humanSize(MAX_KB)}."
            return
        }
        if (!downloading.add(r.full)) return
        status.visibility = View.VISIBLE
        status.setTextColor(C.DIM)
        status.text = "كنحمّل…"
        val dir = app.workspace.create(r.name)
        bg({
            app.gh.download(r.full, dir, ZipUtil.DEFAULT_MAX_BYTES) { files, bytes ->
                onMain { if (sheet.dialog.isShowing) status.text = "كنحمّل…  $files ملف · ${bytes / 1024 / 1024} MB" }
            }
            ProjectInfo.writeMeta(
                dir, JSONObject()
                    .put("repo", r.full).put("url", r.url).put("branch", r.branch)
                    .put("license", r.license).put("stars", r.stars).put("description", r.description)
                    .put("downloaded", System.currentTimeMillis())
            )
            dir
        }) { d, err ->
            downloading.remove(r.full)
            if (err != null || d == null) {
                dir.deleteRecursively()
                if (sheet.dialog.isShowing) {
                    status.setTextColor(C.RED)
                    status.text = "تعذّر التحميل: " + (err?.message ?: "")
                } else ctx.toast("تعذّر تحميل ${r.full}")
            } else if (sheet.dialog.isShowing) {
                done(d)
            } else {
                ctx.toast("تحمّل ${r.full}. لقاه فـ«مشاريعي».")
            }
        }
    }

    private fun loadIssues(r: GitHubApi.Repo, sheet: Sheet, status: TextView, box: LinearLayout) {
        box.removeAllViews()
        box.addView(ctx.label("كنجيب الـ issues…", 13f, C.DIM))
        bg({ app.gh.issues(r.full, 20) }) { list, err ->
            box.removeAllViews()
            if (!alive) return@bg
            if (err != null || list == null) {
                box.addView(ctx.label(err?.message ?: "وقع مشكل", 13f, C.RED))
                return@bg
            }
            if (list.isEmpty()) {
                box.addView(ctx.label("ما كاين حتى issue مفتوح.", 13f, C.DIM))
                return@bg
            }
            box.addView(ctx.label("اضغط على issue باش يخدم عليه الوكيل:", 12f, C.DIM))
            list.forEach { iss ->
                val row = LinearLayout(ctx).apply {
                    orientation = LinearLayout.VERTICAL
                    background = ctx.ripple(C.SURFACE2, 12, C.LINE)
                    setPadding(ctx.dp(12), ctx.dp(10), ctx.dp(12), ctx.dp(10))
                    isClickable = true
                    setOnClickListener {
                        ensureLocal(r, status, sheet) { dir ->
                            sheet.dismiss()
                            host.openProject(
                                dir,
                                "خدم على issue #${iss.number} («${iss.title}») ديال هاد المشروع. " +
                                    "اقراه بأداة github_issue، لقا الكود المعني، وطبّق الإصلاح أو الميزة المطلوبة بأقل تعديلات ممكنة."
                            )
                        }
                    }
                }
                row.addView(ctx.label("#${iss.number}  ${iss.title}", 13f, C.TEXT).apply {
                    maxLines = 2
                    ellipsize = TextUtils.TruncateAt.END
                }, lp())
                if (iss.labels.isNotEmpty()) {
                    row.addView(ctx.label(iss.labels.take(4).joinToString("  ·  "), 11f, C.DIM).apply {
                        textDirection = View.TEXT_DIRECTION_LTR
                        textAlignment = View.TEXT_ALIGNMENT_VIEW_START
                    }, lp().margins(0, 4, 0, 0, ctx))
                }
                box.addView(row, lp().margins(0, 5, 0, 0, ctx))
            }
        }
    }

    private companion object {
        const val PER = 15
        const val MAX_KB = 150_000
    }
}
