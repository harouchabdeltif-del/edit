package com.zellige.app.ui

import android.app.Dialog
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** لوحة الألوان: أسود دافئ + عنبر. التطبيق داكن فقط. */
object C {
    val BG = Color.parseColor("#0A0C10")
    val SURFACE = Color.parseColor("#12151B")
    val SURFACE2 = Color.parseColor("#1A1E26")
    val LINE = Color.parseColor("#262B35")
    val TEXT = Color.parseColor("#D9DDE5")
    val DIM = Color.parseColor("#8A93A3")
    val AMBER = Color.parseColor("#FFB454")
    val AMBER_SOFT = Color.parseColor("#2A2112")
    val ON_AMBER = Color.parseColor("#1A1000")
    val GREEN = Color.parseColor("#7BD88F")
    val RED = Color.parseColor("#FF7A7A")
    val BLUE = Color.parseColor("#7AB8FF")
}

// ---------------------------------------------------------------------- sizes & shapes
fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

fun Context.rounded(fill: Int, radiusDp: Int, stroke: Int = 0): GradientDrawable = GradientDrawable().apply {
    setColor(fill)
    cornerRadius = dp(radiusDp).toFloat()
    if (stroke != 0) setStroke(dp(1), stroke)
}

fun Context.ripple(fill: Int, radiusDp: Int, stroke: Int = 0): Drawable =
    RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), rounded(fill, radiusDp, stroke), rounded(Color.WHITE, radiusDp))

fun Context.circle(fill: Int): Drawable =
    RippleDrawable(
        ColorStateList.valueOf(0x33FFFFFF),
        GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(fill) },
        GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.WHITE) }
    )

fun lp(w: Int = ViewGroup.LayoutParams.MATCH_PARENT, h: Int = ViewGroup.LayoutParams.WRAP_CONTENT, weight: Float = 0f) =
    LinearLayout.LayoutParams(w, h, weight)

/** هوامش بالـ dp: start / top / end / bottom (نسبية للاتجاه، مناسبة لـ RTL). */
fun LinearLayout.LayoutParams.margins(s: Int = 0, t: Int = 0, e: Int = 0, b: Int = 0, ctx: Context): LinearLayout.LayoutParams {
    topMargin = ctx.dp(t)
    bottomMargin = ctx.dp(b)
    marginStart = ctx.dp(s)
    marginEnd = ctx.dp(e)
    return this
}

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

// ---------------------------------------------------------------------- text & controls
fun Context.label(
    text: CharSequence,
    sp: Float = 14f,
    color: Int = C.TEXT,
    bold: Boolean = false,
    mono: Boolean = false
): TextView = TextView(this).apply {
    this.text = text
    setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
    setTextColor(color)
    if (bold) typeface = Typeface.DEFAULT_BOLD
    if (mono) {
        typeface = Typeface.MONOSPACE
        textDirection = View.TEXT_DIRECTION_LTR
        textAlignment = View.TEXT_ALIGNMENT_VIEW_START
    }
}

const val FILLED = 0
const val TONAL = 1
const val OUTLINE = 2
const val DANGER = 3

fun Context.button(text: String, kind: Int = FILLED, onClick: () -> Unit): TextView = TextView(this).apply {
    this.text = text
    setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
    typeface = Typeface.DEFAULT_BOLD
    gravity = Gravity.CENTER
    minHeight = dp(44)
    setPadding(dp(18), dp(8), dp(18), dp(8))
    when (kind) {
        FILLED -> { setTextColor(C.ON_AMBER); background = ripple(C.AMBER, 12) }
        TONAL -> { setTextColor(C.TEXT); background = ripple(C.SURFACE2, 12, C.LINE) }
        OUTLINE -> { setTextColor(C.AMBER); background = ripple(C.BG, 12, C.AMBER) }
        else -> { setTextColor(C.RED); background = ripple(C.BG, 12, C.RED) }
    }
    isClickable = true
    setOnClickListener { onClick() }
}

fun Context.chip(text: String, selected: Boolean, onClick: () -> Unit): TextView = TextView(this).apply {
    this.text = text
    setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
    gravity = Gravity.CENTER
    setPadding(dp(14), dp(7), dp(14), dp(7))
    setTextColor(if (selected) C.ON_AMBER else C.TEXT)
    background = ripple(if (selected) C.AMBER else C.SURFACE, 18, if (selected) C.AMBER else C.LINE)
    isClickable = true
    setOnClickListener { onClick() }
}

fun Context.icon(res: Int, tint: Int = C.DIM, sizeDp: Int = 24, padDp: Int = 10, onClick: (() -> Unit)? = null): ImageView =
    ImageView(this).apply {
        setImageResource(res)
        setColorFilter(tint)
        scaleType = ImageView.ScaleType.FIT_CENTER
        val p = dp(padDp)
        setPadding(p, p, p, p)
        layoutParams = LinearLayout.LayoutParams(dp(sizeDp + padDp * 2), dp(sizeDp + padDp * 2))
        if (onClick != null) {
            background = circle(0x00000000)
            isClickable = true
            setOnClickListener { onClick() }
        }
    }

fun Context.field(
    hint: String,
    text: String = "",
    secret: Boolean = false,
    multiline: Boolean = false,
    mono: Boolean = false
): EditText = EditText(this).apply {
    this.hint = hint
    setText(text)
    setHintTextColor(C.DIM)
    setTextColor(C.TEXT)
    setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
    background = rounded(C.SURFACE2, 12, C.LINE)
    setPadding(dp(14), dp(11), dp(14), dp(11))
    inputType = when {
        secret -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        multiline -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        else -> InputType.TYPE_CLASS_TEXT or (if (mono) InputType.TYPE_TEXT_VARIATION_URI else 0)
    }
    if (mono) { typeface = Typeface.MONOSPACE; textDirection = View.TEXT_DIRECTION_LTR; textAlignment = View.TEXT_ALIGNMENT_VIEW_START }
    if (multiline) { maxLines = 6; gravity = Gravity.TOP or Gravity.START }
}

fun Context.divider(): View = View(this).apply {
    setBackgroundColor(C.LINE)
    layoutParams = LinearLayout.LayoutParams(MATCH, dp(1))
}

fun Context.spacer(h: Int): View = View(this).apply { layoutParams = LinearLayout.LayoutParams(MATCH, dp(h)) }

fun Context.toast(msg: String) { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show() }

fun View.hideKeyboard() {
    val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
    imm.hideSoftInputFromWindow(windowToken, 0)
}

fun View.showKeyboard() {
    requestFocus()
    val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
    imm.showSoftInput(this, InputMethodManager.SHOW_IMPLICIT)
}

fun TextView.ellipsize1() {
    maxLines = 1
    ellipsize = TextUtils.TruncateAt.MIDDLE
}

// ---------------------------------------------------------------------- scroll with a max height
class MaxHeightScroll(ctx: Context, private val maxPx: Int) : ScrollView(ctx) {
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val h = MeasureSpec.getSize(heightMeasureSpec)
        val cap = if (h in 1 until maxPx) h else maxPx
        super.onMeasure(widthMeasureSpec, MeasureSpec.makeMeasureSpec(cap, MeasureSpec.AT_MOST))
    }
}

// ---------------------------------------------------------------------- background work
private val main = Handler(Looper.getMainLooper())

fun onMain(f: () -> Unit) { main.post(f) }

fun <T> bg(work: () -> T, done: (T?, Throwable?) -> Unit) {
    Thread {
        var r: T? = null
        var e: Throwable? = null
        try { r = work() } catch (t: Throwable) { e = t }
        main.post { done(r, e) }
    }.also { it.isDaemon = true }.start()
}

fun relTime(ms: Long): String {
    val d = System.currentTimeMillis() - ms
    val m = d / 60_000
    return when {
        m < 1 -> "الآن"
        m < 60 -> "منذ $m دقيقة"
        m < 60 * 24 -> "منذ ${m / 60} ساعة"
        m < 60 * 24 * 30 -> "منذ ${m / (60 * 24)} يوم"
        else -> "منذ مدة"
    }
}

fun humanCount(n: Int): String = when {
    n >= 1_000_000 -> String.format(java.util.Locale.US, "%.1fM", n / 1_000_000.0)
    n >= 1_000 -> String.format(java.util.Locale.US, "%.1fk", n / 1_000.0)
    else -> n.toString()
}

fun humanSize(kb: Int): String = when {
    kb >= 1024 -> String.format(java.util.Locale.US, "%.1f MB", kb / 1024.0)
    else -> "$kb KB"
}

// ---------------------------------------------------------------------- bottom sheet
/** نافذة تطلع من الأسفل. body = اللي كيتزاد فيه المحتوى. */
class Sheet(
    private val ctx: Context,
    title: String? = null,
    private val maxHeightFraction: Float = 0.88f,
    monoTitle: Boolean = false
) {

    val dialog = Dialog(ctx)
    val body = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
    private val titleView: TextView?

    init {
        dialog.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE)
        val maxPx = (ctx.resources.displayMetrics.heightPixels * maxHeightFraction).toInt()

        val column = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            val r = ctx.dp(22).toFloat()
            background = GradientDrawable().apply {
                setColor(C.SURFACE)
                cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
            }
            setPadding(ctx.dp(18), ctx.dp(10), ctx.dp(18), ctx.dp(18))
        }
        val handle = View(ctx).apply {
            background = ctx.rounded(C.LINE, 3)
            layoutParams = LinearLayout.LayoutParams(ctx.dp(40), ctx.dp(5)).apply {
                gravity = Gravity.CENTER_HORIZONTAL
                bottomMargin = ctx.dp(12)
            }
        }
        column.addView(handle)
        titleView = title?.let {
            ctx.label(it, if (monoTitle) 16f else 18f, C.TEXT, bold = true, mono = monoTitle).also { t ->
                t.layoutParams = lp().margins(0, 0, 0, 10, ctx)
                column.addView(t)
            }
        }
        val scroll = MaxHeightScroll(ctx, maxPx).apply {
            isFillViewport = false
            addView(body, FrameLayout.LayoutParams(MATCH, WRAP))
        }
        column.addView(scroll, LinearLayout.LayoutParams(MATCH, WRAP))
        dialog.setContentView(column)
        dialog.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT)
            setGravity(Gravity.BOTTOM)
            setDimAmount(0.6f)
            setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        }
    }

    fun setTitle(t: String) { titleView?.text = t }

    fun add(v: View, topMarginDp: Int = 0): Sheet {
        val p = (v.layoutParams as? LinearLayout.LayoutParams) ?: lp()
        p.topMargin = ctx.dp(topMarginDp)
        body.addView(v, p)
        return this
    }

    fun show(): Sheet { dialog.show(); return this }
    fun dismiss() { try { dialog.dismiss() } catch (t: Throwable) { /* الشاشة سدّات */ } }
}

/** سؤال بسيط بحقل نص. */
fun Context.askText(title: String, hint: String, initial: String, okLabel: String, onOk: (String) -> Unit) {
    val s = Sheet(this, title)
    val f = field(hint, initial)
    s.add(f)
    val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
    row.addView(button("إلغاء", TONAL) { s.dismiss() }, lp(0, WRAP, 1f).margins(0, 0, 6, 0, this))
    row.addView(button(okLabel, FILLED) {
        val v = f.text.toString().trim()
        if (v.isNotEmpty()) { s.dismiss(); onOk(v) }
    }, lp(0, WRAP, 1f).margins(6, 0, 0, 0, this))
    s.add(row, 14)
    s.show()
    f.post { f.setSelection(f.text.length); f.showKeyboard() }
}

fun Context.confirm(title: String, message: String, okLabel: String, danger: Boolean = false, onOk: () -> Unit) {
    val s = Sheet(this, title)
    s.add(label(message, 14f, C.DIM))
    val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
    row.addView(button("إلغاء", TONAL) { s.dismiss() }, lp(0, WRAP, 1f).margins(0, 0, 6, 0, this))
    row.addView(button(okLabel, if (danger) DANGER else FILLED) { s.dismiss(); onOk() }, lp(0, WRAP, 1f).margins(6, 0, 0, 0, this))
    s.add(row, 16)
    s.show()
}

/** قائمة اختيار مع بحث. */
fun Context.chooser(title: String, items: List<String>, current: String, onPick: (String) -> Unit) {
    val s = Sheet(this, title)
    val filter = field("بحث…")
    s.add(filter)
    val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    s.add(box, 8)
    fun render(q: String) {
        box.removeAllViews()
        val shown = items.filter { q.isBlank() || it.contains(q, ignoreCase = true) }.take(150)
        if (shown.isEmpty()) box.addView(label("ما كاين حتى نتيجة", 13f, C.DIM).also { it.setPadding(0, dp(12), 0, dp(12)) })
        shown.forEach { item ->
            val row = label(item, 14f, if (item == current) C.AMBER else C.TEXT, bold = item == current, mono = true).apply {
                setPadding(dp(8), dp(12), dp(8), dp(12))
                background = ripple(C.SURFACE, 8)
                isClickable = true
                setOnClickListener { s.dismiss(); onPick(item) }
            }
            box.addView(row, lp())
        }
    }
    render("")
    filter.addTextChangedListener(object : android.text.TextWatcher {
        override fun afterTextChanged(e: android.text.Editable?) { render(e?.toString().orEmpty().trim()) }
        override fun beforeTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
        override fun onTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
    })
    s.show()
}

/** LinearLayout ما كيتعداش نسبة معينة من عرض الأب (فقاعات الشات). */
class FractionBox(ctx: Context, private val fraction: Float = 0.88f) : LinearLayout(ctx) {
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        val cap = (w * fraction).toInt()
        super.onMeasure(MeasureSpec.makeMeasureSpec(if (w > 0) cap else w, if (w > 0) MeasureSpec.AT_MOST else MeasureSpec.getMode(widthMeasureSpec)), heightMeasureSpec)
    }
}
