package com.zellige.app.ui

import android.view.View
import java.io.File

/** صفحة من صفحات التطبيق الثلاث. */
interface Page {
    val view: View
    fun onShow() {}
    fun onHide() {}
    /** true إلا كانت الصفحة تعاملات مع زر الرجوع. */
    fun onBack(): Boolean = false
}

/** ما تحتاجه الصفحات من الـ Activity. */
interface Host {
    /** يفتح مشروعا فالشات. thenSend = طلب يتبعث للوكيل مباشرة (مثلا خدمة على issue). */
    fun openProject(dir: File, thenSend: String? = null)
    fun openSettings()
    fun showTab(index: Int)
    /** تغيّر المشروع النشط أو حالة الوكيل: حدّث الرأس. */
    fun refreshHeader()
}
