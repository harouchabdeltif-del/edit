package com.zellige.app.ui

import android.content.Context
import android.text.InputType
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import com.zellige.app.ZelligeApp
import com.zellige.app.ai.AiClient
import com.zellige.app.ai.AiProviders

/** الإعدادات: المزوّد + المفتاح + الموديل، وتوكن GitHub الاختياري. */
fun showSettings(ctx: Context, app: ZelligeApp, onSaved: () -> Unit) {
    val p = app.aiPrefs
    val s = Sheet(ctx, "الإعدادات", 0.92f)

    fun section(t: String) = ctx.label(t, 12f, C.AMBER, bold = true)
    fun hint(t: String) = ctx.label(t, 12f, C.DIM)

    val providerBtn = ctx.button("", TONAL) {}
    val keyField = ctx.field("مفتاح API", secret = true, mono = true)
    val modelField = ctx.field("الموديل (فارغ = الافتراضي)", mono = true)
    val baseField = ctx.field("Base URL (اختياري)", mono = true)
    val customBox = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
    val cName = ctx.field("اسم المزوّد")
    val cFormat = ctx.button("", TONAL) {}
    val cHeader = ctx.field("اسم header المفتاح (فارغ = الافتراضي)", mono = true)
    val cPrefix = ctx.field("بادئة المفتاح (مثلا Bearer)", mono = true)
    val cHeaders = ctx.field("headers إضافية، سطر لكل واحد: Name: value", multiline = true, mono = true)
    val cPath = ctx.field("مسار الدردشة (مثلا /v1/chat/completions)", mono = true)
    val tokenField = ctx.field("توكن GitHub (اختياري)", app.appPrefs.githubToken, secret = true, mono = true)
    val status = ctx.label("", 13f, C.DIM)

    var format = p.customFormat

    fun providerLabel(): String =
        (if (p.provider == "custom") "Custom — " + p.customName.ifBlank { "مزوّد آخر" }
        else AiProviders.get(p.provider)?.label ?: p.provider) + "  ▾"

    fun fill() {
        providerBtn.text = providerLabel()
        keyField.setText(p.apiKey)
        modelField.setText(p.model)
        baseField.setText(p.baseUrl)
        baseField.hint = AiProviders.get(p.provider)?.base?.ifBlank { null } ?: "https://…/v1"
        modelField.hint = AiProviders.get(p.provider)?.model?.ifBlank { null } ?: "اسم الموديل"
        keyField.hint = if (p.needsKey()) "مفتاح API" else "مفتاح API (ماشي ضروري)"
        customBox.visibility = if (p.provider == "custom") View.VISIBLE else View.GONE
        cName.setText(p.customName)
        format = p.customFormat
        cFormat.text = "الصيغة: $format  ▾"
        cHeader.setText(p.customAuthHeader)
        cPrefix.setText(p.customAuthPrefix)
        cHeaders.setText(p.customHeaders)
        cPath.setText(p.customChatPath)
    }

    fun commit() {
        p.apiKey = keyField.text.toString().trim()
        p.model = modelField.text.toString().trim()
        p.baseUrl = baseField.text.toString().trim()
        if (p.provider == "custom") {
            p.customName = cName.text.toString().trim()
            p.customFormat = format
            p.customAuthHeader = cHeader.text.toString().trim()
            p.customAuthPrefix = cPrefix.text.toString()
            p.customHeaders = cHeaders.text.toString()
            p.customChatPath = cPath.text.toString().trim()
        }
    }

    providerBtn.setOnClickListener {
        val labels = AiProviders.ALL.map { it.label }
        ctx.chooser("المزوّد", labels, AiProviders.get(p.provider)?.label.orEmpty()) { picked ->
            val id = AiProviders.ALL.firstOrNull { it.label == picked }?.id ?: return@chooser
            commit()
            p.provider = id
            fill()
        }
    }
    cFormat.setOnClickListener {
        ctx.chooser("الصيغة", listOf("openai", "anthropic", "gemini"), format) { format = it; cFormat.text = "الصيغة: $it  ▾" }
    }

    s.add(section("الذكاء الاصطناعي"))
    s.add(providerBtn, 8)
    s.add(keyField, 8)
    s.add(hint("المفتاح كيبقى فهاد الهاتف فقط، وكيتبعث لمزوّد الذكاء اللي اخترتي وحدو."), 4)

    val modelRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
    modelRow.addView(modelField, lp(0, WRAP, 1f))
    modelRow.addView(ctx.button("جلب", TONAL) {
        commit()
        status.setTextColor(C.DIM)
        status.text = "كنجيب الموديلات…"
        bg({ AiClient.listModels(p) }) { list, err ->
            if (err != null || list == null) {
                status.setTextColor(C.RED)
                status.text = err?.message ?: "وقع مشكل"
            } else {
                status.text = "لقيت ${list.size} موديل"
                ctx.chooser("الموديل", list, modelField.text.toString().trim()) { modelField.setText(it) }
            }
        }
    }, lp(WRAP, WRAP).margins(8, 0, 0, 0, ctx))
    s.add(modelRow, 8)
    s.add(baseField, 8)

    customBox.addView(cName, lp().margins(0, 8, 0, 0, ctx))
    customBox.addView(cFormat, lp().margins(0, 8, 0, 0, ctx))
    customBox.addView(cHeader, lp().margins(0, 8, 0, 0, ctx))
    customBox.addView(cPrefix, lp().margins(0, 8, 0, 0, ctx))
    customBox.addView(cHeaders, lp().margins(0, 8, 0, 0, ctx))
    customBox.addView(cPath, lp().margins(0, 8, 0, 0, ctx))
    s.add(customBox)

    s.add(ctx.spacer(10))
    s.add(section("GitHub"), 8)
    s.add(tokenField, 8)
    s.add(hint("اختياري. من غير توكن: 60 طلب فالساعة للبحث والتحميل. مع توكن (حتى بلا صلاحيات): 5000. توكن بصلاحية «repo» غادي نستعملوه نشر المشاريع مستقبلا."), 4)

    s.add(status, 12)

    val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
    row.addView(ctx.button("اختبار الاتصال", TONAL) {
        commit()
        if (!p.ready()) { status.setTextColor(C.RED); status.text = "أدخل المفتاح الأول"; return@button }
        status.setTextColor(C.DIM)
        status.text = "كنجرّب…"
        bg({ AiClient.ping(p) }) { r, err ->
            if (err != null) { status.setTextColor(C.RED); status.text = err.message ?: "فشل" }
            else { status.setTextColor(C.GREEN); status.text = "✓ الاتصال خدام (${p.effectiveModel()}): " + r }
        }
    }, lp(0, WRAP, 1f).margins(0, 0, 6, 0, ctx))
    row.addView(ctx.button("حفظ", FILLED) {
        commit()
        app.appPrefs.githubToken = tokenField.text.toString().trim()
        s.dismiss()
        onSaved()
    }, lp(0, WRAP, 1f).margins(6, 0, 0, 0, ctx))
    s.add(row, 8)

    fill()
    s.show()
}
