package com.zellige.app.ui

import android.content.ContentValues
import android.content.Context
import android.os.Environment
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.zellige.app.ZelligeApp
import com.zellige.app.agent.ProjectInfo
import com.zellige.app.github.ZipUtil
import java.io.File

/** مشاريعي: كل المشاريع (اللي صاوبتها وكذلك اللي حمّلتي من GitHub). */
class ProjectsPage(private val ctx: Context, private val app: ZelligeApp, private val host: Host) : Page {

    private val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
    override val view: View = col
    private val list = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }

    init {
        col.layoutDirection = View.LAYOUT_DIRECTION_RTL
        col.setPadding(ctx.dp(14), ctx.dp(10), ctx.dp(14), 0)

        val head = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(ctx.label("مشاريعي", 20f, C.TEXT, bold = true), lp(0, WRAP, 1f))
        head.addView(ctx.button("+ مشروع جديد", OUTLINE) {
            ctx.askText("مشروع جديد", "اسم المشروع", "", "إنشاء") { name ->
                host.openProject(app.workspace.create(name))
            }
        })
        col.addView(head, lp().margins(0, 0, 0, 10, ctx))

        val scroll = ScrollView(ctx)
        scroll.addView(list, android.widget.FrameLayout.LayoutParams(MATCH, WRAP))
        col.addView(scroll, lp(MATCH, 0, 1f))
    }

    override fun onShow() { render() }

    fun render() {
        list.removeAllViews()
        val projects = app.workspace.projects()
        if (projects.isEmpty()) {
            list.addView(ctx.label(
                "ما عندك حتى مشروع بعد.\nكتب فكرة فالشات، أو حمّل مشروع من «اكتشف».",
                14f, C.DIM
            ).apply { gravity = Gravity.CENTER }, lp().margins(0, 50, 0, 0, ctx))
            return
        }
        val active = app.agent.root()?.canonicalPath
        projects.forEach { list.addView(card(it, it.canonicalPath == active), lp().margins(0, 5, 0, 5, ctx)) }
        list.addView(ctx.spacer(16))
    }

    private fun card(dir: File, isActive: Boolean): View {
        val repo = ProjectInfo.repo(dir)
        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = ctx.ripple(C.SURFACE, 16, if (isActive) C.AMBER else C.LINE)
            setPadding(ctx.dp(14), ctx.dp(12), ctx.dp(6), ctx.dp(12))
            isClickable = true
            setOnClickListener { host.openProject(dir) }
            setOnLongClickListener { actions(dir); true }
        }
        val info = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        info.addView(ctx.label(dir.name, 15f, C.TEXT, bold = true).also { it.ellipsize1() }, lp())
        val sub = (if (repo != null) "GitHub · $repo" else "مشروع جديد") + "  ·  " + relTime(app.workspace.lastActivity(dir))
        info.addView(ctx.label(sub, 12f, C.DIM).apply {
            textDirection = View.TEXT_DIRECTION_LTR
            textAlignment = View.TEXT_ALIGNMENT_VIEW_START
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }, lp().margins(0, 3, 0, 0, ctx))
        row.addView(info, lp(0, WRAP, 1f))
        if (isActive) {
            row.addView(ctx.label("مفتوح", 11f, C.AMBER, bold = true).apply {
                background = ctx.rounded(C.AMBER_SOFT, 8)
                setPadding(ctx.dp(8), ctx.dp(2), ctx.dp(8), ctx.dp(2))
            }, LinearLayout.LayoutParams(WRAP, WRAP).also { it.marginEnd = ctx.dp(4) })
        }
        row.addView(ctx.label("⋮", 22f, C.DIM).apply {
            gravity = Gravity.CENTER
            setPadding(ctx.dp(12), ctx.dp(4), ctx.dp(12), ctx.dp(4))
            isClickable = true
            setOnClickListener { actions(dir) }
        })
        return row
    }

    // ------------------------------------------------------------------ actions
    private fun isBusyOn(dir: File): Boolean = app.agent.busy() && app.agent.root()?.canonicalPath == dir.canonicalPath

    private fun actions(dir: File) {
        val s = Sheet(ctx, dir.name)
        fun item(label: String, color: Int = C.TEXT, f: () -> Unit) {
            s.add(TextView(ctx).apply {
                text = label
                setTextColor(color)
                textSize = 15f
                setPadding(ctx.dp(8), ctx.dp(14), ctx.dp(8), ctx.dp(14))
                background = ctx.ripple(C.SURFACE, 10)
                isClickable = true
                setOnClickListener { s.dismiss(); f() }
            })
        }
        item("فتح") { host.openProject(dir) }
        item("إعادة تسمية") { rename(dir) }
        item("تصدير كملف ZIP (فمجلد Downloads)") { export(dir) }
        item("مسح المحادثة (الملفات كتبقى)") { clearChat(dir) }
        item("حذف المشروع", C.RED) { delete(dir) }
        s.show()
    }

    private fun rename(dir: File) {
        if (isBusyOn(dir)) { ctx.toast("الوكيل كيخدم على هاد المشروع. وقفو أولا."); return }
        ctx.askText("إعادة تسمية", "الاسم الجديد", dir.name, "حفظ") { name ->
            val clean = app.workspace.sanitize(name)
            if (clean.isEmpty() || clean == dir.name) return@askText
            val target = File(app.workspace.dir, app.workspace.uniqueName(clean))
            if (!dir.renameTo(target)) { ctx.toast("تعذّر تغيير الاسم"); return@askText }
            if (app.agent.root()?.canonicalPath == dir.canonicalPath || app.appPrefs.activeProject == dir.name) {
                if (app.agent.open(target)) app.appPrefs.activeProject = target.name
            }
            render()
            host.refreshHeader()
        }
    }

    private fun clearChat(dir: File) {
        if (isBusyOn(dir)) { ctx.toast("الوكيل كيخدم على هاد المشروع. وقفو أولا."); return }
        ctx.confirm("مسح المحادثة", "غادي تتمسح المحادثة فقط. الملفات والمشروع كيبقاو.", "مسح") {
            if (app.agent.root()?.canonicalPath == dir.canonicalPath) app.agent.reset()
            else try { ProjectInfo.chatFile(dir).delete() } catch (t: Throwable) { /* ما يهمش */ }
            render()
        }
    }

    private fun delete(dir: File) {
        if (isBusyOn(dir)) { ctx.toast("الوكيل كيخدم على هاد المشروع. وقفو أولا."); return }
        ctx.confirm("حذف المشروع", "غادي يتحذف «${dir.name}» وكل ملفاتو نهائيا.", "حذف", danger = true) {
            val wasActive = app.agent.root()?.canonicalPath == dir.canonicalPath
            if (app.workspace.delete(dir)) {
                if (wasActive) { app.agent.open(null); app.appPrefs.activeProject = "" }
                render()
                host.refreshHeader()
            } else ctx.toast("تعذّر الحذف")
        }
    }

    private fun export(dir: File) {
        ctx.toast("كنصاوب ZIP…")
        bg({
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, dir.name + ".zip")
                put(MediaStore.Downloads.MIME_TYPE, "application/zip")
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val resolver = ctx.contentResolver
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("تعذّر إنشاء الملف فـ Downloads")
            val out = resolver.openOutputStream(uri) ?: throw IllegalStateException("تعذّر فتح الملف")
            val n = out.use { ZipUtil.zipDir(dir, it) }
            val done = ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }
            resolver.update(uri, done, null, null)
            n
        }) { n, err ->
            if (err != null) ctx.toast("تعذّر التصدير: " + (err.message ?: ""))
            else ctx.toast("تصدّر $n ملف: Downloads/${dir.name}.zip")
        }
    }
}
