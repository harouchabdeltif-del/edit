package com.zellige.app.ai

import android.content.Context

/**
 * إعدادات الذكاء الاصطناعي. المفتاح والموديل والعنوان كيتخزنوا لكل مزوّد على حدة،
 * وبالتالي تبديل المزوّد ما كيضيّع حتى مفتاح.
 */
class AiPrefs(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("zellige_ai", Context.MODE_PRIVATE)

    private fun str(k: String): String = sp.getString(k, "") ?: ""
    private fun put(k: String, v: String) { sp.edit().putString(k, v).apply() }

    var provider: String
        get() = sp.getString("provider", "deepseek") ?: "deepseek"
        set(v) { put("provider", v) }

    fun keyFor(id: String): String = str("key_$id")
    fun setKeyFor(id: String, v: String) = put("key_$id", v)
    fun modelFor(id: String): String = str("model_$id")
    fun setModelFor(id: String, v: String) = put("model_$id", v)
    fun baseFor(id: String): String = str("base_$id")
    fun setBaseFor(id: String, v: String) = put("base_$id", v)

    var model: String
        get() = modelFor(provider)
        set(v) { setModelFor(provider, v) }

    var apiKey: String
        get() = keyFor(provider)
        set(v) { setKeyFor(provider, v) }

    var baseUrl: String
        get() = baseFor(provider)
        set(v) { setBaseFor(provider, v) }

    // ---- مزوّد مخصص (custom): أي خدمة متوافقة
    var customName: String
        get() = str("custom_name")
        set(v) { put("custom_name", v) }

    /** openai | anthropic | gemini */
    var customFormat: String
        get() = str("custom_format").ifBlank { "openai" }
        set(v) { put("custom_format", v) }

    var customAuthHeader: String
        get() = str("custom_auth_header")
        set(v) { put("custom_auth_header", v) }

    var customAuthPrefix: String
        get() = str("custom_auth_prefix")
        set(v) { put("custom_auth_prefix", v) }

    /** headers إضافية: سطر لكل header بالشكل  Name: value */
    var customHeaders: String
        get() = str("custom_headers")
        set(v) { put("custom_headers", v) }

    var customChatPath: String
        get() = str("custom_chat_path")
        set(v) { put("custom_chat_path", v) }

    fun needsKey(): Boolean = AiProviders.get(provider)?.needsKey ?: true

    fun ready(): Boolean = apiKey.isNotBlank() || !needsKey()

    fun effectiveModel(): String = model.ifBlank { AiProviders.get(provider)?.model.orEmpty() }

    fun providerLabel(): String =
        if (provider == "custom") customName.ifBlank { "Custom" }
        else AiProviders.get(provider)?.label?.substringBefore(" (")?.substringBefore(" —") ?: provider
}
