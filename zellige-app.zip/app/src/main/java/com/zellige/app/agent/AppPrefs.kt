package com.zellige.app.agent

import android.content.Context

/** إعدادات التطبيق (غير الذكاء): المشروع النشط وتوكن GitHub الاختياري. */
class AppPrefs(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("zellige_app", Context.MODE_PRIVATE)

    var activeProject: String
        get() = sp.getString("active_project", "") ?: ""
        set(v) { sp.edit().putString("active_project", v).apply() }

    /** اختياري: كيرفع حدّ الطلبات على GitHub (60 ← 5000 فالساعة) وكيفتح بحثا أسرع. للقراءة فقط يكفي توكن بلا صلاحيات. */
    var githubToken: String
        get() = sp.getString("github_token", "") ?: ""
        set(v) { sp.edit().putString("github_token", v.trim()).apply() }
}
