package com.zellige.app.agent

import com.zellige.app.ai.AiClient
import com.zellige.app.github.GitHubApi
import java.io.File
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.concurrent.CopyOnWriteArrayList

/**
 * الوكيل: كيستقبل طلب المستعمل، كيدور فحلقة (نموذج ← أدوات ← نموذج) حتى يكمل،
 * وكيبعث أحداثا للواجهة (بلا كود أبدا): خطوة بخطوة، المسارات فقط، وجملة قصيرة فالأخير.
 *
 * كيعيش فـ Application باش ما يتوقفش مع تدوير الشاشة. الأحداث كتجي من خيط خلفي (الواجهة هي اللي ترجعها للخيط الرئيسي).
 */
class Agent(
    /** (system, رسائل) ← رد النموذج. فالتطبيق هو AiClient؛ فالاختبارات نموذج مزيّف. */
    private val model: (String, List<AiClient.Msg>) -> String,
    private val gh: GitHubApi?
) {

    sealed class Event {
        data class Step(val label: String, val path: String, val kind: String) : Event()
        data class Done(val ok: Boolean, val label: String, val path: String, val detail: String, val kind: String) : Event()
        data class Note(val text: String) : Event()
        /** changes: مسار ← نوع (new | edit | delete | dir | move) */
        data class Finish(val error: String?, val stopped: Boolean, val changes: List<Pair<String, String>>, val summary: String) : Event()
    }

    /** سطر فالمحادثة: كلام المستعمل أو الجملة الأخيرة ديال الوكيل (مع المسارات اللي لمسها). */
    data class Turn(val fromUser: Boolean, val text: String, val paths: List<String> = emptyList())

    @Volatile var listener: ((Event) -> Unit)? = null

    private val msgs = ArrayList<AiClient.Msg>()
    private val undos = ArrayList<Tools.Undo>()
    private val runEvents = CopyOnWriteArrayList<Event>()

    @Volatile private var root: File? = null
    @Volatile private var busy = false
    @Volatile private var cancelled = false
    @Volatile private var undoNote = ""
    private var worker: Thread? = null

    fun root(): File? = root
    fun busy(): Boolean = busy

    /** أحداث الجولة الحالية/الأخيرة (باش شاشة جديدة تعاود ترسم النافذة الصغيرة). */
    fun liveEvents(): List<Event> = runEvents.toList()

    /** يفتح مشروعا ويحمّل محادثتو. يرفض إلا كان الوكيل مشغول. */
    fun open(project: File?): Boolean {
        if (busy) return false
        root = project
        synchronized(msgs) {
            msgs.clear()
            if (project != null) msgs.addAll(ProjectInfo.loadChat(project))
        }
        undos.clear()
        runEvents.clear()
        undoNote = ""
        return true
    }

    fun history(): List<Turn> {
        val snap = synchronized(msgs) { msgs.toList() }
        val out = ArrayList<Turn>()
        var paths = LinkedHashSet<String>()
        for ((i, m) in snap.withIndex()) {
            if (m.role == "user") {
                if (Tools.isResults(m)) continue
                paths = LinkedHashSet()
                out.add(Turn(true, m.content))
            } else {
                val calls = Tools.parse(m.content)
                calls.filter { it.name in Tools.MUTATING }.forEach { paths.add(shownPath(it)) }
                if (calls.isNotEmpty()) continue
                val next = snap.getOrNull(i + 1)
                if (next != null && Tools.isResults(next) && next.content.contains(CODE_FIX_MARK)) continue
                val t = Tools.clean(m.content)
                if (t.isNotBlank() && !t.startsWith("(")) out.add(Turn(false, t, paths.toList()))
            }
        }
        return out
    }

    // ------------------------------------------------------------------ run control
    fun send(prompt: String): Boolean {
        val r = root ?: return false
        val text = prompt.trim()
        if (text.isEmpty() || busy) return false
        busy = true
        cancelled = false
        runEvents.clear()
        val undo = Tools.Undo()
        val base: Int
        synchronized(msgs) {
            for (i in msgs.indices) msgs[i] = Tools.compact(msgs[i])
            base = msgs.size
            msgs.add(AiClient.Msg("user", text))
        }
        val note = undoNote
        undoNote = ""
        worker = Thread({ run(r, base, undo, note) }, "zellige-agent").also { it.isDaemon = true; it.start() }
        return true
    }

    fun stop() { cancelled = true }

    fun canUndo(): Boolean = undos.isNotEmpty() && !busy

    /** يتراجع عن آخر جولة (الملفات فقط). يرجع عدد الملفات اللي تبدلات. */
    fun undoLast(): Int {
        if (busy || undos.isEmpty()) return 0
        val u = undos.removeAt(undos.lastIndex)
        val n = u.restore()
        undoNote = "The user pressed Undo: the files changed in your previous round were restored to how they were before it (" +
            u.changes.keys.take(12).joinToString(", ") + "). Don't assume your last edits exist any more; re-read before editing."
        runEvents.clear()
        return n
    }

    /** يمسح محادثة المشروع (الملفات كتبقى). */
    fun reset() {
        if (busy) return
        val r = root ?: return
        synchronized(msgs) { msgs.clear() }
        undos.clear()
        runEvents.clear()
        try { ProjectInfo.chatFile(r).delete() } catch (t: Throwable) { /* ما يهمش */ }
    }

    // ------------------------------------------------------------------ the loop
    private fun emit(e: Event) {
        runEvents.add(e)
        try { listener?.invoke(e) } catch (t: Throwable) { /* واجهة ميتة ما توقفش الوكيل */ }
    }

    private fun add(m: AiClient.Msg) { synchronized(msgs) { msgs.add(m) } }

    private fun run(r: File, base: Int, undo: Tools.Undo, undoInfo: String) {
        var error: String? = null
        var stopped = false
        var summary = ""
        try {
            val box = Tools.Box(Sandbox(r), undo, gh, ProjectInfo.repo(r))
            val system = buildSystem(r, undoInfo)
            var used = 0
            var strikes = 0
            var blanks = 0
            var cuts = 0
            while (true) {
                if (cancelled) { stopped = true; break }
                val view = synchronized(msgs) { fit(msgs.toList()) }
                val reply = model(system, view)
                if (cancelled) { stopped = true; break }

                if (reply.isBlank()) {
                    if (++blanks > 2) throw IllegalStateException("النموذج رجّع جوابا فارغا")
                    continue
                }
                val all = Tools.parse(reply)
                val calls = all.take(MAX_PER_REPLY)
                val say = Tools.clean(reply)
                // وسم مقطوع (حدّ طول الرد): ما كيتنفّذش، كنخبرو النموذج باش يعاود بدفعات أصغر
                val cutOff = Tools.countTags(reply) > all.size

                if (calls.isEmpty()) {
                    if (cutOff && cuts < 4) {
                        cuts++
                        add(AiClient.Msg("assistant", reply))
                        add(AiClient.Msg("user", Tools.formatResults(listOf(CUT_RESULT))))
                        continue
                    }
                    if (Tools.hasCodeDump(reply) && strikes < 2) {
                        strikes++
                        add(AiClient.Msg("assistant", reply))
                        add(AiClient.Msg("user", CODE_FIX))
                        continue
                    }
                    add(AiClient.Msg("assistant", reply))
                    summary = say
                    break
                }

                if (say.isNotBlank()) emit(Event.Note(say))
                val results = ArrayList<Tools.StepResult>()
                for (c in calls) {
                    if (cancelled) break
                    used++
                    val kind = Tools.kindOf(c.name)
                    val shown = shownPath(c)
                    val label = Tools.describe(c)
                    emit(Event.Step(label, shown, kind))
                    val res = box.execute(c)
                    results.add(res)
                    emit(Event.Done(res.ok, label, shown, firstLine(res.text), kind))
                }
                for (c in calls.drop(results.size)) results.add(Tools.StepResult(c, false, "skipped: the user stopped the run"))
                if (cutOff && !cancelled) results.add(CUT_RESULT)
                add(AiClient.Msg("assistant", reply))
                add(AiClient.Msg("user", Tools.formatResults(fitResults(results))))
                persist(r)

                if (cancelled) { stopped = true; break }
                if (used >= MAX_CALLS) {
                    summary = "وصلت للحد الأقصى من الخطوات فهاد الجولة. قل لي «كمّل» باش نواصل من فين وقفت."
                    add(AiClient.Msg("assistant", "(حدّ الخطوات)"))
                    break
                }
            }
        } catch (t: Throwable) {
            error = errorText(t)
        }

        synchronized(msgs) {
            if (error != null || stopped) {
                if (msgs.size == base + 1) msgs.removeAt(base)             // الطلب ما تنفّذش أصلا
                else if (msgs.lastOrNull()?.role == "user")
                    msgs.add(AiClient.Msg("assistant", if (stopped) "(أوقفه المستعمل)" else "(توقّف العمل بسبب خطأ)"))
            }
        }
        persist(r)
        if (!undo.isEmpty()) {
            undos.add(undo)
            while (undos.size > MAX_UNDO) undos.removeAt(0)
        }
        val changes = undo.changes.entries.map { it.key to it.value }
        busy = false
        emit(Event.Finish(error, stopped, changes, summary))
    }

    private fun persist(r: File) {
        val tail = synchronized(msgs) { msgs.takeLast(MAX_SAVED).map { Tools.compact(it) } }
        val start = tail.indexOfFirst { it.role == "user" && !Tools.isResults(it) }
        if (start < 0) return
        ProjectInfo.saveChat(r, tail.drop(start))
    }

    private fun shownPath(c: Tools.Call): String =
        if (c.name == "move") c.path + " ← " + c.attrs["to"].orEmpty() else c.path

    private fun firstLine(s: String): String = s.lineSequence().firstOrNull { it.isNotBlank() }.orEmpty().take(160)

    private fun errorText(t: Throwable): String = when {
        t is AiClient.ApiException && (t.code == 401 || t.code == 403) -> "المفتاح غير صالح أو ما عندوش صلاحية (${t.code}). تأكد منو فالإعدادات."
        t is AiClient.ApiException && t.code == 402 -> "رصيد المزوّد سالى (402). عمّر الحساب أو بدّل المزوّد."
        t is AiClient.ApiException && t.code == 429 -> "تجاوزت حدّ الطلبات عند المزوّد (429). عاود بعد شوية."
        t is AiClient.ApiException -> "خطأ من المزوّد (${t.code}): ${t.message}".take(400)
        t is UnknownHostException -> "ما كاين اتصال بالإنترنت."
        t is SocketTimeoutException -> "انتهت المهلة، المزوّد ما جاوبش. عاود."
        else -> (t.message ?: t.javaClass.simpleName).take(400)
    }

    // ------------------------------------------------------------------ context budget
    /** نسخة مصغّرة من المحادثة تدخل فحدود السياق: كنحيّدو أقدم الجولات ثم كنقصّو القديم. */
    private fun fit(all: List<AiClient.Msg>): List<AiClient.Msg> {
        var view = all
        fun size(l: List<AiClient.Msg>) = l.sumOf { it.content.length }
        while (size(view) > MAX_CONTEXT) {
            val next = (1 until view.size).firstOrNull { view[it].role == "user" && !Tools.isResults(view[it]) } ?: break
            view = view.subList(next, view.size)
        }
        if (size(view) > MAX_CONTEXT) {
            val keep = 6
            view = view.mapIndexed { i, m ->
                if (i < view.size - keep && m.content.length > 1500) AiClient.Msg(m.role, m.content.take(1500) + "\n[…]") else m
            }
        }
        return view
    }

    /** نتائج الأدوات فرد واحد ما تفوتش ميزانية: كل نتيجة كتتقصّ بحال ما كثرو. */
    private fun fitResults(rs: List<Tools.StepResult>): List<Tools.StepResult> {
        if (rs.sumOf { it.text.length } <= RESULT_BUDGET) return rs
        val each = maxOf(1500, RESULT_BUDGET / rs.size)
        return rs.map { if (it.text.length > each) it.copy(text = it.text.take(each) + "\n…[تم الاقتطاع]") else it }
    }

    // ------------------------------------------------------------------ system prompt
    private fun buildSystem(root: File, undoInfo: String): String {
        val tree = Tools.treeText(root, 3, 120)
        val readme = listOf("README.md", "readme.md", "README", "README.txt").map { File(root, it) }
            .firstOrNull { it.isFile }?.let { Tools.readText(it) }?.take(2500).orEmpty()
        val notes = ProjectInfo.notes(root).trim()
        val repo = ProjectInfo.repo(root)
        val stack = detectStack(root)
        return buildString {
            append(PROMPT_CORE)
            append("\n\n=== CURRENT PROJECT ===\n")
            append("Name: ").append(root.name).append('\n')
            if (repo != null) append("Source: GitHub repository ").append(repo)
                .append(" (public). github_issues / github_issue tools are available.\n")
            if (stack.isNotEmpty()) append("Detected stack: ").append(stack).append('\n')
            if (tree.isBlank()) append("The project folder is EMPTY: this is a new project. Build it from scratch.\n")
            else append("Top of the file tree:\n").append(tree).append('\n')
            if (readme.isNotBlank()) append("\nREADME (start):\n").append(readme).append('\n')
            if (notes.isNotBlank()) append("\nYour saved notes about this project:\n").append(notes).append('\n')
            if (undoInfo.isNotBlank()) append("\nNOTE: ").append(undoInfo).append('\n')
        }
    }

    private fun detectStack(root: File): String {
        val found = ArrayList<String>()
        fun has(vararg p: String) = p.any { File(root, it).exists() }
        if (has("settings.gradle.kts", "settings.gradle", "build.gradle.kts", "build.gradle")) {
            var android = has("app/src/main/AndroidManifest.xml")
            if (!android) {
                var seen = 0
                Tools.walkFiles(root) { f -> if (f.name == "AndroidManifest.xml") android = true; ++seen < 4000 && !android }
            }
            found.add(if (android) "Android (Gradle)" else "Gradle / JVM")
        }
        if (has("pubspec.yaml")) found.add("Flutter / Dart")
        if (has("package.json")) found.add("Node / JavaScript (package.json)")
        if (has("pyproject.toml", "requirements.txt", "setup.py")) found.add("Python")
        if (has("Cargo.toml")) found.add("Rust (Cargo)")
        if (has("go.mod")) found.add("Go")
        if (has("pom.xml")) found.add("Java (Maven)")
        if (has("Package.swift")) found.add("Swift package")
        if (found.isEmpty() && has("index.html")) found.add("Static web (HTML/CSS/JS)")
        return found.joinToString(", ")
    }

    companion object {
        const val MAX_CALLS = 90          // خطوات الأدوات فالجولة الواحدة
        const val MAX_PER_REPLY = 16      // أدوات فرد واحد
        const val MAX_UNDO = 10
        const val MAX_SAVED = 40
        const val MAX_CONTEXT = 150_000   // حروف
        const val RESULT_BUDGET = 60_000

        private val CUT_RESULT = Tools.StepResult(
            Tools.Call("cut-off", emptyMap(), ""), false,
            "Your last tool tag was CUT OFF (reply length limit) and was NOT executed. Send it again on its own, " +
                "and keep each reply smaller: at most 2-3 files per reply."
        )

        private const val CODE_FIX_MARK = "You wrote code in the chat"
        private const val CODE_FIX =
            "<tool_results>\n<result ok=\"false\" label=\"rule\">$CODE_FIX_MARK. The user must NEVER see code in the chat. " +
                "Apply it now with write_file / edit_file tool tags (the file content goes inside the tag), " +
                "then finish with 1-3 plain sentences that contain no code.</result>\n</tool_results>"

        private val PROMPT_CORE = """
You are Zellige's builder agent. You live inside an Android app. The user (usually on a phone, often with no computer) tells you in plain words what they want, and you create or change a REAL project made of files, working directly on its files with the tools below.

ABSOLUTE RULES
1. NEVER write code in your chat replies: no code blocks, no snippets, no diffs, not even one line of code. All code and all file content go ONLY inside tool tags (write_file / edit_file). The user does not read code in the chat; the app shows separately which files you touched.
2. Your final reply (the one without tool tags) is 1-3 short, plain sentences in the language the user writes in (Arabic / Darija stays Arabic). Say in words what you did and name the files by relative path, for example: "أنشأت شاشة تسجيل الدخول في app/src/main/java/com/example/LoginActivity.kt وربطتها بالـ manifest." No headings, no lists of code, no tables. If something is unfinished or uncertain, say so honestly in one sentence.
3. Work autonomously until the task is really done. Don't ask permission for obvious things and don't stop to present a plan first. Ask ONE short question (with no tools in that reply) only if the request is truly ambiguous and a wrong guess would waste a lot of work.
4. You cannot run, compile or test anything. So be careful: read before you edit, double-check imports, names, ids and paths, and after writing key files search or read them back to verify references. Never claim that something was built or tested.
5. Everything is inside the project folder. All paths are relative to its root. Never mention or touch anything outside it.

TOOLS - plain-text tags written inside your reply. You may write several per reply (they run in order, max 16); their results come back in the next message. Do not use any native function-calling.
<tool name="tree" path="." depth="3"/>                       directory tree (depth 1-6)
<tool name="list_dir" path="app/src"/>                        one directory with file sizes
<tool name="outline" path="app/src" glob="*.kt"/>             declarations (classes / functions) per file: the fastest way to understand a big codebase
<tool name="read_file" path="a/B.kt" start="1" end="120" numbered="true"/>   start/end/numbered are optional
<tool name="search" path="." query="LoginActivity" regex="false" glob="*.kt" context="2"/>   text search (regex / glob / context optional)
<tool name="find_files" path="." pattern="*Activity.kt"/>     find files by name or glob
<tool name="write_file" path="a/B.kt">
the complete file content exactly as it should be stored, with no markdown fences
</tool>
<tool name="edit_file" path="a/B.kt">
<find>exact existing text; it must appear exactly once in the file</find>
<replace>the new text</replace>
</tool>                                                        (several find/replace pairs are applied in order)
<tool name="create_dir" path="a/new"/>
<tool name="move" path="a/Old.kt" to="a/New.kt"/>
<tool name="delete" path="a/Old.kt"/>                        (files or folders; only when needed or asked)
<tool name="remember">short durable fact about this project (decision, how to build, convention)</tool>
<tool name="github_issues" limit="15"/>                       open issues of the source repo (projects from GitHub only)
<tool name="github_issue" number="12"/>                       one issue with its first comments

HOW TO WORK
- New project: pick a sensible structure, then write ALL the files needed for a complete, coherent, working project in as few rounds as possible. Keep each reply moderately sized (about 3-4 files): your reply length is limited, and a tag that gets cut off is NOT executed. Add a short README.md. Prefer simple, dependency-light solutions.
- Existing project (from GitHub or created earlier): first explore with tree / outline / search / read_file, locate the relevant code, then make focused, minimal edits that follow the existing style and conventions. Do not rewrite or reformat files you don't need to change. Do not delete things unless asked.
- Big files: read slices (start/end), use search with context, and change them with edit_file. Never rewrite a big file just to change a few lines. If edit_file says the text was not found or is not unique, read the file again and copy the text exactly, with more context.
- If the user asks you to fix or implement a GitHub issue by number, read it with github_issue first, find the code, fix it, and then say in plain words what you changed.
- When the user asks to understand or explain something, answer in plain words (still no code blocks) after reading what you need.
- Use remember sparingly for facts that will matter in later sessions (how the project is built, naming rules, decisions the user made).

ANDROID PROJECTS (the most common request, e.g. "make a login app", "expense tracker")
Create a complete standalone Gradle project that builds in GitHub Actions (there is no Gradle wrapper because a binary jar cannot be written, so the workflow installs Gradle itself):
- settings.gradle.kts (rootProject.name, include(":app"), pluginManagement/dependencyResolutionManagement with google() and mavenCentral()), root build.gradle.kts (plugins: com.android.application 8.5.2 apply false, org.jetbrains.kotlin.android 1.9.24 apply false), gradle.properties (android.useAndroidX=true, org.gradle.jvmargs=-Xmx2g).
- app/build.gradle.kts: namespace + applicationId (choose a clean id like com.example.<appname>), compileSdk 34, minSdk 24, targetSdk 34, Java/Kotlin JVM target 17, viewBinding or plain findViewById, dependencies androidx.core:core-ktx:1.13.1, androidx.appcompat:appcompat:1.7.0, com.google.android.material:material:1.12.0, androidx.constraintlayout:constraintlayout:2.1.4. Use Views + XML by default. Only use Compose if the user asks (then kotlinCompilerExtensionVersion 1.5.14 and compose-bom 2024.06.00). For storage prefer SharedPreferences or SQLiteOpenHelper (no kapt / KSP unless asked).
- app/src/main/AndroidManifest.xml (supportsRtl true, launcher activity exported, icon from a vector drawable you create), the Activities, layouts, res/values/strings.xml and themes.xml (Theme.Material3.DayNight.NoActionBar or Theme.MaterialComponents.DayNight.NoActionBar), colors, and a simple vector launcher icon in res/drawable.
- .github/workflows/build.yml: on push and workflow_dispatch; steps: actions/checkout@v4, actions/setup-java@v4 (distribution temurin, java-version 17), gradle/actions/setup-gradle@v4 with gradle-version 8.7, then run "gradle :app:assembleDebug --no-daemon", then actions/upload-artifact@v4 named apk with path app/build/outputs/apk/debug/*.apk. Don't reference secrets.
- Make real, working screens and logic (validation, navigation, persistence), not placeholders. Use Arabic UI text when the user writes Arabic.
Other kinds of project (web page, Python script, Node tool, Flutter, ...): choose the simplest structure that fully does the job.
""".trimIndent()
    }
}
