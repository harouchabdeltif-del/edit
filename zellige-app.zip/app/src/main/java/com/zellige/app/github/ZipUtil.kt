package com.zellige.app.github

import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/** فك وضغط zip بشكل آمن (zip-slip، حدود الحجم وعدد الملفات). */
object ZipUtil {

    const val DEFAULT_MAX_BYTES = 200L * 1024 * 1024
    const val DEFAULT_MAX_FILES = 30_000

    /**
     * يفك الـ zip فـ dest. إلا stripFirst = true كيتحيّد المجلد الأول من كل مسار (zip ديال GitHub فيه owner-repo-sha/).
     * يرجع عدد الملفات.
     */
    fun extract(
        input: InputStream,
        dest: File,
        stripFirst: Boolean,
        maxBytes: Long,
        maxFiles: Int,
        onProgress: (Int, Long) -> Unit = { _, _ -> }
    ): Int {
        dest.mkdirs()
        val root = dest.canonicalFile
        var files = 0
        var bytes = 0L
        val buf = ByteArray(64 * 1024)
        ZipInputStream(input).use { zin ->
            var e: ZipEntry? = zin.nextEntry
            while (e != null) {
                var name = e.name.replace('\\', '/')
                if (stripFirst) name = name.substringAfter('/', "")
                if (name.isNotEmpty()) {
                    val target = File(root, name).canonicalFile
                    if (target != root && !target.path.startsWith(root.path + File.separator)) {
                        throw SecurityException("مسار مشبوه داخل الـ zip: ${e.name}")
                    }
                    if (e.isDirectory) {
                        target.mkdirs()
                    } else {
                        if (++files > maxFiles) throw IllegalStateException("المشروع فيه ملفات كثيرة بزاف (> $maxFiles)")
                        target.parentFile?.mkdirs()
                        target.outputStream().use { out ->
                            while (true) {
                                val n = zin.read(buf)
                                if (n < 0) break
                                bytes += n
                                if (bytes > maxBytes) throw IllegalStateException("المشروع كبير بزاف (> ${maxBytes / 1024 / 1024} MB)")
                                out.write(buf, 0, n)
                            }
                        }
                        if (files % 25 == 0) onProgress(files, bytes)
                    }
                }
                zin.closeEntry()
                e = zin.nextEntry
            }
        }
        onProgress(files, bytes)
        return files
    }

    /** يضغط مجلد مشروع فـ zip (بلا .zellige وبلا مجلدات البناء الثقيلة). يرجع عدد الملفات. */
    fun zipDir(src: File, out: OutputStream): Int {
        val root = src.canonicalFile
        var n = 0
        ZipOutputStream(out).use { zos ->
            fun walk(d: File) {
                val kids = d.listFiles()?.sortedBy { it.name } ?: return
                for (f in kids) {
                    if (f.name == ".zellige" && f.parentFile == root) continue
                    if (f.isDirectory && (f.name == "build" || f.name == ".gradle")) continue
                    if (f.isDirectory) {
                        walk(f)
                    } else {
                        val rel = f.path.removePrefix(root.path + File.separator).replace(File.separatorChar, '/')
                        zos.putNextEntry(ZipEntry(rel))
                        f.inputStream().use { it.copyTo(zos) }
                        zos.closeEntry()
                        n++
                    }
                }
            }
            walk(root)
        }
        return n
    }
}
