package com.zellige.app.ui

import android.app.Activity
import android.content.res.ColorStateList
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import com.zellige.app.R
import com.zellige.app.ZelligeApp
import java.io.File

/** الهيكل: رأس (المشروع النشط + الإعدادات) + 3 صفحات (الشات / اكتشف / مشاريعي) + شريط تنقل سفلي. */
class MainActivity : Activity(), Host {

    private lateinit var app: ZelligeApp
    private lateinit var chat: ChatPage
    private lateinit var discover: DiscoverPage
    private lateinit var projects: ProjectsPage
    private lateinit var pages: List<Page>

    private lateinit var content: FrameLayout
    private lateinit var projectChip: TextView
    private lateinit var spinner: ProgressBar
    private val navIcons = ArrayList<ImageView>()
    private val navLabels = ArrayList<TextView>()
    private var tab = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        app = application as ZelligeApp

        chat = ChatPage(this, app, this)
        discover = DiscoverPage(this, app, this)
        projects = ProjectsPage(this, app, this)
        pages = listOf(chat, discover, projects)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(C.BG)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            fitsSystemWindows = true
        }

        // ---- الرأس
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(6), dp(6), dp(6))
        }
        header.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_sparkle)
            setColorFilter(C.AMBER)
        }, LinearLayout.LayoutParams(dp(22), dp(22)))
        header.addView(label("زليج", 19f, C.TEXT, bold = true), lp(WRAP, WRAP).margins(8, 0, 10, 0, this))
        projectChip = label("", 13f, C.DIM, mono = false).apply {
            gravity = Gravity.CENTER
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
            background = rounded(C.SURFACE, 14, C.LINE)
            setPadding(dp(12), dp(6), dp(12), dp(6))
            isClickable = true
            setOnClickListener { showTab(2) }
        }
        header.addView(projectChip, lp(0, WRAP, 1f))
        spinner = ProgressBar(this, null, android.R.attr.progressBarStyleSmall).apply {
            indeterminateTintList = ColorStateList.valueOf(C.AMBER)
            visibility = View.GONE
        }
        header.addView(spinner, LinearLayout.LayoutParams(dp(18), dp(18)).also { it.marginStart = dp(10) })
        header.addView(icon(R.drawable.ic_tune, C.DIM, 22, 9) { openSettings() })
        root.addView(header, lp())
        root.addView(divider(), lp())

        // ---- المحتوى
        content = FrameLayout(this)
        root.addView(content, lp(MATCH, 0, 1f))

        // ---- الشريط السفلي
        root.addView(divider(), lp())
        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val items = listOf(
            Triple("الشات", R.drawable.ic_chat, 0),
            Triple("اكتشف", R.drawable.ic_compass, 1),
            Triple("مشاريعي", R.drawable.ic_folder, 2)
        )
        items.forEach { (name, ic, i) ->
            val cell = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(0, dp(8), 0, dp(8))
                background = ripple(C.BG, 0)
                isClickable = true
                setOnClickListener { showTab(i) }
            }
            val img = ImageView(this).apply { setImageResource(ic) }
            val txt = label(name, 11f, C.DIM)
            cell.addView(img, LinearLayout.LayoutParams(dp(24), dp(24)))
            cell.addView(txt, lp(WRAP, WRAP).margins(0, 3, 0, 0, this))
            navIcons.add(img)
            navLabels.add(txt)
            nav.addView(cell, lp(0, WRAP, 1f))
        }
        root.addView(nav, lp())

        setContentView(root)

        // المشروع النشط (إلا كان الوكيل فارغ بعد عملية قتل)
        if (app.agent.root() == null) {
            app.workspace.find(app.appPrefs.activeProject)?.let { app.agent.open(it) }
        }
        chat.attach()
        showTab(0)
        refreshHeader()
    }

    override fun onDestroy() {
        chat.detach()
        discover.destroy()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ Host
    override fun openProject(dir: File, thenSend: String?) {
        val a = app.agent
        val same = a.root()?.canonicalPath == dir.canonicalPath
        if (!same) {
            if (a.busy()) { toast("الوكيل مازال كيخدم على مشروع آخر. وقفو أولا."); return }
            a.open(dir)
        }
        app.appPrefs.activeProject = dir.name
        showTab(0)
        chat.reload()
        refreshHeader()
        if (thenSend != null) chat.sendPrompt(thenSend)
    }

    override fun openSettings() {
        showSettings(this, app) { refreshHeader(); chat.reload() }
    }

    override fun showTab(index: Int) {
        if (index == tab) { pages[index].onShow(); return }
        if (tab >= 0) {
            pages[tab].onHide()
            pages[tab].view.hideKeyboard()
        }
        tab = index
        content.removeAllViews()
        content.addView(pages[index].view, FrameLayout.LayoutParams(MATCH, MATCH))
        pages[index].onShow()
        for (i in navIcons.indices) {
            val c = if (i == index) C.AMBER else C.DIM
            navIcons[i].setColorFilter(c)
            navLabels[i].setTextColor(c)
        }
    }

    override fun refreshHeader() {
        val name = app.agent.root()?.name
        projectChip.text = name ?: "بلا مشروع — كتب فكرة"
        projectChip.setTextColor(if (name != null) C.TEXT else C.DIM)
        spinner.visibility = if (app.agent.busy()) View.VISIBLE else View.GONE
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (pages[tab].onBack()) return
        if (tab != 0) { showTab(0); return }
        @Suppress("DEPRECATION")
        super.onBackPressed()
    }
}
